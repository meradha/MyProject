import * as jquery from 'jquery';
window['jQuery'] = window['$'] = jquery;

