export class SalesInterface {
          _id?: string;
          salesNumber: string ;
          salesTax: string ;
          salesDiscount: string ;
          salesTotal: string ;
          salesCreatedBy: string ;
          salesTotalItem: string ;
          salesStatus: string ;
}