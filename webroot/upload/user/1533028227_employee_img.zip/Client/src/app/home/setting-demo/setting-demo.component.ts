import { Component, OnInit, Injectable } from '@angular/core';
import {CKEditorModule} from 'ng2-ckeditor';
import { Observable } from 'rxjs/Observable';
import {  HttpModule } from '@angular/http';
import {Router,ActivatedRoute,Params} from '@angular/router';
import { Http, Headers, Request, Response, RequestOptions } from '@angular/http';
import { HttpService} from './image.services';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import {SettingService} from './setting-services'
import { FileUploader } from 'ng2-file-upload';
import { SettingInterface} from './setting-interface';
import { StoreInterface} from '../stores/store-interface';
import {StoreService } from '../stores/store.services';

@Component({
  selector: 'app-setting-demo',
  templateUrl: './setting-demo.component.html',
  styleUrls: ['./setting-demo.component.css'],
  providers:[ HttpService, SettingService,StoreService]
})
export class SettingDemoComponent implements OnInit {

   // interface is deaclare for storage the value
    settingInterfaces :  SettingInterface[];
    settingInterface:  SettingInterface[];
    storeInterfaces:  StoreInterface[];
    storeInterface:  StoreInterface[];

    // variable deaclration
    id:any; country;
    State; Address;
    private sub: any;
    Email; storeID;
    companyName: string ;
    companyLogo:  string ;
    companyPhone:string ;
    companyCode: string ;
    companyDiscount: string ;
    Tax;ID;
    companyNumberDecimal: string ;
    companyImagename: string;
    companyHeaderParagraph: string ;
    companyFooterParagraph: string ;
    compnayStripeSecretkey: string ;
    compnayStripePublishedKey: string ;
    CGST: string ;storeName;
    storeEmail;storePhone;
    storecountry;storeCity;storestate;storeAddress;storeReceipt;
    SGST: string ;
    IGST: string ;

  ngOnInit() {
     // get request call
     this.settingService.getSettingrRequest()
          .subscribe( settingInterfaces => {
            this.settingInterfaces = settingInterfaces.Setting[0]
            console.log( 'this.settingInterfaces',  this.settingInterfaces);
            this.id = settingInterfaces.Setting[0]._id;
            this.companyName = settingInterfaces.Setting[0].companyName;
            this.companyPhone = settingInterfaces.Setting[0].companyPhone;
            this.companyDiscount = settingInterfaces.Setting[0].companyDiscount;
            this.country = settingInterfaces.Setting[0].country;
            this.State = settingInterfaces.Setting[0].State;
            this.Address = settingInterfaces.Setting[0].Address;
            this.Email= settingInterfaces.Setting[0].companyEmail;
            this.companyImagename = settingInterfaces.Setting[0].companyImagename;
            this.companyHeaderParagraph = settingInterfaces.Setting[0].companyHeaderParagraph;
            this.companyFooterParagraph = settingInterfaces.Setting[0].companyFooterParagraph;
            console.log( 'this.settingInterfaces',  this.companyHeaderParagraph);
          });

          /****** Store Get All the value*****/
      this.storeService.getStoreRequest()
        .subscribe(  storeInterfaces => {
          console.log( storeInterfaces)
          this.storeInterfaces =  storeInterfaces;
         console.log('storeInterfaces',this.storeInterfaces);
      });
  }

  /*********Get Single Store Value************/
  getstore(value:any){
       console.log('value',value);
       let id=value;
       console.log('value',id);
       this.storeService.getStoreSingle(id )
      .subscribe(  storeInterface => {
            this.storeInterface = storeInterface.StoreDetail;
            console.log( this.storeInterface)
            this.ID = storeInterface.StoreDetail._id;
            this.companyName = storeInterface.StoreDetail.storeName;
            this.Email = storeInterface.StoreDetail.storeEmail;
            this.companyPhone = storeInterface.StoreDetail.storePhone;
            this.country = storeInterface.StoreDetail.storecountry;
            this.storeCity = storeInterface.StoreDetail.storeCity;
            this.State = storeInterface.StoreDetail.storestate;
            this.Address= storeInterface.StoreDetail.storeAddress;
      });
  }
 addSetting() {
       console.log( this.companyName);
       const newUser = {
              store_id:this.ID,
              companyName: this.companyName ,
              companyLogo:  this.companyLogo,
              companyPhone: this.companyPhone,
              companyEmail:this.Email,
              companydefaultDiscount:this.companyDiscount,
              companydefaulttax:this.Tax,
              companyImagename:this.companyImagename,
              companyHeaderParagraph: this.companyHeaderParagraph,
              companyFooterParagraph: this.companyFooterParagraph ,
              country:this.country,
              State:this.State,
              Address:this.Address,
       };      alert('Data Successfully Saved');
              console.log('newUser',newUser);
              this.settingService.postSettingRequest(newUser)
                   .subscribe( settingInterfac=> {
                   //this.settingInterface.push(settingInterfac);
              // get request call
             this.settingService.getSettingrRequest()
                    .subscribe( settingInterfaces => {
                  this.settingInterfaces = settingInterfaces.Setting[0]
                  console.log( 'this.settingInterfaces',  this.settingInterfaces);
              });     
            });
  }
  constructor(private _http: Http,
              private settingService: SettingService ,private route : ActivatedRoute,
            private httpservies:HttpService,private storeService : StoreService) {}

  //  It is used for upload the image
  fileChanged(e: Event) {
    var target: HTMLInputElement = e.target as HTMLInputElement;
    for ( var i = 0;i < target.files.length; i++) {
        this.upload(target.files[i]);
        console.log('targert',target.files[i])
    }
  }
  upload(file) {
    
       var formData: FormData = new FormData();
       formData.append('file', file);
       this.companyImagename = file.name;
       console.log('this.companyImagename',this.companyImagename);
       var xhr = new XMLHttpRequest();
       xhr.upload.addEventListener('progress', (ev: ProgressEvent) => {});
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                  let   resolve = (JSON.parse(xhr.response))
                  console.log('response', resolve)
                } else {
                  let  reject = (xhr.response)
                }
            }
        }
       xhr.open('POST', 'http://172.104.42.153:3005/uploadFile',file);
       console.log('post image value', file);
       xhr.send(formData);
   
    }

  updatesetting() {
      const newUser = {
              store_id:this.ID,
              companyName: this.companyName ,
              companyLogo:  this.companyLogo,
              companyPhone: this.companyPhone,
              companyEmail:this.Email,
              companydefaultDiscount:this.companyDiscount,
              companydefaulttax:this.Tax,
              companyImagename:this.companyImagename,
              companyHeaderParagraph: this.companyHeaderParagraph,
              companyFooterParagraph: this.companyFooterParagraph ,
              country:this.country,
              State:this.State,
              Address:this.Address,
       };   
     console.log( newUser);
    
    var headers = new Headers();
     headers.append('Content-Type', 'application/json');
    // console.log('call the id ',this.id)
     this._http.put('http://172.104.42.153:3005/api/setting_update/'+this.id ,newUser, { headers: headers  })
     .map((res) => res.json())
     .subscribe(data => console.log(data));
     alert('Data Successfully Update');
     this.settingService.getSettingrRequest()
          .subscribe( settingInterfaces => {
            this.settingInterfaces = settingInterfaces.Setting[0]
            console.log( 'this.settingInterfaces',  this.settingInterfaces);
            this.id = settingInterfaces.Setting[0]._id;
            this.companyName = settingInterfaces.Setting[0].companyName;
            this.companyPhone = settingInterfaces.Setting[0].companyPhone;
            this.companyCode = settingInterfaces.Setting[0].companyCode;
            this.companyDiscount = settingInterfaces.Setting[0].companyDiscount;
            this.CGST = settingInterfaces.Setting[0].CGST;
            this.IGST = settingInterfaces.Setting[0].IGST;
            this.SGST = settingInterfaces.Setting[0].SGST;
            this.companyImagename = settingInterfaces.Setting[0].companyImagename;
            this.companyNumberDecimal = settingInterfaces.Setting[0].companyNumberDecimal;
            this.compnayStripeSecretkey = settingInterfaces.Setting.compnayStripeSecretkey ;
            this.companyHeaderParagraph = settingInterfaces.Setting[0].companyHeaderParagraph;
            this.companyFooterParagraph = settingInterfaces.Setting[0].companyFooterParagraph;
            this.compnayStripeSecretkey = settingInterfaces.Setting[0].compnayStripeSecretkey ;
            this.compnayStripePublishedKey = settingInterfaces.Setting[0].compnayStripePublishedKey;
            console.log( 'this.settingInterfaces',  this.companyHeaderParagraph);
          });
         // this.router.navigate(['home/setting/settingDemo']);

  }  

}
