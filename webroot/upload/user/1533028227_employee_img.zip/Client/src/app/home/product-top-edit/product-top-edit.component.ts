import { Component, OnInit } from '@angular/core';
import {  Response, Headers, RequestOptions, Http } from '@angular/http';
import {Router,ActivatedRoute, Params, Data } from '@angular/router';
import { FormsModule } from '@angular/forms';
import 'rxjs/add/operator/map';
import {Product_TopService} from '../product-top/product_Top.services';
import {Product_TopInterface}  from '../product-top/product-top.interface';
import { Ng2FilterPipeModule } from 'ng2-filter-pipe';
import {CategoriesProductService} from '../product/product.services';
@Component({
  selector: 'app-product-top-edit',
  templateUrl: './product-top-edit.component.html',
  styleUrls: ['./product-top-edit.component.css'],
  providers:[Product_TopService,CategoriesProductService]
})
export class ProductTopEditComponent implements OnInit {
   option: string;
  // interface declare
      product_TopInterface: Product_TopInterface[];

  //variable declare
      id:any;
      categoriesProductInterfaces;
      productType: string ;
      productCode: string ;
      productName: string ;
      productCategory: string;
      productSupplier: string ;
      productPurchasePrice: string ;
      productTax: string ;
      productTaxMethod: string;
      productPriceINR: string;
      productUnit: string ;
      productAlertQuantity: string ;
      productDiscription: string ;
      productImage: string ;
      productParagraph: string ;
      constructor(private http: Http,
        private router: Router,private categoriesProductService:CategoriesProductService,
        private product_TopService: Product_TopService,
        private route : ActivatedRoute) {
         }
  ngOnInit() {
      // params define
      this.route.params.subscribe(params => this.id=params);
      console.log('this is params  id value',this.id);

      // get request call
     this.product_TopService.getProduct_TopSingleRequest(this.id )
     .subscribe(  product_TopInterface => {
        this.product_TopInterface =  product_TopInterface.ProductDetail;
        this.productType =  product_TopInterface.ProductDetail.productType;
        this.productCode =  product_TopInterface.ProductDetail.productCode;
        this.productName =  product_TopInterface.ProductDetail.productName;
        this.productCategory =  product_TopInterface.ProductDetail.productCategory;
        this.productSupplier  =  product_TopInterface.ProductDetail.productSupplier;
        this.productPurchasePrice =  product_TopInterface.ProductDetail.productPurchasePrice;
        this.productTax =  product_TopInterface.ProductDetail.productTax;
        this.productTaxMethod =  product_TopInterface.ProductDetail.productTaxMethod;
        this.productPriceINR =  product_TopInterface.ProductDetail.productPriceINR;
        this.productUnit =  product_TopInterface.ProductDetail.productUnit;
        this.productAlertQuantity =  product_TopInterface.ProductDetail.productAlertQuantity;
        this.productDiscription =  product_TopInterface.ProductDetail.productDiscription;
        this.productImage =  product_TopInterface.ProductDetail.productImage;
        this.productParagraph =  product_TopInterface.ProductDetail.productParagraph;
        console.log( 'proDuct Value show',product_TopInterface)
    });
     this.categoriesProductService.getCategoriesProductRequest()
          .subscribe( categoriesProductInterfaces  => {
            console.log( categoriesProductInterfaces )
             this.categoriesProductInterfaces  = categoriesProductInterfaces
    });

  }


  updateProduct_Top() {
              const newUser = {
                productType: this.productType,
                productCode: this.productCode,
                productName:  this.productName,
                productCategory:  this.productCategory,
                productSupplier:  this.productSupplier,
                productPurchasePrice:  this.productPurchasePrice,
                productTax:  this.productTax,
                productTaxMethod:  this.productTaxMethod,
                productPriceINR:  this.productPriceINR,
                productImage: this.productImage,
                productUnit:  this.productUnit,
                productAlertQuantity:  this.productAlertQuantity,
                productDiscription:  this.productDiscription,
                productParagraph:  this.productParagraph
          }
              console.log(newUser);
               var headers = new Headers();
               headers.append('Content-Type', 'application/json');
               console.log('show the value',newUser)

               this.http.put('http://172.104.42.153:3005/api/product_update/'+this.id.id ,newUser, { headers: headers  })
               .map((res) => res.json())
               .subscribe(
                data => console.log(data))
                alert('Sucessful Update your Data');
                this.product_TopService.getProduct_TopSingleRequest(this.id )
                .subscribe(  product_TopInterface => {
                   this.product_TopInterface =  product_TopInterface.ProductDetail;
                   this.productType =  product_TopInterface.ProductDetail.productType;
                   this.productCode =  product_TopInterface.ProductDetail.productCode;
                   this.productName =  product_TopInterface.ProductDetail.productName;
                   this.productCategory =  product_TopInterface.ProductDetail.productCategory;
                   this.productSupplier  =  product_TopInterface.ProductDetail.productSupplier;
                   this.productPurchasePrice =  product_TopInterface.ProductDetail.productPurchasePrice;
                   this.productTax =  product_TopInterface.ProductDetail.productTax;
                   this.productTaxMethod =  product_TopInterface.ProductDetail.productTaxMethod;
                   this.productPriceINR =  product_TopInterface.ProductDetail.productPriceINR;
                   this.productUnit =  product_TopInterface.ProductDetail.productUnit;
                   this.productAlertQuantity =  product_TopInterface.ProductDetail.productAlertQuantity;
                   this.productDiscription =  product_TopInterface.ProductDetail.productDiscription;
                   this.productImage =  product_TopInterface.ProductDetail.productImage;
                   this.productParagraph =  product_TopInterface.ProductDetail.productParagraph;
                   console.log( 'proDuct Value show',product_TopInterface)
                });
                this.router.navigate(['home/product_top']);

              }
  // this function is related to show and hide option in modal option
      onSelect(option: string) {
      this.option = option

}
 //  this method is used for method upload
  fileChanged(e: Event) {
    var target: HTMLInputElement = e.target as HTMLInputElement;
    for ( var i = 0;i < target.files.length; i++) {
        this.upload(target.files[i]);
        console.log('targert',target.files[i])
    }
  }
  upload(file) {
       var formData: FormData = new FormData();
       formData.append('file', file);
       console.log('file',file);
       this.productImage = file.name;
       var xhr = new XMLHttpRequest();
       xhr.upload.addEventListener('progress', (ev: ProgressEvent) => {});
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                  let   resolve = (JSON.parse(xhr.response))
                  console.log('response', resolve)
                } else {
                  let  reject = (xhr.response)
                }
            }
        }
       xhr.open('POST', 'http://172.104.42.153:3005/uploadFile',file);
       console.log('post image value', file);
       xhr.send(formData);
   
  }

}
