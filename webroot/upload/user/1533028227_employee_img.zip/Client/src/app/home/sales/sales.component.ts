import { Component, ViewChild, OnInit } from '@angular/core';
import { ModalComponent } from 'ng2-bs3-modal';
import { Http, Headers } from '@angular/http';
import {CustomerInterface} from '../customers/customer-interface';
import {CustomerService} from '../customers/customer-services';
import {UserInterface} from '../users/user.interface';
import {UserService} from '../users/user.services';
import {SettingService} from '../setting-demo/setting-services'
import { SettingInterface} from '../setting-demo/setting-interface';
import {POSService } from '../pos-add-/pos.add.services';
import {PosInterface} from '../pos-add-/pos.add.interface';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {NgxPaginationModule} from 'ngx-pagination';
import {SalesService} from './sales.services';
@Component({
  selector: 'app-sales',
  templateUrl: './sales.component.html',
  styleUrls: ['./sales.component.css'],
  providers:[CustomerService,UserService,
            SettingService,POSService,SalesService]
})
export class SalesComponent implements OnInit {
  @ViewChild('myModal')
    Editmodal: ModalComponent;
    Paymentmodal: ModalComponent;
    Invoicemodal: ModalComponent;
    receiptmodal: ModalComponent;
     value = [2,10,25,50,100];
     selectValue = this.value[0];
  // variable declare
  userName: string; date: string; customerName: string; productName: string; quantity: string;
  token: string; subtotal: string; totalitems: string; total: string; product: string; ArrayItem: string;
  salesid: string;
  // interface define for customer related
  customerInterfaces:CustomerInterface[];
  salesInterface: SalesService[];
  // interface define for User component Related
  userInterfaces :UserInterface[];
  // interface define for Setting Demo
  settingInterfaces: SettingInterface[];
  posInterfaces: PosInterface[];
    constructor(private customerService: CustomerService,
    private userService: UserService,private salesService:SalesService,
    private settingService: SettingService,  private pOSService:POSService) { }

  ngOnInit() {
    // get request call for customer component
     this.customerService.getCustomerRequest()
          .subscribe(   customerInterfaces => {
           // console.log(customerInterfaces)
             this.customerInterfaces =   customerInterfaces;
            // console.log(this.customerInterfaces);
          });
    // get request  call for user component
     this.userService.getUserRequest()
          .subscribe(  userInterfaces => {
            // console.log(userInterfaces)
             this.userInterfaces =  userInterfaces;
            // console.log(this.userInterfaces);
          });
            // get request call
     this.settingService.getSettingrRequest()  // get the teacher value
          .subscribe( settingInterfaces => {
            // console.log( settingInterfaces)
             this.settingInterfaces = settingInterfaces;
          });
    // Item the value
    this.pOSService.getItemRequest()
    .subscribe( posInterfaces => {
      console.log(posInterfaces)
       this.posInterfaces = posInterfaces;
      // console.log('pos value get', this.posInterfaces);
    });
    var currentUser = JSON.parse(localStorage.getItem('currentUser'));
    this.token = currentUser && currentUser.token;
    this.userName = currentUser && currentUser.userName;
   // console.log('this.userName' ,this.userName);

  // this method is used for  sales get data
  this.salesService.getSalesdata(this.salesid);
  }
  // get the data for recipt value
  productid(id){
    console.log('id',id);
    this.salesid = id;
    this.salesService.getSalesdata( this.salesid)
    .subscribe(  salesInterface => {
      console.log('salesInterface',salesInterface.salesDetail);
       this.salesInterface =   salesInterface.salesDetail;
       this.customerName = salesInterface.salesDetail[0].customerName;
       this.date =  salesInterface.salesDetail[0].date;
       this.product =  salesInterface.salesDetail[0].products;
       this.ArrayItem  = salesInterface.salesDetail[0].gst;
       this.totalitems =  salesInterface.salesDetail[0].count;
       this.total =  salesInterface.salesDetail[0].subtotal;
       console.log('this.ArrayItem',salesInterface.salesDetail[0].gst);
    });
  }
   // apply  for Delete method request
  deletesales(id) {
    console.log('deleteid',id);
      this.salesService.deleteSalesRequest(id)
        .subscribe(data => {
         if (data.n == 1) {
            for ( let i = 0 ; i  < this.posInterfaces.length; i++) {
                 if (this.posInterfaces[i]._id == id)
                 // tslint:disable-next-line:one-line
                 {
                  this.posInterfaces.splice(i, 1);
                 }
            }
         }
       })
}
}
