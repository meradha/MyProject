export class StoreInterface {
       _id?: string;
       storeName: string;
       storeEmail: string;
       storePhone: string;
       storecountry: string;
       storeCity: string;
       storeAddress: string;
       storeReceipt: string;
   
}
