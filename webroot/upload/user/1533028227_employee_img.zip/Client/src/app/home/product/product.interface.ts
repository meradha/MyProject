export class CategoriesProductInterface {
       _id?: string;
       categoryproductName: string ;
       categoCreateAt: string ;

}

