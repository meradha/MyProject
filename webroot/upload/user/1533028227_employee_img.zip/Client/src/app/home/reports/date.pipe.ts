import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'datesPipe'
})
export class DatesPipe implements PipeTransform {

    transform(value, fromdate , todat , arg3 , arg4 ){

    return value.filter(row => {
      return row.date >= fromdate && row.date <= todat;
    });
  }
   
}



