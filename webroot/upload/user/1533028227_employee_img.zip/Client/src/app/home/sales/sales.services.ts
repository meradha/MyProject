import { Injectable } from '@angular/core';
import {Http, Headers} from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/map';
@Injectable()
export class SalesService {
    res: any;
    constructor(private http: Http, private router: Router) {}
   // apply for get request

      getSalesdata(salesid) {
          let id = salesid;
          return this.http.get('http://172.104.42.153:3005/api/sales_get_value/'+id)
                              .map(res => res.json());
          }
          deleteSalesRequest(id) {
            alert('delete value successful');
           return this.http.delete('http://172.104.42.153:3005/api/sales_delete/'+id)
                   .map(res => res.json());
         }
}
