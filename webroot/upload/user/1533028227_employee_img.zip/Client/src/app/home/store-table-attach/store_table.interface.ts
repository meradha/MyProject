export class StoreTableInterface {
       _id?: string;
        zoneName: string;
        storeTable: string;
        zonecode: string
}
