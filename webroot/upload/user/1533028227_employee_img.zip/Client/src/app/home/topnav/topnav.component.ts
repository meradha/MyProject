import { Component, OnInit,Input } from '@angular/core';
import { Headers, Http, Response } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
import {UserInterface} from '../users/user.interface';
import {UserService} from '../users/user.services';
import {LoginComponent} from '../../login/login.component';
import { StoreInterface} from '../stores/store-interface';
import {StoreService } from '../stores/store.services';

@Component({
  selector: 'app-topnav',
  templateUrl: './topnav.component.html' ,
  styleUrls: ['./topnav.component.css'],
  providers:[UserService,StoreService],
})
export class TopnavComponent implements OnInit {

  // user interface
 UserInterfaces: UserInterface[];
 token: string;
 userName:string; 
 userImageName:string
 storeInterface :StoreInterface[];
 id;

 constructor(private router: Router,private storeService:StoreService,
             private http: Http,
             private userService:UserService,private route : ActivatedRoute) {
              var currentUser = JSON.parse(localStorage.getItem('currentUser'));
              this.token = currentUser && currentUser.token;
              this.userName = currentUser && currentUser.userName;
              this.userImageName=  currentUser && currentUser.userImageName;
             // console.log('this.userName' ,this.userName);
             }
  ngOnInit() {
    // user compoenent get request call
     this.userService.getUserRequest()
          .subscribe(  UserInterfaces => {
      //      console.log( UserInterfaces)
             this.UserInterfaces =  UserInterfaces;
           //  console.log('login',this.UserInterfaces);
    });
    /*********Store ID GEt*************/
    // get request for store call
      this.storeService.getStoreRequest()  // get the teacher value
          .subscribe(  storeInterfaces => {
         
             this.id =  storeInterfaces[0]._id;
      //  console.log('this.storeInterface',this.id);
      });

   
  }
clicked() {
     // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
          this.router.navigateByUrl('/login');
         // console.log('token delet');
  }

  

}
