import { Component, ViewChild, OnInit } from '@angular/core';
import { ModalComponent } from 'ng2-bs3-modal';
import { Http, Headers } from '@angular/http';
import {Router} from '@angular/router';
import {ReactiveFormsModule,FormsModule, FormGroup,FormControl,Validators,FormBuilder,NgForm} from '@angular/forms';
import {CategoriesExpenseInterface} from './expeense.interface';
import {CategoriesExpenseService} from './expese.services';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module

@Component({
  selector: 'app-expense',
  templateUrl: './expense.component.html',
  styleUrls: ['./expense.component.css'],
  providers:[CategoriesExpenseService]
})
export class ExpenseComponent implements OnInit {
// this is related to bootstrap modal
  @ViewChild('myModal')
    modal: ModalComponent;
    viewmodal: ModalComponent;
    value = [2,10,25,50,100];
    selectValue = this.value[1];
// interface declare
    categoriesExpenseInterfaces : CategoriesExpenseInterface[];
    categoriesExpenseInterface : CategoriesExpenseInterface;
// variable declare
       category_expernseName: string ;
       category_CreateAt: string ;
        

  constructor(private router: Router, private  categoriesExpenseService : CategoriesExpenseService) { }


  ngOnInit() {
    // get request call
     this.categoriesExpenseService.getCategoriesExpenseRequest()  
          .subscribe( categoriesExpenseInterfaces  => {
         // console.log( categoriesExpenseInterfaces )
          this.categoriesExpenseInterfaces  = categoriesExpenseInterfaces;
       });
  }
  
      // it is used for redirect operation perform.
      redirect(_id) {
    this.router.navigate(['home/category_edit_expense',_id]);
  }

  // this function is used for add modal value
  addExpense(f:NgForm) {
      // console.log( this.category_expernseName);
       const newUser = {
             category_expernseName: this.category_expernseName ,
             category_CreateAt: new Date
       }
          //    console.log(newUser);
              this.categoriesExpenseService.postCategoriesExpenseeRequest(newUser)
                   .subscribe( categoriesProductInterface=> {
                   this.categoriesExpenseInterfaces.push(categoriesProductInterface);
                   // get request call
               this.categoriesExpenseService.getCategoriesExpenseRequest()  // get the teacher value
                   .subscribe( categoriesExpenseInterfaces  => {
                //   console.log( categoriesExpenseInterfaces )
                   this.categoriesExpenseInterfaces  = categoriesExpenseInterfaces
               });
               f.reset();
      })
       

  }
      // apply  for Delete method request
  deleteCategoriesExpense(id: any) {
    this.categoriesExpenseService.deleteCategoriesExpenseRequest(id)  // get the teacher value
    .subscribe( categoriesExpenseInterfaces  => {
     // console.log('categoriesProductInterfaces',categoriesExpenseInterfaces);
       if( categoriesExpenseInterfaces.success === true){
        alert('If you want to delet this Value, before delet existing value');
      //  console.log('categoriesProductInterfaces',categoriesExpenseInterfaces);
       } else {
        alert('Delete Value Successfully');
        this.categoriesExpenseService.getCategoriesExpenseRequest()  // get the teacher value
        .subscribe( categoriesExpenseInterface  => {
           this.categoriesExpenseInterfaces  = categoriesExpenseInterface;
        });

       }
    });

    }
  // this method is used for get value which is show on view modal
  view(id){
    // get request call
    this.categoriesExpenseService.getCategoriesExpenseSingle(id )
    .subscribe(  categoriesExpenseInterface => {
    //  console.log( categoriesExpenseInterface)
       this.categoriesExpenseInterface =  categoriesExpenseInterface.CategoryExpenseDetail;
       this.category_expernseName =  categoriesExpenseInterface.CategoryExpenseDetail.category_expernseName;
       this.category_CreateAt =   categoriesExpenseInterface.CategoryExpenseDetail.category_CreateAt;
    //  console.log('this.category_expernseName',this.categoriesExpenseInterface);
    });
  }
   closee(f:NgForm){
        f.reset();
        this.category_expernseName = null ;
        this.category_CreateAt = null ;
     //   console.log('clear');
  }
}
