import { Component, ViewChild, OnInit } from '@angular/core';
import { ModalComponent } from 'ng2-bs3-modal';
import { Http, Headers } from '@angular/http';
import {CKEditorModule} from 'ng2-ckeditor';
import {Router} from '@angular/router';
import {Expense_Top_Interface} from './expense-top.Interface';
import {Expense_TopService} from './expense-top.services';
import { StoreInterface} from '../stores/store-interface';
import {StoreService } from '../stores/store.services';
import {CategoriesExpenseInterface} from '../expense/expeense.interface';
import {CategoriesExpenseService} from '../expense/expese.services';
import {UserInterface} from '../users/user.interface';
import {UserService} from '../users/user.services';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {ReactiveFormsModule,FormsModule, FormGroup,FormControl,Validators,FormBuilder,NgForm} from '@angular/forms';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module
@Component({
  selector: 'app-expense-top-nav',
  templateUrl: './expense-top-nav.component.html',
  styleUrls: ['./expense-top-nav.component.css'],
  providers:[Expense_TopService,StoreService,CategoriesExpenseService,UserService]
})
export class ExpenseTopNavComponent implements OnInit {
// there are relaetd to modal t option.
   @ViewChild('myModal')
    modal: ModalComponent;
    viewmodal:  ModalComponent;

// interface declare
    expense_Top_Interfaces :Expense_Top_Interface[] ;
    expense_Top_Interface:Expense_Top_Interface;

// interface part of the store component
    storeInterfaces :StoreInterface[] ;
    storeInterface : StoreInterface;

// interface part of the Categories_expense
  categoriesExpenseInterfaces : CategoriesExpenseInterface[];
  categoriesExpenseInterface  : CategoriesExpenseInterface;

// interface declare    which is part of the Users component
   UserInterfaces: UserInterface[];
   UserInterface: UserInterface;
  

// variable declare
    expenseDate: string ;
    expenseReference:  string ;
    expenseCategory: string ;
    expenseStore: string ;
    expenseAmount: string ;
    expenseFileImage: string ;
    expenseParagraph: string;
    expenseCreatedBy: string;
    value = [2,10,25,50,100];
    selectValue = this.value[1]; 

   constructor(private router: Router,
               private expense_TopService:Expense_TopService,
               private storeService:StoreService,
               private categoriesExpenseService: CategoriesExpenseService,
               private userService :UserService ) {

               }

  ngOnInit() {
    // get request call
     this.expense_TopService.getExpense_TopsRequest()
          .subscribe(  expense_Top_Interfaces => {
          //  console.log( expense_Top_Interfaces)
             this.expense_Top_Interfaces = expense_Top_Interfaces
          });

    // part of the Categories_expense component get request
    // get request call
     this.storeService.getStoreRequest()  // get the teacher value
          .subscribe(  storeInterfaces => {
           // console.log( storeInterfaces)
             this.storeInterfaces =  storeInterfaces;
            // console.log(this.storeInterfaces);
          });
    // part of the store component get request
    // get request call
     this.categoriesExpenseService.getCategoriesExpenseRequest()  // get the teacher value
          .subscribe( categoriesExpenseInterfaces  => {
            console.log( categoriesExpenseInterfaces )
             this.categoriesExpenseInterfaces  = categoriesExpenseInterfaces;
          });
     // this is part of the  Users component
    // get request call
     this.userService.getUserRequest()  //
          .subscribe(  UserInterfaces => {
           // console.log( UserInterfaces)
             this.UserInterfaces =  UserInterfaces
            // console.log(this.UserInterfaces);
          });// get request call

  }

     redirect(_id) {
    this.router.navigate(['home/expense_top_edit',_id]);

  }
    // apply for value store in data base
   addExpense_Top(f:NgForm) {
    // console.log( this.expenseDate);
       const newUser = {
            expenseDate: this.expenseDate ,
            expenseReference: this.expenseReference ,
            expenseCategory: this.expenseCategory,
            expenseStore: this.expenseStore,
            expenseAmount: this.expenseAmount,
            expenseFileImage: this.expenseFileImage,
            expenseParagraph: this.expenseParagraph,
             expenseCreatedBy: this.expenseCreatedBy
       }
              // console.log(newUser);
              this.expense_TopService.postExpense_TopRequest(newUser)
                   .subscribe( expense_Top_Interface=> {
                   this.expense_Top_Interfaces.push( expense_Top_Interface);
                   this.expense_TopService.getExpense_TopsRequest()
                   .subscribe(  expense_Top_Interfaces => {
                   //  console.log( expense_Top_Interfaces)
                      this.expense_Top_Interfaces = expense_Top_Interfaces
                   });
                   f.reset();
             })
}
  // apply  for Delete method request
  deleteExpense_Top(id: any) {
         var  expense_Top_Interfaces = this.expense_Top_Interfaces;
         this.expense_TopService.deleteExpense_TopRequest(id)
             .subscribe(data => {
              if (data.n == 1) {
                 for ( let i = 0 ; i  <  expense_Top_Interfaces.length; i++) {
                      if ( expense_Top_Interfaces[i]._id == id)
                      // tslint:disable-next-line:one-line
                      {
                        expense_Top_Interfaces.splice(i, 1);
                      }
                 }
              }
            })
    }
view(id){
  this.expense_TopService.getExpenseSingle(id )
  .subscribe(  expense_Top_Interfaces => {
     this.expense_Top_Interface= expense_Top_Interfaces.ExpenseDetail;
     this.expenseDate  =  expense_Top_Interfaces.ExpenseDetail.expenseDate;
     this.expenseReference   =  expense_Top_Interfaces.ExpenseDetail.expenseReference;
     this.expenseCategory  =  expense_Top_Interfaces.ExpenseDetail.expenseCategory;
     this.expenseStore   =  expense_Top_Interfaces.ExpenseDetail.expenseStore;
     this.expenseAmount =  expense_Top_Interfaces.ExpenseDetail.expenseAmount;
     this.expenseFileImage =  expense_Top_Interfaces.ExpenseDetail.expenseFileImage;
     this.expenseParagraph =  expense_Top_Interfaces.ExpenseDetail.expenseParagraph;
  });
}
 //  this method is used for method upload
  fileChanged(e: Event) {
    var target: HTMLInputElement = e.target as HTMLInputElement;
    for ( var i = 0;i < target.files.length; i++) {
        this.upload(target.files[i]);
        console.log('targert',target.files[i])
    }
  }
  upload(file) {
       var formData: FormData = new FormData();
       formData.append('file', file);
       console.log('file',file);
       this.expenseFileImage= file.name;
       var xhr = new XMLHttpRequest();
       xhr.upload.addEventListener('progress', (ev: ProgressEvent) => {});
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                  let   resolve = (JSON.parse(xhr.response))
                  console.log('response', resolve)
                } else {
                  let  reject = (xhr.response)
                }
            }
        }
       xhr.open('POST', 'http://172.104.42.153:3005/uploadFile',file);
       console.log('post image value', file);
       xhr.send(formData);
   
  }

  closee(f:NgForm){
        f.reset();
       this.expenseDate  =  null;
     this.expenseReference   =  null;
     this.expenseCategory  =  null;
     this.expenseStore   = null;
     this.expenseAmount = null;
     this.expenseFileImage =  null;
     this.expenseParagraph =  null
        console.log('clear');
  }

}
