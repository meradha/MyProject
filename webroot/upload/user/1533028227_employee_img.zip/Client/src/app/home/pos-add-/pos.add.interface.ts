export class PosInterface {
  _id?: string;
  POScustomerName: string ;
  POScustomerPhone: string ;
  POSproduct_Name: string;
  POSwaiterName: string;
  POStotalPrize :string;

}
