export class CustomerInterface {
       _id?: string;
    customerName: string ;
    customerPhone: string ;
    customerEmail: string ;
    customerDiscount: string ;
    customerCreatedAt: string ;
}

