import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,  ReactiveFormsModule, FormControl,FormGroup } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { routing } from './app.routing';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import {  HomeModule  } from './home/home/home.module';
import { AngularFontAwesomeModule } from 'angular-font-awesome/angular-font-awesome';
import { Ng4LoadingSpinnerModule, Ng4LoadingSpinnerService  } from 'ng4-loading-spinner';
import { NglModule } from 'ng-lightning/ng-lightning';
import {BusyModule} from 'angular2-busy';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent
  ],
  imports: [
    BrowserModule, Ng4LoadingSpinnerModule, BusyModule,
    routing,
    HttpModule,AngularFontAwesomeModule,
    FormsModule,  ReactiveFormsModule,NglModule,
    RouterModule,
    RouterModule,
    HomeModule ,
  ],
    
  providers: [Ng4LoadingSpinnerService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
