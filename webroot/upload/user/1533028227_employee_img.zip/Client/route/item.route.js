//  it is used for contain the value of the 
var express = require('express');
var router = express.Router();
var item_modal = require('../Modal/item.model');
var table = require('../Modal/store-table.model');
var people_customers_modal = require('../Modal/people-customers-model');
// get the single value 
router.get('/item_get_single_value/:id', (req, res, next) => {
    var id = req.params.id;
    item_modal.find(({ Posid: id, status: false }), function(err, itemDetail) {
        if (err) {

            res.json({ success: false, message: 'itemDetail single  Detail not found' });
        } else {

            res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

        }
    })
})


router.get('/item_single_value/:id', (req, res, next) => {
    var id = req.params.id;
    item_modal.find(({ Posid: id }), function(err, itemDetail) {
        if (err) {

            res.json({ success: false, message: 'itemDetail single  Detail not found' });
        } else {

            res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

        }
    })
})


// all the get value
router.get('/item', (req, res, next) => {
    item_modal.find(function(err, classmodel) {
        res.json(classmodel);
    })

});
//apply the post mehtod 
//save the class value
router.post('/item_post_value', (req, res, next) => {
    console.log('req', req.body);
    const newClass = item_modal({
        Posid: req.body.Posid,
        customerName: req.body.customerName,
        customerState: req.body.customerState,
        customerType: req.body.customerType,
        customerId: req.body.customerId,
        WaiterName: req.body.WaiterName,
        products: req.body.products,
        table_id: req.body.table_id,
        total: req.body.total,
        gst: req.body.gst,
        singlegstvalue: req.body.ItemAdd,
        count: req.body.count,
        subtotal: req.body.subtotal
    })

    newClass.save(function(err, ItemDetail) {
            if (err) {
                res.json({ success: false, message: err });
            } else {
                if (ItemDetail.Posid) {
                    id = ItemDetail.Posid
                    table.findOne({ _id: id }, function(err, table) {
                        console.log('Table', table)
                        if (err) {
                            res.json({ success: false, message: 'Table Detail not found' });
                        } else {
                            table.update({ status: false }, function(err, success) {
                                console.log('Table status', success)

                                if (err) {
                                    res.json({ success: false, message: err });
                                } else {
                                    // res.json({ success: true, data: ItemDetail, message: 'New collection saved' });
                                    ItemDetail.update({ status: false }, function(err, success) {
                                        console.log('Table status', success)

                                        if (err) {
                                            res.json({ success: false, message: err });
                                        } else {
                                            res.json({ success: true, data: ItemDetail, message: 'New collection saved' });
                                        }
                                    });
                                }
                            });
                        }
                    })
                }
            }
        })
        //console.log(req);
});


// apply the delet mehtod
// the save value
router.delete('/item_delet/:productName', (req, res, next) => {
    console.log('req.params.productName', req.params.productName);

    item_modal.remove({ productName: req.params.productName }, function(err, result) {
        if (err) {
            res.json(err);
        } else {
            res.json(result);

        }
    });
});

//all the value delet value
router.delete('/item_All_delet/:id', (req, res, next) => {
    item_modal.remove({ Posid: req.params.id, status: false }, function(err, result) {
        if (err) {
            res.json(err);
        } else {
            res.json(result);

        }
    });
});

//update the and apply update request
router.put('/item_update/:id', function(req, res) {
    var id = req.params.id;
    //console.log('response',req.params)

    item_modal.findOne({ Posid: id, status: false }, function(err, item) {
        //console.log('item',item)
        if (err) {
            res.json({ success: false, message: 'Item Detail not found' });
        } else {
            item.update(req.body, function(err, success) {
                if (err) {
                    res.json({ success: false, message: err });
                } else {
                    table.findOne({ _id: id }, function(err, table) {
                        console.log('Table', table)
                        if (err) {
                            res.json({ success: false, message: 'Table Detail not found' });
                        } else {
                            table.update({ status: false }, function(err, success) {
                                console.log('Table status', success)

                                if (err) {
                                    res.json({ success: false, message: err });
                                } else {
                                    // res.json({ success: true, data: ItemDetail, message: 'New collection saved' });
                                    item.update({ status: false }, function(err, success) {
                                        console.log('Table status', success)

                                        if (err) {
                                            res.json({ success: false, message: err });
                                        } else {
                                            res.json({ success: true, message: 'Item Detail update successfully' });
                                        }
                                    });
                                }
                            });
                        }
                    })
                }
            });
        }
    })
});
//update the and apply for Payment Option update request
//update the and apply for Payment Option update request
//update the and apply update request
router.put('/item_Payment_update/:id', function(req, res) {
    var id = req.params.id;
    //console.log('response',req.params)

    item_modal.findOne({ Posid: id, status: false }, function(err, item) {
        //console.log('item',item)
        if (err) {
            res.json({ success: false, message: 'Item Detail not found' });
        } else {
            item.update(req.body, function(err, success) {
                if (err) {
                    res.json({ success: false, message: err });
                } else {
                    table.findOne({ _id: id }, function(err, table) {
                        console.log('Table', table)
                        if (err) {
                            res.json({ success: false, message: 'Table Detail not found' });
                        } else {
                            table.update({ status: true }, function(err, success) {
                                console.log('Table status', success)

                                if (err) {
                                    res.json({ success: false, message: err });
                                } else {
                                    // res.json({ success: true, data: ItemDetail, message: 'New collection saved' });
                                    item.update({ status: true }, function(err, success) {
                                        console.log('item status', success)

                                        if (err) {
                                            res.json({ success: false, message: err });
                                        } else {
                                            res.json({ success: true, message: 'Item Detail update successfully' });
                                        }
                                    });
                                }
                            });
                        }
                    })
                }
            });
        }
    })
});

// it is used for get the customer detail
router.post('/item_get_Customer_value', (req, res, next) => {
    var customerName = req.body.customerName;
    var date = req.body.datemodel.beginJsDate;
    console.log(' req.body', req.body);
    var startDate = new Date(req.body.datemodel.beginJsDate);

    startDate.setHours(00)
    startDate.setMinutes(00)
    startDate.setSeconds(00)
    console.log('+ startDate', +startDate);
    var endDate = new Date(req.body.datemodel.endJsDate);
    endDate.setHours(23)
    endDate.setMinutes(59)
    endDate.setSeconds(59)
    console.log("End Date:" + endDate)

    item_modal.find({ customerName: customerName, date: { $gte: startDate, $lt: endDate } }, function(err, itemDetail) {
        if (err) {

            res.json({ success: false, message: 'itemDetail single  Detail not found' });
        } else {
            res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });
            console.log(itemDetail)
        }
    })
})



// this is method apply for get the map value 
router.get('/Chart_Value', (req, res, next) => {
    item_modal.aggregate({ $unwind: "$products" }, { $unwind: "$products.productName" }, { $group: { _id: "$products.productName", count: { $sum: 1 } } }, { $sort: { 'count': -1 } }, function(err, itemDetail) {
        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });
    })
});

// this is method apply for Customer value 
router.get('/Customer_Value', (req, res, next) => {
    item_modal.aggregate({ $unwind: "$customerName" }, { $group: { _id: "$customerName", count: { $sum: 1 } } }, { $sort: { 'count': -1 } }, function(err, itemDetail) {
        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });
    })
});
// this method is used for saled component
// this method is used for saled component
router.get('/sales_get_value/:id', (req, res, next) => {
    var id = req.params.id;
    console.log(' id', id)

    item_modal.find({ _id: id }, function(err, salesDetail) {
        if (err) {

            res.json({ success: false, message: 'salesDetail single  Detail not found' });
        } else {

            res.json({ success: true, salesDetail, message: 'itemDetail single datail found' });

        }
    })
})

//this method is used for delete sales data
router.delete('/sales_delete/:id', (req, res, next) => {
    var id = req.params.id;
    item_modal.remove({ _id: id }, function(err, result) {
        if (err) {
            res.json(err);
        } else {
            res.json(result);

        }
    });
});

router.post('/report_today', (req, res, next) => {
    var startDate = new Date(req.body.date);
    startDate.setHours(00)
    startDate.setMinutes(00)
    startDate.setSeconds(00)
    var endDate = new Date(req.body.date);
    endDate.setHours(23)
    endDate.setMinutes(59)
    endDate.setSeconds(59)
    console.log("start Date:" + startDate)
    console.log("End Date:" + endDate)


    item_modal.find({ date: { $gte: startDate, $lt: endDate } }, function(err, salesDetail) {
        if (err) {

            res.json({ success: false, message: 'salesDetail single  Detail not found' });
        } else {

            res.json({ success: true, salesDetail, message: 'salesDetail single datail found' });

        }
    })
})

router.post('/item_sales_Report', (req, res, next) => {

    var startDate = new Date(req.body.fromdate.beginJsDate);

    startDate.setHours(00)
    startDate.setMinutes(00)
    startDate.setSeconds(00)
    console.log('+ startDate', +startDate);
    var endDate = new Date(req.body.fromdate.endJsDate);
    endDate.setHours(23)
    endDate.setMinutes(59)
    endDate.setSeconds(59)
    console.log("End Date:" + endDate)

    item_modal.find({ date: { $gte: startDate, $lt: endDate } }, function(err, itemDetail) {
        if (err) {

            res.json({ success: false, message: 'itemDetail single  Detail not found' });
        } else {
            res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });
            console.log(itemDetail)
        }
    })
})

// Delete the product when we product cancel
router.post('/delete_product', (req, res, next) => {
    var product_id = req.body.product_id
    var tableid = req.body.tableid
    console.log('table_id', tableid);
    item_modal.update({ Posid: tableid }, { $pull: { 'products': { product_id: product_id } } }, function(err, itemDetail) {
        if (err) {

            res.json({ success: false, message: 'itemDetail single  Detail not found' });
        } else {
            res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });
        }
    })
})

// all the get value
router.get('/item_list', (req, res, next) => {
    item_modal.aggregate([{
        $lookup: {
            from: "tbl_people_customers_schemas",
            localField: "customerId",
            foreignField: "_id",
            as: "classmodel"
        }
    }], function(err, classmodel) {
        if (err) {
            res.json({ success: false, data: err, message: 'User not found' });
        } else {
            res.json({ success: true, data: classmodel });
        }
    })

});
/**************Customer Search filter*************/
router.post('/customerfilter', (req, res, next) => {
        var subtotal = req.body.total;
        var customerType = req.body.customerType;
        var customerName = req.body.customername;
        if (req.body === undefined) {
            item_modal.find(function(err, itemDetail) {
                if (err) {
                    res.json({ success: false, message: 'itemDetail single  Detail not found' });
                } else {
                    res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                }
            })
        } else if (customerType === 'All' && subtotal === undefined && req.body.firstdate === undefined && req.body.lastdate === undefined && customerName === undefined) {
            item_modal.find(function(err, itemDetail) {
                if (err) {
                    res.json({ success: false, message: 'itemDetail single  Detail not found' });
                } else {
                    res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                }
            })
        } else if (customerType === undefined && subtotal === undefined && req.body.firstdate === undefined && req.body.lastdate === undefined) {
            item_modal.find({
                    customerName: customerName
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })
        } else if (customerType === 'All' && subtotal === undefined && req.body.firstdate == undefined && req.body.lastdate === undefined && customerName === "") {
            item_modal.find(
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'personal' && subtotal === undefined && req.body.firstdate === undefined && req.body.lastdate === undefined && customerName === undefined) {
            item_modal.find({
                    customerType: customerType
                },
                function(err, itemDetail) {
                    res.json({ success: true, itemDetail });
                })
        } else if (customerType === 'business' && subtotal === undefined && req.body.firstdate === undefined && req.body.lastdate === undefined && customerName === undefined) {
            item_modal.find({
                    customerType: customerType
                },
                function(err, itemDetail) {
                    res.json({ success: true, itemDetail });
                })

        } else if (subtotal === undefined && customerType === undefined && customerName === undefined) {
            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            console.log('startDate', startDate);
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({ date: { $gte: startDate, $lte: endDate } }, function(err, itemDetail) {
                if (err) {
                    res.json({ success: false, message: 'itemDetail single  Detail not found' });
                } else {
                    res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                }
            })
        } else if (req.body.firstdate === undefined && req.body.lastdate === undefined && customerType === undefined && customerName === undefined) {
            var tot = subtotal.split("-");
            var totA = tot[0];
            var totB = tot[1];
            var tot1 = parseInt(totA);
            var tot2 = parseInt(totB);
            console.log('totA', totA);
            console.log('totB', totB);
            console.log('tot1', tot1);
            console.log('tot2', tot2);
            console.log('tot', tot);
            item_modal.find({
                subtotal: { $gte: totA, $lte: totB }
            }, function(err, itemDetail) {
                if (err) {
                    res.json({ success: false, message: 'itemDetail single  Detail not found' });
                } else {
                    console.log('itemDetail', itemDetail);
                    res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });
                }
            })
        } else if (customerType === 'All' && subtotal === undefined && customerName === undefined) {
            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            console.log('startDate', startDate);
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({ date: { $gte: startDate, $lte: endDate } }, function(err, itemDetail) {
                if (err) {
                    res.json({ success: false, message: 'itemDetail single  Detail not found' });
                } else {
                    res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                }
            })
        } else if (customerType === 'personal' && subtotal === undefined && customerName === undefined) {
            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            console.log('startDate', startDate);
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                $and: [{
                        customerType: customerType
                    },
                    {
                        date: { $gte: startDate, $lte: endDate }
                    }
                ]
            }, function(err, itemDetail) {
                if (err) {
                    res.json({ success: false, message: 'itemDetail single  Detail not found' });
                } else {
                    res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                }
            })

        } else if (customerType === 'business' && subtotal === undefined && customerName === undefined) {
            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            console.log('startDate', startDate);
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                $and: [{
                        customerType: customerType
                    },
                    {
                        date: { $gte: startDate, $lte: endDate }
                    }
                ]
            }, function(err, itemDetail) {
                if (err) {
                    res.json({ success: false, message: 'itemDetail single  Detail not found' });
                } else {
                    res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                }
            })

        } else if (customerType === 'All' && req.body.firstdate === undefined && req.body.lastdate === undefined && customerName === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);
            item_modal.find({
                subtotal: { $gte: tot1, $lt: tot2 }

            }, function(err, itemDetail) {
                if (err) {
                    res.json({ success: false, message: 'itemDetail single  Detail not found' });
                } else {
                    res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                }
            })
        } else if (customerType === 'personal' && req.body.firstdate === undefined && req.body.lastdate === undefined && customerName === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);
            item_modal.find({
                $and: [{
                        customerType: customerType
                    },
                    {
                        subtotal: { $gte: tot1, $lt: tot2 }
                    }
                ]
            }, function(err, itemDetail) {
                if (err) {
                    res.json({ success: false, message: 'itemDetail single  Detail not found' });
                } else {
                    res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                }
            })
        } else if (customerType === 'business' && req.body.firstdate === undefined && req.body.lastdate === undefined && customerName === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);
            item_modal.find({
                $and: [{
                        customerType: customerType
                    },
                    {
                        subtotal: { $gte: tot1, $lt: tot2 }
                    }
                ]
            }, function(err, itemDetail) {
                if (err) {
                    res.json({ success: false, message: 'itemDetail single  Detail not found' });
                } else {
                    res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                }
            })
        } else if (customerType === 'personal' && subtotal === undefined && req.body.firstdate === undefined && req.body.lastdate === undefined) {
            item_modal.find({
                    $and: [{
                            customerType: customerType
                        },
                        {
                            customerName: customerName
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })
        } else if (customerType === 'business' && subtotal === undefined && req.body.firstdate === undefined && req.body.lastdate === undefined) {
            item_modal.find({
                    $and: [{
                            customerType: customerType
                        },
                        {
                            customerName: customerName
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })
        } else if (customerType === undefined && customerName === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);
            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                    $and: [{
                            subtotal: { $gte: tot1, $lte: tot2 }
                        },
                        {
                            date: { $gte: startDate, $lte: endDate }
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === undefined && subtotal === undefined) {
            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                    $and: [{
                            customerName: customerName
                        },
                        {
                            date: { $gte: startDate, $lte: endDate }
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === undefined && req.body.firstdate === undefined && req.body.lastdate === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);
            item_modal.find({
                    $and: [{
                            customerName: customerName
                        },
                        {
                            subtotal: { $gte: tot1, $lte: tot2 }
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'personal' && subtotal === undefined) {

            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                    $and: [{
                            customerName: customerName
                        }, { customerType: customerType },
                        {
                            date: { $gte: startDate, $lte: endDate }
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'All' && subtotal === undefined) {

            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                    $and: [{
                            customerName: customerName
                        },
                        {
                            date: { $gte: startDate, $lte: endDate }
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'business' && subtotal === undefined) {

            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                    $and: [{
                            customerName: customerName
                        }, { customerType: customerType },
                        {
                            date: { $gte: startDate, $lte: endDate }
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'personal' && customerName === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);
            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                    $and: [{
                            subtotal: { $gte: tot1, $lte: tot2 }
                        }, { customerType: customerType },
                        {
                            date: { $gte: startDate, $lte: endDate }
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'All' && customerName === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);
            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                    $and: [{
                            subtotal: { $gte: tot1, $lte: tot2 }
                        },
                        {
                            date: { $gte: startDate, $lte: endDate }
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'business' && customerName === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);
            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                    $and: [{
                            subtotal: { $gte: tot1, $lte: tot2 }
                        }, { customerType: customerType },
                        {
                            date: { $gte: startDate, $lte: endDate }
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'All' && subtotal === undefined && req.body.firstdate === undefined && req.body.lastdate === undefined) {
            item_modal.find({ customerName: customerName }, function(err, itemDetail) {
                if (err) {
                    res.json({ success: false, message: 'itemDetail single  Detail not found' });
                } else {
                    res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                }
            })
        } else if (customerType === 'All' && req.body.firstdate === undefined && req.body.lastdate === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);

            item_modal.find({
                    $and: [{
                            subtotal: { $gte: tot1, $lte: tot2 }
                        },
                        {
                            customerName: customerName
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'personal' && req.body.firstdate === undefined && req.body.lastdate === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);

            item_modal.find({
                    $and: [{
                            subtotal: { $gte: tot1, $lte: tot2 }
                        }, { customerType: customerType },
                        {
                            customerName: customerName
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'business' && req.body.firstdate === undefined && req.body.lastdate === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);

            item_modal.find({
                    $and: [{
                            subtotal: { $gte: tot1, $lte: tot2 }
                        }, { customerType: customerType },
                        {
                            customerName: customerName
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'All' && req.body.firstdate === undefined && req.body.lastdate === undefined && customerName === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);

            item_modal.find({

                    subtotal: { $gte: tot1, $lte: tot2 }

                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'personal' && req.body.firstdate === undefined && req.body.lastdate === undefined && customerName === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);

            item_modal.find({
                    $and: [{
                        subtotal: { $gte: tot1, $lte: tot2 }
                    }, { customerType: customerType }, ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'business' && req.body.firstdate === undefined && req.body.lastdate === undefined && customerName === undefined) {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);

            item_modal.find({
                    $and: [{
                        subtotal: { $gte: tot1, $lte: tot2 }
                    }, { customerType: customerType }, ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'All') {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);
            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                    $and: [{
                            subtotal: { $gte: tot1, $lte: tot2 }
                        },
                        {
                            date: { $gte: startDate, $lte: endDate }
                        }, {
                            customerName: customerName
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'personal') {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);
            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                    $and: [{
                            subtotal: { $gte: tot1, $lte: tot2 }
                        }, { customerType: customerType },
                        {
                            date: { $gte: startDate, $lte: endDate }
                        }, {
                            customerName: customerName
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        } else if (customerType === 'business') {
            var tot = subtotal.split("-");
            var tot1 = tot[0];
            var tot2 = tot[1];
            console.log('tot1', tot1);
            var startDate = new Date(req.body.firstdate.beginJsDate);
            startDate.setHours(00)
            startDate.setMinutes(00)
            startDate.setSeconds(00)
            var endDate = new Date(req.body.lastdate.endJsDate);
            endDate.setHours(23)
            endDate.setMinutes(59)
            endDate.setSeconds(59)
            console.log('startDate', startDate);
            console.log('endDate', endDate);
            item_modal.find({
                    $and: [{
                            subtotal: { $gte: tot1, $lte: tot2 }
                        }, { customerType: customerType },
                        {
                            date: { $gte: startDate, $lte: endDate }
                        }, {
                            customerName: customerName
                        }
                    ]
                },
                function(err, itemDetail) {
                    if (err) {
                        res.json({ success: false, message: 'itemDetail single  Detail not found' });
                    } else {
                        res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

                    }
                })

        }
    })
    /************Product Filter*******/
router.post('/productfilter', (req, res, next) => {
    let month1 = req.body.monthpick;
    let month2 = req.body.monthpick2;
    console.log('month2', month2);
    console.log('month1', month1);
    let firstdate = req.body.firstdate;
    let lastdate = req.body.lastdate;
    console.log('firstdate', firstdate);
    if (firstdate === undefined && lastdate === undefined) {
        var startDate = new Date(month1);
        startDate.setHours(00)
        startDate.setMinutes(00)
        startDate.setSeconds(00)
        var endDate = new Date(month2);
        endDate.setHours(23)
        endDate.setMinutes(59)
        endDate.setSeconds(59)
        console.log('startDate', startDate);
        console.log('endDate', endDate);
        item_modal.find({
            date: { $gte: startDate, $lte: endDate }
        }).select('date products ').exec(function(err, itemDetail) {
            if (err) {
                res.json({ success: false, message: 'itemDetail single  Detail not found' });
            } else {
                res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

            }
        })
    } else if (month1 === undefined && month2 === undefined) {
        var startDate = new Date(firstdate);
        startDate.setHours(00)
        startDate.setMinutes(00)
        startDate.setSeconds(00)
        var endDate = new Date(lastdate);
        endDate.setHours(23)
        endDate.setMinutes(59)
        endDate.setSeconds(59)
        console.log('startDate', startDate);
        console.log('endDate', endDate);
        item_modal.find({
            date: { $gte: startDate, $lte: endDate }
        }).select('date products ').exec(function(err, itemDetail) {
            if (err) {
                res.json({ success: false, message: 'itemDetail single  Detail not found' });
            } else {
                res.json({ success: true, itemDetail, message: 'itemDetail single datail found' });

            }
        })
    }


})
module.exports = router;