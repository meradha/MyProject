'use strict '

var mongoose = require('mongoose');

var Schema = mongoose.Schema;


var setting_Schema = new Schema({
    store_id: { type: String },
    companyName: { type: String, default: '' },
    companyLogo: { type: String, default: '' },
    companyPhone: { type: String, default: '' },
    companyEmail: { type: String, default: '' },
    companyDiscount: { type: String, default: '' },
    companyTax: { type: String, default: '' },
    companyImagename: { type: String, default: '' },
    companyHeaderParagraph: { type: String, default: '' },
    companyFooterParagraph: { type: String, default: '' },
    State: { type: String, default: '' },
    country: { type: String, default: '' },
    Address: { type: String, default: '' },
});



// Expose the model to other object (similar to a 'public' setter).
module.exports = mongoose.model('tbl_setting', setting_Schema);