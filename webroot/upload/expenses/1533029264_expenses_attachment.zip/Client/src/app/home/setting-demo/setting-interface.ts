export class SettingInterface {
       _id?: string;
    companyName: string ;
    companyLogo:  string ;
    companyPhone:string ;
    companyCode: string ;
    companyDiscount: string ;
    companyTax: string ;
    companyNumberDecimal: string ;
    companyTimer: string;
    companyHeaderParagraph: string ;
    companyFooterParagraph: string ;
    compnayStripeSecretkey: string ;
    compnayStripePublishedKey: string ;
}
