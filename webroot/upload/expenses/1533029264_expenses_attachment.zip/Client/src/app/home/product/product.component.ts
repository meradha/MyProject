import { Component, ViewChild, OnInit } from '@angular/core';
import { ModalComponent } from 'ng2-bs3-modal';
import { Http, Headers } from '@angular/http';
import {Router} from '@angular/router';
import {ReactiveFormsModule,FormsModule, FormGroup,FormControl,Validators,FormBuilder,NgForm} from '@angular/forms';
import {CategoriesProductInterface} from './product.interface';
import {CategoriesProductService} from './product.services';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers:[CategoriesProductService]
})
export class ProductComponent implements OnInit {
// it is related to bootstrap modal
 @ViewChild('myModal')
    modal: ModalComponent;
    viewmodal: ModalComponent;  // both are related to modal option
// interface declare
   categoriesProductInterfaces : CategoriesProductInterface[];
   categoriesProductInterface:  CategoriesProductInterface;
// variable declare
   categoryproductName: string ;
   categoCreateAt: string ;
   
   idd: string;
   value = [2,10,25,50,100];
   selectValue = this.value[1];
   // form varibale 
 
  

   constructor(private router: Router,private builder: FormBuilder,
               private categoriesProductService: CategoriesProductService) {
                 
               }
             

  ngOnInit() {
      // get request call
      this.categoriesProductService.getCategoriesProductRequest()  // get the teacher value
          .subscribe( categoriesProductInterfaces  => {
            console.log( categoriesProductInterfaces )
             this.categoriesProductInterfaces  = categoriesProductInterfaces;
          });

  }
   

 redirect(_id) {
    this.router.navigate(['home/category_edit_product', _id]);
  }

// this function is used for add modal value
  addProduct(f: NgForm) {
       console.log( this.categoryproductName);
       const newUser = {
              categoryproductName: this.categoryproductName,
              categoCreateAt: new Date
       }
              console.log(newUser);
              this.categoriesProductService.postCategoriesProducteRequest(newUser)
                   .subscribe( categoriesProductInterface=> {
                   this.categoriesProductInterfaces.push(categoriesProductInterface);
            //get request
            this.categoriesProductService.getCategoriesProductRequest()  // get the teacher value
            .subscribe( categoriesProductInterfaces  => {
              console.log( categoriesProductInterfaces )
               this.categoriesProductInterfaces  = categoriesProductInterfaces;
            });
      })
      
      f.reset();
  }

// apply  for Delete method request
  deleteCategoriesProduct(id: any) {
    this.categoriesProductService.deleteCategoriesProductRequest(id)  // get the teacher value
    .subscribe( categoriesProductInterfaces  => {
      if(categoriesProductInterfaces.success ===true) {
         alert('If you want to delet this Value, before delet existing value');
         console.log('categoriesProductInterfaces',categoriesProductInterfaces);
      } else {
        alert('Delete Value Successfully');
        this.categoriesProductService.getCategoriesProductRequest()  // get the teacher value
        .subscribe( categoriesProductInterface  => {
          console.log( categoriesProductInterface );
          this.categoriesProductInterfaces  = categoriesProductInterface;
        });
      }

    });
          }
    // apply for view value
  view(id) {
    console.log('id',id);
    this.categoriesProductService.getCategoriesProductSingle(id)
    .subscribe(  categoriesProductInterface => {
       this.categoriesProductInterface =  categoriesProductInterface.CategoryProductDetail;
       this.categoryproductName = categoriesProductInterface.CategoryProductDetail.categoryproductName;
       this.categoCreateAt =   categoriesProductInterface.CategoryProductDetail.categoCreateAt;
       console.log('categoriesProductInterface', categoriesProductInterface.CategoryProductDetail);
    });
    
  }
   closee(f:NgForm){
        f.reset();
        this.categoryproductName = null;
        this.categoCreateAt=null ;
        console.log('clear');
  }
}
