export class Expense_Top_Interface {
       _id?: string;
     expenseDate: string ;
    expenseReference:  string ;
    expenseCategory: string ;
    expenseStore: string ;
    expenseAmount: string ;
    expenseFileImage: string ;
    expenseParagraph: string 
    expenseCreatedBy: string;

}