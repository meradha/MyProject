import { Component, OnInit, ViewChild } from '@angular/core';
import {CustomerInterface} from '../customers/customer-interface';
import {CustomerService} from '../customers/customer-services';
import {Product_TopService} from '../product-top/product_Top.services';
import {Product_TopInterface} from '../product-top/product-top.interface';
import {CategoriesProductInterface} from '../product/product.interface';
import {CategoriesProductService} from '../product/product.services';
import { MyDateRangePickerModule } from 'mydaterangepicker';
import { ModalComponent } from 'ng2-bs3-modal';
import {ReactiveFormsModule,FormsModule, FormGroup,FormControl,Validators,FormBuilder,NgForm} from '@angular/forms';
import { Http, Headers } from '@angular/http';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { StoreInterface} from '../stores/store-interface';
import {StoreService } from '../stores/store.services';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module
import {Expense_Top_Interface} from '../expense-top-nav/expense-top.Interface';
import {Expense_TopService} from '../expense-top-nav/expense-top.services';
import {StoreTableService} from '../store-table-attach/storetable.services';
import * as d3 from 'd3-selection';
import { Ng2SearchPipeModule } from 'ng2-search-filter';

import * as d3Scale from 'd3-scale';
import * as d3Shape from 'd3-shape';
import * as d3Array from 'd3-array';
import { Ng2FilterPipeModule } from 'ng2-filter-pipe';
import {UsersPipe} from './filter.pipe';

import { Stats } from './stats';
import * as d3Axis from 'd3-axis';
import { Stocks } from './data';
import {WaitersInterface} from '../waiters/waiters-Interface';
import {WaiterService} from '../waiters/waiters.services';
import {CategoriesExpenseInterface} from '../expense/expeense.interface';
import {CategoriesExpenseService} from '../expense/expese.services';
@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css'],
  providers: [ CustomerService, Product_TopService,StoreTableService,WaiterService,
               CategoriesProductService,StoreService,Expense_TopService,CategoriesExpenseService]           
})
export class ReportsComponent implements OnInit {
  customerInterfaces: CustomerInterface[];
  customerInterface: CustomerInterface[];
  product_TopInterfaces: Product_TopInterface[];
  product_TopInterface: Product_TopInterface[];
  categoriesProductInterfaces: CategoriesProductInterface[];
  storeInterface:  StoreInterface[];
  waitersInterfaces: WaitersInterface[];
  ItemInterface: Product_TopInterface[];
  categoriesExpenseInterfaces: CategoriesExpenseInterface[];
  expenseInterface: Expense_Top_Interface[];fillcount=0;vacantcount=0;
  categoriesProductInterface: CategoriesProductInterface[];total;
  chartData = [];storeTax; 
  customerData = [];selectdate;selectmonth;
  productChartdata=[];monthpick;
  categoryproduct=[];
  categoryexpense = [];
  storelength;model;
  customerArray=[];
   selectedData=[];
   totalsum:number;totalexpesne:number;
  productArray=[];
  totalproductArray=[];
  selected;commercial;
 orderid;customertype;tax;TotalAmount;datetime;paymentstatus;
 customername;
 productmodel;firstdat;lastdat;
  clientstatus: ModalComponent;
  productstatus: ModalComponent;
  storestatus: ModalComponent;
  // variable declare
  customerName: string; datemodel: string; subtotal= 0;idd;

  /*********PIE Chart************/
  private margin = {top: 20, right: 20, bottom: 30, left: 10};
  private width: number;
  private width1:number;
  private height: number;
  private height1:number;
  private radius: number;
  firstdate;monthpick2;
  seconddate;
  totall;
  productdate =[];
 
  private arc: any;
  private labelArc: any;
  private pie: any;
  private color: any;
  private svg: any;
   private x: any;
  private y: any;
  private sv:any;count1=0;
    private line: d3Shape.Line<[number, number]>;
  constructor(private  customerService: CustomerService, private router: Router, private http: Http,private storeTableService:StoreTableService,
              private product_TopService: Product_TopService, private storeService: StoreService,private waiterService:WaiterService,
              private categoriesProductService: CategoriesProductService, private expense_TopService: Expense_TopService,private categoriesExpenseService:CategoriesExpenseService ) {
                  /********PIE Chart data*******/
                  this.width = 300 - this.margin.left - this.margin.right;
                  this.width1 = 500 - this.margin.left - this.margin.right;
                  this.height = 300 - this.margin.top - this.margin.bottom;
                  this.height1 = 500 - this.margin.top - this.margin.bottom;
                  this.radius = Math.min(this.width, this.height) / 2;
                  
               }
  ngOnInit() {
    this.initSvg1();
    this.initAxis();
    this.drawAxis();
    this.drawLine();
   
    // This Request  is used for get the value of the Pie Chart
    this.http.get('http://172.104.42.153:3005/api/Chart_Value' )
    .map((res) => res.json())
    .subscribe( ItemInterface => {
     // console.log(' ItemInterface ', ItemInterface.itemDetail );
     this.chartData=ItemInterface.itemDetail;
 //    console.log('this.chartData',this.chartData);
     /********PIE Chart function define*******/
    this.initSvg();
    this.drawPie();
    this.initTOPSvg();
     this.drawTOPPie();
    
  });
   /********Calculate total Expeensae******/
    this.http.get('http://172.104.42.153:3005/api/expense_get_value')
     .map((res) => res.json())
     .subscribe(data => {
        for(let i=0;i<data.length;i++){
       //  console.log('data',data[i].expenseAmount);
         this.totalexpesne=0;
         this.totalexpesne =parseInt(data[i].expenseAmount) +  this.totalexpesne;
       }
     })
   /*********TOP 5 Product Get Method *******/
    this.http.get('http://172.104.42.153:3005/api/item_list' )
    .map((res) => res.json())
    .subscribe( ItemInterface => {
      //console.log(' ItemInterface ', ItemInterface);
          this.productChartdata = ItemInterface;
       for(let i=0;i<ItemInterface.data.length;i++){
         this.totalsum = 0;
         this.totalsum = ItemInterface.data[i].subtotal + this.totalsum;
         console.log('this.totalsum',this.totalsum);
       }
  });

    /****This is used for Top Customer*********/
    // This Request  is used for get the value of the Pie Chart
    this.http.get('http://172.104.42.153:3005/api/Customer_Value' )
    .map((res) => res.json())
    .subscribe( ItemInterfacee => {
 //    console.log(' ItemInterfacee ', ItemInterfacee.itemDetail );
     this.customerData = ItemInterfacee.itemDetail;
     this.initSvgCustomer();
     this.drawPieCustomer();
   });

    let newValue = {
      date :new  Date
     };
 //  console.log('newValue',newValue);  
   var headers = new Headers();
   headers.append('Content-Type', 'application/json');
   this.http.post('http://172.104.42.153:3005/api/report_today', newValue,  { headers: headers})
      .map((res) => res.json())
      .subscribe( date => {
        this.total=0.0;
        for(let i=0;i<date.salesDetail.length;i++){
          // console.log('date.salesDetail',date.salesDetail[i]);
           this.total = parseFloat(date.salesDetail[i].subtotal)+ parseFloat(this.total);
          //   console.log('total',this.total);
      }
     });
    // get request call
    this.customerService.getCustomerRequest()
    .subscribe(  customerInterfaces => {
     // console.log(customerInterfaces);
       this.customerInterface =   customerInterfaces.length;
       this.customerInterfaces  =   customerInterfaces;
      // console.log(this.customerInterfaces);
    });

    // get value from product
    this.product_TopService.getProduct_TopRequest()
    .subscribe(  product_TopInterfaces  => {
       this.product_TopInterface  = product_TopInterfaces.length;
       this.product_TopInterfaces  = product_TopInterfaces;
     //  console.log('product',this.product_TopInterfaces);
    });
     // get request call
     this.categoriesProductService.getCategoriesProductRequest()  // get the teacher value
     .subscribe( categoriesProductInterfaces  => {
    //   console.log( categoriesProductInterfaces );
        this.categoriesProductInterface  = categoriesProductInterfaces.length;
        this.categoriesProductInterfaces  = categoriesProductInterfaces;

     });

     // get request for store call
      this.storeService.getStoreRequest()  // get the teacher value
          .subscribe(  storeInterfaces => {
           // console.log( storeInterfaces )
             this.storeInterface =  storeInterfaces;
             this.storelength= storeInterfaces.length;
             console.log('store',storeInterfaces[0]._id);
             let id= storeInterfaces[0]._id;
             this.idd = storeInterfaces[0]._id;
             this.storeTableService. getStoreTableRe(id) 
        .subscribe(  storeTableInterface => {
          //  console.log( 'storeTableInterface 2',storeTableInterface);
            for(let i=0;i<storeTableInterface.length;i++){
              if(storeTableInterface[i].status === true){
                this.vacantcount++;
            //    console.log('vacantcount',this.vacantcount);
              }else if(storeTableInterface[i].status === false) {
                 this.fillcount++
             //    console.log('fillcount',this.fillcount);
              } else {
                alert('Table is not added');
              }
            } 
            
        });
      });
    

    /**********Get the Waiters******************/
    this.waiterService.getWaitersRequest()
        .subscribe(  waitersInterfaces => {
        this.waitersInterfaces =  waitersInterfaces.length;
    });
    
    /**********Get the Bill No***********/
    this.http.get('http://172.104.42.153:3005/api/item' )
    .map((res) => res.json())
    .subscribe( ItemInterface => {
         let count=0;
         for(let i=0;i<ItemInterface.length;i++){
            if(ItemInterface[i].status === false ){
              count++;
             // console.log('count stats false',count++);
            } else {
              this.count1++;
            }
         }
    });

    /*********Get the Expesne Category length***********/
    this.categoriesExpenseService.getCategoriesExpenseRequest()  // get the teacher value
          .subscribe( categoriesExpenseInterfaces  => {
         // console.log( categoriesExpenseInterfaces )
          this.categoriesExpenseInterfaces  = categoriesExpenseInterfaces.length;
       });
    /********************Get the top Product  Category********************/ 
    this.http.get('http://172.104.42.153:3005/api/product_category' )
        .map((res) => res.json())
        .subscribe( data  => {
       //    console.log('data',data);
           this.categoryproduct = data.itemDetail;
         //  console.log('data',data.itemDetail);
           this.initSvgCategoryProduct();
           this.drawPieCategoryProduct(); 
    });

    /***********************Get the top expense Category***********************/
    this.http.get('http://172.104.42.153:3005/api/expense_Category')
         .map((res) => res.json())
          .subscribe( data  => {
         // console.log('data',data); 
          this.categoryexpense =  data.itemDetail;
          this.initSvgCategoryExpense();
           this.drawPieCategoryExpense(); 
    });
  }

  // this is function apply for modal open
  open() {
    this.clientstatus.open();

}

  // get the value
  ClientApi(customerName, datemodel) {

     let newValue = {
      customerName : customerName,
      datemodel   : datemodel
     };
     var headers = new Headers();
     headers.append('Content-Type', 'application/json');
    this.http.post('http://172.104.42.153:3005/api/item_get_Customer_value ', newValue,  { headers: headers})
        .map((res) => res.json())
        .subscribe( ItemInterface => {
          this.ItemInterface = ItemInterface.itemDetail[0];
         // console.log('Respoanse Value', ItemInterface.itemDetail);
         let subtotal = ItemInterface.itemDetail[0].subtotal;

         // this.customerName = ItemInterface.itemDetail.customerName;


       });
  }
   
   /*************Customer Redirection*********/
   customerredirection(){
     this.router.navigate(['home/customers']);
   }

   /***********Product Redirection*******/
   productredirection(){
       this.router.navigate(['home/product_top']);
       let date= new Date;
      // console.log(' date', date);
   }

   /********get Store************/
   getstore(event:Event){
       // console.log('event',event);
        let id = event;
       
       this.storeTableService.getStoreTableRe(id) 
        .subscribe(  storeTableInterface => {
          //  console.log( 'storeTableInterface 2',storeTableInterface);
            for(let i=0;i<storeTableInterface.length;i++){
              if(storeTableInterface[i].status === true){
                this.vacantcount++;
            //    console.log('vacantcount',this.vacantcount);
              }else if(storeTableInterface[i].status === false) {
                 this.fillcount++
             //    console.log('fillcount',this.fillcount);
              } else {
                alert('Table is not added');
              }
            } 
            
        });
   }
    /***********store Redirection*******/
   storeredirection(){
        let id = this.idd;
             this.router.navigate(['home/pos_next2',id]);
        
   }

   /********** PIE Chart function declare **********/
   private initSvg() {
    this.color = d3Scale.scaleOrdinal()
                         .range(["#0000FF", "#FF0000", "#800080", "#FFFF00", "#FFA500", "#C0C0C0", "#ff8c00"]);
    this.arc = d3Shape.arc()
                      .outerRadius(this.radius - 10)
                      .innerRadius(0);
    this.labelArc = d3Shape.arc()
                           .outerRadius(this.radius - 40)
                           .innerRadius(this.radius - 40);
    this.pie = d3Shape.pie()
                      .sort(null)
                      .value((d: any) => d.count);
                       
    this.svg = d3.select("svg")
                 .append("g")
                 .attr("transform", "translate(" + this.width / 2 + "," + this.height / 2 + ")");
  }

  private drawPie() {
   // console.log('this.chartData 2',this.chartData);
    let g = this.svg.selectAll(".arc")
                    .data(this.pie(this.chartData))
                    .enter().append("g")
                    .attr("class", "arc");
    g.append("path").attr("d", this.arc)
                    .style("fill", (d: any) => this.color(d.data._id));
                   
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")")
                    .attr("dy", ".35em")
                    .text((d: any) => d.data._id);
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")")
                    .attr("dy", "35px")
                    .text((d: any) => d.data.count);
                    
  }

  /*********Customer for Pie Chart*******/
  private initSvgCustomer(){
    this.color = d3Scale.scaleOrdinal()
                         .range(["#0000FF", "#FF0000", "#800080", "#FFFF00", "#FFA500", "#C0C0C0", "#ff8c00"]);
    this.arc = d3Shape.arc()
                      .outerRadius(this.radius - 10)
                      .innerRadius(0);
    this.labelArc = d3Shape.arc()
                           .outerRadius(this.radius - 40)
                           .innerRadius(this.radius - 40);
    this.pie = d3Shape.pie()
                      .sort(null)
                      .value((d: any) => d.count);
                     
    this.svg = d3.select("#piechart")
                 .append("g")
                 .attr("transform", "translate(" + this.width / 2 + "," + this.height / 2 + ")"); 
  }

  private drawPieCustomer(){
   ///  console.log('this.customerData 2',this.customerData);
    let g = this.svg.selectAll(".arc")
                    .data(this.pie(this.customerData))
                    .enter().append("g")
                    .attr("class", "arc");
    g.append("path").attr("d", this.arc)
                    .style("fill", (d: any) => this.color(d.data._id) );
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")")
                    .attr("dy", "3px")
                    .text((d: any) => d.data._id);
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")")
                    .attr("dy", "25px")
                    .text((d: any) => d.data.count); 
  }

  /**********Top 5 Products*******/
  private initTOPSvg() {
    this.color = d3Scale.scaleOrdinal()
                         .range(["#0000FF", "#FF0000", "#800080", "#FFFF00", "#FFA500", "#C0C0C0", "#ff8c00"]);
    this.arc = d3Shape.arc()
                      .outerRadius(this.radius - 10)
                      .innerRadius(0);
    this.labelArc = d3Shape.arc()
                           .outerRadius(this.radius - 40)
                           .innerRadius(this.radius - 40);
    this.pie = d3Shape.pie()
                      .sort(null)
                      .value((d: any) => d.count);
                       
    this.svg = d3.select("#piechartproduct")
                 .append("g")
                 .attr("transform", "translate(" + this.width / 2 + "," + this.height / 2 + ")");
  }

  private drawTOPPie() {
    let g = this.svg.selectAll(".arc")
                    .data(this.pie(this.chartData))
                    .enter().append("g")
                    .attr("class", "arc");
    g.append("path").attr("d", this.arc)
                    .style("fill", (d: any) => this.color(d.data._id));
                   
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")")
                    .attr("dy", ".35em")
                    .text((d: any) => d.data._id)
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")")
                    .attr("dy", "25px")
                    .text((d: any) => d.data.count);                
  }

  /*************Waiter Redirection**********/
  waiterredirection(){
     this.router.navigate(['home/waiters']);
  }
  /**********Store Redirection********/
  storeredirectio(){
    this.router.navigate(['home/stores']);
  }
 
  /************Category Product Redirection**************/
  productcategoryredirectio(){
     this.router.navigate(['home/product']);
  }
  expensecategoryredirectio(){
     this.router.navigate(['home/expense']);
  }

  /**********Pie chart for Top Product Categories*************/
  private initSvgCategoryProduct() {
    this.color = d3Scale.scaleOrdinal()
                         .range(["#0000FF", "#FF0000", "#800080", "#FFFF00", "#FFA500", "#C0C0C0", "#ff8c00"]);
    this.arc = d3Shape.arc()
                      .outerRadius(this.radius - 10)
                      .innerRadius(0);
    this.labelArc = d3Shape.arc()
                           .outerRadius(this.radius - 40)
                           .innerRadius(this.radius - 40);
    this.pie = d3Shape.pie()
                      .sort(null)
                      .value((d: any) => d.count);
                       
    this.svg = d3.select("#productCategory")
                 .append("g")
                 .attr("transform", "translate(" + this.width / 2 + "," + this.height / 2 + ")");
  }

  private drawPieCategoryProduct() {
    let g = this.svg.selectAll(".arc")
                    .data(this.pie( this.categoryproduct))
                    .enter().append("g")
                    .attr("class", "arc");
    g.append("path").attr("d", this.arc)
                    .style("fill", (d: any) => this.color(d.data._id));
                   
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")")
                    .attr("dy", ".35em")
                    .text((d: any) => d.data._id)
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")")
                    .attr("dy", "25px")
                    .text((d: any) => d.data.count);                
  }

  /**************Pie chart for Top Expense Categories****************/
  private initSvgCategoryExpense() {
    this.color = d3Scale.scaleOrdinal()
                        .range(["#0000FF", "#FF0000", "#800080", "#FFFF00", "#FFA500", "#C0C0C0", "#ff8c00"]);
    this.arc = d3Shape.arc()
                      .outerRadius(this.radius - 10)
                      .innerRadius(0);
    this.labelArc = d3Shape.arc()
                           .outerRadius(this.radius - 40)
                           .innerRadius(this.radius - 40);
    this.pie = d3Shape.pie()
                      .sort(null)
                      .value((d: any) => d.count);
                       
    this.svg = d3.select("#expenseCategory")
                 .append("g")
                 .attr("transform", "translate(" + this.width / 2 + "," + this.height / 2 + ")");
  }

  private drawPieCategoryExpense() {
    let g = this.svg.selectAll(".arc")
                    .data(this.pie( this.categoryexpense))
                    .enter().append("g")
                    .attr("class", "arc");
    g.append("path").attr("d", this.arc)
                    .style("fill", (d: any) => this.color(d.data._id));
                   
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")")
                    .attr("dy", ".35em")
                    .text((d: any) => d.data._id)
    g.append("text").attr("transform", (d: any) => "translate(" + this.labelArc.centroid(d) + ")")
                    .attr("dy", "25px")
                    .text((d: any) => d.data.count);                
  }

  
   /************Draw the Expesen Chart ********/
  private initSvg1() {
    this.svg = d3.select("#svg1")
                 .append("g")
                 .attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");
  }
   private initAxis() {
    this.x = d3Scale.scaleTime().range([0, this.width1]);
    this.y = d3Scale.scaleLinear().range([this.height1, 0]);
    this.x.domain(d3Array.extent(Stocks, (d) => d.date ));
    this.y.domain(d3Array.extent(Stocks, (d) => d.value ));
  }
  private drawAxis() {

    this.svg.append("g")
          .attr("class", "axis axis--x")
          .attr("transform", "translate(0," + this.height + ")")
          .call(d3Axis.axisBottom(this.x));

    this.svg.append("g")
          .attr("class", "axis axis--y")
          .call(d3Axis.axisLeft(this.y))
          .append("text")
          .attr("class", "axis-title")
          .attr("transform", "rotate(-90)")
          .attr("y", 6)
          .attr("dy", ".71em")
          .style("text-anchor", "end")
          .text("Price ($)");
  }
  private drawLine() {
    this.line = d3Shape.line()
                       .x( (d: any) => this.x(d.date) )
                       .y( (d: any) => this.y(d.value) );

    this.svg.append("path")
            .datum(Stocks)
            .attr("class", "line")
            .attr("d", this.line);
  }

  /*********Customer Search Filter*****************/
  ApplyFilter(myForm:NgForm){
    if( this.commercial == null){
      this.commercial = undefined;
    }
    if(this.customername === ""){
      this.customername = undefined;
    }
    if(this.selected === ""){
      this.selected = undefined;
    }

    
    if(this.model === null){
      this.model = undefined;
    }
    let newValue ={
      customerType: this.commercial,
      firstdate: this.model,
      lastdate: this.model,
      total:this.selected,
      customername: this.customername
    }
    console.log('newValue',newValue);
     var headers = new Headers();
     headers.append('Content-Type', 'application/json');
    this.http.post('http://172.104.42.153:3005/api/customerfilter',newValue,{ headers: headers})
        .map((res) => res.json())
        .subscribe(data => {
          console.log('data',data);
           this.customerArray = data.itemDetail;
    });
  }
  /****Reset customer search********/
  reset1(){
    this.model = undefined;
    this.customername = undefined;
    this.selected= undefined;
    this.commercial= undefined;
  
  } 
  /*************Apply filter for Product*******************/
  ApplyFilterMonth(){
    /*************** it is declared for array cleared*********/
    if(this.firstdat === null &&  this.lastdat === null){
       this.firstdat = undefined;
       this.lastdat =undefined;
    } if(this.monthpick === null){
      this.monthpick = undefined;
    }
    if( this.firstdat === undefined && this.lastdat === undefined){
    let adddate = '-01'
    let adddate1 = '-30'
    let newdate = this.monthpick.concat(adddate);
    let newdate2 = this.monthpick2.concat(adddate1);
    console.log('newdate', newdate);
    let newvalue ={  
      firstdate:this.firstdat,
      lastdate: this.lastdat,
      monthpick :newdate,
      monthpick2:newdate2
    }
    
     
    console.log('newValue',newvalue);
     var headers = new Headers();
     headers.append('Content-Type', 'application/json');
    this.http.post('http://172.104.42.153:3005/api/productfilter', newvalue,{ headers: headers})
        .map((res) => res.json())
        .subscribe(data => {
           this.productdate =data.itemDetail;
           for(let i=0;i<data.itemDetail.length;i++){
               let x= data.itemDetail[i];
             for(let j=0; j<x.products.length;j++){
               this.productArray.push(x.products[j]);
             }
           }
           /************get the single array*********/
          for(let i=0;i<this.productArray.length;i++){
             let productNAme = this.productArray[i].productName;
             let price = this.productArray[i].price;
             if(!this.totalproductArray.length){
               this.totalproductArray.push({productName:productNAme,price:price});
               console.log(' this.totalproductArray1', this.totalproductArray);
             } else {
               let  count= 0;
               let productArraylength = 0;
                for(let j = 0; j< this.totalproductArray.length; j++ ) {
                //  console.log('this.totalproductArray2',this.totalproductArray);
                    productArraylength++;
                    if(this.totalproductArray[j].productName === this.productArray[i].productName) {
                        count++; 
                      //  console.log(count);
                    }else {
                      //console.log(count);
                    }
                } 
                if(count ===0){
                   this.totalproductArray.push({productName:productNAme,price:price});
                   console.log(' this.totalproductArray2', this.totalproductArray);
                } else {
                   for(let j = 0; j< this.totalproductArray.length; j++ ){
                      if(this.totalproductArray[j].productName === this.productArray[i].productName){
                         this.totalproductArray[j].price += this.productArray[i].price;
                         console.log('this.totalproductArray[j].price');
                      }
                   }
                }
            }
          }
    });
  } else if(this.monthpick === undefined ){
    let newvalue ={  
      monthpick:this.firstdat,
      monthpick2: this.lastdat,
    }
    console.log('newValue',newvalue);
     var headers = new Headers();
     headers.append('Content-Type', 'application/json');
    this.http.post('http://172.104.42.153:3005/api/productfilter', newvalue,{ headers: headers})
        .map((res) => res.json())
        .subscribe(data => {
           this.productdate =data.itemDetail;
           for(let i=0;i<data.itemDetail.length;i++){
               let x= data.itemDetail[i];
             for(let j=0; j<x.products.length;j++){
               this.productArray.push(x.products[j]);
             }
           }
           /************get the single array*********/
          for(let i=0;i<this.productArray.length;i++){
             let productNAme = this.productArray[i].productName;
             let price = this.productArray[i].price;
             if(!this.totalproductArray.length){
               this.totalproductArray.push({productName:productNAme,price:price});
               console.log(' this.totalproductArray1', this.totalproductArray);
             } else {
               let  count= 0;
               let productArraylength = 0;
                for(let j = 0; j< this.totalproductArray.length; j++ ) {
                //  console.log('this.totalproductArray2',this.totalproductArray);
                    productArraylength++;
                    if(this.totalproductArray[j].productName === this.productArray[i].productName) {
                        count++; 
                      //  console.log(count);
                    }else {
                      //console.log(count);
                    }
                } 
                if(count ===0){
                   this.totalproductArray.push({productName:productNAme,price:price});
                   console.log(' this.totalproductArray2', this.totalproductArray);
                } else {
                   for(let j = 0; j< this.totalproductArray.length; j++ ){
                      if(this.totalproductArray[j].productName === this.productArray[i].productName){
                         this.totalproductArray[j].price += this.productArray[i].price;
                         console.log('this.totalproductArray[j].price');
                      }
                   }
                }
            }
          }
    });
  }
  }
  /************Apply Reset************/
  appplyreset(){
    this.firstdat =undefined;
    this.lastdat = undefined;
    this.monthpick = undefined;
    this.monthpick2 = undefined;
     this.totalproductArray.push();
  }



}