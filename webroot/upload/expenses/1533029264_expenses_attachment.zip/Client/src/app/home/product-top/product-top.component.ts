import { Injectable,Component, ViewChild, OnInit,  Pipe, PipeTransform,Input, Output, ElementRef, EventEmitter, AfterViewInit } from '@angular/core';
import { ModalComponent } from 'ng2-bs3-modal';
import {BrowserModule} from '@angular/platform-browser'

import { Http, Headers ,Response} from '@angular/http';
import {Router} from '@angular/router';
import {Product_TopService} from './product_Top.services';
import {Product_TopInterface}  from './product-top.interface';
import { SupplyInterface} from '../suppliers/supplers-interface';
import {SupplyService} from '../suppliers/supplers-services';
import {CategoriesProductInterface} from '../product/product.interface';
import {CategoriesProductService} from '../product/product.services';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { Ng2FilterPipeModule } from 'ng2-filter-pipe';
import { Observable } from 'rxjs';
import {ReactiveFormsModule,FormsModule, FormGroup,FormControl,Validators,FormBuilder,NgForm} from '@angular/forms';
// import {TypeFilterPipe} from './type-filter.pipe';
// import {SupplierFilterPipe} from './supplier-filter.pipe';
import 'rxjs/add/operator/toPromise';
declare var $: any;
import { FileUtil } from './file.util';

@Component({
  selector: 'app-product-top',
  templateUrl: './product-top.component.html',
   styleUrls: ['./product-top.component.css'],
  providers:[Product_TopService,SupplyService, CategoriesProductService, FileUtil ]
})

export class ProductTopComponent implements OnInit  {
  option: string;
  id:any
  csvData: any[] = [];
   csvRecords = [];
  value = [2,10,25,50,100];productCategoryID;
  selectValue = this.value[1];
   fileImportInput: any;

@ViewChild('myModal')
    modal: ModalComponent;
    modal2:  ModalComponent; // there are related to modal option.
    ViewModal: ModalComponent;
    ImageModal: ModalComponent;
    validate(value)  {
    value < 0 ? this.productTax = '0' : this.productTax = value;
  }

// iterface declare  which is part of the   Product_Top component
   product_TopInterfaces: Product_TopInterface[];
   product_TopInterface :Product_TopInterface;
   product_modelInterface: Product_TopInterface[];
   typeSearch;

// interface declare which is part of the suppliers component
   supplyInterfaces: SupplyInterface[];

// interface declare which is part of the   CategoriesProduct
   categoriesProductInterfaces: CategoriesProductInterface[];
   categoriesProductInterface: CategoriesProductInterface[];

// variable declare
       productType: string ;supplerSearch;
       productCode: string ;
       productName: string ;
       productCategory: string;
       productSupplier: string ;
       productPurchasePrice: string ;
       productTax: string ;
       productTaxMethod: string;
       productPriceINR: string;
       productUnit: string ;
       productAlertQuantity: string ;
       productDiscription: string ;
       productImage: string ;
       productParagraph: string ;
       postax:number;categoryproductName;
       price:number;
       taxrate:number;
  constructor(private http: Http,private _fileUtil: FileUtil,
              private router: Router,
              private product_TopService: Product_TopService,
              private supplyService: SupplyService,
              private categoriesProductService: CategoriesProductService,private _rootNode: ElementRef ) { }
   // it is related to modal option


// this is declare for get the View Modal value show
   transferid(id){

     console.log('view the',id);
      // get the id from single value
    this.product_TopService.getProduct_TopmodalRequest(id )
    .subscribe(  product_modelInterface => {
       this.product_modelInterface =  product_modelInterface.ProductDetail
       this.productType = product_modelInterface.ProductDetail.productType
       this.productCode =  product_modelInterface.ProductDetail.productCode
       this.productName = product_modelInterface.ProductDetail.productName
       this.productCategory =  product_modelInterface.ProductDetail.productCategory
       this.productSupplier  =  product_modelInterface.ProductDetail.productSupplier
       this.productPurchasePrice = product_modelInterface.ProductDetail.productPurchasePrice
       this.productTax =  product_modelInterface.ProductDetail.productTax
       this.productTaxMethod = product_modelInterface.ProductDetail.productTaxMethod
       this.productPriceINR =  product_modelInterface.ProductDetail.productPriceINR
       this.productUnit =  product_modelInterface.ProductDetail.productUnit
       this.productAlertQuantity = product_modelInterface.ProductDetail.productAlertQuantity
       this.productDiscription =  product_modelInterface.ProductDetail.productDiscription
       this.productImage = product_modelInterface.ProductDetail.productImage
       this.productParagraph =  product_modelInterface.ProductDetail.productParagraph
       console.log( 'proDuct Value show',product_modelInterface)
    });

   }
  ngOnInit() {
     // get method for product-top component
     this.product_TopService.getProduct_TopRequest()
          .subscribe(  product_TopInterfaces  => {
            console.log( product_TopInterfaces )
             this.product_TopInterfaces  = product_TopInterfaces;
      });


      // get request call for supply get request
     this.supplyService.getSupplyRequest()
          .subscribe(  supplyInterfaces => {
            console.log( supplyInterfaces)
             this.supplyInterfaces =  supplyInterfaces
             console.log(this.supplyInterfaces);
      });
      // get request call
      this.categoriesProductService.getCategoriesProductRequest()
          .subscribe( categoriesProductInterfaces  => {
            console.log( categoriesProductInterfaces )
             this.categoriesProductInterfaces  = categoriesProductInterfaces
      });

  }


    // button click and set routing
     redirect(id) {
    this.router.navigate(['home/product_top_edit',id]);
  }
   /*******get the Category*******/
   getcategory(event:Event){
     console.log('event',event);
     this.productCategoryID = event;
     let id= event;
     this.categoriesProductService.getCategoriesProductSingle(id)
            .subscribe(  categoriesProductInterface => {
               this.categoriesProductInterface =  categoriesProductInterface.CategoryProductDetail;
               this.categoryproductName = categoriesProductInterface.CategoryProductDetail.categoryproductName;
               console.log( 'categoriesProductInterface,',this.categoriesProductInterface);
            });

   }
  // this function is used for add modal value
 addProduct_Top(f:NgForm) {

       const newUser = {
              productType: this.productType,
              productCode:this.productCode,
              productName: this.productName,
              productCategory: this.categoryproductName,
              productSupplier: this.productSupplier,
              productPurchasePrice: this.productPurchasePrice,
              productTax: this.productTax,
              productCategoryID:this.productCategoryID,
              productTaxMethod: this.productTaxMethod,
              productPriceINR: this.productPriceINR,
              productUnit: this.productUnit,
              productAlertQuantity: this.productAlertQuantity,
              productDiscription: this.productDiscription,
              productImage: this.productImage,
              productParagraph: this.productParagraph
       }
              console.log(newUser);
              console.log('productCategoryID',this.productCategoryID);
              for(let i=0; i< this.product_TopInterfaces.length;i++){
                if( this.product_TopInterfaces[i].productCode == this.productCode){
                  alert('Product Code is Already Existing');
                }
             }

              this.product_TopService. postProduct_TopRequest(newUser)
                   .subscribe( product_TopInterface=> {
                   this.product_TopInterfaces.push(product_TopInterface);
              // get the Value
              this.product_TopService.getProduct_TopRequest()
                   .subscribe(  product_TopInterfaces  => {
                     console.log( product_TopInterfaces )
                      this.product_TopInterfaces  = product_TopInterfaces
                   });
                  f.reset();
              })
                

       
}

// apply  for Delete method request
  deleteProduct_Top(id: any) {
         console.log('id',id);
         var product_TopInterfaces = this.product_TopInterfaces;
         this.product_TopService. deleteProduct_TopRequest(id)
             .subscribe(data => {
              if (data.n == 1) {
                 for ( let i = 0 ; i  < product_TopInterfaces.length; i++) {
                      if (product_TopInterfaces[i]._id == id)
                      // tslint:disable-next-line:one-line
                      {
                      product_TopInterfaces.splice(i, 1);
                      }
                 }
              }
            })
    }
// this function is related to show and hide option in modal option
 onSelect(option: string) {
    this.option = option

  }

  // download request csv file
 url ='http://172.104.42.153:3005/api/product_get_value';
  sendDownloadRequest(url) {
    console.log('show the url',url);
    let headers = new Headers({
        'Content-Type': 'text/csv'
    });
    return this.http.get('http://172.104.42.153:3005/api/product_get_value', { headers: headers })
        .toPromise()
        .then(res => {
            if(res && res["_body"]){
                this.downloadFile(res["_body"]);
            }
        })
        .catch(this.handleError);
}

handleError(error){  
    console.log("error--  "+error);
}

downloadFile(data){
    let blob = new Blob(['\ufeff' + data], { type: 'text/csv;charset=utf-8;' });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {  //if Safari open in new window to save file with random filename.
    dwldLink.setAttribute("target", "_blank");
}
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", "Product.csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
}

// function apply for sorting
CustomSearch(filtersupp,filtertype) {
  console.log('filtersupp',filtersupp);
  console.log('filtertype',filtertype);
  this.typeSearch  = filtertype;
  this.supplerSearch = filtersupp;
}

fileChanged(e: Event) {
    var target: HTMLInputElement = e.target as HTMLInputElement;
    for ( var i = 0;i < target.files.length; i++) {
        this.upload(target.files[i]);
        console.log('targert',target.files[i])
    }
  }
  upload(file) {
    
       var formData: FormData = new FormData();
       formData.append('file', file);
       console.log('file',file);
       this.productImage = file.name;
       var xhr = new XMLHttpRequest();
       xhr.upload.addEventListener('progress', (ev: ProgressEvent) => {});
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                  let   resolve = (JSON.parse(xhr.response))
                  console.log('response', resolve)
                } else {
                  let  reject = (xhr.response)
                }
            }
        }
       xhr.open('POST', 'http://172.104.42.153:3005/uploadFile',file);
       console.log('post image value', file);
       xhr.send(formData);
   
    }
    // METHOD CALLED WHEN CSV FILE IS IMPORTED
  fileChangeListener($event): void {
    var text = [];
    var files = $event.srcElement.files;
    if (this._fileUtil.isCSVFile(files[0])) {
      var input = $event.target;
      var reader = new FileReader();
      reader.readAsText(input.files[0]);
      reader.onload = (data) => {
        let csvData = reader.result;
        let csvRecordsArray = csvData.split(/\r\n|\n/);
        let headersRow = this._fileUtil
            .getHeaderArray(csvRecordsArray);
        this.csvRecords = this._fileUtil
            .getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
      }
      reader.onerror = function () {
        alert('Unable to read ' + input.files[0]);
      };
    } else {
      alert("Please import valid .csv file.");
      this.fileReset();
    }
  };
  fileReset(){
    this.fileImportInput.nativeElement.value = "";
    this.csvRecords = [];
  }
  /*********Clear the Model After View OPtion again add Produc********/
  closee(f:NgForm){
        f.reset();
          this.productType = null;
       this.productCode =  null;
       this.productName = null;
       this.productCategory =  null;
       this.productSupplier  =  null;
       this.productPurchasePrice = null;
       this.productTax =  null;
       this.productTaxMethod = null;
       this.productPriceINR =  null;
       this.productUnit = null;
       this.productAlertQuantity = null;
       this.productDiscription =  null;
       this.productImage = null;
       this.productParagraph =  null;
        console.log('clear');
  }



}
