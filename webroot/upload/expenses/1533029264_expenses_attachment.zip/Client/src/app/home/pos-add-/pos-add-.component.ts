import { Component,  ViewChild, OnInit,Pipe, PipeTransform , NgZone} from '@angular/core';
import {Product_TopService} from '../product-top/product_Top.services';
import {Product_TopInterface} from '../product-top//product-top.interface';
import { ModalComponent } from 'ng2-bs3-modal';
import { StoreTableInterface} from '../store-table-attach/store_table.interface';
import {CustomerInterface} from '../customers/customer-interface';
import {CustomerService} from '../customers/customer-services';
import {Router,ActivatedRoute,Params} from '@angular/router';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {WaitersInterface} from '../waiters/waiters-Interface';
import {  Response, Headers, RequestOptions, Http, HttpModule } from '@angular/http';
import {WaiterService} from '../waiters/waiters.services';
import {CategoriesProductInterface} from '../product/product.interface';
import {CategoriesProductService} from '../product/product.services';
import {POSService } from './pos.add.services';
import {PosInterface} from './pos.add.interface';
import {Pos} from './interface';
import {Item} from './interface';
import 'rxjs/add/operator/map';
import { StoreInterface} from '../stores/store-interface';
import {StoreService } from '../stores/store.services';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Observable';
import jsPDF from 'jspdf';
import {StoreTableService} from '../store-table-attach/storetable.services';
import {TabComponent} from './tab';
import {SettingService} from '../setting-demo/setting-services';
import { SettingInterface} from '../setting-demo/setting-interface';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import {ReactiveFormsModule,FormsModule, FormGroup,FormControl,Validators,FormBuilder,NgForm} from '@angular/forms'; 
@Component({
  selector: 'app-pos-add-',
   template: `
    <app-spinner></app-spinner>`,
  templateUrl: './pos-add-.component.html',
  styleUrls: ['./pos-add-.component.css'],
  providers:[Product_TopService, CustomerService, WaiterService,StoreTableService,StoreService,
             CategoriesProductService, POSService,SettingService, Ng4LoadingSpinnerService]
})
export class PosAddComponent implements OnInit {
  @ViewChild('myModal')
  customermodal: ModalComponent;
  paymentmodal: ModalComponent;
  receiptmodal:  ModalComponent;
  id:any;sumtotal;totalsum=[];
  date;
  option: string;
  private sub: any;
  customerID;
  // interface declare
  product_TopInterfaces: Product_TopInterface[]; customerInterfaces: CustomerInterface[]; waitersInterfaces: WaitersInterface[];
  posInterfac: PosInterface[]; posInterfaces: PosInterface[]; posInterface: PosInterface[]; posArray: PosInterface[];
  categoriesProductInterfaces: CategoriesProductInterface[];
  settingInterfaces:SettingInterface[];
  customerInterface:CustomerInterface[];
  storeTableInterface:StoreTableInterface[];
  storeInterface:StoreInterface[];
  currentItem = 'personal';
  

  // varibale deaclare
   // variable dealcreation
   companyName;customerType;
    customercountry:string;tab;
    companyGst:string;commercial;productTax; productTaxMethod;Taxx;diffCgst;diffSgst;diffIgst;
   customerName: string ; customerPhone: string ; customerEmail: string ; taxArraylength: number;
   customerDiscount: string ; customerCreatedAt: string ; customerState: string;
   customerAddress: string; POSquanity: number; dummy: string; count = 0;
   CGST; IGST; SGST; productPriceINR: string; productName: string;custState;
   POScustomerName: string ; total; POSproduct_Name: string;customerTrip;
    POSwaiterName: string; POStotalPrize: number; waiterName: string; POSsubtotal= 0;
  Statecontent: string; price; difference; Posid: string;customName:string;
  POScustomer: string; POSphon: string; POSstate: string;disablevalue;
  checknumber: string; creditcardnumber: string; differentIGST;settingSate;
  creditcardholder: string; differentCGST ; differentSGST; item;  store;
  show_count: string; show_total: string; show_customerName: string; show_waitername: string;
   private POSValue: Array<Pos>; POScustomerState: string; show_id: string; filterName: string = null;
   private data= []; ArrayItem = [];
   AddCart= [];
   ItemAdd=[];totalsum1;
   A=[]; B=[];zonecode;
   value = ['Cash'];
   paymentMethod = this.value[0];


  constructor(private http: Http, private product_TopService: Product_TopService,private storeTableService:StoreTableService,
              private customerService: CustomerService,private  settingService:SettingService,
              private router: Router,private spinnerService: Ng4LoadingSpinnerService,
              private route: ActivatedRoute,private storeService:StoreService,
              private waiterService: WaiterService,
              private categoriesProductService: CategoriesProductService,
               private pOSService: POSService, private zone: NgZone) {
                this.POSValue = [];
                this.date = new  Date;
               }


  ngOnInit() {
    // params define
    this.route.params.subscribe(params => this.id=params);
     // get single value  request call ans show the value on display
     this.pOSService.getItemSingleRequest(this.id )
     .subscribe(  PosInterface => {
        this.ArrayItem  = PosInterface.itemDetail;
        this.posInterface = PosInterface.itemDetail;
        this.customerName = PosInterface.itemDetail[0].customerName;
        this.show_id = PosInterface.itemDetail[0].Posid;
        this.show_waitername =   PosInterface.itemDetail[0].WaiterNameName;
        this.custState= PosInterface.itemDetail[0].customerState;
        this.totalsum1=  PosInterface.itemDetail[0].total;
        this.totalsum.push({sumtotal:this.totalsum1})
      //  console.log('custState',PosInterface.itemDetail);
        this.customerState= PosInterface.itemDetail[0].customerState;
        this.count = parseInt(PosInterface.itemDetail[0].count) + this.count;
        this.POSsubtotal= parseFloat(PosInterface.itemDetail[0].subtotal) + this.POSsubtotal;
        this.AddCart = PosInterface.itemDetail[0].products;
        this.ArrayItem = PosInterface.itemDetail[0].gst;
        for(let i=0;i<this.ArrayItem.length;i++){
        //  console.log('this.ArrayItem[i].gst',this.ArrayItem[i])
          this.diffCgst = this.ArrayItem[i].differentCGST;
          this.diffSgst = this.ArrayItem[i].differentSGST;
          this.diffIgst = this.ArrayItem[i].differentIGST;
       //   console.log('this.diffCgst',this.diffCgst);
        }
         
     });
   // get method for product-top component
   this.product_TopService.getProduct_TopRequest()
   .subscribe(  product_TopInterfaces  => {
      this.product_TopInterfaces  = product_TopInterfaces;
   });

      this.storeTableService.getStoreTableSingleRequest(this.id )
            .subscribe( storeTableInterface => {
               this.storeTableInterface =  storeTableInterface.StoreTableDetail
               this.zonecode=  storeTableInterface.StoreTableDetail.zonecode;
             //  console.log( 'this.zonecode',this.zonecode);
               let id= this.zonecode;
                this.storeService.getStoreSingle(id)
              .subscribe(  storeInterface => {
            this.storeInterface = storeInterface.StoreDetail;
             this.settingSate = storeInterface.StoreDetail.storestate;
             this.productTax = storeInterface.StoreDetail.storeTax;
            });
      });
              

   // get request method for Customer Component
   this.customerService.getCustomerRequest()  // get the teacher value
   .subscribe(  customerInterfaces => {
      this.customerInterfaces =   customerInterfaces;
   });

   // get request method used for Waiter Component
   this.waiterService.getWaitersRequest()
   .subscribe(  waitersInterfaces => {
     // console.log( waitersInterfaces)
      this.waitersInterfaces =  waitersInterfaces;
   });


   // get request  method used for Category Product compoent
   // get request call
   this.categoriesProductService.getCategoriesProductRequest()  // get the teacher value
   .subscribe( categoriesProductInterfaces  => {
     // console.log( 'category value',categoriesProductInterfaces.categoryproductName )
      this.categoriesProductInterfaces  = categoriesProductInterfaces;
   });
    this.settingService.getSettingrRequest()
          .subscribe( settingInterfaces => {
            this.settingInterfaces = settingInterfaces.Setting;
         //   console.log( 'this.settingInterfaces',  this.settingInterfaces);
           
           
          });

}
  getcustomer(event:Event):void{
        console.log('customer',event);
        let id = event;
        console.log('id',id);
        this.customerService.getCustomerSingle(id )
       .subscribe(customerInterface => {
       this.customerInterface =  customerInterface.CustomerDetail;
       this.customerID=  id;
       this.custState = customerInterface.CustomerDetail.customerState;
       this.customerName = customerInterface.CustomerDetail.customerName;
       this.customerType = customerInterface.CustomerDetail.commercial;
       console.log(' this.customerType',  this.customerType);
       this.calculation(this.custState);
       });
  }
 // apply the post method request  for Customer Component
 // apply for post method request
 addCustomer(f:NgForm) {
  // console.log( this.customerName);
     let _id= this.id;
      const newCustomers = {
             commercial:this.commercial,
             companyName:this.companyName,
             companyGst:this.companyGst,
             customerName: this.customerName,
             customerPhone: this.customerPhone,
             customerState: this.customerState,
             customerAddress: this.customerAddress,
             customerEmail: this.customerEmail,
             customerDiscount: this.customerDiscount,
             customerCreatedAt: new Date
      }
           //  console.log( newCustomers);
            this.spinnerService.show();
             this.customerService.postCustomerRequest( newCustomers)
                  .subscribe( customerInterface => {
                  this.customerInterfaces.push(customerInterface);
             // get the value
             this.spinnerService.show();
             this.customerService.getCustomerRequest()
             .subscribe(  customerInterfaces => {
               // console.log(customerInterfaces)
                this.customerInterfaces =   customerInterfaces;
               // console.log(this.customerInterfaces);
               this.spinnerService.hide();
             });

        })
        f.reset();
        console.log('id',_id);
       // this.router.navigate(['home/PosAddComponent', id]);
}
// this function is used fot filter category
onSelect(dummy: string) {
  this.dummy = dummy
 // console.log('dummy',this.dummy);

}

onclick(valuee: string){
  let clickon;
  this.onSelect(this.dummy)
 // console.log('valuee',this.dummy);
}

// this function is used for call the selectCustomer()
selectCustomer(name){
    this.Statecontent = name;
 // console.log('show the ',name);
}

// value print on button click and save the value
  valuepass( _id,productName, productPriceINR) {
          let id= _id
          
          this.CalculationSum(productName, productPriceINR, _id);
          this.CalculationGST();
          this.AttachinData(productName, productPriceINR, _id);
         // console.log('idvaluepass',id);
  }

  // Payment option
  // here we have to add the all the value
Payment() {
  const newvalueAdd = {
     checknumber: this.checknumber,
     cash: '1',
     creditcardnumber : this.creditcardnumber,
     creditcardholder: this.creditcardholder,
}
console.log('show the value', newvalueAdd);
// console.log(newvalueAdd);
var headers = new Headers();
headers.append('Content-Type', 'application/json');
 console.log('show the value', newvalueAdd)
alert('Payment Successfully Done ');
 this.http.put('http://172.104.42.153:3005/api/item_Payment_update/' + this.id.id , newvalueAdd, { headers: headers  })
.map((res) => res.json())
.subscribe(  datavlue => {
});
}
// reload the page
refresh(): void {
  window.location.reload();
  this.disablevalue= true;
}

onChange($event){
  let paymentMethod = $event;
  console.log(' paymentMethod', paymentMethod);
}

canceloption() {
     if(this.show_id === undefined) {
       console.log('this.show_id',this.id.id);
      let id = this.id.id;
      this.router.navigate(['home/pos_next2',id]);
     } else {
      console.log('this.show_id',this.show_id);
      alert('You can not able to cancel your order');
     }

}

deleteOrder(){
  // apply  for Delete method request

  let id = this.id.id;
    this.pOSService.deleteItemAllRequest(id)
        .subscribe(data => {
         if (data.n == 1) {
            for ( let i = 0 ; i  <this.posInterfaces.length; i++) {
                 if (this.posInterfaces[i]._id == id)
                 // tslint:disable-next-line:one-line
                 {
                  this.posInterfaces.splice(i, 1);
                 }
            }
         }
       })
       window.location.reload();
}

valuechange($event) {
  this.price = parseFloat(this.price) * parseFloat($event);
  console.log('this.price',this.price);

}
    // chnage the cunstomer trip when we add the customer name
    onChange1(value:any){
      this.commercial = value;
       console.log('commercial',this.commercial);
    }

    // Add Change that time it will work.
    CalculationGST(){
       // This is code used for the Attach GST Code
          if(this.custState === undefined || this.settingSate === this.custState ) {
             this.taxArraylength = 0;
             var countt = 0;
            if(!this.ArrayItem.length){
              this.ArrayItem.push({ CGST: this.CGST, SGST: this.SGST, IGST: this.IGST ,difference: this.difference,
                           differentCGST: this.differentCGST, differentSGST : this.differentSGST
                         });
           //   console.log('this.ArrayItem',this.ArrayItem);
            }  else {
                      for(let i = 0; i < this.ArrayItem.length; i++ ) {
                          //   console.log('this.ArrayItem 2',this.ArrayItem[i]);
                        if(this.ArrayItem[i].SGST === this.SGST && this.ArrayItem[i].CGST === this.CGST){
                          this.ArrayItem[i].differentSGST  =  this.ArrayItem[i].differentSGST + this.differentSGST;
                          this.ArrayItem[i].differentCGST  =  this.ArrayItem[i].differentCGST + this.differentCGST;
                          //this.ArrayItem[i].differentIGST = Igst.toString();
                          //   console.log('this.ArrayItem[i].differentIGST',this.ArrayItem[i].differentSGST);
                        }
                      }
            }
          }   else {
               this.taxArraylength = 0;
               var countt = 0;
             //  console.log('this is change');
              if(!this.ArrayItem.length){
                  //  console.log(' this.ArrayItem', this.ArrayItem);
                  this.ArrayItem.push({ CGST: this.CGST, SGST: this.SGST, IGST: this.IGST, price: this.price, difference: this.difference,
                           differentIGST: this.differentIGST});
                  //  console.log(' this.ArrayItem', this.ArrayItem);
              }else   {
                 for(let k = 0;  k< this.ArrayItem.length; k++ ) {
                       //    console.log('this.ArrayItem 2',this.ArrayItem[i]);
                         if(this.ArrayItem[k].IGST === this.IGST ){
                           this.ArrayItem[k].differentIGST  =  this.ArrayItem[k].differentIGST + this.differentIGST;
                      //     console.log('this.ArrayItem[i].differentIGST',this.ArrayItem[k].differentIGST);
                          }
                       }
                }
                 
              }
          } 
    
    CalculationSum(productName, productPriceINR,_id){
          this.Taxx = this.productTax/2;
          this.productTax = this.productTax;
          this.CGST=this.Taxx;
          this.SGST= this.Taxx;
          this.productName = productName;
          this.productPriceINR = productPriceINR;
          this.POSquanity = 1;
        //  console.log('this.custState',this.custState);
        //  console.log('this.settingSate',this.settingSate);
          if (this.custState === undefined || this.settingSate === this.custState) {
                  this.total =  parseFloat(productPriceINR)* this.productTax /100; 
                  let Tax =   this.total/2;
                  this.differentCGST =  Tax;
                  this.differentSGST = Tax; 
                  this.price =  parseFloat(productPriceINR) ;
                 this.POSsubtotal = this.POSsubtotal  + this.price;
                 if(this.sumtotal === undefined){
                    this.sumtotal =  this.POSsubtotal + this.total;
                    this.totalsum.push({sumtotal:this.sumtotal});
                   // console.log('this.totalsum',this.totalsum);
                 } else {
                    for(let i=0;i< this.totalsum.length;i++){
                       this.totalsum[i].sumtotal = this.totalsum[i].sumtotal  + this.price +this.total;
                     //  console.log('this.totalsum2',this.totalsum);
                    }
                 }
          }   else {
                  this.IGST = this.productTax;
                  this.total =  parseFloat(productPriceINR)* parseFloat(this.productTax) /100; 
                  this.differentIGST =   this.total;
                  this.price =  parseFloat(productPriceINR) ;
                   this.POSsubtotal = this.POSsubtotal  + this.price;
                 if(this.sumtotal === undefined){
                    this.sumtotal =  this.POSsubtotal + this.total;
                    this.totalsum.push({sumtotal:this.sumtotal});
                    console.log('this.totalsum',this.totalsum);
                 } else {
                    for(let i=0;i< this.totalsum.length;i++){
                       this.totalsum[i].sumtotal = this.totalsum[i].sumtotal  + this.price +this.total;
                       console.log('this.totalsum2',this.totalsum);
                    }
                 }
          }
          // this method is apply for add the product value
          this.count = this.count + 1 ;
    }
    /********Data saved and update *************/
    AttachinData(productName, productPriceINR,_id){
        // Add the Value in AddCart Value
         // Add the Value in AddCart Value
          if(!this.AddCart.length) {
              this.POSquanity = 1;
              this.AddCart.push( { productName : productName, productPriceINR: productPriceINR, POSquanity: this.POSquanity, productTax:this.productTax, 
              price: this.price,product_id:_id});
           //   console.log(' this.AddCart', this.AddCart);
          } else {
              var count= 0;
              var productArraylength = 0;
              for(let i = 0; i< this.AddCart.length; i++ ) {
                productArraylength++;
                if(this.AddCart[i].productName === productName) {
                  count++; 
           //       console.log(count);
                }else{
          //        console.log(count);
                }  
              }
              if(count == 0){
               // console.log("insert new item");
                  // console.log('this.sumtotal',this.sumtotal);
                //   console.log(' this.total', this.total);
                this.POSquanity = 1;
                this.AddCart.push( { productName : productName, productPriceINR: productPriceINR, POSquanity: this.POSquanity, productTax:this.productTax, 
                price: this.price,product_id:_id});
                 // console.log('ItemAdd',this.ItemAdd);
              }else{
             //   console.log(" item already inserted only incremaent item");
                for(let i = 0; i < this.AddCart.length; i++ ) {
                  if(this.AddCart[i].productName === productName){
                    this.AddCart[i].POSquanity +=  1;
                    this.AddCart[i].price += this.price;
                  }else{
                  }
                }
              } 
          }
      // this method is apply for call the api value
      if (this.id.id === this.show_id ) {
           this.totalsum1 = this.totalsum[0].sumtotal;
              let newUser = {
              products: this.AddCart,
              gst:this.ArrayItem,
              ItemAdd:this.ItemAdd,
             count: this.count,
             subtotal: this.POSsubtotal,
             total:this.totalsum1
          }
            // console.log(newUser);
            let  headers = new Headers();
             headers.append('Content-Type', 'application/json');
            // console.log('show the value', newUser);
              // alert('Sucessful Update your Data');
             return this.http.put('http://172.104.42.153:3005/api/item_update/' + this.id.id , newUser, { headers: headers  })
              .map((res) => res.json())
             .subscribe(data => {  // console.log('update value', data);
             this.pOSService.getItemSingleRequest(this.id )
            // get value
            .subscribe(  PosInterface => {
              this.posInterface = PosInterface;
              this.show_id = PosInterface.itemDetail[0].Posid; });
           //  console.log('update value', newUser)
            });
     } else {
         
         if(this.customerName=== undefined){
            this.customName= 'Walk In Customer'
          //  console.log('Walk In Customer');
         } else {
            this.customName=   this.customerName;
           // console.log(' this.customName', this.customName);
         }
          this.totalsum1 = this.totalsum[0].sumtotal;
       let newValue = {
         Posid  : this.id.id,
         customerName: this.customName,
         customerState:this.custState,
         customerId: this.customerID,
         customerType:  this.customerType,
         WaiterName: this.POSwaiterName,
         products:  this.AddCart,
         gst:this.ArrayItem,
          ItemAdd:this.ItemAdd,
         count: this.count,
         subtotal: this.POSsubtotal,
          total:this.totalsum1
       }
      // console.log(' newValue.products', newValue);

       let  headers = new Headers();
       headers.append('Content-Type', 'application/json');
       this.http.post('http://172.104.42.153:3005/api/item_post_value' , newValue, { headers: headers  })
       .map((res: Response) => console.log('Response', res.json()))
       .subscribe(
        data => {  // console.log('update value', data);
        this.pOSService.getItemSingleRequest(this.id )
         // get value
        .subscribe(  PosInterface => {
           this.posInterface = PosInterface;
           this.show_id = PosInterface.itemDetail[0].Posid;
           this.show_customerName = PosInterface.itemDetail[0].customerName;
           this.custState= PosInterface.itemDetail[0].customerState
        });
       });
    //   console.log( 'newValue' , newValue);
     }

    }
    /**********Again calculation**********/
    calculation(custState){
      if(!this.AddCart.length){
        console.log('Did not  calculation');
      } else {
        if(this.settingSate === this.custState){
       // console.log('show the state id');
           for(let i = 0;i< this.AddCart.length;i++){
          //   console.log('add value',this.AddCart[i]);
              for(let j=0; j <this.AddCart[i].POSquanity;j++){
                 let tax = this.AddCart[i].productTax /2;
           //      console.log('this.AddCart[i].productTax',this.AddCart[i].productTax);
                 this.CGST= tax;
                 this.SGST = tax;
             //    console.log(' this.CGST 1', this.CGST);
               
                    let total =  parseFloat(this.AddCart[i].productPriceINR)* this.AddCart[i].productTax /100; 
                    let Tax =   total/2;
                    this.differentCGST =  Tax;
                    this.differentSGST = Tax; 
                    this.price =  parseFloat(this.AddCart[i].productPriceINR) ;
                  //  console.log('this.differentSGST',this.differentSGST);
                     
                
                 /****** Insert the value in array********/
                /**B Array used for instert the value of SCGST**/
                if(!this.B.length){
                   this.B.push({ CGST: this.CGST, SGST: this.SGST, 
                           differentCGST: this.differentCGST, differentSGST : this.differentSGST
                         });
                //    console.log('this.B',this.B);
                } else{
                     for(let k=0; k<this.B.length; k++){
                         if(this.B[k].SGST === this.SGST && this.B[k].CGST === this.CGST){
                           this.B[k].differentSGST += this.differentSGST;
                           this.B[k].differentCGST += this.differentCGST;
                        //   console.log(' this.B[k].differentCGST', this.B[k].differentCGST);
                       //    console.log(' this.B[k].differentSGST', this.B[k].differentSGST);
                       //    console.log('this.A[k]',this.A[k]);
                         }
                       }
                    console.log(' this.B', this.B);
                }
              }
           }
              /**********Update the Value ******/
                    let newValue = {
                      customerName:this.customerName,
                      customerState:this.custState,
                      customerId: this.customerID,
                      customerType:  this.customerType,
                        gst:this.B
                    }
                    console.log('newValue',newValue);
                    let  headers = new Headers();
                    headers.append('Content-Type', 'application/json');
                    this.http.put('http://172.104.42.153:3005/api/item_update/' + this.id.id ,  newValue, { headers: headers  })
                    .map((res: Response) => console.log('Response', res.json()))
                    .subscribe(data => {   console.log('update value', data);
                        this.pOSService.getItemSingleRequest(this.id ) 
                          .subscribe(  PosInterface => {
                          this.posInterface = PosInterface;
                           window.location.reload();
                        });
                    });
                   
        } else if(this.settingSate !== this.custState) {
          console.log('did not show the state id');
          for(let i = 0;i< this.AddCart.length;i++){
            console.log('add value',this.AddCart[i]);
             for(let j=0; j <this.AddCart[i].POSquanity;j++){
           //    console.log('quan',this.AddCart[i].POSquanity);
               this.IGST = this.AddCart[i].productTax;
                 this.total =  parseFloat(this.AddCart[i].productPriceINR)* parseFloat(this.AddCart[i].productTax) /100; 
                 this.differentIGST =   this.total;
                /****** Insert the value in array********/
                
                console.log('this.A.length', this.A.length);
                if(!this.A.length){
                  this.A.push({ IGST: this.IGST, price: this.price, difference: this.difference,
                           differentIGST: this.differentIGST});
                           console.log(' this.A', this.A);
                }else {
                   for(let k=0; k<this.A.length; k++){
                         if(this.A[k].IGST === this.IGST){
                           this.A[k].differentIGST += this.differentIGST;
                         //  console.log('this.A[k].differentIGST',this.A[k].differentIGST);
                          // console.log('this.A[k]',this.A[k]);
                         }
                       }
                //    console.log(' this.A', this.A);
                } 
            }
          }
            let newValue = {
             customerName:this.customerName,
             customerState:this.custState,
             customerId: this.customerID,
             customerType:  this.customerType,
             total:this.sumtotal,
             gst:this.A
            }
            console.log('newValue',newValue)
            let  headers = new Headers();
            headers.append('Content-Type', 'application/json');
            this.http.put('http://172.104.42.153:3005/api/item_update/' + this.id.id ,  newValue, { headers: headers  })
              .map((res: Response) => console.log('Response', res.json()))
                  .subscribe(data => {   console.log('update value', data);
                   this.pOSService.getItemSingleRequest(this.id ) 
                    .subscribe(  PosInterface => {
                    this.posInterface = PosInterface;
                    window.location.reload();
                  });
            });
        }
      }   
    } 
       /***********this  function is related to Category show ***********/
       onclic(){
         window.location.reload();
       } 
    /******************Delete the product********************/
    

   //  this method is used for order delet single value
    DeleteItem(_id){
      let id = _id;
         const newvalueAdd = {
          product_id:id,
          tableid:this.id.id
        }
      for(let i=0;i<this.AddCart.length;i++){
          if(this.AddCart[i]. product_id===id){
              let quan =this.AddCart[i].POSquanity;
              for(let i=0;i< quan;i++){
                    if(i===0){
                      var headers = new Headers();
                      headers.append('Content-Type', 'application/json');
                   //   console.log('newvalueAdd',newvalueAdd);
                      this.http.post('http://172.104.42.153:3005/api/delete_product/' , newvalueAdd, { headers: headers  })
                          .map((res) => res.json())
                          .subscribe(  datavlue => {
                            console.log('datavalue',datavlue);
                            this.pOSService.getItemSingleRequest(this.id )
                                .subscribe(  PosInterface => {
                                   this.AddCart = PosInterface.itemDetail[0].products;
                                    this.ArrayItem = PosInterface.itemDetail[0].gst;
                                        if (this.custState === undefined || this.settingSate === this.custState) {
                                           for(let i = 0;i< this.AddCart.length;i++){
                                             console.log('this.Addcart',this.AddCart);
                                             console.log('this.AddCart.length',this.AddCart.length);
                                              for(let j=0; j <this.AddCart[i].POSquanity;j++){
                                                let count =0;
                                                let tax = this.AddCart[i].productTax /2; 
                                                this.CGST= tax;
                                                this.SGST = tax;
                                                let POSsubtotal = 0;
                                                let total =  parseFloat(this.AddCart[i].productPriceINR)* this.AddCart[i].productTax /100; 
                                                let Tax =   total/2;
                                                this.differentCGST =  Tax;
                                                this.differentSGST = Tax; 
                                                this.price =  parseFloat(this.AddCart[i].productPriceINR) ;
                                                console.log(' this.differentCGST 2 ', this.differentCGST);
                                               /****** Insert the value in array********/
                                               /**B Array used for instert the value of SCGST**/
                                                if(!this.B.length){
                                                    this.B.push({ CGST: this.CGST, SGST: this.SGST, difference: this.difference,
                                                          differentCGST: this.differentCGST, differentSGST : this.differentSGST
                                                      });
                                                } else{
                                                  for(let k=0; k<this.B.length; k++){
                                                    if(this.B[k].SGST === this.SGST && this.B[k].CGST === this.CGST){
                                                        this.B[k].differentSGST += this.differentSGST;
                                                       this.B[k].differentCGST += this.differentCGST;
                                                    }
                                                  }
                                                }
                                             }
                                           }
                                            let newValue = {
                                                gst:this.B
                                            }
                                         // console.log('newValue',newValue)
                                          let  headers = new Headers();
                                          headers.append('Content-Type', 'application/json');
                                          this.http.put('http://172.104.42.153:3005/api/item_update/' + this.id.id ,  newValue, { headers: headers  })
                                              .map((res: Response) => console.log('Response', res.json()))
                                              .subscribe(data => {   console.log('update value', data);
                                            this.pOSService.getItemSingleRequest(this.id ) 
                                                           .subscribe(  PosInterface => {
                                                            this.posInterface = PosInterface;
                                                            this.ArrayItem = PosInterface.itemDetail[0].gst;
                                                            console.log('this.ArrayItem',this.ArrayItem);
                                                          });
                                            });
                                        } else if(this.settingSate !== this.custState) {
                                            for(let i = 0;i< this.AddCart.length;i++){
                                               for(let j=0; j <this.AddCart[i].POSquanity;j++){
                                                  this.IGST = this.AddCart[i].productTax;
                                                  this.total =  parseFloat(this.AddCart[i].productPriceINR)* parseFloat(this.AddCart[i].productTax) /100; 
                                                  this.differentIGST =   this.total;
                                                  /****** Insert the value in array********/ 
                                                  if(!this.A.length){
                                                      this.A.push({ IGST: this.IGST, price: this.price, difference: this.difference,
                                                             differentIGST: this.differentIGST});
                                                        console.log(' this.A', this.A);
                                                  }else {
                                                      for(let k=0; k<this.A.length; k++){
                                                           if(this.A[k].IGST === this.IGST){
                                                             this.A[k].differentIGST += this.differentIGST;
                                                             }
                                                      }
                                                  } 
                                               }
                                            }
                                            /*********update the value******/
                                            let newValue = {
                                                gst:this.A
                                            }
                                            let  headers = new Headers();
                                          headers.append('Content-Type', 'application/json');
                                          this.http.put('http://172.104.42.153:3005/api/item_update/' + this.id.id ,  newValue, { headers: headers  })
                                              .map((res: Response) => console.log('Response', res.json()))
                                              .subscribe(data => {   console.log('update value', data);
                                            this.pOSService.getItemSingleRequest(this.id ) 
                                                           .subscribe(  PosInterface => {
                                                            this.posInterface = PosInterface;
                                                            this.ArrayItem = PosInterface.itemDetail[0].gst;
                                                            console.log('this.ArrayItem',this.ArrayItem);
                                                          });
                                            });
                                        }
                                });
                          });
                    }
              }
          }
      }
       
    }   
    

}

