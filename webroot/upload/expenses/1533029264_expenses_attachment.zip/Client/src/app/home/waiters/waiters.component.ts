import { Component, ViewChild, OnInit } from '@angular/core';
import { ModalComponent } from 'ng2-bs3-modal';
import { Http, Headers } from '@angular/http';
import { Routes, RouterModule , Router } from '@angular/router';
import {WaitersInterface} from './waiters-Interface';
import {WaiterService} from './waiters.services';
import {StoreService} from '../stores/store.services';
import {ReactiveFormsModule,FormsModule, FormGroup,FormControl,Validators,FormBuilder,NgForm} from '@angular/forms';
import { StoreInterface} from '../stores/store-interface';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { Ng4LoadingSpinnerModule, Ng4LoadingSpinnerService  } from 'ng4-loading-spinner';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module
@Component({
  selector: 'app-waiters',
  templateUrl: './waiters.component.html',
  styleUrls: ['./waiters.component.css'],
  providers:[WaiterService,StoreService,Ng4LoadingSpinnerService]
})
export class WaitersComponent implements OnInit {
   // it is related to modal
  @ViewChild('myModal')
    modal: ModalComponent;
    viewmodal: ModalComponent;
    value = [2,10,25,50,100];
    selectValue = this.value[1];
  // interface define
    waitersInterfaces: WaitersInterface[];
    waitersInterface: WaitersInterface;
    storeInterfaces: StoreInterface[]; // this is part of the store interface compnent
  // variable declare
    waiterName: string ;
    waiterPhone: string ;
    waiterEmail:  string ;
    waiterStore: string ;
    waiterCreateAt: string;

  constructor(private http: Http,  private ng4LoadingSpinnerService: Ng4LoadingSpinnerService,
             private router: Router, private waiterService: WaiterService, private storeService:StoreService ) { }

  ngOnInit() {
    // get request call
        this.waiterService.getWaitersRequest()
          .subscribe(  waitersInterfaces => {
            console.log( waitersInterfaces)
             this.waitersInterfaces =  waitersInterfaces;
        });
            //  it is related to store services because we have to display the store name
     this.storeService. getStoreRequest()
          .subscribe(  storeInterfaces => {
            console.log( storeInterfaces)
             this.storeInterfaces =  storeInterfaces;
             console.log(this.storeInterfaces);
          });
  }
    // it it used for route
     redirect(_id) {
    this.router.navigate(['home/edit_waiter',_id]);
  }

  addWaiters(f:NgForm) {
    console.log( this. waiterName);
       const newUser = {
             waiterName:  this.waiterName,
             waiterPhone: this.waiterPhone,
             waiterEmail:  this.waiterEmail,
             waiterStore: this.waiterStore,
             waiterCreateAt: new Date,
       }     
        for(let i=0;i<this.waitersInterfaces.length; i++){
                  console.log('waiterEmail',this.waitersInterfaces[i].waiterEmail );
                  if(this.waitersInterfaces[i].waiterEmail == this.waiterEmail){
                    alert('User already Existing');
                  } 
        }
                      console.log(newUser);
                       this.ng4LoadingSpinnerService.show();
                      this.waiterService.postWaitersRequest(newUser)
                       .subscribe(  waitersInterface=> {
                          this.waitersInterfaces.push( waitersInterface);
                      // get the value
                        this.waiterService.getWaitersRequest()
                           .subscribe(  waitersInterfaces => {
                          console.log( waitersInterfaces)
                         this.waitersInterfaces =  waitersInterfaces;
                          this.ng4LoadingSpinnerService.hide();
                         });
                         f.reset();
                        })
}
   // apply  for Delete method request
  deleteWaiters(id: any) {
         this.waiterService.deleteWaitersRequest(id)
         .subscribe(  waitersInterface => {
          console.log( waitersInterface)
          if( waitersInterface.success === true){
            alert('If you want to delet this Value, before delet existing value');
            console.log('categoriesProductInterfaces',waitersInterface);
           } else {
            alert('Delete Value Successfully');
            this.waiterService.getWaitersRequest()
            .subscribe(  waitersInterfaces => {
              console.log( waitersInterfaces)
               this.waitersInterfaces =  waitersInterfaces;
            });
           }
        });
    }
  view(id){
    this.waiterService.getWaitersSingle(id)
    .subscribe(   waitersInterface => {
       this.waitersInterface =   waitersInterface.WaitersDetail;
       this.waiterName = waitersInterface.WaitersDetail.waiterName;
       this.waiterPhone = waitersInterface.WaitersDetail.waiterPhone;
       this.waiterEmail = waitersInterface.WaitersDetail.waiterEmail;
       this.waiterStore = waitersInterface.WaitersDetail.waiterStore;
       this.waiterCreateAt = waitersInterface.WaitersDetail.waiterCreateAt;
       console.log( waitersInterface);
    });
  }
  closee(f:NgForm){
        f.reset();
        this.waiterName = null;
        this.waiterPhone = null;
        this.waiterEmail = null;
        this.waiterStore = null;
        this.waiterCreateAt = null;
        console.log('clear');
  }
}
