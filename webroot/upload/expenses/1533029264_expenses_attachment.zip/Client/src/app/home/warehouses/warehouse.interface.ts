export class WarehouseInterface {
       _id?: string;
    warehouseName:  string;
    warehousePhone: string ;
    warehouseEmail:  string;
    warehouseAddress: string ;
}

    