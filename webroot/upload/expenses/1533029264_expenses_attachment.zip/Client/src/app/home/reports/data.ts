export interface Stock {
  date: Date,
  value: number
}

export const Stocks: Stock[] = [
  {date: new Date("2017-01-01"), value: 210.73},
  {date: new Date("2017-01-04"), value: 214.01},
  {date: new Date("2017-01-05"), value: 214.38},
  {date: new Date("2017-01-06"), value: 400.97},
  {date: new Date("2017-01-07"), value: 500.58},
  {date: new Date("2017-01-08"), value: 211.98},
  {date: new Date("2017-01-11"), value: 210.11},
  {date: new Date("2017-01-12"), value: 500.72},
  {date: new Date("2017-01-13"), value: 400.65},
  {date: new Date("2017-01-14"), value: 209.43},
  {date: new Date("2017-01-15"), value: 205.93},
  
  
 
 
];