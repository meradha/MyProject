export class WaitersInterface {
       _id?: string;
    waiterName: string ;
    waiterPhone: string ;
    waiterEmail:  string ;
    waiterStore: string ;
    waiterCreateAt: string;
}

    