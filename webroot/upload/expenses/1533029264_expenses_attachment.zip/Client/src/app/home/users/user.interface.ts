export class UserInterface {
       _id?: string;
    userName: string ;
    userFirstName: string ;
    userLastName: string ;
    userRole: string ;
    userEmail: string ;
    userpassword: string;
    useractivityDate: string;
    userImageName:string;
}
