export class CategoriesExpenseInterface {
       _id?: string;
     category_expernseName: string ;
       category_CreateAt: string ;
}

    