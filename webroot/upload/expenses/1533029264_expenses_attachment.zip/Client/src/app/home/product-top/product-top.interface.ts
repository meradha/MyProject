export class Product_TopInterface {
       _id?: string;
       productType: string ;
       productCode: string ;
       productName: string ;
       productCategory: string;
       productSupplier: string ;
       productPurchasePrice: string ;
       productTax: string ;
       productTaxMethod: string;
       productPriceINR: string;
       productUnit: string ;
       productAlertQuantity: string ;
       productDiscription: string ;
       productImage: string ;
       productParagraph: string ;
     
}