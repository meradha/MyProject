import { Component, ViewChild, OnInit, OnChanges, SimpleChanges,Input} from '@angular/core';
import { ModalComponent } from 'ng2-bs3-modal';
import { Http, Headers, Request,Response ,RequestOptions } from '@angular/http';
import {Router,ActivatedRoute, Params, Data} from '@angular/router';
import { EqualValidator } from './password.match.directive';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import {UserInterface} from './user.interface';
import { DatePipe } from '@angular/common';
import {UserService}from './user.services';
import {ReactiveFormsModule,FormsModule, FormGroup,FormControl,Validators,FormBuilder,NgForm} from '@angular/forms';
import { Directive, forwardRef, Attribute } from '@angular/core';

@Component({
  selector: 'app-users',
    moduleId: module.id.toString(),
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
  providers:[UserService, EqualValidator ]
})
export class UsersComponent implements OnInit {
  // it is related to modal  component
  @ViewChild('myModal')
    modal: ModalComponent;
 // user interface
 UserInterfaces: UserInterface[];
 UserInterface: UserInterface[];
 today: number = Date.now();
 // variable declaration
    userName: string ;
    userFirstName: string ;
    userLastName: string ;
    userRole: string ;
    userEmail: string ;
    userpassword: string; 
    confirm: string
    useractivityDate: string;
    userImageName:any;
    userimage ='';
    filename;

  constructor(  private router: Router,
               private _http: Http, private  userService: UserService, private route: Router  ) { }

  ngOnInit() {
    // get request call
     this.userService.getUserRequest()  // get the teacher value
          .subscribe(  UserInterfaces => {
             this.UserInterfaces =  UserInterfaces;
            // console.log('user successful',this.UserInterfaces);
          });

  }    // it is related to modal modal button
   
      // this is used for routing
       redirect(_id) {
    this.router.navigate(['home/edit_user',_id]);
  }

// apply for post method for modal option
    addUser(f:NgForm) {
       console.log( this.userFirstName);
       const newUser = {
              userName: this.userName,
              userFirstName: this.userFirstName,
              userLastName: this.userLastName,
              userRole: this.userRole,
              userEmail: this.userEmail,
              userpassword: this.userpassword,
              useractivityDate: new Date,
              userImageName:this.userImageName
       }  
          for(let i=0;i<this.UserInterfaces.length; i++){
                  console.log('username',this.UserInterfaces[i].userName );
                  if(this.UserInterfaces[i].userName == this.userName){
                    alert('User alredy Existing');
                  } else if(this.UserInterfaces[i]. userEmail == this.userEmail){
                     alert('Email already Existing'); 
                  }
                
          }
              console.log(newUser);
               // console.log('userImageName',this.userImageName);
              this.userService.postUserRequest(newUser)
                   .subscribe( UserInterface=> {
                   this.UserInterfaces.push(UserInterface);
                   this.userService.getUserRequest()  // get the teacher value
                   .subscribe(  UserInterfaces => {
                     console.log( UserInterfaces)
                      this.UserInterfaces =  UserInterfaces;
                      console.log(this.UserInterfaces);
                   })
                   f.reset(); // it is clear the ngModel
              })
              
    }

// apply  for Delete method request
userDelete(id: any) {
  this.userService.deleteUserRequest(id)
      .subscribe(data => {
       if (data.n == 1) {
          for ( let i = 0 ; i  <this.UserInterfaces.length; i++) {
               if (this.UserInterfaces[i]._id == id)
               // tslint:disable-next-line:one-line
               {
                this.UserInterfaces.splice(i, 1);
               }
          }
       }
     })
}

  
  fileChanged(e: Event) {
    var target: HTMLInputElement = e.target as HTMLInputElement;
    for ( var i = 0;i < target.files.length; i++) {
        this.upload(target.files[i]);
        console.log('targert',target.files[i])
    }
  }

  upload(file) {
    
       var formData: FormData = new FormData();
       formData.append('file', file);
       console.log('file',file);
        this.userImageName = file.name;
       console.log(' file.filename',  this.userImageName)
       var xhr = new XMLHttpRequest();
       xhr.upload.addEventListener('progress', (ev: ProgressEvent) => {});
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                  let   resolve = (JSON.parse(xhr.response));
                  let imagename = resolve.filename;
                  console.log('response', resolve);
                 
                } else {
                  let  reject = (xhr.response)
                }
            }
        }
       xhr.open('POST', 'http://172.104.42.153:3005/uploadFile',file);
       console.log('post image value', file);
       xhr.send(formData);
  }

  

}
