import { Component, ViewChild, OnInit } from '@angular/core';
import { ModalComponent } from 'ng2-bs3-modal';
import { Http, Headers } from '@angular/http';
import { Routes, RouterModule , Router } from '@angular/router';
import {CustomerInterface} from './customer-interface';
import {CustomerService} from './customer-services';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {ReactiveFormsModule,FormsModule, FormGroup,FormControl,Validators,FormBuilder,NgForm} from '@angular/forms';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module
@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css'],
  providers:[CustomerService]
})
export class CustomersComponent implements OnInit {
   @ViewChild('myModal')
    modal: ModalComponent;
    modalForm : FormGroup;
    // interface declare
    customerInterfaces: CustomerInterface[];
    customerInterface: CustomerInterface;
    value = [2,10,25,50,100];
    selectValue = this.value[1];
  // variable dealcreation
    customerName: string ;companyName;
    customercountry:string;
    companyGst:string
    customerPhone: string ; commercial;
    customerEmail: string ;
    customerDiscount: string ;
    customerCreatedAt: string ;
    customerState: string;
    customerAddress: string ;
   
    web_customerid= new Date().getTime() ; 
    customerId = "web_"+ this.web_customerid;
constructor(private http: Http, private router: Router, private customerService: CustomerService ) { }

  ngOnInit() {
     // get request call
     this.customerService.getCustomerRequest()
          .subscribe(  customerInterfaces => {
            console.log(customerInterfaces)
             this.customerInterfaces =  customerInterfaces;
             console.log(this.customerInterfaces);
          });
  }
 
    // it it used for route
     redirect(_id) {
    this.router.navigate(['home/edit_customers',_id]);
  }


  // apply for post method request
  addCustomer(f:NgForm) {
    console.log( this.customerName);
       const newCustomers = {
              commercial:this.commercial,
              companyName:this.companyName,
              companyGst:this.companyGst,
              customerName: this.customerName,
              customerPhone: this.customerPhone,
              customerEmail: this.customerEmail,
              customerCountry: this.customercountry,
              customerState: this.customerState,
              customerId: this.customerId,
              customerAddress: this.customerAddress,
              customerDiscount: this.customerDiscount,
              customerCreatedAt: new Date
       }
       console.log( newCustomers);
              for(let i=0; i < this.customerInterfaces.length; i++ ){
                    if(this.customerInterfaces[i].customerEmail == this.customerEmail){
                      alert('Email is Already existing');
                    }
              }
              console.log( newCustomers);
              this.customerService.postCustomerRequest( newCustomers)
                   .subscribe( customerInterface => {
                   this.customerInterfaces.push(customerInterface);
              // get the value
              
              this.customerService.getCustomerRequest()  // get the teacher value
              .subscribe(  customerInterfaces => {
                console.log(customerInterfaces)
                 this.customerInterfaces =   customerInterfaces;
                 console.log(this.customerInterfaces);
              });
         })  
         f.reset();
}

    deleteCustomerRequest(id: any) {
         var customerInterfaces = this.customerInterfaces;
         this.customerService.deleteCustomerRequest(id)
             .subscribe(data => {
              if( data.success === true){
                alert('If you want to delet this Value, before delet existing value');
                console.log('categoriesProductInterfaces',data);
               } else {
                alert('Delete Value Successfully');
                this.customerService.getCustomerRequest()
                .subscribe(  customerInterface => {
                  console.log(customerInterfaces)
                   this.customerInterfaces =  customerInterface;
                   console.log(this.customerInterfaces);
                });
               }
            })
    }
    view(id){
      this.customerService.getCustomerSingle(id )
      .subscribe(  customerInterface => {
         this.customerInterface =  customerInterface.CustomerDetail;
         this.customerName = customerInterface.CustomerDetail.customerName;
         this.customerPhone = customerInterface.CustomerDetail.customerPhone;
         this.customerEmail = customerInterface.CustomerDetail.customerEmail;
         this.customerState = customerInterface.CustomerDetail.customerState;
         this.customerAddress = customerInterface.CustomerDetail.customerAddress;
         this.customerDiscount = customerInterface.CustomerDetail.customerDiscount;
         this.customerCreatedAt = customerInterface.CustomerDetail.customerCreatedAt;
         console.log(  this.customerInterface);

      });

    }

     onChange1(value:any){
      this. commercial = value;
       console.log(' commercial',this. commercial);
    }
   
}
