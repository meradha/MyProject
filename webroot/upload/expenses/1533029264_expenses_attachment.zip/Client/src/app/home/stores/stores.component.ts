import { Component, ViewChild, OnInit } from '@angular/core';
import { ModalComponent } from 'ng2-bs3-modal';
import { Http, Headers } from '@angular/http';
import { StoreInterface} from './store-interface';
import {StoreService } from './store.services';
import {ReactiveFormsModule,FormsModule, FormGroup,FormControl,Validators,FormBuilder,NgForm} from '@angular/forms';
import {Router,ActivatedRoute, Params, Data } from '@angular/router';
import { Ng2SearchPipeModule } from 'ng2-search-filter'
@Component({
  selector: 'app-stores',
  templateUrl: './stores.component.html',
  styleUrls: ['./stores.component.css'],
  providers:[StoreService ]
})
export class StoresComponent implements OnInit {

// it is relaetd to modal componenent
  @ViewChild('myModal')
  modal: ModalComponent;
  value = [2,10,25,50,100];
  selectValue = this.value[1];

 // interface declare for store the value ;
     storeInterfaces: StoreInterface[];
     storeInterface: StoreInterface;

// variable declaration
       storeName: string;productTax;
       storeEmail: string;
       storePhone: string;
       storecountry: string;
       storeCity: string;storestate;
       storeAddress: string;
       storeReceipt: string;
       storeenable;
  constructor(private http: Http,
              private storeService: StoreService,
              private router: Router, ) { }

  ngOnInit() {
    // get request call
     this.storeService.getStoreRequest()
        .subscribe(  storeInterfaces => {
            console.log( storeInterfaces)
             this.storeInterfaces =  storeInterfaces;
             console.log(this.storeInterfaces);
          for(let i=0;i<this.storeInterfaces.length;i++){
              if(this.storeInterfaces.length){
                console.log('disable');
                this.storeenable = true;
              }
            
          }
      });


  }
  // it it used for route
  routing(_id) {
    this.router.navigate(['home/edit_store',_id]);
  }
   // function declare for modal opeation perform

    addStor(f:NgForm) {
       console.log( this.storeName);
       const newUser = {
              storeName: this.storeName,
              storeEmail: this.storeEmail,
              storePhone: this.storePhone,
              storecountry: this.storecountry,
              storeTax:this.productTax,
              storestate: this.storestate,
              storeCity: this.storeCity,
              storeAddress: this.storeAddress,
              storeReceipt: this.storeReceipt
       }
             for(let i=0; i<this.storeInterfaces.length;i++){
                if(this.storeInterfaces[i].storeEmail == this.storeEmail){
                  alert('Email Already Existing');
                }
                
             }
              console.log(newUser);
              this.storeService.postStoreRequest(newUser)
                   .subscribe( storeInterface=> {
                   this.storeInterfaces.push(storeInterface);
               // get request call
              this.storeService.getStoreRequest()  // get the teacher value
                 .subscribe(  storeInterfaces => {
                 console.log( storeInterfaces)
              this.storeInterfaces =  storeInterfaces
              console.log(this.storeInterfaces);
         });
         f.reset();
    })
         
  }
   // apply  for Delete method request
  deleteStore(id: any) {
         var storeInterfaces = this.storeInterfaces;
         this.storeService.deleteStoreRequest(id)
             .subscribe(data => {
               console.log('data',data);
              if( data.success === true){
                alert('If you want to delet this Value, before delet existing value');
                console.log('categoriesProductInterfaces',data);
               } else {
                alert('Delete Value Successfully');
                this.storeService.getStoreRequest()
                .subscribe(  storeInterface => {
                  console.log( storeInterface)
                   this.storeInterfaces =  storeInterface;
                   console.log(this.storeInterfaces);
                });
              }

            })
    }

     // this is used for routing
       redirect(_id) {
      this.router.navigate(['home/StoreTableAttachComponent',_id]);
      console.log(_id);

  }

  // this is option is used for show the View
  view(id){
    this.storeService.getStoreSingle(id)
    .subscribe(  storeInterface => {
          this.storeInterface = storeInterface.StoreDetail;
          console.log( this.storeInterface)
          this.storeName = storeInterface.StoreDetail.storeName;
          this.storeEmail = storeInterface.StoreDetail.storeEmail;
          this.storePhone = storeInterface.StoreDetail.storePhone;
          this.storecountry = storeInterface.StoreDetail.storecountry;
          this.storestate = storeInterface.StoreDetail.storestate;
          this.storeCity = storeInterface.StoreDetail.storestate;
          this.storeAddress= storeInterface.StoreDetail.storeAddress;
          this.storeReceipt= storeInterface.StoreDetail.storeReceipt;
    });
  }
   closee(f:NgForm){
        f.reset();
        this.productTax=null;
         this.storeName = null;
          this.storeEmail = null;
          this.storePhone = null;
          this.storecountry = null;
          this.storeCity = null;
          this.storestate=null;
          this.storeAddress= null;
          this.storeReceipt= null;
        console.log('clear');
  }
}
