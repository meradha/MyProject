export class SupplyInterface {
       _id?: string;
       suppliersName: string;
      suppliersPhone: string;
      suppliersEmail: string;
      supplierDate: string;
      suppliersStore: string;
   
}