import { Component, OnInit } from '@angular/core';
import {  Response, Headers, RequestOptions, Http, HttpModule } from '@angular/http';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { FormsModule } from '@angular/forms';
import {UserService} from '../users/user.services';
import {UserInterface} from '../users/user.interface';
@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css'],
  providers: [UserService],
})
export class EditUserComponent implements OnInit {
 // user interface
 UserInterfaces: UserInterface[];
 id:any;
 // variable declare
 userFirstName: string;
 userName: string;
 userLastName: string;
 userEmail: string;
 confirm;
 userImageName:string
 userpassword:string;
 result = null;
 private sub: any;
 userRole;

  constructor(private http: Http,
    private router: Router,
    private userService: UserService,
    private route: ActivatedRoute) {}
  ngOnInit() {
     // params define
     this.route.params.subscribe(params => this.id = params);
     // get request call
     this.userService.getWarehouseSingleRequest(this.id )
     .subscribe(  UserInterfaces => {
        this.UserInterfaces = UserInterfaces.userDetail,
        this.userName = UserInterfaces.userDetail.userName,
        this.userFirstName = UserInterfaces.userDetail.userFirstName,
        this.userLastName = UserInterfaces.userDetail.userLastName,
        this.userEmail = UserInterfaces.userDetail.userEmail;
        this.userRole =  UserInterfaces.userDetail.userRole;
        this.userImageName = UserInterfaces.userDetail.userImageName;
       
     });
  }

  fileChanged(e: Event) {
    var target: HTMLInputElement = e.target as HTMLInputElement;
    for ( var i = 0;i < target.files.length; i++) {
        this.upload(target.files[i]);
        console.log('targert',target.files[i])
    }
  }

  upload(file) {
       var formData: FormData = new FormData();
       formData.append('file', file);
       console.log('file',file);
       this.userImageName = file.name;
       console.log(' file.filename',  file.name)
       var xhr = new XMLHttpRequest();
       xhr.upload.addEventListener('progress', (ev: ProgressEvent) => {});
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                
                  let resolve = (JSON.parse(xhr.response))
                } else {
                  let  reject = (xhr.response)
                }
        }
       xhr.open('POST', 'http://172.104.42.153:3005/uploadFile',file);
       console.log('post image value', file);
       xhr.send(formData);
    
  }

// update Information
  // update request
  updateUSER() {
    const newUser = {
      userName:this.userName,
      userFirstName: this.userFirstName,
      userLastName: this.userLastName,
      userEmail: this.userEmail,
      userRole: this.userRole,
      userpassword:this.userpassword,
      userImageName:this.userImageName
    }
     console.log( newUser);
    
    var headers = new Headers();
     headers.append('Content-Type', 'application/json');
    // console.log('call the id ',this.id)
    this.http.put('http://172.104.42.153:3005/api/user_update/'+this.id.id ,newUser, { headers: headers  })
     .map((res) => res.json())
     .subscribe(data => console.log(data));
     alert('Data Successfully Update');
     this.userService.getWarehouseSingleRequest(this.id )
     .subscribe(  UserInterfaces => {
        this.UserInterfaces = UserInterfaces.userDetail;
         console.log('userImageName',this.userImageName);
     });
     this.router.navigate(['home/setting/users']);

  }
  
}
