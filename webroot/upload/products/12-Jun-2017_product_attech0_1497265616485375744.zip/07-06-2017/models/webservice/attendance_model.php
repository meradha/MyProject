<?php
class Attendance_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   //$this->load->database();
	}

	/* Add New */	
	public function addAttendance($post)
	{
		$this->db->insert('tbl_attendance', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}

}
?>
