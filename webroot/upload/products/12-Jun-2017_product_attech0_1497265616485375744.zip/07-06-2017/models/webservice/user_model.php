<?php

class User_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Check login status */
	public function CheckUserLogin($post)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_email', $post['user_email']);
		$this->db->or_where('user_uname', $post['user_email']);
		$this->db->where('user_password', $post['user_password']);
		$this->db->where('user_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}
	/*	check login details */
	public function CheckUserStatus($post)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_email', $post['user_email']);
		$this->db->or_where('user_uname', $post['user_email']);
		$this->db->where('user_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	check login details */
	public function getUserDetails($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_status', '1');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Update deviceID */
	public function updateDeviceId($post)
	{	
		$data['user_device_id'] = $post['user_device_id'];
		$data['user_login_status'] = $post['user_login_status'];	
		$this->db->where('user_id', $post['user_id']);
		$this->db->update('tbl_user', $data);
		return true;
	}

	/*	show all menu bar  */
	public function getAllTabAsPerRole($role_id)
	{
		$this->db->select('a.*, b.*');
		$this->db->from('user_permission a'); 
		$this->db->join('sidebar_tabs b','a.tab_id = b.tab_id','inner');
		$this->db->where('a.role_id', $role_id);
		$this->db->where('a.userView', '1');
		$this->db->order_by('b.tab_number', 'ASC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Check controller name  */
	public function checkControllerName($controller_name)
	{
		$this->db->select('a.*, b.*');
		$this->db->from('user_permission a'); 
		$this->db->join('sidebar_tabs b','a.tab_id = b.tab_id','inner');
		$this->db->where('b.controller_name', $controller_name);
		$this->db->where('a.userView', '1');
		$this->db->order_by('b.tab_number', 'ASC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all Role List by login user role  */
	public function getAllRole()
	{
		$this->db->select('*');
		$this->db->from('tbl_role');
		$this->db->where('role_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all User by role */
	public function getAllUserByRole($role_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_role_id', $role_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show parent User name */
	public function getParentUserName($user_parent_user_id)
	{
		$this->db->select('user_name');
		$this->db->from('tbl_user');
		$this->db->where('user_id', $user_parent_user_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New User */	
	public function addUser($post)
	{
		$this->db->insert('tbl_user', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	


	/* Update User */
	public function updateUser($post)
	{	
		$data['user_role_id'] = $post['user_role_id'];
		$data['user_all_level'] = $post['user_all_level'];
		$data['user_parent_user_id'] = $post['user_parent_user_id'];
		$data['user_phone'] = $post['user_phone'];
		$data['user_name'] = $post['user_name'];
		$data['user_gender'] = $post['user_gender'];
		$data['user_dob'] = $post['user_dob'];
		$data['user_level'] = $post['user_level'];
		$data['user_status'] = $post['user_status'];
		$data['added_by'] = $post['added_by'];
		$data['user_updated_date'] = $post['user_updated_date'];		
		$this->db->where('user_id', $post['user_id']);
		$this->db->update('tbl_user', $data);
		return true;
	}

	/* Delete User detail */
	function deleteUser($user_id)
	{
		if($this->db->delete('tbl_user', array('user_id' => $user_id)))
		{
			return 1;		
		}
		else
		{
			return 2;		
		}		
	}

	/*	Show parent User */
	public function getAllUser($user_level)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_level', $user_level);
		$query = $this->db->get();
		return $query->result() ;
	}

	
	/* Edit User details */	
	public function editUser($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
		return $query->result();
	}

	/*	Show child User */
	public function getChildUser($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_parent_user_id', $user_id);
		$this->db->where('user_id !=', '1');
		$query = $this->db->get();
		return $query->result() ;
	}	


	/*	Show all User  */
	public function getAllUsers()
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_status', '1');
		$this->db->where('user_id !=', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show parent User */
	public function getAllUserByLevelParentID($user_level, $user_parent_user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_level', $user_level);
		$this->db->where('user_parent_user_id', $user_parent_user_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all Role List  */
	public function getRoleList()
	{
		$this->db->select('*');
		$this->db->from('tbl_role');
		$this->db->where('role_status', '1');
		$this->db->where('role_id !=', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all Country List  */
	public function getCountryList()
	{
		$this->db->select('*');
		$this->db->from('country');
		$this->db->where('country_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all State List  */
	public function getStateList()
	{
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('state_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all State List by country list */
	public function getStateListByCountryId($country_id)
	{
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('state_status', '1');
		$this->db->where('country_id', $country_id);
		$query = $this->db->get();
		return $query->result() ;
	}


	/* Add User Live Location */	
	public function addLiveLocation($post)
	{
		$this->db->insert('tbl_live_location', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	
	
	
	
	

}
?>
