<?php

class Stakeholdermeeting_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getStakeHolderMeetingByStakeHolderID($stakeholder_id)
	{
		$this->db->select('a.*, b.user_name as added_by, c.*');
		$this->db->from('tbl_stakeholder_meeting a');
		$this->db->join('tbl_user b','a.user_id = b.user_id','inner');
		$this->db->join('tbl_stakeholder c','a.stakeholder_id = c.stakeholder_id','inner');
		$this->db->where('a.stakeholder_id', $stakeholder_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getMeetingOrder($stakeholder_id, $start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');
		$this->db->where('stakeholder_id', $stakeholder_id);
		$this->db->where('shm_meeting_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->order_by("shm_id","desc");
		$this->db->limit(1);
		$query = $this->db->get();
		// echo $this->db->last_query();
		// die();
		return $query->result() ;
	}

	/*	Show all */
	public function getAllHealthpostArea()
	{
		$this->db->select('*');
		$this->db->from('tbl_helthpostarea');
		$this->db->where('helthpostarea_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getStakeHolderMeetingInLastMonth($stakeholder_id, $start_date, $end_date)
	{
		$this->db->select('a.*, b.user_name as added_by, c.*');
		$this->db->from('tbl_stakeholder_meeting a');
		$this->db->join('tbl_user b','a.user_id = b.user_id','inner');
		$this->db->join('tbl_stakeholder c','a.stakeholder_id = c.stakeholder_id','inner');
		$this->db->where('a.stakeholder_id', $stakeholder_id);
		$this->db->where('shm_meeting_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$query = $this->db->get();
		return $query->result() ;
	}
/*	Show all */
	public function getStakeHolderMeeting()
	{
		$this->db->select('a.*, b.user_name as added_by, c.*');
		$this->db->from('tbl_stakeholder_meeting a');
		$this->db->join('tbl_user b','a.user_id = b.user_id','inner');
		$this->db->join('tbl_stakeholder c','a.stakeholder_id = c.stakeholder_id','inner');
		$query = $this->db->get();
		return $query->result() ;
	}

	/* stakeholder details */	
	public function getStakeHolderList()
	{
		$this->db->select('a.*, b.country_name, c.state_name');
		$this->db->from('tbl_stakeholder a');
		$this->db->join('country b','a.stakeholder_country_id = b.country_id','inner');
		$this->db->join('state c','a.stakeholder_state_id = c.state_id','inner');
		$query = $this->db->get();
		return $query->result();
	}

	/* stakeholder details */	
	public function getStakeHolderDetails($stakeholder_id)
	{
		$this->db->select('a.*, b.country_name, c.state_name');
		$this->db->from('tbl_stakeholder a');
		$this->db->join('country b','a.stakeholder_country_id = b.country_id','inner');
		$this->db->join('state c','a.stakeholder_state_id = c.state_id','inner');
		$this->db->where('a.stakeholder_id', $stakeholder_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Add New  */	
	public function addStakeHolderMeeting($post)
	{
		$this->db->insert('tbl_stakeholder_meeting', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Add New  */	
	public function addStakeHolderMeetingImg($post)
	{
		$this->db->insert('tbl_stakeholder_meeting_img', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Edit User details */	
	public function editStakeHolderMeeting($shm_id)
	{
		$this->db->select('a.*, c.*');
		$this->db->from('tbl_stakeholder_meeting a');
		$this->db->join('tbl_stakeholder c','a.stakeholder_id = c.stakeholder_id','inner');
		$this->db->where('a.shm_id', $shm_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Edit User details */	
	public function editStakeHolderMeetingImg($shm_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting_img');
		$this->db->where('shm_id', $shm_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Update User */
	public function updateStakeHolderMeeting($post)
	{	
		$data['shm_no_of_participants'] = $post['shm_no_of_participants'];
		$data['shm_meting_location'] = $post['shm_meting_location'];
		$data['shm_meeting_date'] = $post['shm_meeting_date'];
		$data['shm_meeting_time_from'] = $post['shm_meeting_time_from'];
		$data['shm_meeting_time_to'] = $post['shm_meeting_time_to'];
		$data['shm_order_of_meeting_this_month'] = $post['shm_order_of_meeting_this_month'];
		$data['shm_met_status_before_month'] = $post['shm_met_status_before_month'];
		$data['shm_no_of_meeting_before_month'] = $post['shm_no_of_meeting_before_month'];
		$data['shm_purpose_of_meeting'] = $post['shm_purpose_of_meeting'];
		$data['shm_purpose_of_meeting_other'] = $post['shm_purpose_of_meeting_other'];
		$data['shm_point_of_discussion'] = $post['shm_point_of_discussion'];
		$data['shm_point_of_discussion_other'] = $post['shm_point_of_discussion_other'];
		$data['shm_track_with_agenda'] = $post['shm_track_with_agenda'];
		$data['shm_participated_status'] = $post['shm_participated_status'];
		$data['shm_achived_purpose'] = $post['shm_achived_purpose'];
		$data['shm_clearified_next_step'] = $post['shm_clearified_next_step'];
		$data['shm_stakeholde_work_status'] = $post['shm_stakeholde_work_status'];
		$data['shm_meeting_time_wroth_spent'] = $post['shm_meeting_time_wroth_spent'];
		$data['shm_power'] = $post['shm_power'];
		$data['shm_interest'] = $post['shm_interest'];
		$data['shm_organization_classified'] = $post['shm_organization_classified'];
		$data['shm_application_social_protection_scheme_status'] = $post['shm_application_social_protection_scheme_status'];
		$data['shm_application_social_protection_scheme'] = $post['shm_application_social_protection_scheme'];
		$data['shm_purpose_of_next_meeting'] = $post['shm_purpose_of_next_meeting'];
		$data['shm_date_of_next_meeting'] = $post['shm_date_of_next_meeting'];
		$data['shm_time_of_next_meeting'] = $post['shm_time_of_next_meeting'];
		$data['shm_date_of_community_activity'] = $post['shm_date_of_community_activity'];
		$data['shm_time_of_community_activity'] = $post['shm_time_of_community_activity'];
		$data['shm_venue_of_community_activity'] = $post['shm_venue_of_community_activity'];
		$data['shm_stakeholder_help'] = $post['shm_stakeholder_help'];
		$data['helthpostarea_id'] = $post['helthpostarea_id'];
		$data['stakeholder_id'] = $post['stakeholder_id'];
		$data['user_id'] = $post['user_id'];
		$data['user_all_level'] = $post['user_all_level'];
		$this->db->where('shm_id', $post['shm_id']);
		$this->db->update('tbl_stakeholder_meeting', $data);
		return true;
	}


	/* Update User */
	public function updateStakeHolderMeetingCount($post)
	{	
		$data['shm_order_of_meeting_this_month'] = $post['shm_order_of_meeting_this_month'];
		$this->db->where('stakeholder_id', $post['stakeholder_id']);
		$this->db->update('tbl_stakeholder', $data);
		return true;
	}


	/* Delete User detail */
	function delete_stakeHolderMeeting($shm_id)
	{
		$this->db->delete('tbl_stakeholder_meeting', array('shm_id' => $shm_id));		
		return 1;		
	}

}
?>
