<?php

class Monthlyreport_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	public function getTotalStakeHolderMapped($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder');
		$this->db->where('stakeholder_mapping_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getTotalStakeHolderResponsive($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');
		$this->db->where('shm_meeting_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('shm_stakeholde_work_status', 'Yes');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getTotalStakeHolderUnResponsive($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');
		$this->db->where('shm_meeting_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('shm_stakeholde_work_status', 'No');
		$query = $this->db->get();
		return $query->result() ;
	}





























	
	public function getTotalSelfReferral($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_created_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pp_referral_type', 'Self Referral');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getTotalCommunityReferral($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_created_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pp_referral_type', 'Community Referral');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getLabName()
	{
		$this->db->select('*');
		$this->db->from('tbl_diagnosis_center');
		$this->db->where('diagnosis_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}
	
	public function getAllReferredCase($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_created_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getAllReferredCasePositive($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_created_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pp_testing_result', 'Positive');
		$query = $this->db->get();
		return $query->result() ;
	}	

	public function getTotalCAT1CAR2($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_created_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pp_testing_result', 'Positive');
		$this->db->like('pp_drug_sensitive_type', 'CAT-1');
		$this->db->or_like('pp_drug_sensitive_type', 'CAT-2');
		$query = $this->db->get();
		return $query->result() ;
	}	
}
?>
