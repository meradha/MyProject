<?php

class Knowledgebase_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getKnowledgebaseAdded($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_knowledgebase a');
		//$this->db->join('tbl_user b','a.kb_assign_to = b.user_id','inner');
		//$this->db->where('a.kb_assign_by', $user_id);
		$this->db->order_by('kb_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getknowledgebaseVideoImages($kb_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_knowledgebase_img_video');
		$this->db->where('kb_id', $kb_id);		
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getknowledgebase($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_knowledgebase');
		//$this->db->join('tbl_user b','a.kb_assign_by = b.user_id','inner');
		$this->db->order_by('kb_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all Role List  */
	public function getRoleByLoginRole($user_role_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_role');
		$this->db->where('role_status', '1');
		$this->db->where('role_id >', $user_role_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all user List by role id  */
	public function getAllUserByRoleID($role_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_status', '1');
		$this->db->where('user_role_id', $role_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all user List by role id  */
	public function getUserAllLevel($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_status', '1');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show parent User */
	public function getAllUser($user_level)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_level', $user_level);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all User  */
	public function getAllUsers()
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_status', '1');
		$this->db->where('user_id !=', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show child User */
	public function getChildUser($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_parent_user_id', $user_id);
		$this->db->where('user_id !=', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New */	
	public function addKnowledgebase($post)
	{
		$this->db->insert('tbl_knowledgebase', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}

	/* Add New */	
	public function addKnowledgebaseImagesVideo($post)
	{
		$this->db->insert('tbl_knowledgebase_img_video', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Delete detail */
	function delete_knowledgebase($kb_id)
	{
		$this->db->delete('tbl_knowledgebase', array('kb_id' => $kb_id));		
		return 1;		
	}

	/* Delete detail */
	function deleteKnowledgebaseVideo($kb_id)
	{
		$this->db->delete('tbl_knowledgebase_img_video', array('kb_id' => $kb_id, 'kb_iv_type' => 'VIDEO'));		
		return 1;		
	}

	/* Edit details */	
	public function editKnowledgebase($kb_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_knowledgebase a');
		// $this->db->join('tbl_user b','a.kb_assign_to = b.user_id','inner');
		// $this->db->join('tbl_role c','a.user_role_id = c.role_id','inner');
		$this->db->where('kb_id', $kb_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Edit details */	
	public function getKnowledgebaseImagesVideo($kb_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_knowledgebase_img_video');
		$this->db->where('kb_id', $kb_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Update details */
	public function updateKnowledgebase($post)
	{	
		$data['kb_title'] = $post['kb_title'];
		$data['kb_description'] = $post['kb_description'];
		$data['kb_status'] = $post['kb_status'];
		$data['kb_updated'] = $post['kb_updated'];
		$this->db->where('kb_id', $post['kb_id']);
		$this->db->update('tbl_knowledgebase', $data);
		return true;
	}

/* Update details */
	public function updateThumbnailImg($post)
	{	
		$data['kb_thumb_img'] = $post['kb_thumb_img'];
		$this->db->where('kb_id', $post['kb_id']);
		$this->db->update('tbl_knowledgebase', $data);
		return true;
	}

















	/*	Get all user List by role id  */
	public function getTaskAssignToUserLevel($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_status', '1');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
		return $query->result() ;
	}

		

	

	/* Add New */	
	public function addSendTaskReportImages($post)
	{
		$this->db->insert('tbl_knowledgebase_report_img', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	

	/* Edit details */	
	public function editTaskSendReport($kb_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_knowledgebase_report');
		$this->db->where('kb_id', $kb_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Edit details */	
	public function editTaskSendReportImages($kb_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_knowledgebase_report_img');
		$this->db->where('kb_id', $kb_id);
		$query = $this->db->get();
		return $query->result();
	}

	

	/* Update details */
	public function updateSendTaskReport($post)
	{	
		$data['task_report_description'] = $post['task_report_description'];
		$data['task_report_status'] = $post['task_report_status'];
		$data['task_report_updated_date'] = $post['task_report_updated_date'];
		$this->db->where('kb_id', $post['kb_id']);
		$this->db->update('tbl_knowledgebase_report', $data);
		return true;
	}

	/* Update details */
	public function updatePerformTaskStatus($post)
	{	
		$data['task_perform_status'] = $post['task_perform_status'];
		$data['task_current_status_date'] = $post['task_current_status_date'];
		$data['task_updated_date'] = $post['task_updated_date'];
		$this->db->where('kb_id', $post['kb_id']);
		$this->db->update('tbl_knowledgebase', $data);
		return true;
	}
	
	/* Update details */
	public function updateCheckReport($post)
	{	
		$data['task_perform_status'] = $post['task_perform_status'];
		$data['task_appproved_status_level'] = $post['task_appproved_status_level'];
		$data['task_appproved_status'] = $post['task_appproved_status'];
		$data['task_appproved_status_date'] = $post['task_appproved_status_date'];
		$data['task_updated_date'] = $post['task_updated_date'];
		$this->db->where('kb_id', $post['kb_id']);
		$this->db->update('tbl_knowledgebase', $data);
		return true;
	}
/* Update details */
	public function updateCheckReportInComplete($post)
	{	
		$data['task_appproved_status_level'] = $post['task_appproved_status_level'];
		$data['task_appproved_status'] = $post['task_appproved_status'];
		$data['task_perform_status'] = $post['task_perform_status'];
		$data['task_reason'] = $post['task_reason'];
		$data['task_updated_date'] = $post['task_updated_date'];
		$this->db->where('kb_id', $post['kb_id']);
		$this->db->update('tbl_knowledgebase', $data);
		return true;
	}

	
}
?>
