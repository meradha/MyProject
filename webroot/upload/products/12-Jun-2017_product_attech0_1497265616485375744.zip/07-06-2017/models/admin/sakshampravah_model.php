<?php

class Sakshampravah_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getTotalNumberOfPatientRegister($sp_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('saksham_pravah_id', $sp_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getSakshamPravah()
	{
		$this->db->select('*');
		$this->db->from('tbl_saksham_pravah');
		$this->db->order_by('sp_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Country List */
	public function getAllCountry()
	{
		$this->db->select('*');
		$this->db->from('country');
		$this->db->where('country_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all State List  */
	public function getAllState()
	{
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('state_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all State List by country list */
	public function getStateListByCountryID($country_id)
	{
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('state_status', '1');
		$this->db->where('country_id', $country_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New */	
	public function addSakshamPravah($post)
	{
		$this->db->insert('tbl_saksham_pravah', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Edit details */	
	public function editSakshamPravah($sp_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_saksham_pravah');
		$this->db->where('sp_id', $sp_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Update details */
	public function updateSakshamPravah($post)
	{	
		$data['sp_name'] = $post['sp_name'];
		$data['sp_owner_name'] = $post['sp_owner_name'];
		$data['sp_email'] = $post['sp_email'];
		$data['sp_phone'] = $post['sp_phone'];
		$data['sp_mobile'] = $post['sp_mobile'];
		$data['sp_address'] = $post['sp_address'];		
		$data['sp_city'] = $post['sp_city'];		
		$data['sp_state_id'] = $post['sp_state_id'];		
		$data['sp_country_id'] = $post['sp_country_id'];		
		$data['sp_postal_code'] = $post['sp_postal_code'];		
		$data['sp_status'] = $post['sp_status'];		
		$data['sp_updated_date'] = $post['sp_updated_date'];		
		$this->db->where('sp_id', $post['sp_id']);
		$this->db->update('tbl_saksham_pravah', $data);
		return true;
	}

	/* Delete detail */
	function delete_sakshamPravah($sp_id)
	{
		$this->db->delete('tbl_saksham_pravah', array('sp_id' => $sp_id));		
		return 1;		
	}
}
?>
