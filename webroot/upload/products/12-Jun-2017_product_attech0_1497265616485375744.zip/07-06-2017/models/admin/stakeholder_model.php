<?php

class stakeholder_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getStakeHolder()
	{
		$this->db->select('a.*, b.user_name as added_by');
		$this->db->from('tbl_stakeholder a');
		$this->db->join('tbl_user b','a.user_id = b.user_id','inner');
		$this->db->order_by('a.stakeHolder_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getAllHealthpostArea()
	{
		$this->db->select('*');
		$this->db->from('tbl_helthpostarea');
		$this->db->where('helthpostarea_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New  */	
	public function addStakeHolder($post)
	{
		$this->db->insert('tbl_stakeholder', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Edit User details */	
	public function editStakeHolder($stakeHolder_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder');
		$this->db->where('stakeHolder_id', $stakeHolder_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Update User */
	public function updateStakeHolder($post)
	{	
		$data['stakeholder_mapping_date'] = $post['stakeholder_mapping_date'];
		$data['stakeholder_name'] = $post['stakeholder_name'];
		$data['stakeholder_phone'] = $post['stakeholder_phone'];
		$data['stakeholder_country_id'] = $post['stakeholder_country_id'];
		$data['stakeholder_state_id'] = $post['stakeholder_state_id'];
		$data['stakeholder_city'] = $post['stakeholder_city'];
		$data['stakeholder_address'] = $post['stakeholder_address'];
		$data['stakeholder_landmark'] = $post['stakeholder_landmark'];
		$data['stakeholder_postal_code'] = $post['stakeholder_postal_code'];
		$data['stakeholder_type'] = $post['stakeholder_type'];
		$data['stakeholder_type_other'] = $post['stakeholder_type_other'];
		$data['stakeholder_correspondance_person'] = $post['stakeholder_correspondance_person'];
		$data['stakeholder_trust_area'] = $post['stakeholder_trust_area'];
		$data['stakeholder_trust_area_other'] = $post['stakeholder_trust_area_other'];
		$data['stakeholder_focus_population'] = $post['stakeholder_focus_population'];
		$data['stakeholder_focus_population_other'] = $post['stakeholder_focus_population_other'];
		$data['stakeholder_area'] = $post['stakeholder_area'];
		$data['healthpostarea_id'] = $post['healthpostarea_id'];
		$data['stakeholder_power_structure'] = $post['stakeholder_power_structure'];
		$data['stakeholder_working_since'] = $post['stakeholder_working_since'];
		$data['stakeholder_any_remarks'] = $post['stakeholder_any_remarks'];
		$data['stakeholder_status'] = $post['stakeholder_status'];
		$data['user_id'] = $post['user_id'];
		$data['user_all_level'] = $post['user_all_level'];
		$data['stakeholder_updated_date'] = $post['stakeholder_updated_date'];
		$this->db->where('stakeHolder_id', $post['stakeHolder_id']);
		$this->db->update('tbl_stakeholder', $data);
		return true;
	}

	/* Delete User detail */
	function delete_stakeHolder($stakeHolder_id)
	{
		$this->db->delete('tbl_stakeholder', array('stakeHolder_id' => $stakeHolder_id));		
		return 1;		
	}



	

	






















	
	

	/*	Get all Role List  */
	public function getRoleList()
	{
		$this->db->select('*');
		$this->db->from('tbl_role');
		$this->db->where('role_status', '1');
		$this->db->where('role_id !=', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all Country List  */
	public function getCountryList()
	{
		$this->db->select('*');
		$this->db->from('country');
		$this->db->where('country_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all State List  */
	public function getStateList()
	{
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('state_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all State List by country list */
	public function getStateListByCountryId($country_id)
	{
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('state_status', '1');
		$this->db->where('country_id', $country_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	
	
	
	
	

}
?>
