<?php

class User_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Get all Role List  */
	public function getRoleByLoginRole($user_role_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_role');
		$this->db->where('role_status', '1');
		$this->db->where('role_id >', $user_role_id);
		$this->db->order_by('role_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all User by role */
	public function getAllUserByRole($role_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_role_id', $role_id);
		$this->db->order_by('user_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show parent User name */
	public function getParentUserName($user_parent_user_id)
	{
		$this->db->select('user_name');
		$this->db->from('tbl_user');
		$this->db->where('user_id', $user_parent_user_id);
		$query = $this->db->get();
		return $query->result() ;
	}
	
	/*	Show parent User */
	public function getAllUser($user_level)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_level', $user_level);
		$query = $this->db->get();
		return $query->result() ;
	}


	/*	Show child User */
	public function getChildUser($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_parent_user_id', $user_id);
		$this->db->where('user_id !=', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getUserByID($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New User */	
	public function addUser($post)
	{
		$this->db->insert('tbl_user', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Edit User details */	
	public function editUser($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
		return $query->result();
	}

	/*	Show all User  */
	public function getAllUsers()
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_status', '1');
		$this->db->where('user_id !=', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show parent User */
	public function getAllUserByLevelParentID($user_level, $user_parent_user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_level', $user_level);
		$this->db->where('user_parent_user_id', $user_parent_user_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Update User */
	public function updateUser($post)
	{	
		if($post['user_img'])
		{
			$data['user_img'] = $post['user_img'];
		}
		$data['user_role_id'] = $post['user_role_id'];
		if($post['Change_Level'] == 'Change_Level')
		{
			$data['user_all_level'] = $post['user_all_level'];
			$data['user_parent_user_id'] = $post['user_parent_user_id'];			
		}
		$data['user_phone'] = $post['user_phone'];
		$data['user_name'] = $post['user_name'];
		$data['user_gender'] = $post['user_gender'];
		$data['user_dob'] = $post['user_dob'];
		$data['user_level'] = $post['user_level'];
		$data['user_status'] = $post['user_status'];
		$data['added_by'] = $post['added_by'];
		$data['user_updated_date'] = $post['user_updated_date'];		
		$this->db->where('user_id', $post['user_id']);
		$this->db->update('tbl_user', $data);
		return true;
	}



	

	






















	
	

	/*	Get all Role List  */
	public function getRoleList()
	{
		$this->db->select('*');
		$this->db->from('tbl_role');
		$this->db->where('role_status', '1');
		$this->db->where('role_id !=', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all Country List  */
	public function getCountryList()
	{
		$this->db->select('*');
		$this->db->from('country');
		$this->db->where('country_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all State List  */
	public function getStateList()
	{
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('state_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all State List by country list */
	public function getStateListByCountryId($country_id)
	{
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('state_status', '1');
		$this->db->where('country_id', $country_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	
	
	
	
	/* Delete User detail */
	function delete_user($user_id)
	{
		if($this->db->delete('tbl_user', array('user_id' => $user_id)))
		{
			return 1;
		}	
		else
		{
			return 2;
		}		
	}

}
?>
