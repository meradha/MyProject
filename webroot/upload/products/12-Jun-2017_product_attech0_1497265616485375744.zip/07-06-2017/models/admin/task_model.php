<?php

class Task_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getTask($user_id)
	{
		$this->db->select('a.*, b.*');
		$this->db->from('tbl_task a');
		$this->db->join('tbl_taskform b','a.taskform_id = b.taskform_id','inner');
		$this->db->where('a.user_id', $user_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getTaskForm()
	{
		$this->db->select('*');
		$this->db->from('tbl_taskform');
		$this->db->where('taskform_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New */	
	public function addTask($post)
	{
		$this->db->insert('tbl_task', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	


	/* Edit details */	
	public function editTask($task_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_task');
		$this->db->where('task_id', $task_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Update details */
	public function updateTask($post)
	{	
		$data['taskform_id'] = $post['taskform_id'];
		$data['task_type'] = $post['task_type'];
		$data['task_name'] = $post['task_name'];
		$data['task_description'] = $post['task_description'];
		$data['task_status'] = $post['task_status'];
		$data['user_id'] = $post['user_id'];		
		$data['user_all_level'] = $post['user_all_level'];
		$data['task_updated_date'] = $post['task_updated_date'];
		$this->db->where('task_id', $post['task_id']);
		$this->db->update('tbl_task', $data);
		return true;
	}

	/* Delete detail */
	function delete_task($task_id)
	{
		$this->db->delete('tbl_task', array('task_id' => $task_id));		
		return 1;		
	}
}
?>
