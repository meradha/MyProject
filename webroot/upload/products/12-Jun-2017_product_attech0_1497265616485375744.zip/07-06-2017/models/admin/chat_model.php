<?php

class Chat_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getAllChat()
	{
		$this->db->select('*');
		$this->db->from('tbl_chat');
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New */	
	public function addChat($post)
	{
		$this->db->insert('tbl_chat', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

}
?>
