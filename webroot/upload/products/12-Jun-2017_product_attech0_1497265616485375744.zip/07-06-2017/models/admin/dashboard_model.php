<?php

class Dashboard_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	public function getAllRole()
	{
		$this->db->select('*');
		$this->db->from('tbl_role');
		$this->db->where('role_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getUserByRoleID($role_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_role_id', $role_id);
		$query = $this->db->get();
		return $query->result() ;
	}
	
	public function getAllStakeHolder()
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder');
		$this->db->where('stakeholder_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getAllStakeholderMeeting()
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getAllCommunityMeeting()
	{
		$this->db->select('*');
		$this->db->from('tbl_task_community_awareness');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getAllPresumptivePatient()
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getAllPatient()
	{
		$this->db->select('*');
		$this->db->from('tbl_patient');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getAllReferralLinkages()
	{
		$this->db->select('*');
		$this->db->from('tbl_saksham_pravah');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getAllLabs()
	{
		$this->db->select('*');
		$this->db->from('tbl_diagnosis_center');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getAllStakeHolderBySakshamSathiID($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
		return $query->result() ;
	}	
	public function getAllSakshamSathi()
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_role_id', '7');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getNameOfWardCountEast()
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_tb_details');
		$this->db->where('ptb_name_ward', 'M/East');
		$query = $this->db->get();
		return $query->result() ;
	}
	public function getNameOfWardCountWest()
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_tb_details');
		$this->db->where('ptb_name_ward', 'M/West');
		$query = $this->db->get();
		return $query->result() ;
	}

	
	public function getPowerStuctureHH()
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');
		$this->db->where('shm_organization_classified', 'High power, High interest');
		$query = $this->db->get();
		return $query->result() ;
	}	
	public function getPowerStuctureHL()
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');
		$this->db->where('shm_organization_classified', 'High power, Low interest');
		$query = $this->db->get();
		return $query->result() ;
	}
	public function getPowerStuctureLH()
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');
		$this->db->where('shm_organization_classified', 'Low power, High interest');
		$query = $this->db->get();
		return $query->result() ;
	}
	public function getPowerStuctureLL()
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');
		$this->db->where('shm_organization_classified', 'Low power, Low interest');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getFocusPopulation()
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder');
		$query = $this->db->get();
		return $query->result() ;
	}
	
}
?>
