<?php

class Common_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}
	
	/*	Country List */
	public function getAllCountry()
	{
		$this->db->select('*');
		$this->db->from('country');
		$this->db->where('country_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all State List  */
	public function getAllState()
	{
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('state_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all State List by country list */
	public function getStateListByCountryID($country_id)
	{
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('state_status', '1');
		$this->db->where('country_id', $country_id);
		$query = $this->db->get();
		return $query->result() ;
	}
}
?>
