<?php

class cron_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	public function updateTaskWorkStatus($post)
	{
		$data['ta_work_status'] = $post['ta_work_status'];
		$this->db->where('ta_id', $post['ta_id']);
		$this->db->update('tbl_task_assigned', $data);
		return true;
	}
	
	public function updateTaskCountTargetStatus($post)
	{
		$data['ttc_target_status'] = $post['ttc_target_status'];
		$this->db->where('ta_id', $post['ta_id']);
		$this->db->update('tbl_task_assigned', $data);
		return true;
	}

	public function stopTaskWorkStatus()
	{
		$this->db->select('*');
		$this->db->from('tbl_task_assigned');
		$query = $this->db->get();
		return $query->result() ;
	}

}
?>
