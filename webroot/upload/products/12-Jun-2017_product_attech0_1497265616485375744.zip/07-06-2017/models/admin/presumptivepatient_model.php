<?php

class Presumptivepatient_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getAllHealthpostArea()
	{
		$this->db->select('*');
		$this->db->from('tbl_helthpostarea');
		$this->db->where('helthpostarea_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}
	
	/*	Show all */
	public function getAllPresumptivePatient()
	{
		$this->db->select('a.*, b.user_name as added_by, c.diagnosis_name');
		$this->db->from('tbl_patient_presumptive a');
		$this->db->join('tbl_user b','a.user_id = b.user_id','inner');
		$this->db->join('tbl_diagnosis_center c','a.diagnosis_id = c.diagnosis_id','inner');
		 $this->db->order_by('a.pp_id','DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	all Diagnosis List */
	public function getAllDiagnosis()
	{
		$this->db->select('*');
		$this->db->from('tbl_diagnosis_center');
		$this->db->where('diagnosis_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	all stakeholder List */
	public function getAllStakeholder()
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder');
		$this->db->where('stakeholder_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New */	
	public function addPresumptivePatient($post)
	{
		$this->db->insert('tbl_patient_presumptive', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Edit details */	
	public function editPresumptivePatient($pp_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_id', $pp_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Update details */
	public function updateSakshamID($post)
	{	
		$data['pp_saksham_patient_id'] = $post['pp_saksham_patient_id'];				
		$this->db->where('pp_id', $post['pp_id']);
		$this->db->update('tbl_patient_presumptive', $data);
		return true;
	}

	/* Update details */
	public function updatePresumptivePatient($post)
	{	
		$data['pp_referral_date'] = $post['pp_referral_date'];
		$data['pp_referral_type'] = $post['pp_referral_type'];
		$data['pp_community_activity_name'] = $post['pp_community_activity_name'];
		$data['pp_date_of_activity'] = $post['pp_date_of_activity'];
		$data['pp_sputum_date'] = $post['pp_sputum_date'];
		$data['pp_stakeholder_name'] = $post['pp_stakeholder_name'];
		$data['pp_patient_name'] = $post['pp_patient_name'];
		$data['pp_age'] = $post['pp_age'];
		$data['pp_sex'] = $post['pp_sex'];		
		$data['country_id'] = $post['country_id'];		
		$data['state_id'] = $post['state_id'];		
		$data['pp_city'] = $post['pp_city'];		
		$data['pp_address'] = $post['pp_address'];		
		$data['pp_postal_code'] = $post['pp_postal_code'];		
		$data['pp_phone_no'] = $post['pp_phone_no'];		
		$data['diagnosis_id'] = $post['diagnosis_id'];		
		$data['pp_landmark'] = $post['pp_landmark'];		
		$data['pp_updated_date'] = $post['pp_updated_date'];		
		$this->db->where('pp_id', $post['pp_id']);
		$this->db->update('tbl_patient_presumptive', $data);
		return true;
	}

	/* Delete detail */
	function delete_presumptivePatient($pp_id)
	{
		$this->db->delete('tbl_patient_presumptive', array('pp_id' => $pp_id));		
		return 1;		
	}

	/*	Show all */
	public function presumptivePatientDetailsByID($pp_id)
	{
		$this->db->select('a.*, b.user_name, c.diagnosis_name, d.country_name, e.state_name');
		$this->db->from('tbl_patient_presumptive a');
		$this->db->join('tbl_user b','a.user_id = b.user_id','inner');
		$this->db->join('tbl_diagnosis_center c','a.diagnosis_id = c.diagnosis_id','inner');
		$this->db->join('country d','a.country_id = d.country_id','inner');
		$this->db->join('state e','a.state_id = e.state_id','inner');
		$this->db->where('a.pp_id', $pp_id);
		$query = $this->db->get();
		// echo $this->db->last_query();die();
		return $query->result() ;
	}

	/*	Patient category */
	public function patientCategoryList()
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_category');
		$this->db->where('patient_category_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Update details */
	public function updatePresumptivePatientReportStatus($post)
	{	
		$data['pp_reached_status'] = $post['pp_reached_status'];
		if($post['pp_reached_status'] == 'Yes')
		{
			$data['pp_testing_status'] = $post['pp_testing_status'];
			if($post['pp_testing_status'] == 'Yes')
			{
				$data['pp_testing_date'] = $post['pp_testing_date'];
				$data['pp_testing_number'] = $post['pp_testing_number'];
				$data['pp_testing_result'] = $post['pp_testing_result'];
				if($post['pp_testing_result'] == 'Positive')
				{
					$data['pp_diagnosis_date'] = $post['pp_diagnosis_date'];
					$data['pp_drug_resistance_status'] = $post['pp_drug_resistance_status'];
					if($post['pp_drug_resistance_status'] == 'Drug Sensitive')
					{
						$data['pp_drug_sensitive_type'] = $post['pp_drug_sensitive_type'];
						$data['pp_drug_sensitive_type_other'] = $post['pp_drug_sensitive_type_other'];
						if($post['pp_drug_sensitive_type'])
						{
							$data['pp_report_status'] = $post['pp_report_status'];
						}
					}
					else
					{
						$data['pp_drug_resistance_type'] = $post['pp_drug_resistance_type'];
						$data['pp_drug_resistance_type_other'] = $post['pp_drug_resistance_type_other'];
						$data['pp_comments'] = $post['pp_comments'];
						$data['pp_report_status'] = $post['pp_report_status'];
					}
				}
				elseif($post['pp_testing_result'] == 'Negative')
				{
					$data['pp_report_status'] = '1';
				}
			}
			else
			{
				$data['pp_testing_reason'] = $post['pp_testing_reason'];
			}
		}		
		$data['pp_updated_date'] = $post['pp_updated_date'];
		$this->db->where('pp_id', $post['pp_id']);
		$this->db->update('tbl_patient_presumptive', $data);
		return true;
	}

	/*	Saksham Pravah List */
	public function getSakshamPravahList()
	{
		$this->db->select('*');
		$this->db->from('tbl_saksham_pravah');
		$this->db->where('sp_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Update details */
	public function updatePresumptivePatientSendSakshamPravah($post)
	{	
		$data['pp_patient_nikshay_id'] = $post['pp_patient_nikshay_id'];
		$data['pp_date_of_saksham_counsellor'] = $post['pp_date_of_saksham_counsellor'];
		$data['pp_helth_post_area'] = $post['pp_helth_post_area'];
		$data['saksham_pravah_id'] = $post['saksham_pravah_id'];	
		$data['pp_send_pravah_status'] = $post['pp_send_pravah_status'];	
		$data['pp_report_status'] = $post['pp_report_status'];	
		$this->db->where('pp_id', $post['pp_id']);
		$this->db->update('tbl_patient_presumptive', $data);
		return true;
	}

	/*	Saksham Pravah data by id*/
	public function getSakshamPravahData($saksham_pravah_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_saksham_pravah');
		$this->db->where('sp_status', '1');
		$this->db->where('sp_id', $saksham_pravah_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Update details */
	public function updateAcceptanceBySakshamPravah($post)
	{	
		$data['pp_send_pravah_status'] = $post['pp_send_pravah_status'];
		$this->db->where('pp_id', $post['pp_id']);
		$this->db->update('tbl_patient_presumptive', $data);
		return true;
	}

	/*	Show all */
	public function showSendSakhamPravahData($pp_id)
	{
		$this->db->select('a.*, b.user_name, c.diagnosis_name, d.country_name, e.state_name, f.sp_name');
		$this->db->from('tbl_patient_presumptive a');
		$this->db->join('tbl_user b','a.user_id = b.user_id','inner');
		$this->db->join('tbl_diagnosis_center c','a.diagnosis_id = c.diagnosis_id','inner');
		$this->db->join('country d','a.country_id = d.country_id','inner');
		$this->db->join('state e','a.state_id = e.state_id','inner');
		$this->db->join('tbl_saksham_pravah f','a.saksham_pravah_id = f.sp_id','inner');
		$this->db->where('a.pp_id', $pp_id);
		$query = $this->db->get();
		// echo $this->db->last_query();
		// die;
		return $query->result() ;
	}

	/* Set Active / Inactive Status  */
	function setStatus($post)
	{
		$data = array(
			'pp_permission_presumptive_status' => $post['pp_permission_presumptive_status']
		);
		$this->db->where('pp_id', $post['pp_id']);
		$this->db->update('tbl_patient_presumptive', $data); 
		return true; 
	} 


}
?>
