<?php

class Healthpostarea_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getHealthpostArea()
	{
		$this->db->select('*');
		$this->db->from('tbl_helthpostarea');
		$this->db->order_by('helthpostarea_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New */	
	public function addHealthpostArea($post)
	{
		$this->db->insert('tbl_helthpostarea', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Edit details */	
	public function editHealthpostArea($helthpostarea_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_helthpostarea');
		$this->db->where('helthpostarea_id', $helthpostarea_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Update details */
	public function updateHealthpostArea($post)
	{	
		$data['helthpostarea_name'] = $post['helthpostarea_name'];		
		$data['helthpostarea_status'] = $post['helthpostarea_status'];		
		$data['user_id'] = $post['user_id'];		
		$data['user_all_level'] = $post['user_all_level'];		
		$data['helthpostarea_updated_date'] = $post['helthpostarea_updated_date'];		
		$this->db->where('helthpostarea_id', $post['helthpostarea_id']);
		$this->db->update('tbl_helthpostarea', $data);
		return true;
	}

	/* Delete detail */
	function delete_healthpostArea($helthpostarea_id)
	{
		$this->db->delete('tbl_helthpostarea', array('helthpostarea_id' => $helthpostarea_id));		
		return 1;		
	}
}
?>
