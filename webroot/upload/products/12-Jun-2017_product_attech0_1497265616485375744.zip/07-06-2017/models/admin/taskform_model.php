<?php

class Taskform_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getTaskForm($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_taskform');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New */	
	public function addTaskForm($post)
	{
		$this->db->insert('tbl_taskform', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Edit details */	
	public function editTaskForm($taskform_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_taskform');
		$this->db->where('taskform_id', $taskform_id);
		$query = $this->db->get();
		return $query->result();
	}


	/* Update details */
	public function updateTaskForm($post)
	{	
		$data['taskform_name'] = $post['taskform_name'];
		$data['taskform_status'] = $post['taskform_status'];
		$data['user_id'] = $post['user_id'];
		$data['user_all_level'] = $post['user_all_level'];
		$data['taskform_updated_date'] = $post['taskform_updated_date'];
		$this->db->where('taskform_id', $post['taskform_id']);
		$this->db->update('tbl_taskform', $data);
		return true;
	}
	
	/* Delete detail */
	function delete_taskForm($taskform_id)
	{
		$this->db->delete('tbl_taskform', array('taskform_id' => $taskform_id));		
		return 1;		
	}
}
?>
