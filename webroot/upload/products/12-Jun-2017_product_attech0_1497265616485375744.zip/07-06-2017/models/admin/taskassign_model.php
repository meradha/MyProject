<?php

class Taskassign_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getTaskAssignBy($user_id)
	{
		$this->db->select('a.*, b.*, c.*');
		$this->db->from('tbl_task_assigned a');
		$this->db->join('tbl_task b','a.task_id = b.task_id','inner');
		$this->db->join('tbl_user c','a.ta_assign_to = c.user_id','inner');
		$this->db->where('a.ta_assign_by', $user_id);
		$this->db->order_by('a.ta_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getTaskAssignApproved()
	{
		$this->db->select('a.*, b.*, c.user_name as assign_to, d.user_name as assign_by');
		$this->db->from('tbl_task_assigned a');
		$this->db->join('tbl_task b','a.task_id = b.task_id','inner');
		$this->db->join('tbl_user c','a.ta_assign_to = c.user_id','inner');
		$this->db->join('tbl_user d','a.ta_assign_by = d.user_id','inner');
		$this->db->order_by('a.ta_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all Role List  */
	public function getRoleByLoginRole($user_role_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_role');
		$this->db->where('role_status', '1');
		$this->db->where('role_id >', $user_role_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all user List by role id  */
	public function getAllUserByRoleID($role_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_status', '1');
		$this->db->where('user_role_id', $role_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getAllTask()
	{
		$this->db->select('*');
		$this->db->from('tbl_task');
		$this->db->where('task_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getTaskFormByTaskID($task_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_task');
		$this->db->where('task_id', $task_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getAllStakeholder()
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder');
		$this->db->where('stakeholder_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getAllHelthPostArea()
	{
		$this->db->select('*');
		$this->db->from('tbl_helthpostarea');
		$this->db->where('helthpostarea_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getUserLevel($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_status', '1');
		$this->db->where('user_id', $user_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getTaskDetailsByTaskID($task_id)
	{
		$this->db->select('a.*, b.*');
		$this->db->from('tbl_task a');
		$this->db->join('tbl_taskform b', 'a.taskform_id = b.taskform_id', 'inner');
		$this->db->where('a.task_status', '1');
		$this->db->where('a.task_id', $task_id);
		$query = $this->db->get();
		return $query->result() ;
	}

		/* Add New */	
	public function addTaskAssign($post)
	{
		$this->db->insert('tbl_task_assigned', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	
	/* Add New */	
	public function addTaskTarget($post)
	{
		$this->db->insert('tbl_task_target_count', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

		/* Edit details */	
	public function editTaskAssign($ta_id)
	{
		$this->db->select('a.*, b.*, c.*, d.*');
		$this->db->from('tbl_task_assigned a');
		$this->db->join('tbl_task b','a.task_id = b.task_id','inner');
		$this->db->join('tbl_taskform d','a.taskform_id = d.taskform_id','inner');
		$this->db->join('tbl_user c','a.ta_assign_to = c.user_id','inner');
		$this->db->where('a.ta_id', $ta_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Update details */
	public function updateTaskAssign($post)
	{	
		$data['task_id'] = $post['task_id'];
		$data['ta_task_start_date'] = $post['ta_task_start_date'];
		$data['ta_task_end_date'] = $post['ta_task_end_date'];
		$data['ta_total_task'] = $post['ta_total_task'];
		$data['ta_low_case_area_task'] = $post['ta_low_case_area_task'];
		$data['ta_high_case_area_task'] = $post['ta_high_case_area_task'];		
		$data['ta_status'] = $post['ta_status'];
		$data['user_id'] = $post['user_id'];
		$data['user_all_level'] = $post['user_all_level'];
		$data['ta_remaining_task'] = $post['ta_remaining_task'];
		$data['ta_updated_date'] = $post['ta_updated_date'];
		$this->db->where('ta_id', $post['ta_id']);
		$this->db->update('tbl_task_assigned', $data);
		return true;
	}

	/* Update details */
	public function updateTaskTarget($post)
	{	
		$data['ttc_total_target'] = $post['ttc_total_target'];
		$data['ttc_hca_total_target'] = $post['ttc_hca_total_target'];
		$data['ttc_lca_total_target'] = $post['ttc_lca_total_target'];
		$data['user_id'] = $post['user_id'];
		$data['user_all_level'] = $post['user_all_level'];
		$this->db->where('ta_id', $post['ta_id']);
		$this->db->update('tbl_task_target_count', $data);
		return true;
	}
	
	/* Delete detail */
	function delete_taskAssign($ta_id)
	{
		$this->db->delete('tbl_task_assigned', array('ta_id' => $ta_id));		
		return 1;		
	}
	
	/* Edit details */	
	public function getTaskFormDetail($task_id)
	{
		$this->db->select('a.*, b.*');
		$this->db->from('tbl_taskform a');
		$this->db->join('tbl_task b','a.taskform_id = b.taskform_id','inner');
		$this->db->where('b.task_id', $task_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Edit details */	
	public function getAllSendReport($ta_id)
	{
		$this->db->select('a.*, b.*');
		$this->db->from('tbl_task_community_awareness a');
		$this->db->join('tbl_task b','a.task_id = b.task_id','inner');
		$this->db->where('a.ta_id', $ta_id);
		$query = $this->db->get();
		//echo $this->db->last_query();die();
		return $query->result();
	}

		/* Add New */	
	public function addTaskAssignedReport($post)
	{
		$this->db->insert('tbl_task_community_awareness', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	
	/* Add New */	
	public function addTaskAssignedReportImg($post)
	{
		$this->db->insert('tbl_task_community_awareness_img', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Delete detail */
	function delete_taskASsignedSendReport($tca_id)
	{
		$this->db->delete('tbl_task_community_awareness', array('tca_id' => $tca_id));		
		return 1;		
	}

	/* Edit details */	
	public function editTaskAssignReport($tca_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_task_community_awareness');
		$this->db->where('tca_id', $tca_id);
		$query = $this->db->get();
		//echo $this->db->last_query();die();
		return $query->result();
	}

	/* Edit details */	
	public function editTaskAssignReportImg($tca_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_task_community_awareness_img');
		$this->db->where('tca_id', $tca_id);
		$query = $this->db->get();
		//echo $this->db->last_query();die();
		return $query->result();
	}


	/* Update details */
	public function updateTaskAssignReport($post)
	{	
		$data['ta_id'] = $post['ta_id'];
		$data['task_id'] = $post['task_id'];
		$data['tca_activity_place'] = $post['tca_activity_place'];
		$data['tca_activity_subarea'] = $post['tca_activity_subarea'];
		$data['tca_activity_date'] = $post['tca_activity_date'];
		$data['tca_activity_start_time'] = $post['tca_activity_start_time'];
		$data['tca_activity_end_time'] = $post['tca_activity_end_time'];		
		$data['tca_type_of_community_activity'] = $post['tca_type_of_community_activity'];
		$data['tca_type_of_community_activity_other'] = $post['tca_type_of_community_activity_other'];
		$data['tca_focus_population'] = $post['tca_focus_population'];
		$data['tca_name_of_stakeholder'] = $post['tca_name_of_stakeholder'];
		$data['tca_area'] = $post['tca_area'];
		$data['tca_total_no_attendess'] = $post['tca_total_no_attendess'];
		$data['tca_no_of_presumptive_tb_case'] = $post['tca_no_of_presumptive_tb_case'];
		$data['tca_covered_topics'] = $post['tca_covered_topics'];
		$data['tca_updated_date'] = $post['tca_updated_date'];
		$data['user_id'] = $post['user_id'];
		$data['user_all_level'] = $post['user_all_level'];
		$this->db->where('tca_id', $post['tca_id']);
		$this->db->update('tbl_task_community_awareness', $data);
		return true;
	}

	/* target task count */	
	public function getTaskTargetCount($ta_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_task_target_count');
		$this->db->where('ta_id', $ta_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Add New */	
	public function addTaskTargetCount($post)
	{
		$this->db->insert('tbl_task_target_count', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Add New */	
	public function updateTaskTargetCount($post)
	{

		$data['ttc_r_target'] = $post['ttc_r_target'];
		if($post['tca_area'] == 'Low case burden area')
		{
			$data['ttc_r_lca_target'] = $post['ttc_r_lca_target'];
		}
		else
		{
			$data['ttc_r_hca_target'] = $post['ttc_r_hca_target'];
		}	
		$this->db->where('ta_id', $post['ta_id']);
		$this->db->update('tbl_task_target_count', $data);
		return true;
	}	

	/* Add New */	
	public function updateTaskAssignTargetCount($post)
	{
		$data['ta_remaining_task'] = $post['ta_remaining_task'];			
		$this->db->where('ta_id', $post['ta_id']);
		$this->db->update('tbl_task_assigned', $data);
		return true;
	}	

	/* target task count */	
	public function getOldTaskByAssignToUserID($user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_task_assigned');
		$this->db->where('ta_assign_to', $user_id);
		$this->db->where('ta_work_status', '1');
		$this->db->order_by('ta_id', 'DESC');
		$this->db->limit(1);
		$query = $this->db->get();
		return $query->result();
	}
	
	/* target task count */	
	public function getTaskTargetCountByAssignUserId($user_id, $taskform_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_task_target_count');
		$this->db->where('ttc_asign_user_id', $user_id);
		$this->db->where('taskform_id', $taskform_id);
		$this->db->where('ttc_target_status', '1');
		$this->db->order_by('ttc_id', 'DESC');
		//$this->db->limit(1);
		$query = $this->db->get();
		return $query->result();
	}
	//----------------------AMIT CODE START---------------------//
	public function getTaskAssignTo($user_id)
	{
		$where = "FIND_IN_SET('".$user_id."', a.user_all_level_assign_to)";
		$this->db->select('a.*,b.*,c.*');
		$this->db->from('tbl_task_assigned a');
		$this->db->join('tbl_task b','a.task_id = b.task_id','inner');
		$this->db->join('tbl_user c','a.ta_assign_to = c.user_id','inner');
		// $this->db->where('a.ta_assign_to', $user_id);
		$this->db->where($where);
		$query = $this->db->get();
		return $query->result() ;
	}
	
	public function get_reminder($user_id)
	{
		$where = "FIND_IN_SET('".$user_id."', user_all_level)";
		$this->db->select('*');
		$this->db->from('tbl_reminder');	
		// $this->db->where('uid', $user_id);
		$this->db->where($where);
		$query = $this->db->get();
		return $query->result() ;
	}
	
	/* Add New */	
	public function add_reminder($post)
	{
		$this->db->insert('tbl_reminder', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}
	
	/* Add New */	
	public function update_reminder($post)
	{
		$this->db->where('reminder_id', $post['reminder_id']);
		$this->db->update('tbl_reminder', $post);
		return true;	
	}	

	public function delete_reminder($reminder_id)
	{
		$this->db->delete('tbl_reminder', array('reminder_id' => $reminder_id));		
		return 1;		
	}	

 	public function get_meetings($user_id)
 	{
 		$where = "FIND_IN_SET('".$user_id."', user_all_level)";
        $this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');	
		$this->db->where($where);
		// $this->db->where('user_id', $user_id);
		$query = $this->db->get();
		return $query->result() ;

	}

	public function get_followup($user_id)
	{
		$where = "FIND_IN_SET('".$user_id."', a.user_all_level)";
		$this->db->select('a.*,b.*');
		$this->db->from('tbl_patient_follow_up_dates a');
		$this->db->join('tbl_patient b','a.patient_id = b.patient_id','inner');		
		$this->db->where($where);
		// $this->db->where('a.user_id', $user_id);
		$query = $this->db->get();
		return $query->result() ;
	}
	
	/*	Show all User by role(Saskham) */
	public function getUserByRoleAndLevel($user_id,$role_id)
	{
		$where = "FIND_IN_SET('".$user_id."', user_all_level)";
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_role_id', $role_id);
		$this->db->where('user_status', 1);
		$this->db->where($where);
		$query = $this->db->get();
		return $query->result() ;
	}
	//----------------AMIT CODE END--------------------------//
}
?>
