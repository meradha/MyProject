<?php

class Labdata_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	public function getAllLabData()
	{
		$this->db->select('a.*, b.*');
		$this->db->from('tbl_lab_data a');
		$this->db->join('tbl_diagnosis_center b','a.diagnosis_id = b.diagnosis_id','inner');
		$this->db->order_by('a.ld_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getLabDataByMonthYearLabID($diagnosis_id, $ld_year, $ld_month)
	{
		$this->db->select('a.*, b.*');
		$this->db->from('tbl_lab_data a');
		$this->db->join('tbl_diagnosis_center b','a.diagnosis_id = b.diagnosis_id','inner');
		$this->db->where('a.diagnosis_id', $diagnosis_id);
		$this->db->where('a.ld_year', $ld_year);
		$this->db->where('a.ld_month', $ld_month);
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getAllLabList()
	{
		$this->db->select('*');
		$this->db->from('tbl_diagnosis_center');
		$this->db->where('diagnosis_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New */	
	public function addLabData($post)
	{
		$this->db->insert('tbl_lab_data', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	


	/* Update details */
	public function updateLabData($post)
	{	
		$data['ld_year'] = $post['ld_year'];
		$data['ld_month'] = $post['ld_month'];
		$data['diagnosis_id'] = $post['diagnosis_id'];
		$data['ld_presumptive_tested'] = $post['ld_presumptive_tested'];
		$data['ld_presumptive_tested_positive'] = $post['ld_presumptive_tested_positive'];
		$data['ld_referred_by_saksham_sathi'] = $post['ld_referred_by_saksham_sathi'];		
		$data['ld_tested_out_referred_by_saksham_sathi'] = $post['ld_tested_out_referred_by_saksham_sathi'];		
		$data['ld_positive_referred_by_saksham_sathi'] = $post['ld_positive_referred_by_saksham_sathi'];
		$data['user_id'] = $post['user_id'];		
		$data['user_all_level'] = $post['user_all_level'];		
		$data['ld_updated_date'] = $post['ld_updated_date'];	
		$this->db->where('ld_id', $post['ld_id']);
		$this->db->update('tbl_lab_data', $data);
		return true;
	}
	
	
}
?>
