<?php

class Leave_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getApplyLeave($user_id)
	{
		$this->db->select('a.*, b.user_name');
		$this->db->from('tbl_leave a');
		$this->db->join('tbl_user b','a.leave_approved_by = b.user_id','inner');
		$this->db->where('a.leave_user_id', $user_id);
		$this->db->order_by('a.leave_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getAppliedLeave()
	{
		$this->db->select('a.*, b.user_name');
		$this->db->from('tbl_leave a');
		$this->db->join('tbl_user b','a.leave_user_id = b.user_id','inner');
		//$this->db->where('a.leave_approved_by', $user_id);
		$this->db->order_by('a.leave_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Show all */
	public function getParentUserDetails($user_parent_user_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_id', $user_parent_user_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New */	
	public function addLeave($post)
	{
		$this->db->insert('tbl_leave', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Edit details */	
	public function editLeave($leave_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_leave');
		$this->db->where('leave_id', $leave_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Update details */
	public function updateLeave($post)
	{	
		$data['leave_start_date'] = $post['leave_start_date'];
		$data['leave_end_date'] = $post['leave_end_date'];
		$data['leave_reason'] = $post['leave_reason'];
		$data['leave_status'] = $post['leave_status'];
		$data['leave_approved_status'] = $post['leave_approved_status'];
		$data['leave_approved_by'] = $post['leave_approved_by'];
		$data['leave_user_id'] = $post['leave_user_id'];		
		$data['leave_user_level'] = $post['leave_user_level'];		
		$data['leave_updated_date'] = $post['leave_updated_date'];	
		$this->db->where('leave_id', $post['leave_id']);
		$this->db->update('tbl_leave', $data);
		return true;
	}

	/* Update details */
	public function updateApproveLeaveStatus($post)
	{	
		$data['leave_approved_status'] = $post['leave_approved_status'];
		$data['leave_updated_date'] = $post['leave_updated_date'];			
		$this->db->where('leave_id', $post['leave_id']);
		$this->db->update('tbl_leave', $data);
		//echo $this->db->last_query();die();
		return true;
	}

	/* Delete detail */
	function delete_leave($leave_id)
	{
		$this->db->delete('tbl_leave', array('leave_id' => $leave_id));		
		return 1;		
	}
}
?>
