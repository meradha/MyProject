<?php

class Monthlyreport_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	public function getTotalStakeHolderMapped($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder');
		$this->db->where('stakeholder_mapping_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getTotalStakeHolderMeetingInThisMonth($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');
		$this->db->where('shm_meeting_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getTotalStakeHolderResponsive($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');
		$this->db->where('shm_meeting_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('shm_stakeholde_work_status', 'Yes');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getTotalStakeHolderUnResponsive($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');
		$this->db->where('shm_meeting_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('shm_stakeholde_work_status', 'No');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getTotalCommunityMeetingEvents($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_task_community_awareness');
		$this->db->where('tca_activity_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$query = $this->db->get();
		return $query->result() ;
	}


	public function getTotalCommunityMeetingEventsLowCase($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_task_community_awareness');
		$this->db->where('tca_activity_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('tca_area', 'Low case burden area');
		$query = $this->db->get();
		return $query->result() ;
	}


	public function getTotalCommunityMeetingEventsHighCase($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_task_community_awareness');
		$this->db->where('tca_activity_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('tca_area', 'High case burden area');
		$query = $this->db->get();
		return $query->result() ;
	}


	public function getTotalSelfReferral($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_referral_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pp_referral_type', 'Self referral during community activity');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getTotalCommunityReferral($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_referral_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pp_referral_type', 'Community referral');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getTotalCAT1CAR2($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_created_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pp_testing_result', 'Positive');
		$this->db->like('pp_drug_sensitive_type', 'CAT-1');
		$this->db->or_like('pp_drug_sensitive_type', 'CAT-2');
		$query = $this->db->get();
		return $query->result() ;
	}	


	public function getTotalCAT1CAR2CounsellingService($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_created_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pp_testing_result', 'Positive');
		$this->db->where('pp_register_patient_Status', '1');
		$this->db->like('pp_drug_sensitive_type', 'CAT-1');
		$this->db->or_like('pp_drug_sensitive_type', 'CAT-2');
		$query = $this->db->get();
		return $query->result() ;
	}	

	public function getTotalCaregivers($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_caregiver');
		$this->db->where('pcg_date_of_registration BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$query = $this->db->get();
		return $query->result() ;
	}	

	public function getTotalDRTBPositivePatient($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_created_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pp_testing_result', 'Positive');
		$this->db->where('pp_drug_resistance_status', 'Drug Resistant');
		$query = $this->db->get();
		return $query->result() ;
	}	


	public function getTotalDRTBPositivePatientLinkToCounseller($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_created_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pp_testing_result', 'Positive');
		$this->db->where('pp_drug_resistance_status', 'Drug Resistant');
		$this->db->where('pp_send_pravah_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}	

	public function getTotalFollowUps($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_follow_up');
		$this->db->where('pfu_follow_up_visit BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$query = $this->db->get();
		return $query->result() ;
	}	

	public function getTotalIteruptionOfPatient($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_follow_up');
		$this->db->where('pfu_follow_up_visit BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pfu_treatment_iterruption_last_visit', 'Yes');
		$query = $this->db->get();
		return $query->result() ;
	}	

	public function getTotalIteruptionOfPatientLost($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_follow_up');
		$this->db->where('pfu_follow_up_visit BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pfu_last_counselling_iteraction', 'Yes');
		$query = $this->db->get();
		return $query->result() ;
	}	







	public function getLabName()
	{
		$this->db->select('*');
		$this->db->from('tbl_diagnosis_center');
		$this->db->where('diagnosis_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}
	
	public function getAllReferredCase($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_created_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getAllReferredCasePositive($start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('pp_created_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$this->db->where('pp_testing_result', 'Positive');
		$query = $this->db->get();
		return $query->result() ;
	}	


}
?>
