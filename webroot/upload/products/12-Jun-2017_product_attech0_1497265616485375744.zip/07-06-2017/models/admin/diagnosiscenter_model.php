<?php

class Diagnosiscenter_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getDiagnosisCenter()
	{
		$this->db->select('*');
		$this->db->from('tbl_diagnosis_center');
		$this->db->order_by('diagnosis_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Country List */
	public function getAllCountry()
	{
		$this->db->select('*');
		$this->db->from('country');
		$this->db->where('country_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all State List  */
	public function getAllState()
	{
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('state_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	Get all State List by country list */
	public function getStateListByCountryID($country_id)
	{
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('state_status', '1');
		$this->db->where('country_id', $country_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New */	
	public function addDiagnosisCenter($post)
	{
		$this->db->insert('tbl_diagnosis_center', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Edit details */	
	public function editDiagnosisCenter($diagnosis_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_diagnosis_center');
		$this->db->where('diagnosis_id', $diagnosis_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Update details */
	public function updateDiagnosisCenter($post)
	{	
		$data['diagnosis_name'] = $post['diagnosis_name'];
		$data['diagnosis_owner_name'] = $post['diagnosis_owner_name'];
		$data['diagnosis_email'] = $post['diagnosis_email'];
		$data['diagnosis_phone'] = $post['diagnosis_phone'];
		$data['diagnosis_mobile'] = $post['diagnosis_mobile'];
		$data['diagnosis_address'] = $post['diagnosis_address'];		
		$data['diagnosis_city'] = $post['diagnosis_city'];		
		$data['diagnosis_state_id'] = $post['diagnosis_state_id'];		
		$data['diagnosis_country_id'] = $post['diagnosis_country_id'];		
		$data['diagnosis_postal_code'] = $post['diagnosis_postal_code'];		
		$data['diagnosis_status'] = $post['diagnosis_status'];		
		$data['diagnosis_updated_date'] = $post['diagnosis_updated_date'];		
		$this->db->where('diagnosis_id', $post['diagnosis_id']);
		$this->db->update('tbl_diagnosis_center', $data);
		return true;
	}

	/* Delete detail */
	function delete_diagnosisCenter($diagnosis_id)
	{
		$this->db->delete('tbl_diagnosis_center', array('diagnosis_id' => $diagnosis_id));		
		return 1;		
	}
}
?>
