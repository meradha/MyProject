<?php

class Caregiver_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getAllCaregiver($patient_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_caregiver');
		$this->db->where('patient_id', $patient_id);
		$this->db->order_by('pcg_id', 'DESC');
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Delete detail */
	function delete_patientCaregiver($pcg_id)
	{
		$this->db->delete('tbl_patient_caregiver', array('pcg_id' => $pcg_id));		
		return 1;		
	}

	/*	Show all */
	public function patientDetailsByID($patient_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient');
		$this->db->where('patient_id', $patient_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Add New */	
	public function addPatientCaregiverDetails($post)
	{
		$this->db->insert('tbl_patient_caregiver', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}	

	/* Edit details */	
	public function editPatientCareGiver($pcg_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_caregiver');
		$this->db->where('pcg_id', $pcg_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Update details */
	public function updatePatientCareGiver($post)
	{	
		$data['patient_id'] = $post['patient_id'];
		$data['pp_id'] = $post['pp_id'];
		$data['user_id'] = $post['user_id'];
		$data['user_all_level'] = $post['user_all_level'];
		$data['patient_saksham_id'] = $post['patient_saksham_id'];
		$data['pcg_patient_name'] = $post['pcg_patient_name'];
		$data['pcg_patient_father_name'] = $post['pcg_patient_father_name'];
		$data['pcg_patient_dob'] = $post['pcg_patient_dob'];
		$data['pcg_date_of_registration'] = $post['pcg_date_of_registration'];
		$data['pcg_place_for_registration'] = $post['pcg_place_for_registration'];
		$data['pcg_share_detail_status'] = $post['pcg_share_detail_status'];
		$data['pcg_caregiver_name'] = $post['pcg_caregiver_name'];
		$data['pcg_relationship_with_patient'] = $post['pcg_relationship_with_patient'];
		$data['pcg_caregiver_age'] = $post['pcg_caregiver_age'];
		$data['pcg_caregiver_gender'] = $post['pcg_caregiver_gender'];
		$data['pcg_past_history_of_TB'] = $post['pcg_past_history_of_TB'];
		$data['pcg_suffer_from_TB'] = $post['pcg_suffer_from_TB'];
		$data['pcg_category_of_TB'] = $post['pcg_category_of_TB'];
		$data['pcg_organ_affected_from_TB'] = $post['pcg_organ_affected_from_TB'];
		$data['pcg_treatment_present_outcome'] = $post['pcg_treatment_present_outcome'];
		$data['pcg_self_substance_abuse'] = $post['pcg_self_substance_abuse'];
		$data['pcg_self_substance_abuse_other'] = $post['pcg_self_substance_abuse_other'];
		$data['pcg_patient_substance_abuse'] = $post['pcg_patient_substance_abuse'];
		$data['pcg_patient_substance_abuse_other'] = $post['pcg_patient_substance_abuse_other'];
		$data['pcg_counselling_topics'] = $post['pcg_counselling_topics'];
		$data['pcg_counselling_topics_other'] = $post['pcg_counselling_topics_other'];
		$data['pcg_csw_remarks'] = $post['pcg_csw_remarks'];
		$data['pcg_updated_date'] = $post['pcg_updated_date'];
		$this->db->where('pcg_id', $post['pcg_id']);
		$this->db->update('tbl_patient_caregiver', $data);
		return true;
	}























	/*	Patient Category List */
	public function getAllPatientCategory()
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_category');
		$this->db->where('patient_category_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}

	/*	all Diagnosis List */
	public function getAllCounsellingTopics()
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_counselling_topics');
		$this->db->where('counselling_topics_status', '1');
		$query = $this->db->get();
		return $query->result() ;
	}



	/* Update details */
	public function updatePresumptivePatientRegistration($post)
	{		
		$data['pp_register_patient_Status'] = $post['pp_register_patient_Status'];		
		$this->db->where('pp_id', $post['pp_id']);
		$this->db->update('tbl_patient_presumptive', $data);
		return true;
	}

	/* Edit details */	
	public function editPatient($patient_id, $pp_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient');
		$this->db->where('patient_id', $patient_id);
		$this->db->where('pp_id', $pp_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Edit details */	
	public function editPatientFamily($patient_id, $pp_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_family_details');
		$this->db->where('patient_id', $patient_id);
		$this->db->where('pp_id', $pp_id);
		$query = $this->db->get();
		return $query->result();
	}

	/* Edit details */	
	public function editPatientTBDetails($patient_id, $pp_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_tb_details');
		$this->db->where('patient_id', $patient_id);
		$this->db->where('pp_id', $pp_id);
		$query = $this->db->get();
		return $query->result();
	}




	/* Update details */
	public function updatePatient($post)
	{	
		$data['pp_id'] = $post['pp_id'];
		$data['user_id'] = $post['user_id'];
		$data['user_all_level'] = $post['user_all_level'];
		$data['saksham_patient_id'] = $post['saksham_patient_id'];
		$data['patient_name'] = $post['patient_name'];
		$data['patient_father_name'] = $post['patient_father_name'];
		$data['patient_dob'] = $post['patient_dob'];
		$data['patient_age'] = $post['patient_age'];
		$data['patient_contact_no'] = $post['patient_contact_no'];
		$data['patient_alternat_contact_no'] = $post['patient_alternat_contact_no'];
		$data['patient_gender'] = $post['patient_gender'];
		$data['patient_c_country_id'] = $post['patient_c_country_id'];
		$data['patient_c_state_id'] = $post['patient_c_state_id'];
		$data['patient_c_city'] = $post['patient_c_city'];
		$data['patient_c_address'] = $post['patient_c_address'];
		$data['patient_c_landmark'] = $post['patient_c_landmark'];
		$data['patient_c_postal_code'] = $post['patient_c_postal_code'];
		$data['patient_p_country_id'] = $post['patient_p_country_id'];
		$data['patient_p_state_id'] = $post['patient_p_state_id'];
		$data['patient_p_city'] = $post['patient_p_city'];
		$data['patient_p_address'] = $post['patient_p_address'];
		$data['patient_p_postal_code'] = $post['patient_p_postal_code'];
		$data['patient_religion'] = $post['patient_religion'];
		$data['patient_caste'] = $post['patient_caste'];
		$data['patient_aadhar_no'] = $post['patient_aadhar_no'];
		$data['patient_ration_card_no'] = $post['patient_ration_card_no'];
		$data['patient_type_of_locality'] = $post['patient_type_of_locality'];
		$data['patient_education'] = $post['patient_education'];
		$data['patient_working_status'] = $post['patient_working_status'];
		$data['patient_employement_status'] = $post['patient_employement_status'];
		$data['patient_occupation'] = $post['patient_occupation'];
		$data['patient_unemployed_reason'] = $post['patient_unemployed_reason'];
		$data['patient_staying_with'] = $post['patient_staying_with'];
		$data['patient_total_house_member'] = $post['patient_total_house_member'];
		$data['patient_total_children_less_6'] = $post['patient_total_children_less_6'];
		$data['patient_earning_house_member'] = $post['patient_earning_house_member'];
		$data['patient_family_income'] = $post['patient_family_income'];
		$data['patient_marital_status'] = $post['patient_marital_status'];
		$data['patient_living_in_mumbai'] = $post['patient_living_in_mumbai'];
		$data['patient_updated_date'] = $post['patient_updated_date'];
		$this->db->where('patient_id', $post['patient_id']);
		$this->db->update('tbl_patient', $data);
		return true;
	}

	/* Update details */
	public function updatePatientFamily($post)
	{	
		$data['pp_id'] = $post['pp_id'];
		$data['user_id'] = $post['user_id'];
		$data['user_all_level'] = $post['user_all_level'];
		$data['pf_name'] = $post['pf_name'];
		$data['pf_age'] = $post['pf_age'];
		$data['pf_sex'] = $post['pf_sex'];
		$data['pf_relationship'] = $post['pf_relationship'];
		$data['pf_household_is_caregiver'] = $post['pf_household_is_caregiver'];
		$data['pf_household_history_tb'] = $post['pf_household_history_tb'];
		$data['pf_household_treatment'] = $post['pf_household_treatment'];
		$data['pf_updated_date'] = $post['pf_updated_date'];		
		$this->db->where('patient_id', $post['patient_id']);
		$this->db->update('tbl_patient_family_details', $data);
		return true;
	}


	/* Update details */
	public function updatePatientTBDetails($post)
	{	
		$data['pp_id'] = $post['pp_id'];
		$data['user_id'] = $post['user_id'];
		$data['user_all_level'] = $post['user_all_level'];
		$data['patient_saksham_id'] = $post['patient_saksham_id'];
		$data['ptb_saksham_registration_date'] = $post['ptb_saksham_registration_date'];
		$data['ptb_name_ward'] = $post['ptb_name_ward'];
		$data['ptb_referral_type'] = $post['ptb_referral_type'];
		$data['ptb_share_details_status'] = $post['ptb_share_details_status'];
		$data['ptb_consent_for_counselling_status'] = $post['ptb_consent_for_counselling_status'];
		$data['ptb_place_of_registration'] = $post['ptb_place_of_registration'];
		$data['ptb_type_of_tb_by_card'] = $post['ptb_type_of_tb_by_card'];
		$data['ptb_extra_organ_affected_by_card'] = $post['ptb_extra_organ_affected_by_card'];
		$data['ptb_drug_sensitive_status_by_card'] = $post['ptb_drug_sensitive_status_by_card'];
		$data['ptb_current_phase_of_treatment_card'] = $post['ptb_current_phase_of_treatment_card'];
		$data['ptb_name_of_PHC'] = $post['ptb_name_of_PHC'];
		$data['ptb_PMDT_no'] = $post['ptb_PMDT_no'];
		$data['ptb_RNTCP_registration_date'] = $post['ptb_RNTCP_registration_date'];
		$data['ptb_diagnosis_date'] = $post['ptb_diagnosis_date'];
		$data['ptb_start_treatment_date'] = $post['ptb_start_treatment_date'];
		$data['ptb_treatement_history'] = $post['ptb_treatement_history'];
		$data['ptb_HIV_status'] = $post['ptb_HIV_status'];
		$data['ptb_HIV_treatment_status'] = $post['ptb_HIV_treatment_status'];
		$data['ptb_diabetes_status'] = $post['ptb_diabetes_status'];
		$data['ptb_diabetes_treatment_status'] = $post['ptb_diabetes_treatment_status'];
		$data['ptb_other_diseas'] = $post['ptb_other_diseas'];
		$data['ptb_substance_abuse'] = $post['ptb_substance_abuse'];
		$data['ptb_home_visit_status'] = $post['ptb_home_visit_status'];
		$data['ptb_worklace_status'] = $post['ptb_worklace_status'];
		$data['ptb_counselling_topics'] = $post['ptb_counselling_topics'];
		$data['ptb_counselling_tool'] = $post['ptb_counselling_tool'];
		$data['ptb_need_referral_linkage_identified'] = $post['ptb_need_referral_linkage_identified'];
		$data['ptb_referral_service_linkage_towords'] = $post['ptb_referral_service_linkage_towords'];
		$data['ptb_name_of_referred_agency'] = $post['ptb_name_of_referred_agency'];
		$data['ptb_csw_remarks'] = $post['ptb_csw_remarks'];
		$data['ptb_next_follow_up_date'] = $post['ptb_next_follow_up_date'];
		$data['ptb_next_follow_up_time'] = $post['ptb_next_follow_up_time'];
		$data['ptb_next_follow_up_visit_place'] = $post['ptb_next_follow_up_visit_place'];
		$data['ptb_updated_date'] = $post['ptb_updated_date'];
		$this->db->where('patient_id', $post['patient_id']);
		$this->db->update('tbl_patient_tb_details', $data);
		return true;
	}

	

	/* Edit details */	
	public function getFollowUpDetailsByPatientID($patient_id)
	{
		$this->db->select('a.*, b.user_name as added_by,c.*');
		$this->db->from('tbl_patient_follow_up a');
		$this->db->join('tbl_user b','a.user_id = b.user_id','inner');
		$this->db->join('tbl_patient c','a.patient_id = c.patient_id','inner');
		$this->db->where('a.patient_id', $patient_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Edit details */	
	public function getPatientDeails($patient_id)
	{
		$this->db->select('a.*, b.*, c.country_name, d.state_name');
		$this->db->from('tbl_patient a');
		$this->db->join('tbl_patient_tb_details b','a.patient_id = b.patient_id','inner');
		$this->db->join('country c','a.patient_c_country_id = c.country_id','inner');
		$this->db->join('state d','a.patient_c_state_id = d.state_id','inner');
		$this->db->where('a.patient_id', $patient_id);
		$query = $this->db->get();
		return $query->result() ;
	}

	/* Add New */	
	public function addPatientFollowUp($post)
	{
		$this->db->insert('tbl_patient_follow_up', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}

	/* Edit details */	
	public function editPatientFollowUp($patient_id, $pfu_id)
	{
		$this->db->select('a.*, c.country_name, d.state_name');
		$this->db->from('tbl_patient_follow_up a');
		$this->db->join('country c','a.pfu_country_id = c.country_id','inner');
		$this->db->join('state d','a.pfu_state_id = d.state_id','inner');
		$this->db->where('a.patient_id', $patient_id);
		$this->db->where('a.pfu_id', $pfu_id);
		$query = $this->db->get();
		return $query->result();
	}	

	/* Update details */
	public function updatePatientFollowUp($post)
	{	
		$data['patient_id'] = $post['patient_id'];	
		$data['user_id'] = $post['user_id'];	
		$data['user_all_level'] = $post['user_all_level'];	
		$data['pfu_patient_name'] = $post['pfu_patient_name'];	
		$data['pfu_patient_father_name'] = $post['pfu_patient_father_name'];	
		$data['pfu_patient_dob'] = $post['pfu_patient_dob'];	
		$data['pfu_follow_up_visit'] = $post['pfu_follow_up_visit'];	
		$data['pfu_follow_up_visit_no'] = $post['pfu_follow_up_visit_no'];	
		$data['pfu_visited_at'] = $post['pfu_visited_at'];	
		$data['pfu_country_id'] = $post['pfu_country_id'];	
		$data['pfu_state_id'] = $post['pfu_state_id'];	
		$data['pfu_city'] = $post['pfu_city'];	
		$data['pfu_address'] = $post['pfu_address'];	
		$data['pfu_landmark'] = $post['pfu_landmark'];	
		$data['pfu_postal_code'] = $post['pfu_postal_code'];	
		$data['pfu_contact_no'] = $post['pfu_contact_no'];	
		$data['pfu_name_of_caregiver'] = $post['pfu_name_of_caregiver'];	
		$data['pfu_treatment_status'] = $post['pfu_treatment_status'];	
		$data['pfu_ADR_occurance_last_visit'] = $post['pfu_ADR_occurance_last_visit'];	
		$data['pfu_name_of_ADR'] = $post['pfu_name_of_ADR'];	
		$data['pfu_approch_for_ADR'] = $post['pfu_approch_for_ADR'];	
		$data['pfu_outcome_approch_for_ADR'] = $post['pfu_outcome_approch_for_ADR'];	
		$data['pfu_refer_any_medical_advice'] = $post['pfu_refer_any_medical_advice'];	
		$data['pfu_instance_of_stigma'] = $post['pfu_instance_of_stigma'];	
		$data['pfu_addressed_by_counselling'] = $post['pfu_addressed_by_counselling'];	
		$data['pfu_treatment_iterruption_last_visit'] = $post['pfu_treatment_iterruption_last_visit'];	
		$data['pfu_number_of_doses_missed'] = $post['pfu_number_of_doses_missed'];	
		$data['pfu_duration_of_iterruption'] = $post['pfu_duration_of_iterruption'];	
		$data['pfu_last_counselling_iteraction'] = $post['pfu_last_counselling_iteraction'];	
		$data['pfu_reason_of_iterruption'] = $post['pfu_reason_of_iterruption'];	
		$data['pfu_counselling_topic_covered'] = $post['pfu_counselling_topic_covered'];	
		$data['pfu_linkage_identified'] = $post['pfu_linkage_identified'];	
		$data['pfu_linkage_made_towards'] = $post['pfu_linkage_made_towards'];	
		$data['pfu_number_of_caregiver_testing'] = $post['pfu_number_of_caregiver_testing'];	
		$data['pfu_caregiver_diagnosed_TB_positive'] = $post['pfu_caregiver_diagnosed_TB_positive'];	
		$data['pfu_household_member_started_treatment'] = $post['pfu_household_member_started_treatment'];	
		$data['pfu_month_of_treatment'] = $post['pfu_month_of_treatment'];	
		$data['pfu_number_of_doses_in_month'] = $post['pfu_number_of_doses_in_month'];	
		$data['pfu_number_of_doses_missed_in_month'] = $post['pfu_number_of_doses_missed_in_month'];	
		$data['pfu_mention_the_treatment_regimen'] = $post['pfu_mention_the_treatment_regimen'];	
		$data['pfu_next_follo_up_date'] = $post['pfu_next_follo_up_date'];	
		$data['pfu_next_follow_up_visit_place'] = $post['pfu_next_follow_up_visit_place'];	
		$data['pfu_csw_remarks'] = $post['pfu_csw_remarks'];	
		$data['pfu_updated_date'] = $post['pfu_updated_date'];	
		$this->db->where('pfu_id', $post['pfu_id']);
		$this->db->update('tbl_patient_follow_up', $data);
		return true;
	}

	/* Delete detail */
	function delete_patientFollowUp($pfu_id)
	{
		$this->db->delete('tbl_patient_follow_up', array('pfu_id' => $pfu_id));		
		return 1;		
	}

}
?>
