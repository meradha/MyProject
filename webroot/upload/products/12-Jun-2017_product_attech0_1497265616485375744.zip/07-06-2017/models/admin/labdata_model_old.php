<?php

class Labdata_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	public function getAllLab()
	{
		$this->db->select('*');
		$this->db->from('tbl_diagnosis_center');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getPresumptivePatient($diagnosis_id, $start_date, $end_date)
	{
		$this->db->select('*');
		$this->db->from('tbl_patient_presumptive');
		$this->db->where('diagnosis_id', $diagnosis_id);
		$this->db->where('pp_testing_date BETWEEN "'.$start_date. '" and "'.$end_date.'"');
		$query = $this->db->get();
		return $query->result() ;
	}
	
}
?>
