<?php

class Map_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}

	/*	Show all */
	public function getAllChat()
	{
		$this->db->select('*');
		$this->db->from('tbl_chat');
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getAllpatient($user_id)
	{
		$where = "FIND_IN_SET('".$user_id."', user_all_level)";
		$this->db->select('*');
		$this->db->from('tbl_patient');
		$this->db->where($where);
		$query = $this->db->get();
		return $query->result() ;
	}

	
	public function getCommunityawareness($user_id)
	{
		$where = "FIND_IN_SET('".$user_id."', user_all_level)";
		$this->db->select('*');
		$this->db->from('tbl_task_community_awareness');
		$this->db->where($where);
		$query = $this->db->get();
		return $query->result() ;
	}

	public function getStakeholdermeeting($user_id)
	{
		$where = "FIND_IN_SET('".$user_id."', user_all_level)";
		$this->db->select('*');
		$this->db->from('tbl_stakeholder_meeting');
		$this->db->where($where);
		$query = $this->db->get();
		return $query->result() ;
	}
	
	public function getUserCurrentLoc($user_id)
	{
	return $this->db->query("SELECT tb1.*,tb2.user_name FROM tbl_live_location AS tb1 INNER JOIN tbl_user AS tb2 ON tb1.user_id = tb2.user_id WHERE tb1.user_id IN ($user_id)")->result_array();
		
	}
}
?>
