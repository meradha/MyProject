<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Common extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/common_model');
	}
	
	/* Get State List */
	public function getStateList()
	{
		$country_id = $this->input->post('country_id');
		$state_list = $this->common_model->getStateListByCountryId($country_id);

		$html = '';
		if(count($state_list) > 0)
		{
			foreach ($state_list as $s_list) 
			{
				$html .= '<option value="'.$s_list->state_id.'">'.$s_list->state_name.'</option>';
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}

	/* Get State List by Country id */
	public function getStateListByCountryID()
	{
		$country_id = $this->input->post('country_id');
		$state_list = $this->common_model->getStateListByCountryID($country_id);

		$html = '';
		$html .= '<option value=""></option>';
		if(!empty($state_list))
		{
			foreach ($state_list as $s_list) 
			{
				$html .= '<option value="'.$s_list->state_id.'">'.$s_list->state_name.'</option>';
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}

	/*Thanks page */
	public function thanksPage()
	{
		$this->load->view('admin/thanks');
	}
}

/* End of file */?>