<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class StakeHolderMeeting extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/stakeholdermeeting_model');
		$this->load->model('admin/taskassign_model');
	}
		
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{
			$stakeholder_id = $this->uri->segment(4);
			if($stakeholder_id)
			{
				$this->data['stakeholder_res'] = $this->stakeholdermeeting_model->getStakeHolderMeetingByStakeHolderID($stakeholder_id);
				$this->show_view_admin('admin/stakeholder/stakeHolderMeeting', $this->data);
			}	
			else
			{
				$this->data['stakeholder_res'] = $this->stakeholdermeeting_model->getStakeHolderMeeting();
				$this->show_view_admin('admin/stakeholder/stakeHolderMeeting', $this->data);
			}	
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }

    /* Details */
	public function stakeHolderMeetingView()
	{
		if($this->checkViewPermission())
		{
			$shm_id = $this->uri->segment(5);
			$stakeholder_id = $this->uri->segment(4);
			$this->data['healthpostarea_list'] = $this->stakeholdermeeting_model->getAllHealthpostArea();
			$this->data['stakeholder_id'] = $stakeholder_id;
			$this->data['stakeHoldermeeting_edit'] = $this->stakeholdermeeting_model->editStakeHolderMeeting($shm_id);
			$this->data['stakeHoldermeeting_img'] = $this->stakeholdermeeting_model->editStakeHolderMeetingImg($shm_id);	
			$this->show_view_admin('admin/stakeholder/stakeHolderMeetingView', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addStakeHolderMeeting()
	{
		$shm_id = $this->uri->segment(5);
		$stakeholder_id = $this->uri->segment(4);
		if($shm_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$post['shm_id'] = $shm_id;
					$post['shm_no_of_participants'] = $this->input->post('shm_no_of_participants');
					$post['shm_meting_location'] = $this->input->post('shm_meting_location');
					$post['shm_meeting_date'] = $this->input->post('shm_meeting_date');
					$post['shm_meeting_time_from'] = $this->input->post('shm_meeting_time_from');
					$post['shm_meeting_time_to'] = $this->input->post('shm_meeting_time_to');
					$post['shm_order_of_meeting_this_month'] = $this->input->post('shm_order_of_meeting_this_month');
					$post['shm_met_status_before_month'] = $this->input->post('shm_met_status_before_month');
					$post['shm_no_of_meeting_before_month'] = $this->input->post('shm_no_of_meeting_before_month');
					$shm_purpose_of_meeting = $this->input->post('shm_purpose_of_meeting');
					for($i=0; $i<count($shm_purpose_of_meeting); $i++)
					{
						if($i==0)
						{
							if($shm_purpose_of_meeting[$i] == 'Other')
							{
								$post['shm_purpose_of_meeting_other'] = $this->input->post('shm_purpose_of_meeting_other');
								$a = $shm_purpose_of_meeting[$i];
							}
							else
							{
								$post['shm_purpose_of_meeting_other'] = '';
								$a = $shm_purpose_of_meeting[$i];
							}
						}
						else
						{
							if($shm_purpose_of_meeting[$i] == 'Other')
							{
								$post['shm_purpose_of_meeting_other'] = $this->input->post('shm_purpose_of_meeting_other');
								$a = $a.'/'.$shm_purpose_of_meeting[$i];
							}
							else
							{
								$post['shm_purpose_of_meeting_other'] = '';
								$a = $a.'/'.$shm_purpose_of_meeting[$i];
							}
						}
					}
					$post['shm_purpose_of_meeting'] = $a;

					$shm_point_of_discussion = $this->input->post('shm_point_of_discussion');
					for($j=0; $j<count($shm_point_of_discussion); $j++)
					{
						if($j==0)
						{
							if($shm_point_of_discussion[$j] == 'Other')
							{
								$post['shm_point_of_discussion_other'] = $this->input->post('shm_point_of_discussion_other');
								$b = $shm_point_of_discussion[$j];
							}
							else
							{
								$post['shm_point_of_discussion_other'] = '';
								$b = $shm_point_of_discussion[$j];
							}
						}
						else
						{
							if($shm_point_of_discussion[$j] == 'Other')
							{
								$post['shm_point_of_discussion_other'] = $this->input->post('shm_point_of_discussion_other');
								$b = $b.'/'.$shm_point_of_discussion[$j];
							}
							else
							{
								$post['shm_point_of_discussion_other'] = '';
								$b = $b.'/'.$shm_point_of_discussion[$j];
							}
						}
					}
					$post['shm_point_of_discussion'] = $b;


					$post['shm_track_with_agenda'] = $this->input->post('shm_track_with_agenda');
					$post['shm_participated_status'] = $this->input->post('shm_participated_status');
					$post['shm_achived_purpose'] = $this->input->post('shm_achived_purpose');
					$post['shm_clearified_next_step'] = $this->input->post('shm_clearified_next_step');
					$post['shm_stakeholde_work_status'] = $this->input->post('shm_stakeholde_work_status');
					$post['shm_meeting_time_wroth_spent'] = $this->input->post('shm_meeting_time_wroth_spent');
					$post['shm_power'] = $this->input->post('shm_power');
					$post['shm_interest'] = $this->input->post('shm_interest');
					$post['shm_organization_classified'] = $this->input->post('shm_organization_classified');
					$post['shm_application_social_protection_scheme_status'] = $this->input->post('shm_application_social_protection_scheme_status');
					$post['shm_application_social_protection_scheme'] = $this->input->post('shm_application_social_protection_scheme');
					$post['shm_purpose_of_next_meeting'] = $this->input->post('shm_purpose_of_next_meeting');
					$post['shm_date_of_next_meeting'] = $this->input->post('shm_date_of_next_meeting');
					$post['shm_time_of_next_meeting'] = $this->input->post('shm_time_of_next_meeting');
					$post['shm_date_of_community_activity'] = $this->input->post('shm_date_of_community_activity');
					$post['shm_time_of_community_activity'] = $this->input->post('shm_time_of_community_activity');
					$post['shm_venue_of_community_activity'] = $this->input->post('shm_venue_of_community_activity');
					$post['shm_stakeholder_help'] = $this->input->post('shm_stakeholder_help');
					$post['helthpostarea_id'] = $this->input->post('helthpostarea_id');
					

					$post['stakeholder_id'] = $stakeholder_id;
					$post['user_id'] = $this->data['session'][0]->user_id;
					$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
					$post['shm_updated_date'] = date('Y-m-d');
					$this->stakeholdermeeting_model->updateStakeHolderMeeting($post);
						
					if($_FILES["shm_img"]['name'])
					{
						$tca_img_name_arr = $_FILES["shm_img"]["name"];
	                    for($i = 0; $i < count($tca_img_name_arr); $i++)
	 					{	
	        				$_FILES['new_file']['name'] = $_FILES['shm_img']['name'][$i];
	        				$_FILES['new_file']['type'] = $_FILES['shm_img']['type'][$i];
			                $_FILES['new_file']['tmp_name'] = $_FILES['shm_img']['tmp_name'][$i];
			                $_FILES['new_file']['error'] = $_FILES['shm_img']['error'][$i];
			                $_FILES['new_file']['size'] = $_FILES['shm_img']['size'][$i];
	                      
	                      	$name = 'shm_img';
	                      	$imagePath = 'webroot/admin/upload/stekeholder/meeting/';
	                       	$temp = explode(".",$_FILES['new_file']['name']);
							$extension = end($temp);
							$filenew =  date('d-M-Y').'_'.str_replace($_FILES['new_file']['name'],$name,$_FILES['new_file']['name']).'_'.time().''.rand(). "." .$extension;  		
							$config['file_name'] = $filenew;
							$config['upload_path'] = $imagePath;
							$config['allowed_types'] = 'GIF | gif | JPE | jpe | JPEG | jpeg | JPG | jpg | PNG | png';
							$this->upload->initialize($config);
							$this->upload->set_allowed_types('*');
							$this->upload->set_filename($config['upload_path'],$filenew);
							
							if(!$this->upload->do_upload('new_file'))
							{
								$data = array('msg' => $this->upload->display_errors());
							}
							else 
							{ 
								$data = $this->upload->data();	
								$imageName = $data['file_name'];
							}	

							if($imageName)
	                      	{
			                   	$post_img['shmi_img'] = $Path.''.$image_name;
								$post_img['shm_id'] =  $shm_id;
								$post_img['shmi_status'] = '1';
								$post_img['shmi_created_date'] = date('Y-m-d');
								$post_img['shmi_updated_date'] = date('Y-m-d');
								$this->stakeholdermeeting_model->addStakeHolderMeetingImg($post_img);
	                      	}
						}
					}
					$msg = 'stake Holder meeting update successfully!!';					
					$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
					redirect(base_url().'admin/stakeHolderMeeting/index/'.$stakeholder_id);
				}
				else
				{
					$this->data['healthpostarea_list'] = $this->stakeholdermeeting_model->getAllHealthpostArea();
					$this->data['stakeholder_id'] = $stakeholder_id;
					$this->data['stakeHoldermeeting_edit'] = $this->stakeholdermeeting_model->editStakeHolderMeeting($shm_id);
					$this->data['stakeHoldermeeting_img'] = $this->stakeholdermeeting_model->editStakeHolderMeetingImg($shm_id);
					$this->show_view_admin('admin/stakeholder/stakeHolderMeeting_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					if($stakeholder_id)
					{
						$post['stakeholder_id'] = $stakeholder_id;
					}
					else
					{
						$post['stakeholder_id'] = $this->input->post('stakeholder_id');
					}
					$year = date('Y');
					$month = date('m');
					$start_date = $year.'-'.$month.'-01';
  					$end_date = date('Y-m-t', strtotime(date("Y").'-'.$month)); 
					$stakeHolder_meeting_res = $this->stakeholdermeeting_model->getMeetingOrder($post['stakeholder_id'], $start_date, $end_date);
					if(!empty($stakeHolder_meeting_res))
					{
						$post['shm_order_of_meeting_this_month'] = $stakeHolder_meeting_res[0]->shm_order_of_meeting_this_month+1;
					}
					else
					{
						$post['shm_order_of_meeting_this_month'] = '1';						
					}
					
					$st_post['shm_order_of_meeting_this_month'] = $post['shm_order_of_meeting_this_month'];
					$st_post['stakeholder_id'] = $post['stakeholder_id'];
					$this->stakeholdermeeting_model->updateStakeHolderMeetingCount($st_post);


					$post['shm_let'] = $this->data['lat'];
					$post['shm_long'] = $this->data['lon'];
					$post['shm_no_of_participants'] = $this->input->post('shm_no_of_participants');
					$post['shm_meting_location'] = $this->input->post('shm_meting_location');
					$post['shm_meeting_date'] = $this->input->post('shm_meeting_date');
					$post['shm_meeting_time_from'] = $this->input->post('shm_meeting_time_from');
					$post['shm_meeting_time_to'] = $this->input->post('shm_meeting_time_to');
					$post['shm_met_status_before_month'] = $this->input->post('shm_met_status_before_month');
					$post['shm_no_of_meeting_before_month'] = $this->input->post('shm_no_of_meeting_before_month');
					$shm_purpose_of_meeting = $this->input->post('shm_purpose_of_meeting');
					for($i=0; $i<count($shm_purpose_of_meeting); $i++)
					{
						if($i==0)
						{
							if($shm_purpose_of_meeting[$i] == 'Other')
							{
								$post['shm_purpose_of_meeting_other'] = $this->input->post('shm_purpose_of_meeting_other');
								$a = $shm_purpose_of_meeting[$i];
							}
							else
							{
								$a = $shm_purpose_of_meeting[$i];
							}
						}
						else
						{
							if($shm_purpose_of_meeting[$i] == 'Other')
							{
								$post['shm_purpose_of_meeting_other'] = $this->input->post('shm_purpose_of_meeting_other');
								$a = $a.'/'.$shm_purpose_of_meeting[$i];
							}
							else
							{
								$a = $a.'/'.$shm_purpose_of_meeting[$i];
							}
						}
					}
					$post['shm_purpose_of_meeting'] = $a;

					$shm_point_of_discussion = $this->input->post('shm_point_of_discussion');
					for($j=0; $j<count($shm_point_of_discussion); $j++)
					{
						if($j==0)
						{
							if($shm_point_of_discussion[$j] == 'Other')
							{
								$post['shm_point_of_discussion_other'] = $this->input->post('shm_point_of_discussion_other');
								$b = $shm_point_of_discussion[$j];
							}
							else
							{
								$b = $shm_point_of_discussion[$j];
							}
						}
						else
						{
							if($shm_point_of_discussion[$j] == 'Other')
							{
								$post['shm_point_of_discussion_other'] = $this->input->post('shm_point_of_discussion_other');
								$b = $b.'/'.$shm_point_of_discussion[$j];
							}
							else
							{
								$b = $b.'/'.$shm_point_of_discussion[$j];
							}
						}
					}
					$post['shm_point_of_discussion'] = $b;


					$post['shm_track_with_agenda'] = $this->input->post('shm_track_with_agenda');
					$post['shm_participated_status'] = $this->input->post('shm_participated_status');
					$post['shm_achived_purpose'] = $this->input->post('shm_achived_purpose');
					$post['shm_clearified_next_step'] = $this->input->post('shm_clearified_next_step');
					$post['shm_stakeholde_work_status'] = $this->input->post('shm_stakeholde_work_status');
					$post['shm_meeting_time_wroth_spent'] = $this->input->post('shm_meeting_time_wroth_spent');
					$post['shm_power'] = $this->input->post('shm_power');
					$post['shm_interest'] = $this->input->post('shm_interest');
					$post['shm_organization_classified'] = $this->input->post('shm_organization_classified');
					$post['shm_application_social_protection_scheme_status'] = $this->input->post('shm_application_social_protection_scheme_status');
					$post['shm_application_social_protection_scheme'] = $this->input->post('shm_application_social_protection_scheme');
					$post['shm_purpose_of_next_meeting'] = $this->input->post('shm_purpose_of_next_meeting');
					$post['shm_date_of_next_meeting'] = $this->input->post('shm_date_of_next_meeting');
					$post['shm_time_of_next_meeting'] = $this->input->post('shm_time_of_next_meeting');
					$post['shm_date_of_community_activity'] = $this->input->post('shm_date_of_community_activity');
					$post['shm_time_of_community_activity'] = $this->input->post('shm_time_of_community_activity');
					$post['shm_venue_of_community_activity'] = $this->input->post('shm_venue_of_community_activity');
					$post['shm_stakeholder_help'] = $this->input->post('shm_stakeholder_help');
					$post['helthpostarea_id'] = $this->input->post('helthpostarea_id');
					
					$post['user_id'] = $this->data['session'][0]->user_id;
					$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
					$post['shm_created_date'] = date('Y-m-d');
					$post['shm_updated_date'] = date('Y-m-d');
					$shm_id =  $this->stakeholdermeeting_model->addStakeHolderMeeting($post);
					if($shm_id)
					{
						if($_FILES["shm_img"]['name'])
						{
							$tca_img_name_arr = $_FILES["shm_img"]["name"];
		                    for($i = 0; $i < count($tca_img_name_arr); $i++)
		 					{	
		        				$_FILES['new_file']['name'] = $_FILES['shm_img']['name'][$i];
		        				$_FILES['new_file']['type'] = $_FILES['shm_img']['type'][$i];
				                $_FILES['new_file']['tmp_name'] = $_FILES['shm_img']['tmp_name'][$i];
				                $_FILES['new_file']['error'] = $_FILES['shm_img']['error'][$i];
				                $_FILES['new_file']['size'] = $_FILES['shm_img']['size'][$i];
		                      
		                      	$name = 'shm_img';
		                      	$imagePath = 'webroot/admin/upload/stekeholder/meeting/';
		                       	$temp = explode(".",$_FILES['new_file']['name']);
								$extension = end($temp);
								$filenew =  date('d-M-Y').'_'.str_replace($_FILES['new_file']['name'],$name,$_FILES['new_file']['name']).'_'.time().''.rand(). "." .$extension;  		
								$config['file_name'] = $filenew;
								$config['upload_path'] = $imagePath;
								$config['allowed_types'] = 'GIF | gif | JPE | jpe | JPEG | jpeg | JPG | jpg | PNG | png';
								$this->upload->initialize($config);
								$this->upload->set_allowed_types('*');
								$this->upload->set_filename($config['upload_path'],$filenew);
								
								if(!$this->upload->do_upload('new_file'))
								{
									$data = array('msg' => $this->upload->display_errors());
								}
								else 
								{ 
									$data = $this->upload->data();	
									$imageName = $data['file_name'];
								}	

								if($imageName)
		                      	{
				                   	$post_img['shmi_img'] = $imagePath.''.$imageName;
									$post_img['shm_id'] =  $shm_id;
									$post_img['shmi_status'] = '1';
									$post_img['shmi_created_date'] = date('Y-m-d');
									$post_img['shmi_updated_date'] = date('Y-m-d');
									$this->stakeholdermeeting_model->addStakeHolderMeetingImg($post_img);
		                      	}
							}
						}

						$stakeholder_res = $this->stakeholdermeeting_model->getStakeHolderDetails($post['stakeholder_id']);
						if(!empty($stakeholder_res))
						{
							$assign_task_val = $this->stakeholdermeeting_model->getAssignTaskByUserIdFormID($post['user_id']);
							if(!empty($assign_task_val))
							{
								foreach ($assign_task_val as $a_t_val) 
								{
									if($a_t_val->ta_task_start_date<=$post['shm_meeting_date'] && $a_t_val->ta_task_end_date>=$post['shm_meeting_date'])
									{
										$ta_id = $a_t_val->ta_id;
										$target_count_val = $this->taskassign_model->getTaskTargetCount($ta_id);
										if(!empty($target_count_val))
										{
											$post_tc['tca_area'] = $stakeholder_res[0]->stakeholder_area;
											$post_tc['ta_id'] = $ta_id;
											if($target_count_val[0]->ttc_r_target != 0)
											{
												$post_tc['ttc_r_target'] = $target_count_val[0]->ttc_r_target - 1;
											}
											else
											{
												$post_tc['ttc_r_target'] = '0';
											}
											
											if($post_tc['tca_area'] == 'Low case burden area')
											{
												if($target_count_val[0]->ttc_r_target != 0)
												{
													$post_tc['ttc_r_lca_target'] = $target_count_val[0]->ttc_r_lca_target - 1;
												}
												else
												{
													$post_tc['ttc_r_lca_target'] = '0';
												}
												
											}
											else
											{
												if($target_count_val[0]->ttc_r_target != 0)
												{
													$post_tc['ttc_r_hca_target'] = $target_count_val[0]->ttc_r_hca_target - 1;
												}
												else
												{
													$post_tc['ttc_r_hca_target'] = '0';
												}
											}
											$this->taskassign_model->updateTaskTargetCount($post_tc);

											$taskassign_edit = $this->taskassign_model->editTaskAssign($ta_id);
											if(!empty($taskassign_edit))
											{
												if($taskassign_edit[0]->ta_remaining_task != 0)
												{
													$post_t_a_tc['ta_remaining_task'] = $taskassign_edit[0]->ta_remaining_task - 1;
													$post_t_a_tc['ta_id'] = $ta_id;
													$this->taskassign_model->updateTaskAssignTargetCount($post_t_a_tc);
												}
					 						}

										}
									}
								}
							}
						}







							
							

						

						$msg = 'stake holder meeting added successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/stakeHolderMeeting');
					}
					else
					{
						$msg = 'Whoops, looks like something went wrong!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/stakeHolderMeeting/addStakeHolderMeeting');
					}		
				}
				else
				{
					$this->data['stakeholder_id'] = $stakeholder_id;	
					if($stakeholder_id)
					{
						$this->data['stakeHolder_res'] = $this->stakeholdermeeting_model->getStakeHolderDetails($stakeholder_id);
						$year = date('Y');
						$month = date('m');
						$start_date = $year.'-'.$month.'-01';
      					$end_date = date('Y-m-t', strtotime(date("Y").'-'.$month)); 

						$this->data['healthpostarea_list'] = $this->stakeholdermeeting_model->getAllHealthpostArea();
						$this->data['stakeHolder_meeting_res'] = $this->stakeholdermeeting_model->getMeetingOrder($stakeholder_id, $start_date, $end_date);
					}
					else
					{
						$this->data['healthpostarea_list'] = $this->stakeholdermeeting_model->getAllHealthpostArea();
						$this->data['stakeHolder_res'] = $this->stakeholdermeeting_model->getStakeHolderList();						
					}
					$this->show_view_admin('admin/stakeholder/stakeHolderMeeting_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}
	
	/* Delete */
	public function delete_stakeHolderMeeting()
	{
		if($this->checkDeletePermission())
		{
			$stakeholder_id = $this->uri->segment(5);
			$shm_id = $this->uri->segment(5);
			
			$this->stakeholdermeeting_model->delete_stakeHolderMeeting($shm_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/stakeHolderMeeting/index/'.$stakeholder_id); 
			}
			else
			{
				$msg = 'stake holder meeting remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/stakeHolderMeeting/index/'.$stakeholder_id);
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}

	function getTotalNumberOfMeeting()
	{
		$start_date = date('Y-m-d', strtotime("first day of last month"));
		$end_date = date('Y-m-d', strtotime("last day of last month"));
		$stakeholder_id = $this->input->post('stakeholder_id');
		$stakeHolder_meeting_res = $this->stakeholdermeeting_model->getStakeHolderMeetingInLastMonth($stakeholder_id, $start_date, $end_date);
		echo json_encode(array('stakeHolder_meeting_res'=>count($stakeHolder_meeting_res)));
	}	

	function getTotalNumberOfMeetingOrder()
	{
		$year = date('Y');
      	$month = date('m');
     	$start_date = $year.'-'.$month.'-01';
      	$end_date = date('Y-m-t', strtotime(date("Y").'-'.$month)); 
		$stackholder_id = $this->input->post('stackholder_id');
		$stakeHolder_meeting_res = $this->stakeholdermeeting_model->getMeetingOrder($stackholder_id, $start_date, $end_date);
		if(!empty($stakeHolder_meeting_res))
		{
			$stakeHolder_meeting_no = $stakeHolder_meeting_res[0]->shm_order_of_meeting_this_month + 1;
		}
		else
		{
			$stakeHolder_meeting_no = 1;
		}
		echo $stakeHolder_meeting_no;
	}	
}

/* End of file */?>