<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Patient extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/patient_model');
		$this->load->model('admin/caregiver_model');
	}

	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{			
			$this->data['patient_res'] = $this->patient_model->getAllPatient();
			$this->show_view_admin('admin/patient/patient', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }

    /* Details */
	public function patientView()
	{
		if($this->checkViewPermission())
		{	
			$pp_id = $this->uri->segment(4);
			$patient_id = $this->uri->segment(5);
			$tab = $this->uri->segment(6);
			$user_id = $this->data['session'][0]->user_id;	
			$user_all_level = $this->data['session'][0]->user_all_level;
			$this->data['tab'] = $tab;
			$this->data['patient_edit'] = $this->patient_model->editPatient($patient_id, $pp_id);
			$this->data['patient_family_edit'] = $this->patient_model->editPatientFamily($patient_id, $pp_id);
			$this->data['patient_tb_details_edit'] = $this->patient_model->editPatientTBDetails($patient_id, $pp_id);
			$this->data['patient_caregiver_edit'] = $this->patient_model->editPatientCareGiver($patient_id, $pp_id);
			$this->data['presumptive_patient_res'] = $this->patient_model->presumptivePatientDetailsByID($pp_id);
			$this->data['state_list'] = $this->common_model->getStateListByCountryID('99');
			$this->show_view_admin('admin/patient/patientView', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addPatient()
	{
		$pp_id = $this->uri->segment(4);
		$patient_id = $this->uri->segment(5);
		$tab = $this->uri->segment(6);
		$user_id = $this->data['session'][0]->user_id;	
		$user_all_level = $this->data['session'][0]->user_all_level;	
		if($patient_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{ 
					// echo "<pre>";
					// print_r($_POST);
					// die();
					$post['patient_id'] = $patient_id;
					/***************** TAB 1 *****************/
					$post['pp_id'] = $pp_id;
					$post['user_id'] = $user_id;
					$post['user_all_level'] = $user_all_level.','.$user_id;
					$post['saksham_patient_id'] = $this->input->post('saksham_patient_id');
					$post['patient_name'] = $this->input->post('patient_name');					
					$post['patient_father_name'] = $this->input->post('patient_father_name');
					$post['patient_dob'] = $this->input->post('patient_dob');
					$post['patient_age'] = $this->input->post('patient_age');
					$post['patient_contact_no'] = $this->input->post('patient_contact_no');
					$post['patient_alternat_contact_no'] = $this->input->post('patient_alternat_contact_no');
					$post['patient_gender'] = $this->input->post('patient_gender');
					$post['patient_c_country_id'] = '99';
					$post['patient_c_state_id'] = '1493';
					$post['patient_c_city'] = 'Mumbai';
					$post['patient_c_address'] = $this->input->post('patient_c_address');
					$post['patient_c_landmark'] = $this->input->post('patient_c_landmark');
					$post['patient_c_postal_code'] = $this->input->post('patient_c_postal_code');
					$post['patient_p_country_id'] = '99';
					$post['patient_p_state_id'] = $this->input->post('patient_p_state_id');
					$post['patient_p_city'] = $this->input->post('patient_p_city');
					$post['patient_p_address'] = $this->input->post('patient_p_address');
					$post['patient_p_postal_code'] = $this->input->post('patient_p_postal_code');
					$post['patient_religion'] = $this->input->post('patient_religion');
					if($post['patient_religion'] == 'Other')
					{
						$post['patient_religion_other'] = $this->input->post('patient_religion_other');
					}
					else
					{
						$post['patient_religion_other'] = '';
					}
					$post['patient_caste'] = $this->input->post('patient_caste');
					$post['patient_aadhar_no'] = $this->input->post('patient_aadhar_no');
					$post['patient_ration_card_no'] = $this->input->post('patient_ration_card_no');
					$post['patient_type_of_locality'] = $this->input->post('patient_type_of_locality');
					if($post['patient_type_of_locality'] == 'Other')
					{
						$post['patient_type_of_locality_other'] = $this->input->post('patient_type_of_locality_other');
					}	
					else{
						$post['patient_type_of_locality_other'] = '';
					}			
					$post['patient_education'] = $this->input->post('patient_education');
					if($post['patient_education'] == 'Other')
					{
						$post['patient_education_other'] = $this->input->post('patient_education_other');
					}
					else
					{
						$post['patient_education_other'] = '';
					}
					$post['patient_working_status'] = $this->input->post('patient_working_status');
					$post['patient_employement_status'] = $this->input->post('patient_employement_status');
					$post['patient_occupation'] = $this->input->post('patient_occupation');
					if($post['patient_occupation'] == 'Other')
					{
						$post['patient_occupation_other'] = $this->input->post('patient_occupation_other');
					}
					else
					{
						$post['patient_occupation_other'] = '';
					}
					
					$post['patient_unemployed_reason'] = $this->input->post('patient_unemployed_reason');
					if($post['patient_unemployed_reason'] == 'Other')
					{
						$post['patient_unemployed_reason_other'] = $this->input->post('patient_unemployed_reason_other');
					}
					else
					{
						$post['patient_unemployed_reason_other'] = '';
					}
					$post['patient_staying_with'] = $this->input->post('patient_staying_with');
					$post['patient_total_house_member'] = $this->input->post('patient_total_house_member');
					$post['patient_total_children_less_6'] = $this->input->post('patient_total_children_less_6');
					$post['patient_earning_house_member'] = $this->input->post('patient_earning_house_member');
					$post['patient_family_income'] = $this->input->post('patient_family_income');
					$post['patient_marital_status'] = $this->input->post('patient_marital_status');
					$post['patient_living_in_mumbai'] = $this->input->post('patient_living_in_mumbai');
					$post['patient_updated_date'] = date('Y-m-d');
					$this->patient_model->updatePatient($post);

					/***************** TAB 2 *****************/
					$patient_family_edit = $this->patient_model->editPatientFamily($patient_id, $pp_id);
					for($j=0; $j<count($patient_family_edit); $j++)
					{
						$post_f_u['patient_id'] = $patient_id;
						$post_f_u['pp_id'] = $pp_id;
						$post_f_u['user_id'] = $user_id;
						$post_f_u['user_all_level'] = $user_all_level.','.$user_id;
						$post_f_u['pf_name'] = $this->input->post('pf_name_u')[$j];
						$post_f_u['pf_age'] = $this->input->post('pf_age_u')[$j];
						$post_f_u['pf_sex'] = $this->input->post('pf_sex_u')[$i];
						$post_f_u['pf_relationship'] = $this->input->post('pf_relationship_u')[$j];
						$post_f_u['pf_household_is_caregiver'] = $this->input->post('pf_household_is_caregiver_u')[$j];
						$post_f_u['pf_household_history_tb'] = $this->input->post('pf_household_history_tb_u')[$j];
						$post_f_u['pf_household_treatment'] = $this->input->post('pf_household_treatment_u')[$j];
						$post_f['pf_updated_date'] = date('Y-m-d');
						$this->patient_model->updatePatientFamily($post_f_u);
					}

					
					$total_member = $this->input->post('total_member');
					
					if($total_member != '')
					{
						for($i=0; $i<count($total_member); $i++)
						{
							$post_f['patient_id'] = $patient_id;
							$post_f['pp_id'] = $pp_id;
							$post_f['user_id'] = $user_id;
							$post_f['user_all_level'] = $user_all_level.','.$user_id;
							$post_f['pf_name'] = $this->input->post('pf_name')[$i];
							$post_f['pf_age'] = $this->input->post('pf_age')[$i];
							$post_f['pf_sex'] = $this->input->post('pf_sex')[$i];
							$post_f['pf_relationship'] = $this->input->post('pf_relationship')[$i];
							$post_f['pf_household_is_caregiver'] = $this->input->post('pf_household_is_caregiver')[$i];
							$post_f['pf_household_history_tb'] = $this->input->post('pf_household_history_tb')[$i];
							$post_f['pf_household_treatment'] = $this->input->post('pf_household_treatment')[$i];
							$post_f['pf_created_date'] = date('Y-m-d');
							$post_f['pf_updated_date'] = date('Y-m-d');
							$this->patient_model->addPatientFamily($post_f);
						}
					}
					/***************** TAB 3 & TAB 4 *****************/
					$post_tb['patient_id'] = $patient_id;
					$post_tb['pp_id'] = $pp_id;
					$post_tb['user_id'] = $user_id;
					$post_tb['user_all_level'] = $user_all_level.','.$user_id;
					$post_tb['patient_saksham_id'] = $this->input->post('patient_saksham_id');
					$post_tb['ptb_saksham_registration_date'] = $this->input->post('ptb_saksham_registration_date');
					$post_tb['ptb_name_ward'] = $this->input->post('ptb_name_ward');
					$post_tb['ptb_referral_type'] = $this->input->post('ptb_referral_type');
					if($post_tb['ptb_referral_type'] == 'Other')
					{
						$post_tb['ptb_referral_type_other'] = $this->input->post('ptb_referral_type_other');
					}
					else
					{
						$post_tb['ptb_referral_type_other'] = '';
					}
					$post_tb['ptb_share_details_status'] = $this->input->post('ptb_share_details_status');
					$post_tb['ptb_consent_for_counselling_status'] = $this->input->post('ptb_consent_for_counselling_status');
					$post_tb['ptb_place_of_registration'] = $this->input->post('ptb_place_of_registration');
					if($post_tb['ptb_place_of_registration'] == 'Other')
					{
						$post_tb['ptb_place_of_registration_other'] = $this->input->post('ptb_place_of_registration_other');
					}
					else
					{
						$post_tb['ptb_place_of_registration_other'] = '';
					}
					$post_tb['ptb_type_of_tb_by_card'] = $this->input->post('ptb_type_of_tb_by_card');
					$post_tb['ptb_extra_organ_affected_by_card'] = $this->input->post('ptb_extra_organ_affected_by_card');
					$post_tb['ptb_drug_sensitive_status_by_card'] = $this->input->post('ptb_drug_sensitive_status_by_card');
					$post_tb['ptb_current_phase_of_treatment_card'] = $this->input->post('ptb_current_phase_of_treatment_card');
					$post_tb['ptb_name_of_PHC'] = $this->input->post('ptb_name_of_PHC');
					$post_tb['ptb_PMDT_no'] = $this->input->post('ptb_PMDT_no');
					$post_tb['ptb_RNTCP_registration_date'] = $this->input->post('ptb_RNTCP_registration_date');
					$post_tb['ptb_diagnosis_date'] = $this->input->post('ptb_diagnosis_date');
					$post_tb['ptb_treatement_history'] = $this->input->post('ptb_treatement_history');
					$post_tb['ptb_HIV_status'] = $this->input->post('ptb_HIV_status');
					$post_tb['ptb_HIV_treatment_status'] = $this->input->post('ptb_HIV_treatment_status');
					$post_tb['ptb_diabetes_status'] = $this->input->post('ptb_diabetes_status');
					$post_tb['ptb_diabetes_treatment_status'] = $this->input->post('ptb_diabetes_treatment_status');
					$post_tb['ptb_other_diseas'] = $this->input->post('ptb_other_diseas');
					$post_tb['ptb_start_treatment_date'] = $this->input->post('ptb_start_treatment_date');
					$post_tb['ptb_substance_abuse'] = $this->input->post('ptb_substance_abuse');
					if($post_tb['ptb_substance_abuse'])
					{
						$post_tb['ptb_substance_abuse_other'] = $this->input->post('ptb_substance_abuse_other');
					}
					else
					{
						$post_tb['ptb_substance_abuse_other'] = '';
					}
					$post_tb['ptb_home_visit_status'] = $this->input->post('ptb_home_visit_status');
					$post_tb['ptb_worklace_status'] = $this->input->post('ptb_worklace_status');
					$ptb_counselling_topics = $this->input->post('ptb_counselling_topics');
					if($ptb_counselling_topics)
					{
						$a = '';
						for ($i=0; $i < count($ptb_counselling_topics) ; $i++) 
						{ 
							if($i==0)
							{
								if($ptb_counselling_topics[$i] == 'Other')
								{
									$post_tb['ptb_counselling_topics_other'] = $this->input->post('ptb_counselling_topics_other');
									$a = $ptb_counselling_topics[$i];
								}
								else
								{
									$post_tb['ptb_counselling_topics_other'] = '';
									$a = $ptb_counselling_topics[$i];
								}
							}
							else
							{
								if($ptb_counselling_topics[$i] == 'Other')
								{
									$post_tb['ptb_counselling_topics_other'] = $this->input->post('ptb_counselling_topics_other');
									$a = $a.','.$ptb_counselling_topics[$i];
								}
								else
								{
									$post_tb['ptb_counselling_topics_other'] = '';
									$a = $a.','.$ptb_counselling_topics[$i];
								}
							}
						}
					}
					$post_tb['ptb_counselling_topics'] = $a;
					$post_tb['ptb_counselling_tool'] = $this->input->post('ptb_counselling_tool');
					$post_tb['ptb_need_referral_linkage_identified'] = $this->input->post('ptb_need_referral_linkage_identified');
					
					$ptb_referral_service_linkage_towords = $this->input->post('ptb_referral_service_linkage_towords');
					if($ptb_referral_service_linkage_towords)
					{
						$b = '';
						for ($j=0; $j < count($ptb_referral_service_linkage_towords) ; $j++) 
						{ 
							if($j==0)
							{
								if($ptb_counselling_topics[$i] == 'Other')
								{
									$post_tb['ptb_referral_service_linkage_towords_other'] = $this->input->post('ptb_referral_service_linkage_towords_other');
									$b = $ptb_referral_service_linkage_towords[$j];
								}
								else
								{
									$post_tb['ptb_referral_service_linkage_towords_other'] = '';
									$b = $ptb_referral_service_linkage_towords[$j];
								}
							}
							else
							{
								if($ptb_counselling_topics[$i] == 'Other')
								{
									$post_tb['ptb_referral_service_linkage_towords_other'] = $this->input->post('ptb_referral_service_linkage_towords_other');
									$b = $b.','.$ptb_referral_service_linkage_towords[$j];
								}
								else
								{
									$post_tb['ptb_referral_service_linkage_towords_other'] = '';
									$b = $b.','.$ptb_referral_service_linkage_towords[$j];
								}
							}
						}
					}
					$post_tb['ptb_referral_service_linkage_towords'] = $b;
					$post_tb['ptb_name_of_referred_agency'] = $this->input->post('ptb_name_of_referred_agency');
					$post_tb['ptb_csw_remarks'] = $this->input->post('ptb_csw_remarks');
					$post_tb['ptb_next_follow_up_date'] = $this->input->post('ptb_next_follow_up_date');
					$post_tb['ptb_next_follow_up_time'] = $this->input->post('ptb_next_follow_up_time');
					$post_tb['ptb_next_follow_up_visit_place'] = $this->input->post('ptb_next_follow_up_visit_place');
					if($post_tb['ptb_next_follow_up_visit_place'] == 'Other')
					{
						$post_tb['ptb_next_follow_up_visit_place_other'] = $this->input->post('ptb_next_follow_up_visit_place_other');
					}
					else
					{
						$post_tb['ptb_next_follow_up_visit_place_other'] = '';
					}
					$post_tb['ptb_updated_date'] = date('Y-m-d');
					$this->patient_model->updatePatientTBDetails($post_tb);

					/***************** TAB 5 *****************/
					$post_cg['patient_id'] = $patient_id;
					$post_cg['pp_id'] = $pp_id;
					$post_cg['user_id'] = $user_id;
					$post_cg['user_all_level'] = $user_all_level.','.$user_id;
					$post_cg['pcg_patient_name'] = $this->input->post('pcg_patient_name');
					$post_cg['pcg_patient_father_name'] = $this->input->post('pcg_patient_father_name');
					$post_cg['pcg_patient_dob'] = $this->input->post('pcg_patient_dob');
					$post_cg['patient_saksham_id'] = $this->input->post('patient_saksham_id');
					$post_cg['pcg_date_of_registration'] = $this->input->post('pcg_date_of_registration');
					$post_cg['pcg_place_for_registration'] = $this->input->post('pcg_place_for_registration');
					$post_cg['pcg_share_detail_status'] = $this->input->post('pcg_share_detail_status');
					$post_cg['pcg_caregiver_name'] = $this->input->post('pcg_caregiver_name');
					$post_cg['pcg_relationship_with_patient'] = $this->input->post('pcg_relationship_with_patient');
					$post_cg['pcg_caregiver_age'] = $this->input->post('pcg_caregiver_age');
					$post_cg['pcg_caregiver_gender'] = $this->input->post('pcg_caregiver_gender');
					$post_cg['pcg_past_history_of_TB'] = $this->input->post('pcg_past_history_of_TB');
					$post_cg['pcg_suffer_from_TB'] = $this->input->post('pcg_suffer_from_TB');
					$post_cg['pcg_category_of_TB'] = $this->input->post('pcg_category_of_TB');
					$post_cg['pcg_organ_affected_from_TB'] = $this->input->post('pcg_organ_affected_from_TB');
					$pcg_treatment_present_outcome = $this->input->post('pcg_treatment_present_outcome');
					if($pcg_treatment_present_outcome)
					{
						$d = '';
						for ($l=0; $l < count($pcg_treatment_present_outcome) ; $l++) 
						{ 
							if($l==0)
							{
								$d = $pcg_treatment_present_outcome[$l];
							}
							else
							{
								$d = $d.','.$pcg_treatment_present_outcome[$l];
							}
						}
					}
					$post_cg['pcg_treatment_present_outcome'] = $d;
					$pcg_self_substance_abuse = $this->input->post('pcg_self_substance_abuse');
					if($pcg_self_substance_abuse)
					{
						$e = '';
						for ($m=0; $m < count($pcg_self_substance_abuse) ; $m++) 
						{ 
							if($m==0)
							{
								if($pcg_self_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_self_substance_abuse_other'] = $this->input->post('pcg_self_substance_abuse_other');
									$e = $pcg_self_substance_abuse[$m];
								}
								else
								{
									$post_cg['pcg_self_substance_abuse_other'] = '';
									$e = $pcg_self_substance_abuse[$m];
								}
							}
							else
							{
								if($pcg_self_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_self_substance_abuse_other'] = $this->input->post('pcg_self_substance_abuse_other');
									$e = $e.','.$pcg_self_substance_abuse[$m];
								}
								else
								{
									$post_cg['pcg_self_substance_abuse_other'] = '';
									$e = $e.','.$pcg_self_substance_abuse[$m];
								}
							}							
						}
					}
					$post_cg['pcg_self_substance_abuse'] = $e;
					$pcg_patient_substance_abuse = $this->input->post('pcg_patient_substance_abuse');
					if($pcg_patient_substance_abuse)
					{
						$g = '';
						for ($m=0; $m < count($pcg_patient_substance_abuse) ; $m++) 
						{ 
							if($m==0)
							{
								if($pcg_patient_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_patient_substance_abuse_other']= $this->input->post('pcg_patient_substance_abuse_other');
									$g = $pcg_patient_substance_abuse[$m];
								}
								else
								{
									$post_cg['pcg_patient_substance_abuse_other']= '';
									$g = $pcg_patient_substance_abuse[$m];
								}
							}
							else
							{
								if($pcg_patient_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_patient_substance_abuse_other']= $this->input->post('pcg_patient_substance_abuse_other');
									$g = $g.','.$pcg_patient_substance_abuse[$m];
									
								}
								else
								{
									$post_cg['pcg_patient_substance_abuse_other']= '';
									$g = $g.','.$pcg_patient_substance_abuse[$m];
								}
							}
						}
					}
					$post_cg['pcg_patient_substance_abuse'] = $g;
					
					$pcg_counselling_topics = $this->input->post('pcg_counselling_topics');
					if($pcg_counselling_topics)
					{
						$f = '';
						for ($n=0; $n < count($pcg_counselling_topics) ; $n++) 
						{ 
							if($n==0)
							{
								$f = $bb;
								if($pcg_counselling_topics[$n] == 'Other')
								{
									$post_cg['pcg_counselling_topics_other'] = $this->input->post('pcg_counselling_topics_other');
									$f = $pcg_counselling_topics[$n];
								}
								else
								{
									$post_cg['pcg_counselling_topics_other'] = '';
									$f = $pcg_counselling_topics[$n];
								}
							}
							else
							{
								if($pcg_counselling_topics[$n] == 'Other')
								{
									$post_cg['pcg_counselling_topics_other'] = $this->input->post('pcg_counselling_topics_other');
									$f = $f.','.$pcg_counselling_topics[$n];
								}
								else
								{
									$post_cg['pcg_counselling_topics_other'] = '';
									$f = $f.','.$pcg_counselling_topics[$n];
								}
							}
						}
					}
					$post_cg['pcg_counselling_topics'] = $f;
					$post_cg['pcg_csw_remarks'] = $this->input->post('pcg_csw_remarks');
					$post_cg['pcg_updated_date'] = date('Y-m-d');
					$this->patient_model->updatePatientCareGiver($post_cg);


					$msg = 'Patient details update successfully!!';					
					$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
					redirect(base_url().'admin/patient');
				}
				else
				{
					$this->data['tab'] = $tab;
					$this->data['patient_edit'] = $this->patient_model->editPatient($patient_id, $pp_id);
					$this->data['patient_family_edit'] = $this->patient_model->editPatientFamily($patient_id, $pp_id);
					$this->data['patient_tb_details_edit'] = $this->patient_model->editPatientTBDetails($patient_id, $pp_id);
					$this->data['patient_caregiver_edit'] = $this->patient_model->editPatientCareGiver($patient_id, $pp_id);
					$this->data['presumptive_patient_res'] = $this->patient_model->presumptivePatientDetailsByID($pp_id);
					$this->data['state_list'] = $this->common_model->getStateListByCountryID('99');
					$this->show_view_admin('admin/patient/patient_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					/***************** TAB 1 *****************/
					$post['patient_let'] = $this->data['lat'];
					$post['patient_long'] = $this->data['lon'];
					$post['pp_id'] = $pp_id;
					$post['user_id'] = $user_id;
					$post['user_all_level'] = $user_all_level.','.$user_id;
					$post['saksham_patient_id'] = $this->input->post('saksham_patient_id');
					$post['patient_name'] = $this->input->post('patient_name');					
					$post['patient_father_name'] = $this->input->post('patient_father_name');
					$post['patient_dob'] = $this->input->post('patient_dob');
					$post['patient_age'] = $this->input->post('patient_age');
					$post['patient_contact_no'] = $this->input->post('patient_contact_no');
					$post['patient_alternat_contact_no'] = $this->input->post('patient_alternat_contact_no');
					$post['patient_gender'] = $this->input->post('patient_gender');
					$post['patient_c_country_id'] = '99';
					$post['patient_c_state_id'] = '1493';
					$post['patient_c_city'] = 'Mumbai';
					$post['patient_c_address'] = $this->input->post('patient_c_address');
					$post['patient_c_landmark'] = $this->input->post('patient_c_landmark');
					$post['patient_c_postal_code'] = $this->input->post('patient_c_postal_code');
					$post['patient_p_country_id'] = '99';
					$post['patient_p_state_id'] = $this->input->post('patient_p_state_id');
					$post['patient_p_city'] = $this->input->post('patient_p_city');
					$post['patient_p_address'] = $this->input->post('patient_p_address');
					$post['patient_p_postal_code'] = $this->input->post('patient_p_postal_code');
					$post['patient_religion'] = $this->input->post('patient_religion');
					if($post['patient_religion'] == 'Other')
					{
						$post['patient_religion_other'] = $this->input->post('patient_religion_other');;
					}
					$post['patient_caste'] = $this->input->post('patient_caste');
					$post['patient_aadhar_no'] = $this->input->post('patient_aadhar_no');
					$post['patient_ration_card_no'] = $this->input->post('patient_ration_card_no');
					$post['patient_type_of_locality'] = $this->input->post('patient_type_of_locality');
					if($post['patient_type_of_locality'] == 'Other')
					{
						$post['patient_type_of_locality_other'] = $this->input->post('patient_type_of_locality_other');
					}				
					$post['patient_education'] = $this->input->post('patient_education');
					if($post['patient_education'] == 'Other')
					{
						$post['patient_education_other'] = $this->input->post('patient_education_other');
					}
					$post['patient_working_status'] = $this->input->post('patient_working_status');
					$post['patient_employement_status'] = $this->input->post('patient_employement_status');
					$post['patient_occupation'] = $this->input->post('patient_occupation');
					if($post['patient_occupation'] == 'Other')
					{
						$post['patient_occupation_other'] = $this->input->post('patient_occupation_other');
					}
					$post['patient_unemployed_reason'] = $this->input->post('patient_unemployed_reason');
					if($post['patient_unemployed_reason'] == 'Other')
					{
						$post['patient_unemployed_reason_other'] = $this->input->post('patient_unemployed_reason_other');
					}
					$post['patient_staying_with'] = $this->input->post('patient_staying_with');
					$post['patient_total_house_member'] = $this->input->post('patient_total_house_member');
					$post['patient_total_children_less_6'] = $this->input->post('patient_total_children_less_6');
					$post['patient_earning_house_member'] = $this->input->post('patient_earning_house_member');
					$post['patient_family_income'] = $this->input->post('patient_family_income');
					$post['patient_marital_status'] = $this->input->post('patient_marital_status');
					$post['patient_living_in_mumbai'] = $this->input->post('patient_living_in_mumbai');
					$post['patient_created_date'] = date('Y-m-d');
					$post['patient_updated_date'] = date('Y-m-d');
					$patient_id =  $this->patient_model->addPatient($post);
					
					/***************** TAB 2 *****************/
					$total_member = $this->input->post('total_member');					
					if($total_member != '')
					{
						for($i=0; $i<count($total_member); $i++)
						{
							$post_f['patient_id'] = $patient_id;
							$post_f['pp_id'] = $pp_id;
							$post_f['user_id'] = $user_id;
							$post_f['user_all_level'] = $user_all_level.','.$user_id;
							$post_f['pf_name'] = $this->input->post('pf_name')[$i];
							$post_f['pf_age'] = $this->input->post('pf_age')[$i];
							$post_f['pf_sex'] = $this->input->post('pf_sex')[$i];
							$post_f['pf_relationship'] = $this->input->post('pf_relationship')[$i];
							$post_f['pf_household_is_caregiver'] = $this->input->post('pf_household_is_caregiver')[$i];
							$post_f['pf_household_history_tb'] = $this->input->post('pf_household_history_tb')[$i];
							$post_f['pf_household_treatment'] = $this->input->post('pf_household_treatment')[$i];
							$post_f['pf_created_date'] = date('Y-m-d');
							$post_f['pf_updated_date'] = date('Y-m-d');
							$this->patient_model->addPatientFamily($post_f);
						}
					}

					/***************** TAB 3 & TAB 4 *****************/
					$post_tb['patient_id'] = $patient_id;
					$post_tb['pp_id'] = $pp_id;
					$post_tb['user_id'] = $user_id;
					$post_tb['user_all_level'] = $user_all_level.','.$user_id;
					$post_tb['patient_saksham_id'] = $this->input->post('patient_saksham_id');
					$post_tb['ptb_saksham_registration_date'] = $this->input->post('ptb_saksham_registration_date');
					$post_tb['ptb_name_ward'] = $this->input->post('ptb_name_ward');
					$post_tb['ptb_referral_type'] = $this->input->post('ptb_referral_type');
					if($post_tb['ptb_referral_type'] == 'Other')
					{
						$post_tb['ptb_referral_type_other'] = $this->input->post('ptb_referral_type_other');
					}
					$post_tb['ptb_share_details_status'] = $this->input->post('ptb_share_details_status');
					$post_tb['ptb_consent_for_counselling_status'] = $this->input->post('ptb_consent_for_counselling_status');
					$post_tb['ptb_place_of_registration'] = $this->input->post('ptb_place_of_registration');
					if($post_tb['ptb_place_of_registration'] == 'Other')
					{
						$post_tb['ptb_place_of_registration_other'] = $this->input->post('ptb_place_of_registration_other');;
					}
					$post_tb['ptb_type_of_tb_by_card'] = $this->input->post('ptb_type_of_tb_by_card');
					$post_tb['ptb_extra_organ_affected_by_card'] = $this->input->post('ptb_extra_organ_affected_by_card');
					$post_tb['ptb_drug_sensitive_status_by_card'] = $this->input->post('ptb_drug_sensitive_status_by_card');
					$post_tb['ptb_current_phase_of_treatment_card'] = $this->input->post('ptb_current_phase_of_treatment_card');
					$post_tb['ptb_name_of_PHC'] = $this->input->post('ptb_name_of_PHC');
					$post_tb['ptb_PMDT_no'] = $this->input->post('ptb_PMDT_no');
					$post_tb['ptb_RNTCP_registration_date'] = $this->input->post('ptb_RNTCP_registration_date');
					$post_tb['ptb_diagnosis_date'] = $this->input->post('ptb_diagnosis_date');
					$post_tb['ptb_treatement_history'] = $this->input->post('ptb_treatement_history');
					$post_tb['ptb_HIV_status'] = $this->input->post('ptb_HIV_status');
					$post_tb['ptb_HIV_treatment_status'] = $this->input->post('ptb_HIV_treatment_status');
					$post_tb['ptb_diabetes_status'] = $this->input->post('ptb_diabetes_status');
					$post_tb['ptb_diabetes_treatment_status'] = $this->input->post('ptb_diabetes_treatment_status');
					$post_tb['ptb_other_diseas'] = $this->input->post('ptb_other_diseas');
					$post_tb['ptb_start_treatment_date'] = $this->input->post('ptb_start_treatment_date');
					$post_tb['ptb_substance_abuse'] = $this->input->post('ptb_substance_abuse');
					if($post_tb['ptb_substance_abuse'])
					{
						$post_tb['ptb_substance_abuse_other'] = $this->input->post('ptb_substance_abuse_other');
					}
					$post_tb['ptb_home_visit_status'] = $this->input->post('ptb_home_visit_status');
					$post_tb['ptb_worklace_status'] = $this->input->post('ptb_worklace_status');
					$ptb_counselling_topics = $this->input->post('ptb_counselling_topics');
					if($ptb_counselling_topics)
					{
						$a = '';
						for ($i=0; $i < count($ptb_counselling_topics) ; $i++) 
						{ 
							if($i==0)
							{
								if($ptb_counselling_topics[$i] == 'Other')
								{
									$post_tb['ptb_counselling_topics_other'] = $this->input->post('ptb_counselling_topics_other');
									$a = $ptb_counselling_topics[$i];
								}
								else
								{
									$a = $ptb_counselling_topics[$i];
								}
							}
							else
							{
								if($ptb_counselling_topics[$i] == 'Other')
								{
									$post_tb['ptb_counselling_topics_other'] = $this->input->post('ptb_counselling_topics_other');
									$a = $a.','.$ptb_counselling_topics[$i];
								}
								else
								{
									$a = $a.','.$ptb_counselling_topics[$i];
								}
							}
						}
					}
					$post_tb['ptb_counselling_topics'] = $a;
					$post_tb['ptb_counselling_tool'] = $this->input->post('ptb_counselling_tool');
					$post_tb['ptb_need_referral_linkage_identified'] = $this->input->post('ptb_need_referral_linkage_identified');
					$ptb_referral_service_linkage_towords = $this->input->post('ptb_referral_service_linkage_towords');
					if($ptb_referral_service_linkage_towords)
					{
						$b = '';
						for ($j=0; $j < count($ptb_referral_service_linkage_towords) ; $j++) 
						{ 
							if($j==0)
							{
								if($ptb_counselling_topics[$j] == 'Other')
								{
									$post_tb['ptb_referral_service_linkage_towords_other'] = $this->input->post('ptb_referral_service_linkage_towords_other');
									$b = $ptb_referral_service_linkage_towords[$j];
								}
								else
								{
									$b = $ptb_referral_service_linkage_towords[$j];
								}
							}
							else
							{
								if($ptb_counselling_topics[$j] == 'Other')
								{
									$post_tb['ptb_referral_service_linkage_towords_other'] = $this->input->post('ptb_referral_service_linkage_towords_other');
									$b = $b.','.$ptb_referral_service_linkage_towords[$j];
								}
								else
								{
									$b = $b.','.$ptb_referral_service_linkage_towords[$j];
								}
							}
						}
					}
					$post_tb['ptb_referral_service_linkage_towords'] = $b;
					$post_tb['ptb_name_of_referred_agency'] = $this->input->post('ptb_name_of_referred_agency');
					$post_tb['ptb_csw_remarks'] = $this->input->post('ptb_csw_remarks');
					$post_tb['ptb_next_follow_up_date'] = $this->input->post('ptb_next_follow_up_date');
					$post_tb['ptb_next_follow_up_time'] = $this->input->post('ptb_next_follow_up_time');
					$post_tb['ptb_next_follow_up_visit_place'] = $this->input->post('ptb_next_follow_up_visit_place');
					if($post_tb['ptb_next_follow_up_visit_place'] == 'Other')
					{
						$post_tb['ptb_next_follow_up_visit_place_other'] =$this->input->post('ptb_next_follow_up_visit_place_other');
					}
					$post_tb['ptb_created_date'] = date('Y-m-d');
					$post_tb['ptb_updated_date'] = date('Y-m-d');
					$this->patient_model->addPatientTBDetails($post_tb);

					/***************** TAB 5 *****************/
					$post_cg['cga_men_status'] = '1';
					$post_cg['patient_id'] = $patient_id;
					$post_cg['pp_id'] = $pp_id;
					$post_cg['user_id'] = $user_id;
					$post_cg['user_all_level'] = $user_all_level.','.$user_id;
					$post_cg['pcg_patient_name'] = $this->input->post('pcg_patient_name');
					$post_cg['pcg_patient_father_name'] = $this->input->post('pcg_patient_father_name');
					$post_cg['pcg_patient_dob'] = $this->input->post('pcg_patient_dob');
					$post_cg['patient_saksham_id'] = $this->input->post('patient_saksham_id');
					$post_cg['pcg_date_of_registration'] = $this->input->post('pcg_date_of_registration');
					$post_cg['pcg_place_for_registration'] = $this->input->post('pcg_place_for_registration');
					$post_cg['pcg_share_detail_status'] = $this->input->post('pcg_share_detail_status');
					$post_cg['pcg_caregiver_name'] = $this->input->post('pcg_caregiver_name');
					$post_cg['pcg_relationship_with_patient'] = $this->input->post('pcg_relationship_with_patient');
					$post_cg['pcg_caregiver_age'] = $this->input->post('pcg_caregiver_age');
					$post_cg['pcg_caregiver_gender'] = $this->input->post('pcg_caregiver_gender');
					$post_cg['pcg_past_history_of_TB'] = $this->input->post('pcg_past_history_of_TB');
					$post_cg['pcg_suffer_from_TB'] = $this->input->post('pcg_suffer_from_TB');
					$post_cg['pcg_category_of_TB'] = $this->input->post('pcg_category_of_TB');
					$post_cg['pcg_organ_affected_from_TB'] = $this->input->post('pcg_organ_affected_from_TB');
					$pcg_treatment_present_outcome = $this->input->post('pcg_treatment_present_outcome');
					if($pcg_treatment_present_outcome)
					{
						$d = '';
						for ($l=0; $l < count($pcg_treatment_present_outcome) ; $l++) 
						{ 
							if($l==0)
							{
								$d = $pcg_treatment_present_outcome[$l];
							}
							else
							{
								$d = $d.','.$pcg_treatment_present_outcome[$l];
							}
						}
					}
					$post_cg['pcg_treatment_present_outcome'] = $d;
					$pcg_self_substance_abuse = $this->input->post('pcg_self_substance_abuse');
					if($pcg_self_substance_abuse)
					{
						$e = '';
						for ($m=0; $m < count($pcg_self_substance_abuse) ; $m++) 
						{ 
							if($m==0)
							{
								if($pcg_self_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_self_substance_abuse_other'] = $this->input->post('pcg_self_substance_abuse_other');
									$e = $pcg_self_substance_abuse[$m];
								}
								else
								{
									$e = $pcg_self_substance_abuse[$m];
								}
							}
							else
							{
								if($pcg_self_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_self_substance_abuse_other'] = $this->input->post('pcg_self_substance_abuse_other');
									$e = $e.','.$pcg_self_substance_abuse[$m];
								}
								else
								{
									$e = $e.','.$pcg_self_substance_abuse[$m];
								}
							}							
						}
					}
					$post_cg['pcg_self_substance_abuse'] = $e;
					$pcg_patient_substance_abuse = $this->input->post('pcg_patient_substance_abuse');
					if($pcg_patient_substance_abuse)
					{
						$g = '';
						for ($m=0; $m < count($pcg_patient_substance_abuse) ; $m++) 
						{ 
							if($m==0)
							{
								if($pcg_patient_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_patient_substance_abuse_other']= $this->input->post('pcg_patient_substance_abuse_other');
									$g = $pcg_patient_substance_abuse[$m];
								}
								else
								{
									$g = $pcg_patient_substance_abuse[$m];
								}
							}
							else
							{
								if($pcg_patient_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_patient_substance_abuse_other']= $this->input->post('pcg_patient_substance_abuse_other');
									$g = $g.','.$pcg_patient_substance_abuse[$m];
									
								}
								else
								{
									$g = $g.','.$pcg_patient_substance_abuse[$m];
								}
							}
						}
					}
					$post_cg['pcg_patient_substance_abuse'] = $g;
					$pcg_counselling_topics = $this->input->post('pcg_counselling_topics');
					if($pcg_counselling_topics)
					{
						$f = '';
						for ($n=0; $n < count($pcg_counselling_topics) ; $n++) 
						{ 
							if($n==0)
							{
								// $f = $bb;
								if($pcg_counselling_topics[$n] == 'Other')
								{
									$post_cg['pcg_counselling_topics_other'] = $this->input->post('pcg_counselling_topics_other');
									$f = $pcg_counselling_topics[$n];
								}
								else
								{
									$f = $pcg_counselling_topics[$n];
								}
							}
							else
							{
								if($pcg_counselling_topics[$n] == 'Other')
								{
									$post_cg['pcg_counselling_topics_other'] = $this->input->post('pcg_counselling_topics_other');
									$f = $f.','.$pcg_counselling_topics[$n];
								}
								else
								{
									$f = $f.','.$pcg_counselling_topics[$n];
								}
							}
						}
					}
					$post_cg['pcg_counselling_topics'] = $f;
					$post_cg['pcg_csw_remarks'] = $this->input->post('pcg_csw_remarks');
					$post_cg['pcg_created_date'] = date('Y-m-d');
					$post_cg['pcg_updated_date'] = date('Y-m-d');
					$this->patient_model->addPatientCaregiverDetails($post_cg);

					/********* Add patient follow up **********/
					$post_pfud['pfud_phase'] = $this->input->post('ptb_current_phase_of_treatment_card');
					$post_pfud['pfud_date'] = $this->input->post('ptb_next_follow_up_date');
					$post_pfud['patient_id'] = $patient_id;
					$post_pfud['pfud_no'] = 1;
					$post_pfud['user_id'] = $user_id;;
					$post_pfud['user_all_level'] = $user_all_level.','.$user_id;
					$this->patient_model->addPatientFollowUpDate($post_pfud);

					if($patient_id)
					{
						$u_post['pp_id'] = $pp_id;
						$u_post['pp_register_patient_Status'] = '1';
						$this->patient_model->updatePresumptivePatientRegistration($u_post);

						$msg = 'patient added successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/patient');
					}
					else
					{
						$msg = 'Whoops, looks like something went wrong!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/patient/addPatient');
					}	
				}
				else
				{
					$this->data['presumptive_patient_res'] = $this->patient_model->presumptivePatientDetailsByID($pp_id);
					$this->data['state_list'] = $this->common_model->getStateListByCountryID('99');
					$this->show_view_admin('admin/patient/patient_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}
	
	/* Delete */
	public function delete_patient()
	{
		if($this->checkDeletePermission())
		{
			$patient_id = $this->uri->segment(4);
			
			$this->patient_model->delete_patient($patient_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/patient'); 
			}
			else
			{
				$msg = 'Patient details remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/patient');
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}

	public function showFollowUp()
	{
		$patient_id = $this->uri->segment(4);
		$this->data['patient_id'] = $patient_id;
		$this->data['patient_followup_res'] = $this->patient_model->getFollowUpDetailsByPatientID($patient_id);
		$this->show_view_admin('admin/patient/patient_follow_up', $this->data);
	}

	public function showFollowUpView()
	{
		$patient_id = $this->uri->segment(4);
		$pfu_id = $this->uri->segment(5);
		$user_id = $this->data['session'][0]->user_id;	
		$user_all_level = $this->data['session'][0]->user_all_level.','.$user_id;	
		$this->data['patient_followup_res'] = $this->patient_model->editPatientFollowUp($patient_id, $pfu_id);
		$this->data['patient_id'] = $patient_id ;
		$this->show_view_admin('admin/patient/showFollowUpView', $this->data);
	}


	public function addPatientFollowUp()
	{
		$patient_id = $this->uri->segment(4);
		$pfu_id = $this->uri->segment(5);
		$user_id = $this->data['session'][0]->user_id;	
		$user_all_level = $this->data['session'][0]->user_all_level.','.$user_id;	
		if($pfu_id)
		{
			if(isset($_POST['Submit']) && $_POST['Submit'] == 'EditFollowUp')
			{
				$post['pfu_id'] = $pfu_id;
				$post['patient_id'] = $patient_id;
				$post['user_id'] = $user_id;
				$post['user_all_level'] = $user_all_level.','.$user_id;
				$post['saksham_patient_id'] = $this->input->post('saksham_patient_id');
				$post['pfu_patient_name'] = $this->input->post('pfu_patient_name');
				$post['pfu_patient_father_name'] = $this->input->post('pfu_patient_father_name');
				$post['pfu_patient_dob'] = $this->input->post('pfu_patient_dob');
				$post['pfu_follow_up_visit'] = $this->input->post('pfu_follow_up_visit');
				$post['pfu_follow_up_visit_no'] = $this->input->post('pfu_follow_up_visit_no');
				$post['pfu_share_detail_status'] = $this->input->post('pfu_share_detail_status');
				$post['pfu_visited_at'] = $this->input->post('pfu_visited_at');
				if($post['pfu_visited_at'] == 'Other')
				{
					$post['pfu_visited_at_other'] = $this->input->post('pfu_visited_at_other');
				}
				else
				{
					$post['pfu_visited_at_other'] = '';
				}
				
				$post['pfu_country_id'] ='99';
				$post['pfu_state_id'] ='1493';
				$post['pfu_city'] = $this->input->post('pfu_city');
				$post['pfu_address'] = $this->input->post('pfu_address');
				$post['pfu_landmark'] = $this->input->post('pfu_landmark');
				$post['pfu_postal_code'] = $this->input->post('pfu_postal_code');
				$post['pfu_contact_no'] = $this->input->post('pfu_contact_no');
				$post['pfu_name_of_caregiver'] = $this->input->post('pfu_name_of_caregiver');
				$post['pfu_treatment_status'] = $this->input->post('pfu_treatment_status');
				$post['pfu_ADR_occurance_last_visit'] = $this->input->post('pfu_ADR_occurance_last_visit');
				$post['pfu_name_of_ADR'] = $this->input->post('pfu_name_of_ADR');
				$post['pfu_approch_for_ADR'] = $this->input->post('pfu_approch_for_ADR');
				if($post['pfu_approch_for_ADR'] == 'Other')
				{
					$post['pfu_approch_for_ADR_other'] = $this->input->post('pfu_approch_for_ADR_other');
				}
				else
				{
					$post['pfu_approch_for_ADR_other'] = '';
				}
				
				$post['pfu_outcome_approch_for_ADR'] = $this->input->post('pfu_outcome_approch_for_ADR');
				$post['pfu_refer_any_medical_advice'] = $this->input->post('pfu_refer_any_medical_advice');
				$post['pfu_instance_of_stigma'] = $this->input->post('pfu_instance_of_stigma');
				$post['pfu_addressed_by_counselling'] = $this->input->post('pfu_addressed_by_counselling');
				$post['pfu_treatment_iterruption_last_visit'] = $this->input->post('pfu_treatment_iterruption_last_visit');
				$post['pfu_number_of_doses_missed'] = $this->input->post('pfu_number_of_doses_missed');
				$post['pfu_duration_of_iterruption'] = $this->input->post('pfu_duration_of_iterruption');
				$post['pfu_last_counselling_iteraction'] = $this->input->post('pfu_last_counselling_iteraction');
				$pfu_reason_of_iterruption = $this->input->post('pfu_reason_of_iterruption');
				if($pfu_reason_of_iterruption)
				{
					$d = '';
					for ($l=0; $l < count($pfu_reason_of_iterruption) ; $l++) 
					{ 
						if($l==0)
						{
							if($pfu_reason_of_iterruption[$l] == 'Other')
							{
								$post['pfu_reason_of_iterruption_other'] = $this->input->post('pfu_reason_of_iterruption_other');
								$d = $pfu_reason_of_iterruption[$l];
							}	
							else
							{
								$post['pfu_reason_of_iterruption_other'] = '';
								$d = $pfu_reason_of_iterruption[$l];
							}
						}
						else
						{
							if($pfu_reason_of_iterruption[$l] == 'Other')
							{
								$post['pfu_reason_of_iterruption_other'] = $this->input->post('pfu_reason_of_iterruption_other');
								$d = $d.','.$pfu_reason_of_iterruption[$l];
							}	
							else
							{
								$post['pfu_reason_of_iterruption_other'] = '';
								$d = $d.','.$pfu_reason_of_iterruption[$l];
							}
						}
					}
				}
				$post['pfu_reason_of_iterruption'] = $d;

				$pfu_counselling_topic_covered = $this->input->post('pfu_counselling_topic_covered');
				if($pfu_counselling_topic_covered)
				{
					$a = '';
					for ($ii=0; $ii < count($pfu_counselling_topic_covered) ; $ii++) 
					{ 
						if($ii==0)
						{
							if($pfu_counselling_topic_covered[$ii] == 'Others')
							{
								$post['pfu_counselling_topic_covered_other'] = $this->input->post('pfu_counselling_topic_covered_other');
								$a = $pfu_counselling_topic_covered[$ii];
							}	
							else
							{
								$post['pfu_counselling_topic_covered_other'] = '';
								$a = $pfu_counselling_topic_covered[$ii];
							}
						}
						else
						{
							if($pfu_counselling_topic_covered[$ii] == 'Others')
							{
								$post['pfu_counselling_topic_covered_other'] = $this->input->post('pfu_counselling_topic_covered_other');
								$a = $a.','.$pfu_counselling_topic_covered[$ii];
							}	
							else
							{
								$post['pfu_counselling_topic_covered_other'] = '';
								$a = $a.','.$pfu_counselling_topic_covered[$ii];
							}
						}
					}
				}
				$post['pfu_counselling_topic_covered'] = $a;
				$post['pfu_linkage_identified'] = $this->input->post('pfu_linkage_identified');
				$pfu_linkage_made_towards = $this->input->post('pfu_linkage_made_towards');
				if($pfu_linkage_made_towards)
				{
					$aa = '';
					for ($iii=0; $iii < count($pfu_linkage_made_towards) ; $iii++) 
					{ 
						if($iii==0)
						{
							if($pfu_linkage_made_towards[$iii] == 'Others')
							{
								$post['pfu_linkage_made_towards_other'] = $this->input->post('pfu_linkage_made_towards_other');
								$aa = $pfu_linkage_made_towards[$iii];
							}	
							else
							{
								$post['pfu_linkage_made_towards_other'] = '';
								$aa = $pfu_linkage_made_towards[$iii];
							}
						}
						else
						{
							if($pfu_linkage_made_towards[$iii] == 'Others')
							{
								$post['pfu_linkage_made_towards_other'] = $this->input->post('pfu_linkage_made_towards_other');
								$aa = $aa.','.$pfu_linkage_made_towards[$iii];
							}	
							else
							{
								$post['pfu_linkage_made_towards_other'] = '';
								$aa = $aa.','.$pfu_linkage_made_towards[$iii];
							}
							
						}
					}
				}
				$post['pfu_linkage_made_towards'] = $aa;

				
				$post['pfu_number_of_caregiver_testing'] = $this->input->post('pfu_number_of_caregiver_testing');
				$post['pfu_caregiver_diagnosed_TB_positive'] = $this->input->post('pfu_caregiver_diagnosed_TB_positive');
				$post['pfu_household_member_started_treatment'] = $this->input->post('pfu_household_member_started_treatment');
				$post['pfu_month_of_treatment'] = $this->input->post('pfu_month_of_treatment');
				$post['pfu_number_of_doses_in_month'] = $this->input->post('pfu_number_of_doses_in_month');
				$post['pfu_number_of_doses_missed_in_month'] = $this->input->post('pfu_number_of_doses_missed_in_month');
				$post['pfu_mention_the_treatment_regimen'] = $this->input->post('pfu_mention_the_treatment_regimen');
				$post['pfu_next_follo_up_date'] = $this->input->post('pfu_next_follo_up_date');
				$post['pfu_next_follow_up_visit_place'] = $this->input->post('pfu_next_follow_up_visit_place');
				if($post['pfu_next_follow_up_visit_place'] == 'Other')
				{
					$post['pfu_next_follow_up_visit_place_other'] = $this->input->post('pfu_next_follow_up_visit_place_other');
				}
				else
				{
					$post['pfu_next_follow_up_visit_place_other'] = '';
				}
				
				$post['pfu_csw_remarks'] = $this->input->post('pfu_csw_remarks');
				$post['pfu_updated_date'] = date('Y-m-d');
				$this->patient_model->updatePatientFollowUp($post);
				$msg = 'Patient followup update successfully!!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/patient/showFollowUp/'.$patient_id);
			}
			else
			{
				$this->data['patient_followup_res'] = $this->patient_model->editPatientFollowUp($patient_id, $pfu_id);
				$this->data['patient_id'] = $patient_id ;
				$this->show_view_admin('admin/patient/patient_follow_up_update', $this->data);	
			}
		}
		else
		{
			if(isset($_POST['Submit']) && $_POST['Submit'] == 'AddFollowUp')
			{
				$post['pfu_let'] = $this->data['lat'];
				$post['pfu_long'] = $this->data['lon'];
				$post['patient_id'] = $patient_id;
				$post['user_id'] = $user_id;
				$post['user_all_level'] = $user_all_level.','.$user_id;
				$post['saksham_patient_id'] = $this->input->post('saksham_patient_id');
				$post['pfu_patient_name'] = $this->input->post('pfu_patient_name');
				$post['pfu_patient_father_name'] = $this->input->post('pfu_patient_father_name');
				$post['pfu_patient_dob'] = $this->input->post('pfu_patient_dob');
				$post['pfu_follow_up_visit'] = $this->input->post('pfu_follow_up_visit');
				$post['pfu_follow_up_visit_no'] = $this->input->post('pfu_follow_up_visit_no');
				$post['pfu_share_detail_status'] = $this->input->post('pfu_share_detail_status');
				$post['pfu_visited_at'] = $this->input->post('pfu_visited_at');
				$post['pfu_visited_at_other'] = $this->input->post('pfu_visited_at_other');
				$post['pfu_country_id'] ='99';
				$post['pfu_state_id'] ='1493';
				$post['pfu_city'] = $this->input->post('pfu_city');
				$post['pfu_address'] = $this->input->post('pfu_address');
				$post['pfu_landmark'] = $this->input->post('pfu_landmark');
				$post['pfu_postal_code'] = $this->input->post('pfu_postal_code');
				$post['pfu_contact_no'] = $this->input->post('pfu_contact_no');
				$post['pfu_name_of_caregiver'] = $this->input->post('pfu_name_of_caregiver');
				$post['pfu_treatment_status'] = $this->input->post('pfu_treatment_status');
				$post['pfu_name_of_ADR'] = $this->input->post('pfu_name_of_ADR');
				$post['pfu_approch_for_ADR'] = $this->input->post('pfu_approch_for_ADR');
				$post['pfu_approch_for_ADR_other'] = $this->input->post('pfu_approch_for_ADR_other');
				$post['pfu_ADR_occurance_last_visit'] = $this->input->post('pfu_ADR_occurance_last_visit');
				$post['pfu_outcome_approch_for_ADR'] = $this->input->post('pfu_outcome_approch_for_ADR');
				$post['pfu_refer_any_medical_advice'] = $this->input->post('pfu_refer_any_medical_advice');
				$post['pfu_instance_of_stigma'] = $this->input->post('pfu_instance_of_stigma');
				$post['pfu_addressed_by_counselling'] = $this->input->post('pfu_addressed_by_counselling');
				$post['pfu_treatment_iterruption_last_visit'] = $this->input->post('pfu_treatment_iterruption_last_visit');
				$post['pfu_number_of_doses_missed'] = $this->input->post('pfu_number_of_doses_missed');
				$post['pfu_duration_of_iterruption'] = $this->input->post('pfu_duration_of_iterruption');
				$post['pfu_last_counselling_iteraction'] = $this->input->post('pfu_last_counselling_iteraction');
				$pfu_reason_of_iterruption = $this->input->post('pfu_reason_of_iterruption');
				if($pfu_reason_of_iterruption)
				{
					$d = '';
					for ($l=0; $l < count($pfu_reason_of_iterruption) ; $l++) 
					{ 
						if($l==0)
						{
							if($pfu_reason_of_iterruption[$l] == 'Other')
							{
								$post['pfu_reason_of_iterruption_other'] = $this->input->post('pfu_reason_of_iterruption_other');
								$d = $pfu_reason_of_iterruption[$l];
							}	
							else
							{
								$d = $pfu_reason_of_iterruption[$l];
							}
						}
						else
						{
							if($pfu_reason_of_iterruption[$l] == 'Other')
							{
								$post['pfu_reason_of_iterruption_other'] = $this->input->post('pfu_reason_of_iterruption_other');
								$d = $d.','.$pfu_reason_of_iterruption[$l];
							}	
							else
							{
								$d = $d.','.$pfu_reason_of_iterruption[$l];
							}
						}
					}
				}
				$post['pfu_reason_of_iterruption'] = $d;
				$pfu_counselling_topic_covered = $this->input->post('pfu_counselling_topic_covered');
				if($pfu_counselling_topic_covered)
				{
					$a = '';
					for ($ii=0; $ii < count($pfu_counselling_topic_covered) ; $ii++) 
					{ 
						if($ii==0)
						{
							if($pfu_counselling_topic_covered[$ii] == 'Others')
							{
								$post['pfu_counselling_topic_covered_other'] = $this->input->post('pfu_counselling_topic_covered_other');
								$a = $pfu_counselling_topic_covered[$ii];
							}	
							else
							{
								$a = $pfu_counselling_topic_covered[$ii];
							}
						}
						else
						{
							if($pfu_counselling_topic_covered[$ii] == 'Others')
							{
								$post['pfu_counselling_topic_covered_other'] = $this->input->post('pfu_counselling_topic_covered_other');
								$a = $a.','.$pfu_counselling_topic_covered[$ii];
							}	
							else
							{
								$a = $a.','.$pfu_counselling_topic_covered[$ii];
							}
						}
					}
				}
				$post['pfu_counselling_topic_covered'] = $a;
				$post['pfu_linkage_identified'] = $this->input->post('pfu_linkage_identified');
				$pfu_linkage_made_towards = $this->input->post('pfu_linkage_made_towards');
				if($pfu_linkage_made_towards)
				{
					$aa = '';
					for ($iii=0; $iii < count($pfu_linkage_made_towards) ; $iii++) 
					{ 
						if($iii==0)
						{
							if($pfu_linkage_made_towards[$iii] == 'Others')
							{
								$post['pfu_linkage_made_towards_other'] = $this->input->post('pfu_linkage_made_towards_other');
								$aa = $pfu_linkage_made_towards[$iii];
							}	
							else
							{
								$aa = $pfu_linkage_made_towards[$iii];
							}
						}
						else
						{
							if($pfu_linkage_made_towards[$iii] == 'Others')
							{
								$post['pfu_linkage_made_towards_other'] = $this->input->post('pfu_linkage_made_towards_other');
								$aa = $aa.','.$pfu_linkage_made_towards[$iii];
							}	
							else
							{
								$aa = $aa.','.$pfu_linkage_made_towards[$iii];
							}
							
						}
					}
				}
				$post['pfu_linkage_made_towards'] = $aa;
				$post['pfu_number_of_caregiver_testing'] = $this->input->post('pfu_number_of_caregiver_testing');
				
				
				$post['pfu_caregiver_diagnosed_TB_positive'] = $this->input->post('pfu_caregiver_diagnosed_TB_positive');
				$post['pfu_household_member_started_treatment'] = $this->input->post('pfu_household_member_started_treatment');
				$post['pfu_month_of_treatment'] = $this->input->post('pfu_month_of_treatment');
				$post['pfu_number_of_doses_in_month'] = $this->input->post('pfu_number_of_doses_in_month');
				$post['pfu_number_of_doses_missed_in_month'] = $this->input->post('pfu_number_of_doses_missed_in_month');
				$post['pfu_mention_the_treatment_regimen'] = $this->input->post('pfu_mention_the_treatment_regimen');
				$post['pfu_next_follo_up_date'] = $this->input->post('pfu_next_follo_up_date');
				$post['pfu_next_follow_up_visit_place'] = $this->input->post('pfu_next_follow_up_visit_place');
				$post['pfu_next_follow_up_visit_place_other'] = $this->input->post('pfu_next_follow_up_visit_place_other');
				$post['pfu_csw_remarks'] = $this->input->post('pfu_csw_remarks');
				$post['pfu_created_date'] = date('Y-m-d');
				$post['pfu_updated_date'] = date('Y-m-d');
				$this->patient_model->addPatientFollowUp($post);

				$last_follow_up_data = $this->patient_model->getPatientFollowUpDate($patient_id);
				
				if(!empty($last_follow_up_data))
				{
					$post_pfud['pfud_phase'] = $last_follow_up_data[0]->pfud_phase;
					$post_pfud['pfud_date'] = $post['pfu_next_follo_up_date'];
					$post_pfud['patient_id'] = $patient_id;
					$post_pfud['pfud_no'] = $post['pfu_follow_up_visit_no'] + 1;
					$post_pfud['user_id'] = $user_id;;
					$post_pfud['user_all_level'] = $user_all_level.','.$user_id;
					$this->patient_model->addPatientFollowUpDate($post_pfud);
				}
				
				$msg = 'Patient followup added successfully!!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/patient/showFollowUp/'.$patient_id);
			}
			else
			{
				$this->data['patient_id'] = $patient_id ;
				$this->data['patient_res'] = $this->patient_model->getPatientDeails($patient_id);
				$this->show_view_admin('admin/patient/patient_follow_up_add', $this->data);				
			}
		}
	}

	/* Delete */
	public function delete_patientFollowUp()
	{
		if($this->checkDeletePermission())
		{
			$patient_id = $this->uri->segment(4);
			$pfu_id = $this->uri->segment(5);
			
			$this->patient_model->delete_patientFollowUp($pfu_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/patient/showFollowUp/'.$patient_id);
			}
			else
			{
				$msg = 'Patient details remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/patient/showFollowUp/'.$patient_id);
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}

	/* Delete */
	public function getFollowUpdate()
	{
		$patient_id = $this->input->post('patient_id');
		$last_follow_up_data = $this->patient_model->getPatientFollowUpDate($patient_id);
		echo json_encode(array('last_follow_up_data'=>$last_follow_up_data));
	}
	
	/**************** caregiver ******************/
	/* Details */
	public function caregiver()
	{
		if($this->checkViewPermission())
		{		
			$pp_id = $this->uri->segment(4);	
			$patient_id = $this->uri->segment(5);	
			$this->data['caregiver_res'] = $this->caregiver_model->getAllCaregiver($patient_id);
			$this->data['patient_id'] = $patient_id;
			$this->data['pp_id'] = $pp_id;
			$this->show_view_admin('admin/patient/caregiver/caregiver', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }

    public function caregiverView()
	{
		if($this->checkViewPermission())
		{		
			$pp_id = $this->uri->segment(4);
			$patient_id = $this->uri->segment(5);
			$pcg_id = $this->uri->segment(6);
			$user_id = $this->data['session'][0]->user_id;	
			$user_all_level = $this->data['session'][0]->user_all_level.','.$user_id;	
			$this->data['patient_id'] = $patient_id;
			$this->data['pp_id'] = $pp_id;
			$this->data['patient_caregiver_edit'] = $this->caregiver_model->editPatientCareGiver($pcg_id);
			$this->show_view_admin('admin/patient/caregiver/caregiverView', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addCaregiver()
	{
		$pp_id = $this->uri->segment(4);
		$patient_id = $this->uri->segment(5);
		$pcg_id = $this->uri->segment(6);
		$user_id = $this->data['session'][0]->user_id;	
		$user_all_level = $this->data['session'][0]->user_all_level.','.$user_id;	
		if($pcg_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					// echo "<pre>";
					// print_r($_POST);
					// die();
					$post_cg['pcg_id'] = $pcg_id;
					$post_cg['patient_id'] = $patient_id;
					$post_cg['pp_id'] = $pp_id;
					$post_cg['user_id'] = $user_id;
					$post_cg['user_all_level'] = $user_all_level.','.$user_id;
					$post_cg['patient_saksham_id'] = $this->input->post('patient_saksham_id');
					$post_cg['pcg_patient_name'] = $this->input->post('pcg_patient_name');
					$post_cg['pcg_patient_father_name'] = $this->input->post('pcg_patient_father_name');
					$post_cg['pcg_patient_dob'] = $this->input->post('pcg_patient_dob');
					$post_cg['pcg_date_of_registration'] = $this->input->post('pcg_date_of_registration');
					$post_cg['pcg_place_for_registration'] = $this->input->post('pcg_place_for_registration');
					$post_cg['pcg_share_detail_status'] = $this->input->post('pcg_share_detail_status');
					$post_cg['pcg_caregiver_name'] = $this->input->post('pcg_caregiver_name');
					$post_cg['pcg_relationship_with_patient'] = $this->input->post('pcg_relationship_with_patient');
					$post_cg['pcg_caregiver_age'] = $this->input->post('pcg_caregiver_age');
					$post_cg['pcg_caregiver_gender'] = $this->input->post('pcg_caregiver_gender');
					$post_cg['pcg_past_history_of_TB'] = $this->input->post('pcg_past_history_of_TB');
					$post_cg['pcg_suffer_from_TB'] = $this->input->post('pcg_suffer_from_TB');
					$post_cg['pcg_category_of_TB'] = $this->input->post('pcg_category_of_TB');
					$post_cg['pcg_organ_affected_from_TB'] = $this->input->post('pcg_organ_affected_from_TB');
					$pcg_treatment_present_outcome = $this->input->post('pcg_treatment_present_outcome');
					if($pcg_treatment_present_outcome)
					{
						$d = '';
						for ($l=0; $l < count($pcg_treatment_present_outcome) ; $l++) 
						{ 
							if($l==0)
							{
								$d = $pcg_treatment_present_outcome[$l];
							}
							else
							{
								$d = $d.','.$pcg_treatment_present_outcome[$l];
							}
						}
					}
					$post_cg['pcg_treatment_present_outcome'] = $d;					
					$pcg_self_substance_abuse = $this->input->post('pcg_self_substance_abuse');
					if($pcg_self_substance_abuse)
					{
						$e = '';
						for ($m=0; $m < count($pcg_self_substance_abuse) ; $m++) 
						{ 
							if($m==0)
							{
								if($pcg_self_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_self_substance_abuse_other'] = $this->input->post('pcg_self_substance_abuse_other');
									$e = $pcg_self_substance_abuse[$m];
								}
								else
								{
									$post_cg['pcg_self_substance_abuse_other'] = '';
									$e = $pcg_self_substance_abuse[$m];
								}
							}
							else
							{
								if($pcg_self_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_self_substance_abuse_other'] = $this->input->post('pcg_self_substance_abuse_other');
									$e = $e.','.$pcg_self_substance_abuse[$m];
								}
								else
								{
									$post_cg['pcg_self_substance_abuse_other'] = '';
									$e = $e.','.$pcg_self_substance_abuse[$m];
								}
							}							
						}
					}
					$post_cg['pcg_self_substance_abuse'] = $e;					
					$pcg_patient_substance_abuse = $this->input->post('pcg_patient_substance_abuse');
					if($pcg_patient_substance_abuse)
					{
						$g = '';
						for ($m=0; $m < count($pcg_patient_substance_abuse) ; $m++) 
						{ 
							if($m==0)
							{
								if($pcg_patient_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_patient_substance_abuse_other'] = $this->input->post('pcg_patient_substance_abuse_other');
									$g = $pcg_patient_substance_abuse[$m];
								}
								else
								{
									$post_cg['pcg_patient_substance_abuse_other'] = '';
									$g = $pcg_patient_substance_abuse[$m];
								}
							}
							else
							{
								if($pcg_patient_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_patient_substance_abuse_other'] = $this->input->post('pcg_patient_substance_abuse_other');
									$g = $g.','.$pcg_patient_substance_abuse[$m];
									
								}
								else
								{
									$post_cg['pcg_patient_substance_abuse_other'] = '';
									$g = $g.','.$pcg_patient_substance_abuse[$m];
								}
							}
						}
					}
					$post_cg['pcg_patient_substance_abuse'] = $g;
					$pcg_counselling_topics = $this->input->post('pcg_counselling_topics');
					if($pcg_counselling_topics)
					{
						$f = '';
						for ($n=0; $n < count($pcg_counselling_topics) ; $n++) 
						{
							if($n==0)
							{
								if($pcg_counselling_topics[$n] == 'Other')
								{
									$post_cg['pcg_counselling_topics_other'] = $this->input->post('pcg_counselling_topics_other');
									$f = $pcg_counselling_topics[$n];
								}
								else
								{
									$post_cg['pcg_counselling_topics_other'] = '';
									$f = $pcg_counselling_topics[$n];
								}
							}
							else
							{
								if($pcg_counselling_topics[$n] == 'Other')
								{
									$post_cg['pcg_counselling_topics_other'] = $this->input->post('pcg_counselling_topics_other');
									$f = $f.','.$pcg_counselling_topics[$n];
								}
								else
								{
									$post_cg['pcg_counselling_topics_other'] = '';
									$f = $f.','.$pcg_counselling_topics[$n];
								}
							}
						}
					}
					$post_cg['pcg_counselling_topics'] = $f;
					$post_cg['pcg_csw_remarks'] = $this->input->post('pcg_csw_remarks');
					$post_cg['pcg_updated_date'] = date('Y-m-d');
					$this->caregiver_model->updatePatientCareGiver($post_cg);


					$msg = 'Patient caregiver details update successfully!!';					
					$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
					redirect(base_url().'admin/patient/caregiver/'.$pp_id.'/'.$patient_id);
				}
				else
				{
					$this->data['patient_id'] = $patient_id;
					$this->data['pp_id'] = $pp_id;
					$this->data['patient_caregiver_edit'] = $this->caregiver_model->editPatientCareGiver($pcg_id);
					$this->show_view_admin('admin/patient/caregiver/caregiver_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$post_cg['pcg_let'] = $this->data['lat'];
					$post_cg['pcg_long'] = $this->data['lon'];
					$post_cg['patient_id'] = $patient_id;
					$post_cg['pp_id'] = $pp_id;
					$post_cg['user_id'] = $user_id;
					$post_cg['user_all_level'] = $user_all_level.','.$user_id;
					$post_cg['patient_saksham_id'] = $this->input->post('patient_saksham_id');
					$post_cg['pcg_patient_name'] = $this->input->post('pcg_patient_name');
					$post_cg['pcg_patient_father_name'] = $this->input->post('pcg_patient_father_name');
					$post_cg['pcg_patient_dob'] = $this->input->post('pcg_patient_dob');
					$post_cg['pcg_date_of_registration'] = $this->input->post('pcg_date_of_registration');
					$post_cg['pcg_place_for_registration'] = $this->input->post('pcg_place_for_registration');
					$post_cg['pcg_share_detail_status'] = $this->input->post('pcg_share_detail_status');
					$post_cg['pcg_caregiver_name'] = $this->input->post('pcg_caregiver_name');
					$post_cg['pcg_relationship_with_patient'] = $this->input->post('pcg_relationship_with_patient');
					$post_cg['pcg_caregiver_age'] = $this->input->post('pcg_caregiver_age');
					$post_cg['pcg_caregiver_gender'] = $this->input->post('pcg_caregiver_gender');
					$post_cg['pcg_past_history_of_TB'] = $this->input->post('pcg_past_history_of_TB');
					$post_cg['pcg_suffer_from_TB'] = $this->input->post('pcg_suffer_from_TB');
					$post_cg['pcg_category_of_TB'] = $this->input->post('pcg_category_of_TB');
					$post_cg['pcg_organ_affected_from_TB'] = $this->input->post('pcg_organ_affected_from_TB');
					$pcg_treatment_present_outcome = $this->input->post('pcg_treatment_present_outcome');
					if($pcg_treatment_present_outcome)
					{
						$d = '';
						for ($l=0; $l < count($pcg_treatment_present_outcome) ; $l++) 
						{ 
							if($l==0)
							{
								$d = $pcg_treatment_present_outcome[$l];
							}
							else
							{
								$d = $d.','.$pcg_treatment_present_outcome[$l];
							}
						}
					}
					$post_cg['pcg_treatment_present_outcome'] = $d;					
					$pcg_self_substance_abuse = $this->input->post('pcg_self_substance_abuse');
					if($pcg_self_substance_abuse)
					{
						$e = '';
						for ($m=0; $m < count($pcg_self_substance_abuse) ; $m++) 
						{ 
							if($m==0)
							{
								if($pcg_self_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_self_substance_abuse_other'] = $this->input->post('pcg_self_substance_abuse_other');
									$e = $pcg_self_substance_abuse[$m];
								}
								else
								{
									$post_cg['pcg_self_substance_abuse_other'] == '';
									$e = $pcg_self_substance_abuse[$m];
								}
							}
							else
							{
								if($pcg_self_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_self_substance_abuse_other'] = $this->input->post('pcg_self_substance_abuse_other');
									$e = $e.','.$pcg_self_substance_abuse[$m];
								}
								else
								{
									$post_cg['pcg_self_substance_abuse_other'] == '';
									$e = $e.','.$pcg_self_substance_abuse[$m];
								}
							}							
						}
					}
					$post_cg['pcg_self_substance_abuse'] = $e;					
					$pcg_patient_substance_abuse = $this->input->post('pcg_patient_substance_abuse');
					if($pcg_patient_substance_abuse)
					{
						$g = '';
						for ($m=0; $m < count($pcg_patient_substance_abuse) ; $m++) 
						{ 
							if($m==0)
							{
								if($pcg_patient_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_patient_substance_abuse_other'] = $this->input->post('pcg_patient_substance_abuse_other');
									$g = $pcg_patient_substance_abuse[$m];
								}
								else
								{
									$post_cg['pcg_patient_substance_abuse_other'] = '';
									$g = $pcg_patient_substance_abuse[$m];
								}
							}
							else
							{
								if($pcg_patient_substance_abuse[$m] == 'Other')
								{
									$post_cg['pcg_patient_substance_abuse_other'] = $this->input->post('pcg_patient_substance_abuse_other');
									$g = $g.','.$pcg_patient_substance_abuse[$m];
									
								}
								else
								{
									$post_cg['pcg_patient_substance_abuse_other'] = '';
									$g = $g.','.$pcg_patient_substance_abuse[$m];
								}
							}
						}
					}
					$post_cg['pcg_patient_substance_abuse'] = $g;
					$pcg_counselling_topics = $this->input->post('pcg_counselling_topics');
					if($pcg_counselling_topics)
					{
						$f = '';
						for ($n=0; $n < count($pcg_counselling_topics) ; $n++) 
						{ 
							if($n==0)
							{
								$f = $bb;
								if($pcg_counselling_topics[$n] == 'Other')
								{
									$post_cg['pcg_counselling_topics_other'] = $this->input->post('pcg_counselling_topics_other');
									$f = $pcg_counselling_topics[$n];
								}
								else
								{
									$post_cg['pcg_counselling_topics_other'] = '';
									$f = $pcg_counselling_topics[$n];
								}
							}
							else
							{
								if($pcg_counselling_topics[$n] == 'Other')
								{
									$post_cg['pcg_counselling_topics_other'] = $this->input->post('pcg_counselling_topics_other');
									$f = $f.','.$pcg_counselling_topics[$n];
								}
								else
								{
									$post_cg['pcg_counselling_topics_other'] = '';
									$f = $f.','.$pcg_counselling_topics[$n];
								}
							}
						}
					}
					$post_cg['pcg_counselling_topics'] = $f;
					$post_cg['pcg_csw_remarks'] = $this->input->post('pcg_csw_remarks');
					$post_cg['pcg_created_date'] = date('Y-m-d');
					$post_cg['pcg_updated_date'] = date('Y-m-d');
					$pcg_id = $this->caregiver_model->addPatientCaregiverDetails($post_cg);

					if($pcg_id)
					{
						$msg = 'patient caregiver added successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/patient/caregiver/'.$pp_id.'/'.$patient_id);
					}
					else
					{
						$msg = 'Whoops, looks like something went wrong!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/patient/caregiver/'.$pp_id.'/'.$patient_id);
					}	
				}
				else
				{
					$this->data['patient_id'] = $patient_id;
					$this->data['pp_id'] = $pp_id;
					$this->data['patient_res'] = $this->caregiver_model->patientDetailsByID($patient_id);
					$this->show_view_admin('admin/patient/caregiver/caregiver_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}
	
	/* Delete */
	public function delete_patientCaregiver()
	{
		if($this->checkDeletePermission())
		{
			$pp_id = $this->uri->segment(4);
			$patient_id = $this->uri->segment(5);
			$pcg_id = $this->uri->segment(6);
			
			$this->caregiver_model->delete_patientCaregiver($pcg_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/patient/caregiver/'.$pp_id.'/'.$patient_id);
			}
			else
			{
				$msg = 'Patient caregiver details remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/patient/caregiver/'.$pp_id.'/'.$patient_id);
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}

	/* Set Active / Inactive Status */
	public function setStatus()
	{
		if($this->checkSessionAdmin())
		{
			$post['patient_id'] = $this->input->post('id');
			$post['patient_followup_permission'] = $this->input->post('status');
			$this->patient_model->setStatus($post);
			echo 1 ;
			exit();
		}
		else
		{
			redirect(base_url().'admin');
		}
	}
}

/* End of file */?>