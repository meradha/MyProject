<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class PresumptivePatient extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/presumptivepatient_model');
	}
	
	/*	Validation Rules */
	 protected $validation_rules = array
        (
        'presumptivePatientAdd' => array(
            array(
                'field' => 'pp_referral_date',
                'label' => 'date of referral',
                'rules' => 'trim|required'
            )
        ),
		'presumptivePatientUpdate' => array(
        	array(
                'field' => 'pp_referral_date',
                'label' => 'date of referral',
                'rules' => 'trim|required'
            ) 
        )
    );
	
	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{			
			$this->data['presumptivePatient_res'] = $this->presumptivepatient_model->getAllPresumptivePatient();
			$this->show_view_admin('admin/patient/presumptive/presumptivePatient', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }

    /* Details */
	public function presumptivePatientView()
	{
		if($this->checkViewPermission())
		{	
			$pp_id = $this->uri->segment(4);
			$user_id = $this->data['session'][0]->user_id;			
			$this->data['stakeholder_list'] = $this->presumptivepatient_model->getAllStakeholder();
			$this->data['presumptivePatient_edit'] = $this->presumptivepatient_model->editPresumptivePatient($pp_id);
			$this->data['diagnosis_list'] = $this->presumptivepatient_model->getAllDiagnosis();
			$this->show_view_admin('admin/patient/presumptive/presumptivePatientView', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }

    /* Add and Update */
	public function addPresumptivePatient()
	{
		$pp_id = $this->uri->segment(4);
		$user_id = $this->data['session'][0]->user_id;	
		if($pp_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$this->form_validation->set_rules($this->validation_rules['presumptivePatientUpdate']);
					if($this->form_validation->run())
					{
						$post['pp_id'] = $pp_id;
						$post['pp_referral_date'] = $this->input->post('pp_referral_date');
						$post['pp_referral_type'] = $this->input->post('pp_referral_type');
						$post['pp_community_activity_name'] = $this->input->post('pp_community_activity_name');
						$post['pp_date_of_activity'] = $this->input->post('pp_date_of_activity');
						$post['pp_sputum_date'] = $this->input->post('pp_sputum_date');
						$post['pp_stakeholder_name'] = $this->input->post('pp_stakeholder_name');
						$post['pp_patient_name'] = $this->input->post('pp_patient_name');
						$post['pp_age'] = $this->input->post('pp_age');
						$post['pp_sex'] = $this->input->post('pp_sex');
						$post['country_id'] = '99';		
						$post['state_id'] = '1493';	
						$post['pp_city'] = 'Mumbai';
						$post['pp_address'] = $this->input->post('pp_address');
						$post['pp_postal_code'] = $this->input->post('pp_postal_code');
						$post['pp_phone_no'] = $this->input->post('pp_phone_no');
						$post['diagnosis_id'] = $this->input->post('diagnosis_id');
						$post['pp_landmark'] = $this->input->post('pp_landmark');
                       	$post['user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['pp_updated_date'] = date('Y-m-d');

						$this->presumptivepatient_model->updatePresumptivePatient($post);
						$msg = 'Presumptive patient update successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/presumptivePatient');
					}
					else
					{
						$this->data['stakeholder_list'] = $this->presumptivepatient_model->getAllStakeholder();
						$this->data['presumptivePatient_edit'] = $this->presumptivepatient_model->editPresumptivePatient($pp_id);
						$this->data['diagnosis_list'] = $this->presumptivepatient_model->getAllDiagnosis();
						$this->show_view_admin('admin/patient/presumptive/presumptivePatient_update', $this->data);
					}
				}
				else
				{
					$this->data['stakeholder_list'] = $this->presumptivepatient_model->getAllStakeholder();
					$this->data['presumptivePatient_edit'] = $this->presumptivepatient_model->editPresumptivePatient($pp_id);
					$this->data['diagnosis_list'] = $this->presumptivepatient_model->getAllDiagnosis();
					$this->show_view_admin('admin/patient/presumptive/presumptivePatient_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$this->form_validation->set_rules($this->validation_rules['presumptivePatientAdd']);
					if($this->form_validation->run())
					{
						$post['pp_let'] = $this->data['lat'];
						$post['pp_long'] = $this->data['lon'];
						$post['pp_referral_date'] = $this->input->post('pp_referral_date');
						$post['pp_referral_type'] = $this->input->post('pp_referral_type');
						$post['pp_community_activity_name'] = $this->input->post('pp_community_activity_name');
						$post['pp_date_of_activity'] = $this->input->post('pp_date_of_activity');
						$post['pp_sputum_date'] = $this->input->post('pp_sputum_date');
						$post['pp_stakeholder_name'] = $this->input->post('pp_stakeholder_name');
						$post['pp_patient_name'] = $this->input->post('pp_patient_name');
						$post['pp_age'] = $this->input->post('pp_age');
						$post['pp_sex'] = $this->input->post('pp_sex');
						$post['country_id'] = '99';		
						$post['state_id'] = '1493';	
						$post['pp_city'] = 'Mumbai';
						$post['pp_address'] = $this->input->post('pp_address');
						$post['pp_postal_code'] = $this->input->post('pp_postal_code');
						$post['pp_phone_no'] = $this->input->post('pp_phone_no');
						$post['diagnosis_id'] = $this->input->post('diagnosis_id');
						$post['pp_landmark'] = $this->input->post('pp_landmark');
                       	$post['user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['pp_created_date'] = date('Y-m-d');
						$post['pp_updated_date'] = date('Y-m-d');
						$pp_id =  $this->presumptivepatient_model->addPresumptivePatient($post);
						if($pp_id)
						{
							$post_u['pp_id'] = $pp_id;
							$post_u['pp_saksham_patient_id'] = 'SKP'.$pp_id;
							$this->presumptivepatient_model->updateSakshamID($post_u);

							$msg = 'Presumptive patient added successfully!!';				
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/presumptivePatient');
						}
						else
						{
							$msg = 'Whoops, looks like something went wrong!';				
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/presumptivePatient/addPresumptivePatient ');
						}
					}
					else
					{
						$this->data['diagnosis_list'] = $this->presumptivepatient_model->getAllDiagnosis();
						$this->data['stakeholder_list'] = $this->presumptivepatient_model->getAllStakeholder();
						$this->show_view_admin('admin/patient/presumptive/presumptivePatient_add', $this->data);
					}		
				}
				else
				{
					$this->data['diagnosis_list'] = $this->presumptivepatient_model->getAllDiagnosis();
					$this->data['stakeholder_list'] = $this->presumptivepatient_model->getAllStakeholder();
					$this->show_view_admin('admin/patient/presumptive/presumptivePatient_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}
	
	/* Delete */
	public function delete_presumptivePatient()
	{
		if($this->checkDeletePermission())
		{
			$pp_id = $this->uri->segment(4);
			$this->presumptivepatient_model->delete_presumptivePatient($pp_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/presumptivePatient'); 
			}
			else
			{
				$msg = 'Presumptive patient remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/presumptivePatient');
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}

	/* Add Presumptive report result */
	public function addPresumptiveResult()
	{
		$pp_id = $this->uri->segment(4);
		if (isset($_POST['Submit']) && $_POST['Submit'] == "EditResult") 
		{
			$post['pp_id'] = $pp_id;
			$post['pp_reached_status'] = $this->input->post('pp_reached_status');
			$post['pp_testing_status'] = $this->input->post('pp_testing_status');
			$post['pp_testing_date'] = $this->input->post('pp_testing_date');
			$post['pp_testing_number'] = $this->input->post('pp_testing_number');
			$post['pp_testing_result'] = $this->input->post('pp_testing_result');
			$post['pp_diagnosis_date'] = $this->input->post('pp_diagnosis_date');
			$post['pp_drug_resistance_status'] = $this->input->post('pp_drug_resistance_status');
			$post['pp_drug_resistance_type'] = $this->input->post('pp_drug_resistance_type');
			if($post['pp_drug_resistance_type'] == 'Other')
			{
				$post['pp_drug_sensitive_type_other'] = $this->input->post('pp_drug_sensitive_type_other');
			}
			$post['pp_drug_sensitive_type'] = $this->input->post('pp_drug_sensitive_type');
			if($post['pp_drug_sensitive_type'] == 'Other')
			{
				$post['pp_drug_resistance_type_other'] = $this->input->post('pp_drug_resistance_type_other');
			}

			$post['pp_testing_reason'] = $this->input->post('pp_testing_reason');
			$post['pp_comments'] = $this->input->post('pp_comments');
			$post['pp_updated_date'] = date('Y-m-d');
			$post['pp_report_status'] = '1';

			$this->presumptivepatient_model->updatePresumptivePatientReportStatus($post);


			$msg = 'Presumptive report status added successfully...!';					
			$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
			redirect(base_url().'admin/presumptivePatient');
		}
		else
		{
			$this->data['presumptivePatient_details'] = $this->presumptivepatient_model->presumptivePatientDetailsByID($pp_id);			
			$this->show_view_admin('admin/patient/presumptive/presumptivePatientt_result', $this->data);
		}
	}

	/* submit to sakasham pravah */
	public function sendToShakshamPravah()
	{
		$pp_id = $this->uri->segment(4);
		if (isset($_POST['Submit']) && $_POST['Submit'] == "sendSakshamPravah") 
		{
			$post['pp_id'] = $pp_id;
			$post['pp_patient_nikshay_id'] = $this->input->post('pp_patient_nikshay_id');
			$post['pp_date_of_saksham_counsellor'] = $this->input->post('pp_date_of_saksham_counsellor');
			$post['pp_helth_post_area'] = $this->input->post('pp_helth_post_area');
			$post['saksham_pravah_id'] = $this->input->post('saksham_pravah_id');
			$post['pp_send_pravah_status'] = '2';
			$post['pp_report_status'] = '1';
			$this->presumptivepatient_model->updatePresumptivePatientSendSakshamPravah($post);

			$sakasham_pravah_res = $this->presumptivepatient_model->getSakshamPravahData($post['saksham_pravah_id']);
			if(!empty($sakasham_pravah_res))
			{
				$presumptivePatient_details = $this->presumptivepatient_model->presumptivePatientDetailsByID($pp_id);
				
				$email = $sakasham_pravah_res[0]->sp_email;
				$subject = 'Patient details';
				$message = '';
				$message .= 'Patient name : '.$presumptivePatient_details[0]->pp_patient_name.'<br>';
				$message .= 'Patient age : '.$presumptivePatient_details[0]->pp_age.'<br>';
				$message .= 'Patient gender : '.$presumptivePatient_details[0]->pp_sex.'<br>';
				$message .= 'Patient phone number : '.$presumptivePatient_details[0]->pp_postal_code.'<br>';
				$message .= 'Diagnosis name : '.$presumptivePatient_details[0]->diagnosis_name.'<br>';
				$message .= 'Referred By : '.$presumptivePatient_details[0]->user_name.'<br>';

				$message .= 'Accept Patient to ';

				$message .= '<a href="'.base_url().'admin/presumptivePatient/acceptPatient/'.$pp_id.'/'.$sakasham_pravah_res[0]->sp_id.'">Click Here</a>';




				$mail = $this->send_mail($email, $subject, $message);
				if($mail)
				{
					$msg = 'Presumptive patient data send to sakasham pravah successfully!!';					
					$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
					redirect(base_url().'admin/presumptivePatient');
				}
				else
				{
					$msg = 'Whoops, looks like something went wrong!';					
					$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
					redirect(base_url().'admin/presumptivePatient/sendToShakshamPravah/'.$pp_id);
				}
			}
		}
		else
		{
			$this->data['healthpostarea_list'] = $this->presumptivepatient_model->getAllHealthpostArea();
			$this->data['saksham_pravah_list'] = $this->presumptivepatient_model->getSakshamPravahList();
			$this->data['presumptivePatient_details'] = $this->presumptivepatient_model->presumptivePatientDetailsByID($pp_id);		
			$this->show_view_admin('admin/patient/presumptive/presumptivePatientt_send_to_saksham', $this->data);
		}
	}

	/* Accept Patient */
	public function acceptPatient()
	{
		$pp_id = $this->uri->segment(4);
		$sp_id = $this->uri->segment(5);
		$post['pp_send_pravah_status'] = '1';
		$post['pp_id'] = $pp_id;
		$this->presumptivepatient_model->updateAcceptanceBySakshamPravah($post);
		$msg = 'Thanks for acceptance';					
		$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
		redirect(base_url().'admin/common/thanksPage');
		
	}

	public function showSendSakhamPravahData()
	{
		$pp_id = $this->uri->segment(4);
		$this->data['presumptivePatient_details'] = $this->presumptivepatient_model->showSendSakhamPravahData($pp_id);
		$this->data['healthpostarea_list'] = $this->presumptivepatient_model->getAllHealthpostArea();
		$this->show_view_admin('admin/patient/presumptive/presumptivePatientt_showSendSakhamPravahData', $this->data);
	}

	/* Set Active / Inactive Status */
	public function setStatus()
	{
		if($this->checkSessionAdmin())
		{
			$post['pp_id'] = $this->input->post('id');
			$post['pp_permission_presumptive_status'] = $this->input->post('status');
			$this->presumptivepatient_model->setStatus($post);
			echo 1 ;
			exit();
		}
		else
		{
			redirect(base_url().'admin');
		}
	}
}

/* End of file */?>