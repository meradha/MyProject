<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Caregiver extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/caregiver_model');
	}

	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{		
			$patient_id = $this->uri->segment(4);	
			$pp_id = $this->uri->segment(5);	
			$this->data['caregiver_res'] = $this->caregiver_model->getAllCaregiver($patient_id);
			$this->data['patient_id'] = $patient_id;
			$this->data['pp_id'] = $pp_id;
			$this->show_view_admin('admin/patient/caregiver/caregiver', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addCaregiver()
	{
		$patient_id = $this->uri->segment(4);
		$pp_id = $this->uri->segment(5);
		$pcg_id = $this->uri->segment(6);
		$user_id = $this->data['session'][0]->user_id;	
		$user_all_level = $this->data['session'][0]->user_all_level.','.$user_id;	
		if($pcg_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$post_cg['pcg_id'] = $pcg_id;
					$post_cg['patient_id'] = $patient_id;
					$post_cg['pp_id'] = $pp_id;
					$post_cg['user_id'] = $user_id;
					$post_cg['user_all_level'] = $user_all_level.','.$user_id;
					$post_cg['pcg_patient_name'] = $this->input->post('pcg_patient_name');
					$post_cg['pcg_patient_father_name'] = $this->input->post('pcg_patient_father_name');
					$post_cg['pcg_patient_dob'] = $this->input->post('pcg_patient_dob');
					$post_cg['patient_saksham_id'] = $this->input->post('patient_saksham_id');
					$post_cg['pcg_date_of_registration'] = $this->input->post('pcg_date_of_registration');
					$post_cg['pcg_place_for_registration'] = $this->input->post('pcg_place_for_registration');
					$post_cg['pcg_share_detail_status'] = $this->input->post('pcg_share_detail_status');
					$post_cg['pcg_caregiver_name'] = $this->input->post('pcg_caregiver_name');
					$post_cg['pcg_relationship_with_patient'] = $this->input->post('pcg_relationship_with_patient');
					$post_cg['pcg_caregiver_age'] = $this->input->post('pcg_caregiver_age');
					$post_cg['pcg_caregiver_gender'] = $this->input->post('pcg_caregiver_gender');
					$post_cg['pcg_past_history_of_TB'] = $this->input->post('pcg_past_history_of_TB');
					$post_cg['pcg_suffer_from_TB'] = $this->input->post('pcg_suffer_from_TB');
					$post_cg['pcg_category_of_TB'] = $this->input->post('pcg_category_of_TB');
					$post_cg['pcg_organ_affected_from_TB'] = $this->input->post('pcg_organ_affected_from_TB');
					$pcg_treatment_present_outcome = $this->input->post('pcg_treatment_present_outcome');
					if($pcg_treatment_present_outcome)
					{
						$d = '';
						for ($l=0; $l < count($pcg_treatment_present_outcome) ; $l++) 
						{ 
							if($l==0)
							{
								$d = $pcg_treatment_present_outcome[$l];
							}
							else
							{
								$d = $d.','.$pcg_treatment_present_outcome[$l];
							}
						}
					}
					$post_cg['pcg_treatment_present_outcome'] = $d;
					$pcg_self_substance_abuse = $this->input->post('pcg_self_substance_abuse');
					if($pcg_self_substance_abuse)
					{
						$e = '';
						for ($m=0; $m < count($pcg_self_substance_abuse) ; $m++) 
						{ 
							if($pcg_self_substance_abuse[$m] == 'Other')
							{
								$aa = $this->input->post('pcg_self_substance_abuse_other');
								if($m==0)
								{
									$e = $aa;
								}
								else
								{
									$e = $e.','.$aa;
								}
								
							}
							else
							{
								if($m==0)
								{
									$e = $pcg_self_substance_abuse[$m];
								}
								else
								{
									$e = $e.','.$pcg_self_substance_abuse[$m];
								}
							}							
						}
					}
					$post_cg['pcg_self_substance_abuse'] = $e;
					$pcg_patient_substance_abuse = $this->input->post('pcg_patient_substance_abuse');
					if($pcg_patient_substance_abuse)
					{
						$g = '';
						for ($m=0; $m < count($pcg_patient_substance_abuse) ; $m++) 
						{ 
							if($pcg_patient_substance_abuse[$m] == 'Other')
							{
								$bb = $this->input->post('pcg_patient_substance_abuse_other');
								if($m==0)
								{
									$g = $bb;
								}
								else
								{
									$g = $g.','.$bb;
								}
								
							}
							else
							{
								if($m==0)
								{
									$g = $pcg_patient_substance_abuse[$m];
								}
								else
								{
									$g = $g.','.$pcg_patient_substance_abuse[$m];
								}
							}
						}
					}
					$post_cg['pcg_patient_substance_abuse'] = $g;
					$pcg_counselling_topics = $this->input->post('pcg_counselling_topics');
					if($pcg_counselling_topics)
					{
						$f = '';
						for ($n=0; $n < count($pcg_counselling_topics) ; $n++) 
						{ 
							if($pcg_counselling_topics[$n] == 'Other')
							{
								$bb = $this->input->post('pcg_counselling_topics_other');
								if($n==0)
								{
									$f = $bb;
								}
								else
								{
									$f = $f.','.$bb;
								}
								
							}
							else
							{
								if($n==0)
								{
									$f = $pcg_counselling_topics[$n];
								}
								else
								{
									$f = $f.','.$pcg_counselling_topics[$n];
								}
							}
						}
					}
					$post_cg['pcg_counselling_topics'] = $f;
					$post_cg['pcg_csw_remarks'] = $this->input->post('pcg_csw_remarks');
					$post_cg['pcg_updated_date'] = date('Y-m-d');
					$this->caregiver_model->updatePatientCareGiver($post_cg);


					$msg = 'Patient caregiver details update successfully!!';					
					$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
					redirect(base_url().'admin/caregiver/index/'.$patient_id.'/'.$pp_id);
				}
				else
				{
					$this->data['patient_id'] = $patient_id;
					$this->data['pp_id'] = $pp_id;
					$this->data['patient_caregiver_edit'] = $this->caregiver_model->editPatientCareGiver($pcg_id);
					$this->show_view_admin('admin/patient/caregiver/caregiver_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$post_cg['patient_id'] = $patient_id;
					$post_cg['pp_id'] = $pp_id;
					$post_cg['user_id'] = $user_id;
					$post_cg['user_all_level'] = $user_all_level.','.$user_id;
					$post_cg['pcg_patient_name'] = $this->input->post('pcg_patient_name');
					$post_cg['pcg_patient_father_name'] = $this->input->post('pcg_patient_father_name');
					$post_cg['pcg_patient_dob'] = $this->input->post('pcg_patient_dob');
					$post_cg['patient_saksham_id'] = $this->input->post('patient_saksham_id');
					$post_cg['pcg_date_of_registration'] = $this->input->post('pcg_date_of_registration');
					$post_cg['pcg_place_for_registration'] = $this->input->post('pcg_place_for_registration');
					$post_cg['pcg_share_detail_status'] = $this->input->post('pcg_share_detail_status');
					$post_cg['pcg_caregiver_name'] = $this->input->post('pcg_caregiver_name');
					$post_cg['pcg_relationship_with_patient'] = $this->input->post('pcg_relationship_with_patient');
					$post_cg['pcg_caregiver_age'] = $this->input->post('pcg_caregiver_age');
					$post_cg['pcg_caregiver_gender'] = $this->input->post('pcg_caregiver_gender');
					$post_cg['pcg_past_history_of_TB'] = $this->input->post('pcg_past_history_of_TB');
					$post_cg['pcg_suffer_from_TB'] = $this->input->post('pcg_suffer_from_TB');
					$post_cg['pcg_category_of_TB'] = $this->input->post('pcg_category_of_TB');
					$post_cg['pcg_organ_affected_from_TB'] = $this->input->post('pcg_organ_affected_from_TB');
					$pcg_treatment_present_outcome = $this->input->post('pcg_treatment_present_outcome');
					if($pcg_treatment_present_outcome)
					{
						$d = '';
						for ($l=0; $l < count($pcg_treatment_present_outcome) ; $l++) 
						{ 
							if($l==0)
							{
								$d = $pcg_treatment_present_outcome[$l];
							}
							else
							{
								$d = $d.','.$pcg_treatment_present_outcome[$l];
							}
						}
					}
					$post_cg['pcg_treatment_present_outcome'] = $d;
					$pcg_self_substance_abuse = $this->input->post('pcg_self_substance_abuse');
					if($pcg_self_substance_abuse)
					{
						$e = '';
						for ($m=0; $m < count($pcg_self_substance_abuse) ; $m++) 
						{ 
							if($pcg_self_substance_abuse[$m] == 'Other')
							{
								$aa = $this->input->post('pcg_self_substance_abuse_other');
								if($m==0)
								{
									$e = $aa;
								}
								else
								{
									$e = $e.','.$aa;
								}
								
							}
							else
							{
								if($m==0)
								{
									$e = $pcg_self_substance_abuse[$m];
								}
								else
								{
									$e = $e.','.$pcg_self_substance_abuse[$m];
								}
							}							
						}
					}
					$post_cg['pcg_self_substance_abuse'] = $e;
					$pcg_patient_substance_abuse = $this->input->post('pcg_patient_substance_abuse');
					if($pcg_patient_substance_abuse)
					{
						$g = '';
						for ($m=0; $m < count($pcg_patient_substance_abuse) ; $m++) 
						{ 
							if($pcg_patient_substance_abuse[$m] == 'Other')
							{
								$bb = $this->input->post('pcg_patient_substance_abuse_other');
								if($m==0)
								{
									$g = $bb;
								}
								else
								{
									$g = $g.','.$bb;
								}
								
							}
							else
							{
								if($m==0)
								{
									$g = $pcg_patient_substance_abuse[$m];
								}
								else
								{
									$g = $g.','.$pcg_patient_substance_abuse[$m];
								}
							}
						}
					}
					$post_cg['pcg_patient_substance_abuse'] = $g;
					$pcg_counselling_topics = $this->input->post('pcg_counselling_topics');
					if($pcg_counselling_topics)
					{
						$f = '';
						for ($n=0; $n < count($pcg_counselling_topics) ; $n++) 
						{ 
							if($pcg_counselling_topics[$n] == 'Other')
							{
								$bb = $this->input->post('pcg_counselling_topics_other');
								if($n==0)
								{
									$f = $bb;
								}
								else
								{
									$f = $f.','.$bb;
								}
								
							}
							else
							{
								if($n==0)
								{
									$f = $pcg_counselling_topics[$n];
								}
								else
								{
									$f = $f.','.$pcg_counselling_topics[$n];
								}
							}
						}
					}
					$post_cg['pcg_counselling_topics'] = $f;
					$post_cg['pcg_csw_remarks'] = $this->input->post('pcg_csw_remarks');
					$post_cg['pcg_created_date'] = date('Y-m-d');
					$post_cg['pcg_updated_date'] = date('Y-m-d');
					$pcg_id = $this->caregiver_model->addPatientCaregiverDetails($post_cg);

					if($pcg_id)
					{
						$msg = 'patient caregiver added successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/caregiver/index/'.$patient_id.'/'.$pp_id);
					}
					else
					{
						$msg = 'Whoops, looks like something went wrong!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/caregiver/index/'.$patient_id.'/'. $pp_id);
					}	
				}
				else
				{
					$this->data['patient_id'] = $patient_id;
					$this->data['pp_id'] = $pp_id;
					$this->data['patient_res'] = $this->caregiver_model->patientDetailsByID($patient_id);
					$this->show_view_admin('admin/patient/caregiver/caregiver_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}
	
	/* Delete */
	public function delete_patientCaregiver()
	{
		if($this->checkDeletePermission())
		{
			$pcg_id = $this->uri->segment(4);
			$patient_id = $this->uri->segment(5);
			
			$this->caregiver_model->delete_patientCaregiver($pcg_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/caregiver/index/'.$patient_id.'/'.$pp_id); 
			}
			else
			{
				$msg = 'Patient caregiver details remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/caregiver/index/'.$patient_id.'/'.$pp_id); 
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}
}

/* End of file */?>