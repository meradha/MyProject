<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class HealthpostArea extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/healthpostarea_model');
	}
	
	/*	Validation Rules */
	 protected $validation_rules = array
        (
        'healthpostAreaAdd' => array(
            array(
                'field' => 'helthpostarea_name',
                'label' => 'helthpost area name',
                'rules' => 'trim|required'
            )
        ),
		'healthpostAreaUpdate' => array(
        	array(
                'field' => 'helthpostarea_name',
                'label' => 'helthpost area name',
                'rules' => 'trim|required'
            )   
        )
    );
	
	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{			
			$this->data['helthpostarea_res'] = $this->healthpostarea_model->getHealthpostArea();
			$this->show_view_admin('admin/healthpostArea/healthpostArea', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addHealthpostArea()
	{
		$helthpostarea_id = $this->uri->segment(4);
		if($helthpostarea_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$this->form_validation->set_rules($this->validation_rules['healthpostAreaUpdate']);
					if($this->form_validation->run())
					{
						$post['helthpostarea_id'] = $helthpostarea_id;
						$post['helthpostarea_name'] = $this->input->post('helthpostarea_name');
						$post['helthpostarea_status'] = $this->input->post('helthpostarea_status');
						$post['user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['helthpostarea_updated_date'] = date('Y-m-d');
						$this->healthpostarea_model->updateHealthpostArea($post);

						$msg = 'healthpost area update successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/healthpostArea');
					}
					else
					{
						$this->data['healthpostArea_edit'] = $this->healthpostarea_model->editHealthpostArea($helthpostarea_id);
						$this->show_view_admin('admin/healthpostArea/healthpostArea_update', $this->data);
					}
				}
				else
				{
					$this->data['healthpostArea_edit'] = $this->healthpostarea_model->editHealthpostArea($helthpostarea_id);
					$this->show_view_admin('admin/healthpostArea/healthpostArea_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$this->form_validation->set_rules($this->validation_rules['healthpostAreaAdd']);
					if($this->form_validation->run())
					{
						$post['helthpostarea_name'] = $this->input->post('helthpostarea_name');
						$post['helthpostarea_status'] = $this->input->post('helthpostarea_status');
						$post['user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['helthpostarea_created_date'] = date('Y-m-d');
						$post['helthpostarea_updated_date'] = date('Y-m-d');

						$helthpostarea_id =  $this->healthpostarea_model->addHealthpostArea($post);
						if($helthpostarea_id)
						{
							$msg = 'healthpost area added successfully!!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/healthpostArea');
						}
						else
						{
							$msg = 'Whoops, looks like something went wrong!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/healthpostArea/addHealthpostArea');
						}
					}
					else
					{
						$this->show_view_admin('admin/healthpostArea/healthpostArea_add', $this->data);
					}		
				}
				else
				{
					$this->show_view_admin('admin/healthpostArea/healthpostArea_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}
	
	/* Delete */
	public function delete_healthpostArea()
	{
		if($this->checkDeletePermission())
		{
			$helthpostarea_id = $this->uri->segment(4);
			
			$this->healthpostarea_model->delete_healthpostArea($helthpostarea_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/healthpostArea'); 
			}
			else
			{
				$msg = 'healthpost area remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/healthpostArea');
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}

}

/* End of file */?>