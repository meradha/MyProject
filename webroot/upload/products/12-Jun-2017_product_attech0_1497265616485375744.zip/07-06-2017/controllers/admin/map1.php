<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Map extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/map_model');
	}
	
	/* Show */
	public function index()
	{	
		$this->show_view_admin('admin/map/mapView', $this->data);
    }

    
}

/* End of file */?>