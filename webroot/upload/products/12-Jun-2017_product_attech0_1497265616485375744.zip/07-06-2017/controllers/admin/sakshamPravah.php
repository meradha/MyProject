<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class SakshamPravah extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/sakshampravah_model');
	}
	
	/*	Validation Rules */
	 protected $validation_rules = array
        (
        'sakshamPravahAdd' => array(
            array(
                'field' => 'sp_name',
                'label' => 'name',
                'rules' => 'trim|required'
            ),
			array(
                'field' => 'sp_owner_name',
                'label' => 'owner name',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'sp_email',
                'label' => 'email',
                'rules' => 'trim|required'
            ),
            array(  
				'field' => 'sp_mobile',
				'label' => 'mobile', 
				'rules' => 'trim|required'
            ), 
            array(  
				'field' => 'sp_address',
				'label' => 'address', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'sp_city',
				'label' => 'city', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'sp_state_id',
				'label' => 'state', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'sp_country_id',
				'label' => 'country', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'sp_postal_code',
				'label' => 'postal code', 
				'rules' => 'trim|required'
            )
        ),
		'sakshamPravahUpdate' => array(
        	array(
                'field' => 'sp_name',
                'label' => 'name',
                'rules' => 'trim|required'
            ),
			array(
                'field' => 'sp_owner_name',
                'label' => 'owner name',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'sp_email',
                'label' => 'email',
                'rules' => 'trim|required'
            ),
            array(  
				'field' => 'sp_mobile',
				'label' => 'mobile', 
				'rules' => 'trim|required'
            ), 
            array(  
				'field' => 'sp_address',
				'label' => 'address', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'sp_city',
				'label' => 'city', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'sp_state_id',
				'label' => 'state', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'sp_country_id',
				'label' => 'country', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'sp_postal_code',
				'label' => 'postal code', 
				'rules' => 'trim|required'
            )    
        )
    );
	
	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{			
			$this->data['sakshamPravah_res'] = $this->sakshampravah_model->getSakshamPravah();
			$this->show_view_admin('admin/sakshamPravah/sakshamPravah', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }

    /* Details */
	public function sakshamPravahView()
	{
		if($this->checkViewPermission())
		{	
			$sp_id = $this->uri->segment(4);		
			$this->data['sakshamPravah_edit'] = $this->sakshampravah_model->editSakshamPravah($sp_id);
			$this->data['country_list'] = $this->sakshampravah_model->getAllCountry();
			$this->data['state_list'] = $this->sakshampravah_model->getAllState();
			$this->show_view_admin('admin/sakshamPravah/sakshamPravahView', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addSakshamPravah()
	{
		$sp_id = $this->uri->segment(4);
		if($sp_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$this->form_validation->set_rules($this->validation_rules['sakshamPravahUpdate']);
					if($this->form_validation->run())
					{
						$post['sp_id'] = $sp_id;
						$post['sp_name'] = $this->input->post('sp_name');
						$post['sp_owner_name'] = $this->input->post('sp_owner_name');
						$post['sp_email'] = $this->input->post('sp_email');
						$post['sp_phone'] = $this->input->post('sp_phone');
						$post['sp_mobile'] = $this->input->post('sp_mobile');
						$post['sp_address'] = $this->input->post('sp_address');
						$post['sp_city'] = $this->input->post('sp_city');
						$post['sp_state_id'] = $this->input->post('sp_state_id');
						$post['sp_country_id'] = $this->input->post('sp_country_id');
						$post['sp_postal_code'] = $this->input->post('sp_postal_code');
						$post['sp_status'] = $this->input->post('sp_status');
						$post['sp_added_by'] = $this->data['session'][0]->user_id;
						$post['sp_added_by_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['sp_created_date'] = date('Y-m-d');
						$post['sp_updated_date'] = date('Y-m-d');
						$this->sakshampravah_model->updateSakshamPravah($post);

						$msg = 'Saksham pravah update successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/sakshamPravah');
					}
					else
					{
						$this->data['sakshamPravah_edit'] = $this->sakshampravah_model->editSakshamPravah($sp_id);
						$this->data['country_list'] = $this->sakshampravah_model->getAllCountry();
						$this->data['state_list'] = $this->sakshampravah_model->getAllState();
						$this->show_view_admin('admin/sakshamPravah/sakshamPravah_update', $this->data);
					}
				}
				else
				{
					$this->data['sakshamPravah_edit'] = $this->sakshampravah_model->editSakshamPravah($sp_id);
					$this->data['country_list'] = $this->sakshampravah_model->getAllCountry();
					$this->data['state_list'] = $this->sakshampravah_model->getAllState();
					$this->show_view_admin('admin/sakshamPravah/sakshamPravah_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$this->form_validation->set_rules($this->validation_rules['sakshamPravahAdd']);
					if($this->form_validation->run())
					{
						$post['sp_name'] = $this->input->post('sp_name');
						$post['sp_owner_name'] = $this->input->post('sp_owner_name');
						$post['sp_email'] = $this->input->post('sp_email');
						$post['sp_phone'] = $this->input->post('sp_phone');
						$post['sp_mobile'] = $this->input->post('sp_mobile');
						$post['sp_address'] = $this->input->post('sp_address');
						$post['sp_city'] = $this->input->post('sp_city');
						$post['sp_state_id'] = $this->input->post('sp_state_id');
						$post['sp_country_id'] = $this->input->post('sp_country_id');
						$post['sp_postal_code'] = $this->input->post('sp_postal_code');
						$post['sp_status'] = $this->input->post('sp_status');
						$post['sp_added_by'] = $this->data['session'][0]->user_id;
						$post['sp_added_by_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['sp_created_date'] = date('Y-m-d');
						$post['sp_updated_date'] = date('Y-m-d');

						$sp_id =  $this->sakshampravah_model->addSakshamPravah($post);
						if($sp_id)
						{
							$msg = 'Saksham pravah added successfully!!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/sakshamPravah');
						}
						else
						{
							$msg = 'Whoops, looks like something went wrong!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/sakshamPravah/addSakshamPravah');
						}
					}
					else
					{
						$this->data['country_list'] = $this->sakshampravah_model->getAllCountry();
						$this->show_view_admin('admin/sakshamPravah/sakshamPravah_add', $this->data);
					}		
				}
				else
				{	
					$this->data['country_list'] = $this->sakshampravah_model->getAllCountry();
					$this->show_view_admin('admin/sakshamPravah/sakshamPravah_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}
	
	/* Delete */
	public function delete_sakshamPravah()
	{
		if($this->checkDeletePermission())
		{
			$sp_id = $this->uri->segment(4);
			
			$this->sakshampravah_model->delete_sakshamPravah($sp_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/sakshamPravah'); 
			}
			else
			{
				$msg = 'Saksham pravah remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/sakshamPravah');
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}

	/* Get State List */
	public function getStateList()
	{
		$country_id = $this->input->post('country_id');
		$state_list = $this->sakshampravah_model->getStateListByCountryId($country_id);

		$html = '';
		if(count($state_list) > 0)
		{
			foreach ($state_list as $s_list) 
			{
				$html .= '<option value="'.$s_list->state_id.'">'.$s_list->state_name.'</option>';
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}

	/* Get State List by Country id */
	public function getStateListByCountryID()
	{
		$country_id = $this->input->post('country_id');
		$state_list = $this->sakshampravah_model->getStateListByCountryID($country_id);

		$html = '';
		$html .= '<option value=""></option>';
		if(!empty($state_list))
		{
			foreach ($state_list as $s_list) 
			{
				$html .= '<option value="'.$s_list->state_id.'">'.$s_list->state_name.'</option>';
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}
}

/* End of file */?>