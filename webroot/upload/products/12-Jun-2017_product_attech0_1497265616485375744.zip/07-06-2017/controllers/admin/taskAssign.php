<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class TaskAssign extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/taskassign_model');
	}
	
	/*	Validation Rules */
	 protected $validation_rules = array
        (
        'taskAssignAdd' => array(
            array(
                'field' => 'ta_assign_to_role_id',
                'label' => 'user role',
                'rules' => 'trim|required'
            ),
			array(
                'field' => 'ta_assign_to',
                'label' => 'assign to user',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'task_id',
                'label' => 'task',
                'rules' => 'trim|required'
            ),
            array(  
				'field' => 'ta_task_start_date',
				'label' => 'start date', 
				'rules' => 'trim|required'
            ), 
            array(  
				'field' => 'ta_task_end_date',
				'label' => 'end date', 
				'rules' => 'trim|required'
            ), 
            array(  
				'field' => 'ta_total_task',
				'label' => 'total target', 
				'rules' => 'trim|required'
            ), 
            array(  
				'field' => 'ta_low_case_area_task',
				'label' => 'low case area target', 
				'rules' => 'trim|required'
            ), 
            array(  
				'field' => 'ta_high_case_area_task',
				'label' => 'high case area target', 
				'rules' => 'trim|required'
            )
        ),
		'taskAssignUpdate' => array(
        	array(
                'field' => 'task_id',
                'label' => 'task',
                'rules' => 'trim|required'
            ),
            array(  
				'field' => 'ta_task_start_date',
				'label' => 'start date', 
				'rules' => 'trim|required'
            ),            
            array(  
				'field' => 'ta_total_task',
				'label' => 'total target', 
				'rules' => 'trim|required'
            ), 
            array(  
				'field' => 'ta_low_case_area_task',
				'label' => 'low case area target', 
				'rules' => 'trim|required'
            ), 
            array(  
				'field' => 'ta_high_case_area_task',
				'label' => 'high case area target', 
				'rules' => 'trim|required'
            )  
        )
    );
	
	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{			
			$user_id = $this->data['session'][0]->user_id;
			$this->data['assign_by_task_res'] = $this->taskassign_model->getTaskAssignBy($user_id);
			$this->data['approved_task_res'] = $this->taskassign_model->getTaskAssignApproved();
			$this->show_view_admin('admin/task/taskAssign', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }

    /* Details */
	public function taskAssignApprovedView()
	{
		if($this->checkViewPermission())
		{			
			$ta_id = $this->uri->segment(4);
			$this->data['taskassign_edit'] = $this->taskassign_model->editTaskAssign($ta_id);
			$user_role_id = $this->data['session'][0]->user_role_id;					
			$this->data['role_res'] = $this->taskassign_model->getRoleByLoginRole($user_role_id);
			$this->data['task_res'] = $this->taskassign_model->getAllTask();
			$this->show_view_admin('admin/task/taskAssignApprovedView', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }

    /* Add and Update */
	public function addTaskAssign()
	{
		$ta_id = $this->uri->segment(4);
		if($ta_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$this->form_validation->set_rules($this->validation_rules['taskAssignUpdate']);
					if($this->form_validation->run())
					{
						$post['ta_id'] = $ta_id;						
						$post['task_id'] = $this->input->post('task_id');
						$post['ta_task_start_date'] = $this->input->post('ta_task_start_date');
						$post['ta_task_end_date'] = $this->input->post('ta_task_end_date');
						$post['ta_total_task'] = $this->input->post('ta_total_task');
						$post['ta_low_case_area_task'] = $this->input->post('ta_low_case_area_task');
						$post['ta_high_case_area_task'] = $this->input->post('ta_high_case_area_task');
						$post['ta_status'] = $this->input->post('ta_status');
						$post['user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$post['user_id'];
						$post['ta_remaining_task'] = $this->input->post('ta_total_task');
						$post['ta_updated_date'] = date('Y-m-d');
						$this->taskassign_model->updateTaskAssign($post);

						$msg = 'Task update successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/taskAssign');
					}
					else
					{
						$this->data['taskassign_edit'] = $this->taskassign_model->editTaskAssign($ta_id);
						$user_role_id = $this->data['session'][0]->user_role_id;					
						$this->data['role_res'] = $this->taskassign_model->getRoleByLoginRole($user_role_id);
						$this->data['task_res'] = $this->taskassign_model->getAllTask();
						$this->show_view_admin('admin/task/taskAssign_update', $this->data);
					}
				}
				else
				{
					$this->data['taskassign_edit'] = $this->taskassign_model->editTaskAssign($ta_id);
					$user_role_id = $this->data['session'][0]->user_role_id;					
					$this->data['role_res'] = $this->taskassign_model->getRoleByLoginRole($user_role_id);
					$this->data['task_res'] = $this->taskassign_model->getAllTask();
					$this->show_view_admin('admin/task/taskAssign_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$this->form_validation->set_rules($this->validation_rules['taskAssignAdd']);
					if($this->form_validation->run())
					{
						$post['ta_let'] = $this->data['lat'];
						$post['ta_long'] = $this->data['lon'];
						$ta_assign_to_user = $this->input->post('ta_assign_to');
						$post['ta_assign_to_role_id'] = $this->input->post('ta_assign_to_role_id');
						$post['ta_assign_to'] = $this->input->post('ta_assign_to');
						$post['ta_assign_by'] =  $this->data['session'][0]->user_id;
						$post['task_id'] = $this->input->post('task_id');
						$task_form_res = $this->taskassign_model->getTaskFormByTaskID($post['task_id']);
						$post['taskform_id'] = $task_form_res[0]->taskform_id;
						$post['ta_task_start_date'] = $this->input->post('ta_task_start_date');
						$post['ta_task_end_date'] = $this->input->post('ta_task_end_date');
						$post['ta_low_case_area_task'] = $this->input->post('ta_low_case_area_task');
						$post['ta_high_case_area_task'] = $this->input->post('ta_high_case_area_task');
						$post['ta_total_task'] = $this->input->post('ta_total_task');
						$post['ta_remaining_task'] = $this->input->post('ta_total_task');
						$post['ta_status'] = $this->input->post('ta_status');
						$post['user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$post['user_id'];
						$user_level_res = $this->taskassign_model->getUserLevel($post['ta_assign_to']);
						$post['user_all_level_assign_to'] = $user_level_res[0]->user_all_level.','.$post['ta_assign_to'];
						$post['ta_created_date'] = date('Y-m-d');
						$post['ta_updated_date'] = date('Y-m-d');
						$ta_id =  $this->taskassign_model->addTaskAssign($post);
						
						$post_t['task_id'] = $post['task_id'];
						$post_t['taskform_id'] = $task_form_res[0]->taskform_id;
						$post_t['ttc_asign_user_id'] = $post['ta_assign_to'];
						$post_t['ta_id'] = $ta_id;
						$post_t['ttc_total_target'] = $post['ta_total_task'];
						$post_t['ttc_hca_total_target'] = $post['ta_high_case_area_task'];
						$post_t['ttc_lca_total_target'] = $post['ta_low_case_area_task'];
						$old_task_res = $this->taskassign_model->getTaskTargetCountByAssignUserId($ta_assign_to_user, $post_t['taskform_id']);

						if(!empty($old_task_res))
						{
							$post_t['ttc_r_target'] = $old_task_res[0]->ttc_r_target + $post_t['ttc_total_target'];
							$post_t['ttc_r_hca_target'] = $old_task_res[0]->ttc_r_hca_target + $post_t['ttc_hca_total_target'];
							$post_t['ttc_r_lca_target'] = $old_task_res[0]->ttc_r_lca_target + $post_t['ttc_lca_total_target'];
							$post_t['ttc_o_total'] = $old_task_res[0]->ttc_o_total;
							$post_t['ttc_o_lca_target'] = $old_task_res[0]->ttc_o_lca_target;
							$post_t['ttc_o_hca_target'] = $old_task_res[0]->ttc_o_hca_target;
						}
						else
						{
							$post_t['ttc_r_target'] = $post_t['ttc_total_target'];
							$post_t['ttc_r_hca_target'] = $post_t['ttc_hca_total_target'];
							$post_t['ttc_r_lca_target'] = $post_t['ttc_lca_total_target'];
						}
						$this->taskassign_model->addTaskTarget($post_t);
						if($ta_id)
						{
							$msg = 'Task Assign added successfully!!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/taskAssign');
						}
						else
						{
							$msg = 'Whoops, looks like something went wrong!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/taskAssign/addTaskAssign');
						}
					}
					else
					{
						$user_role_id = $this->data['session'][0]->user_role_id;					
						$this->data['role_res'] = $this->taskassign_model->getRoleByLoginRole($user_role_id);
						$this->data['task_res'] = $this->taskassign_model->getAllTask();
						$this->show_view_admin('admin/task/taskAssign_add', $this->data);
					}		
				}
				else
				{	
					$user_role_id = $this->data['session'][0]->user_role_id;					
					$this->data['role_res'] = $this->taskassign_model->getRoleByLoginRole($user_role_id);
					$this->data['task_res'] = $this->taskassign_model->getAllTask();
					$this->show_view_admin('admin/task/taskAssign_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}

	
	/* Delete */
	public function delete_taskAssign()
	{
		if($this->checkDeletePermission())
		{
			$ta_id = $this->uri->segment(4);
			
			$this->taskassign_model->delete_taskAssign($ta_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/taskAssign'); 
			}
			else
			{
				$msg = 'Task assign remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/taskAssign');
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}
	
	public function getAllUserByRoleID()
	{
		$role_id = $this->input->post('role_id');
		$user_id = $this->input->post('user_id');
		$user_list = $this->taskassign_model->getAllUserByRoleID($role_id);

		$html = '';
		if(count($user_list) > 0)
		{
			foreach ($user_list as $u_list) 
			{
				$u_all_level = explode(',', $u_list->user_all_level);
				if(in_array($user_id, $u_all_level))
				{
					$html .= '<option value="'.$u_list->user_id.'">'.$u_list->user_name.'</option>';
				}
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}

	public function getTaskDetailsByTaskID()
	{
		$task_id = $this->input->post('task_id');
		$task_details = $this->taskassign_model->getTaskDetailsByTaskID($task_id);

		$html = '';
		if(count($task_details) > 0)
		{
			foreach ($task_details as $t_list) 
			{
				$html .= $t_list->task_type.','.$t_list->taskform_name;
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}

	/***************** Send task report ****************/
	public function sendTaskReport()
	{
		$ta_id = $this->uri->segment(4);
		$task_id = $this->uri->segment(5);
		$task_form_details = $this->taskassign_model->getTaskFormDetail($task_id);
		if(!empty($task_form_details))
		{
			if($task_form_details[0]->taskform_name == 'Community awareness activity')
			{
				$this->data['ta_id'] = $ta_id;
				$this->data['task_id'] = $task_id;
				$this->data['send_report_res'] = $this->taskassign_model->getAllSendReport($ta_id);
				$this->show_view_admin('admin/task/taskAssignSendReportDetails', $this->data);
			}
			elseif($task_form_details[0]->taskform_name == 'Community stakeholder meeting')
			{
				redirect(base_url().'admin/stakeHolderMeeting');
			}
		}
	}

	public function sendTaskReportView()
	{
		$ta_id = $this->uri->segment(4);
		$task_id = $this->uri->segment(5);
		$tca_id = $this->uri->segment(6);
		$this->data['taskassignreport_edit'] = $this->taskassign_model->editTaskAssignReport($tca_id);
		$this->data['taskassignreport_edit_img'] = $this->taskassign_model->editTaskAssignReportImg($tca_id);
		$this->data['ta_id'] = $ta_id;
		$this->data['task_id'] = $task_id;
		$this->data['stakeholder_list'] = $this->taskassign_model->getAllStakeholder();
		$this->data['helthpost_area_list'] = $this->taskassign_model->getAllHelthPostArea();
		$this->show_view_admin('admin/task/sendTaskReportView', $this->data);
	}

	public function addTaskAssignedReport()
	{
		$ta_id = $this->uri->segment(4);
		$task_id = $this->uri->segment(5);
		$tca_id = $this->uri->segment(6);
		if($tca_id)
		{
			if (isset($_POST['Submit']) && $_POST['Submit'] == "EditReport") 
			{
				$post['tca_id'] = $tca_id;
				$post['ta_id'] = $ta_id;
				$post['task_id'] = $task_id;
				$post['tca_activity_place'] = $this->input->post('tca_activity_place');
				$post['tca_activity_subarea'] = $this->input->post('tca_activity_subarea');
				$post['tca_activity_date'] = $this->input->post('tca_activity_date');
				$post['tca_activity_start_time'] = $this->input->post('tca_activity_start_time');
				$post['tca_activity_end_time'] = $this->input->post('tca_activity_end_time');
				$tca_type_of_community_activity = $this->input->post('tca_type_of_community_activity');
				if($tca_type_of_community_activity)
				{
					$a = '';
					for ($i=0; $i < count($tca_type_of_community_activity) ; $i++) 
					{ 
						if($i==0)
						{
							if($tca_type_of_community_activity[$i] == 'Other')
							{
								$post['tca_type_of_community_activity_other'] = $this->input->post('tca_type_of_community_activity_other');
								$a = $tca_type_of_community_activity[$i];
							}
							else
							{
								$a = $tca_type_of_community_activity[$i];
							}
						}
						else
						{
							if($tca_type_of_community_activity[$i] == 'Other')
							{
								$post['tca_type_of_community_activity_other'] = $this->input->post('tca_type_of_community_activity_other');
								$a = $a.','.$tca_type_of_community_activity[$i];
							}
							else
							{
								$a = $a.','.$tca_type_of_community_activity[$i];
							}
						}
					}
				}
				$post['tca_type_of_community_activity'] = $a;
				$post['tca_focus_population'] = $this->input->post('tca_focus_population');
				$post['tca_name_of_stakeholder'] = $this->input->post('tca_name_of_stakeholder');
				$post['tca_area'] = $this->input->post('tca_area');
				$post['helthpostarea_id'] = $this->input->post('helthpostarea_id');
				$post['tca_total_no_attendess'] = $this->input->post('tca_total_no_attendess');
				$post['tca_no_of_presumptive_tb_case'] = $this->input->post('tca_no_of_presumptive_tb_case');
				$tca_covered_topics = $this->input->post('tca_covered_topics');
				if($tca_covered_topics)
				{
					$b = '';
					for ($j=0; $j < count($tca_covered_topics) ; $j++) 
					{ 
						if($j==0)
						{
							$b = $tca_covered_topics[$j];
						}
						else
						{
							$b = $b.'/'.$tca_covered_topics[$j];
						}
					}
				}
				$post['tca_covered_topics'] = $b;
				$post['user_id'] = $this->data['session'][0]->user_id;
				$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$post['user_id'];
				$post['tca_updated_date'] = date('Y-m-d');
				$this->taskassign_model->updateTaskAssignReport($post);

				if($_FILES["tca_img_name"]['name'])
				{
					$tca_img_name_arr = $_FILES["tca_img_name"]["name"];
                    for($i = 0; $i < count($tca_img_name_arr); $i++)
 					{	
        				$_FILES['new_file']['name'] = $_FILES['tca_img_name']['name'][$i];
        				$_FILES['new_file']['type'] = $_FILES['tca_img_name']['type'][$i];
		                $_FILES['new_file']['tmp_name'] = $_FILES['tca_img_name']['tmp_name'][$i];
		                $_FILES['new_file']['error'] = $_FILES['tca_img_name']['error'][$i];
		                $_FILES['new_file']['size'] = $_FILES['tca_img_name']['size'][$i];
                      
                      	$name = 'tca_img_name';
                      	$imagePath = 'webroot/admin/upload/task/CommunityAwareness/';
                       	$temp = explode(".",$_FILES['new_file']['name']);
						$extension = end($temp);
						$filenew =  date('d-M-Y').'_'.str_replace($_FILES['new_file']['name'],$name,$_FILES['new_file']['name']).'_'.time().''.rand(). "." .$extension;  		
						$config['file_name'] = $filenew;
						$config['upload_path'] = $imagePath;
						$config['allowed_types'] = 'GIF | gif | JPE | jpe | JPEG | jpeg | JPG | jpg | PNG | png';
						$this->upload->initialize($config);
						$this->upload->set_allowed_types('*');
						$this->upload->set_filename($config['upload_path'],$filenew);
						
						if(!$this->upload->do_upload('new_file'))
						{
							$data = array('msg' => $this->upload->display_errors());
						}
						else 
						{ 
							$data = $this->upload->data();	
							$imageName = $data['file_name'];
						}	

						if($imageName)
                      	{
		                   	$post_img['tca_img_name'] = $imagePath.''.$imageName;
							$post_img['tca_id'] =  $tca_id;
							$post_img['tca_img_status'] = '1';
							$post_img['tca_img_created_date'] = date('Y-m-d');
							$post_img['tca_img_updated_date'] = date('Y-m-d');
							$this->taskassign_model->addTaskAssignedReportImg($post_img);
                      	}
					}
				}

				$msg = 'Task assign report update successfully!!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/taskAssign/sendTaskReport/'.$ta_id.'/'.$task_id);
			}
			else
			{
				$this->data['taskassignreport_edit'] = $this->taskassign_model->editTaskAssignReport($tca_id);
				$this->data['taskassignreport_edit_img'] = $this->taskassign_model->editTaskAssignReportImg($tca_id);
				$this->data['ta_id'] = $ta_id;
				$this->data['task_id'] = $task_id;
				$this->data['stakeholder_list'] = $this->taskassign_model->getAllStakeholder();
				$this->data['helthpost_area_list'] = $this->taskassign_model->getAllHelthPostArea();
				$this->show_view_admin('admin/task/taskAssignSendReportDetails_update', $this->data);
			}
		}
		else
		{
			if (isset($_POST['Submit']) && $_POST['Submit'] == "AddReport") 
			{
				$post['tca_let'] = $this->data['lat'];
				$post['tca_long'] = $this->data['lon'];
				$post['ta_id'] = $ta_id;
				$post['task_id'] = $task_id;
				$post['tca_activity_place'] = $this->input->post('tca_activity_place');
				$post['tca_activity_subarea'] = $this->input->post('tca_activity_subarea');
				$post['tca_activity_date'] = $this->input->post('tca_activity_date');
				$post['tca_activity_start_time'] = $this->input->post('tca_activity_start_time');
				$post['tca_activity_end_time'] = $this->input->post('tca_activity_end_time');
				$tca_type_of_community_activity = $this->input->post('tca_type_of_community_activity');
				if($tca_type_of_community_activity)
				{
					$a = '';
					for ($i=0; $i < count($tca_type_of_community_activity) ; $i++) 
					{ 
						if($i==0)
						{
							if($tca_type_of_community_activity[$i] == 'Other')
							{
								$post['tca_type_of_community_activity_other'] = $this->input->post('tca_type_of_community_activity_other');
								$a = $tca_type_of_community_activity[$i];
							}
							else
							{
								$a = $tca_type_of_community_activity[$i];
							}
						}
						else
						{
							if($tca_type_of_community_activity[$i] == 'Other')
							{
								$post['tca_type_of_community_activity_other'] = $this->input->post('tca_type_of_community_activity_other');
								$a = $a.','.$tca_type_of_community_activity[$i];
							}
							else
							{
								$a = $a.','.$tca_type_of_community_activity[$i];
							}
						}
					}
				}
				$post['tca_type_of_community_activity'] = $a;
				$post['tca_focus_population'] = $this->input->post('tca_focus_population');
				$post['tca_name_of_stakeholder'] = $this->input->post('tca_name_of_stakeholder');
				$post['tca_area'] = $this->input->post('tca_area');
				$post['helthpostarea_id'] = $this->input->post('helthpostarea_id');
				$post['tca_total_no_attendess'] = $this->input->post('tca_total_no_attendess');
				$post['tca_no_of_presumptive_tb_case'] = $this->input->post('tca_no_of_presumptive_tb_case');
				$tca_covered_topics = $this->input->post('tca_covered_topics');
				if($tca_covered_topics)
				{
					$b = '';
					for ($j=0; $j < count($tca_covered_topics) ; $j++) 
					{ 
						if($j==0)
						{
							$b = $tca_covered_topics[$j];
						}
						else
						{
							$b = $b.'/'.$tca_covered_topics[$j];
						}
					}
				}
				$post['tca_covered_topics'] = $b;				
				$post['user_id'] = $this->data['session'][0]->user_id;
				$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$post['user_id'];
				$post['tca_created_date'] = date('Y-m-d');
				$post['tca_updated_date'] = date('Y-m-d');
				$tca_id =  $this->taskassign_model->addTaskAssignedReport($post);

				if($_FILES["tca_img_name"]['name'])
				{
					$tca_img_name_arr = $_FILES["tca_img_name"]["name"];
                    for($i = 0; $i < count($tca_img_name_arr); $i++)
 					{	
        				$_FILES['new_file']['name'] = $_FILES['tca_img_name']['name'][$i];
        				$_FILES['new_file']['type'] = $_FILES['tca_img_name']['type'][$i];
		                $_FILES['new_file']['tmp_name'] = $_FILES['tca_img_name']['tmp_name'][$i];
		                $_FILES['new_file']['error'] = $_FILES['tca_img_name']['error'][$i];
		                $_FILES['new_file']['size'] = $_FILES['tca_img_name']['size'][$i];
                      
                      	$name = 'tca_img_name';
                      	$imagePath = 'webroot/admin/upload/task/CommunityAwareness/';
                       	$temp = explode(".",$_FILES['new_file']['name']);
						$extension = end($temp);
						$filenew =  date('d-M-Y').'_'.str_replace($_FILES['new_file']['name'],$name,$_FILES['new_file']['name']).'_'.time().''.rand(). "." .$extension;  		
						$config['file_name'] = $filenew;
						$config['upload_path'] = $imagePath;
						$config['allowed_types'] = 'GIF | gif | JPE | jpe | JPEG | jpeg | JPG | jpg | PNG | png';
						$this->upload->initialize($config);
						$this->upload->set_allowed_types('*');
						$this->upload->set_filename($config['upload_path'],$filenew);
						
						if(!$this->upload->do_upload('new_file'))
						{
							$data = array('msg' => $this->upload->display_errors());
						}
						else 
						{ 
							$data = $this->upload->data();	
							$imageName = $data['file_name'];
						}	

						if($imageName)
                      	{
		                   	$post_img['tca_img_name'] = $imagePath.''.$imageName;
							$post_img['tca_id'] =  $tca_id;
							$post_img['tca_img_status'] = '1';
							$post_img['tca_img_created_date'] = date('Y-m-d');
							$post_img['tca_img_updated_date'] = date('Y-m-d');
							$this->taskassign_model->addTaskAssignedReportImg($post_img);
                      	}
					}
				}	
				if($tca_id)
				{
					$target_count_val = $this->taskassign_model->getTaskTargetCount($ta_id);
					if(!empty($target_count_val))
					{

						$post_tc['tca_area'] = $post['tca_area'];
						$post_tc['ta_id'] = $ta_id;
						if($target_count_val[0]->ttc_r_target != 0)
						{
							$post_tc['ttc_r_target'] = $target_count_val[0]->ttc_r_target - 1;
						}
						else
						{
							$post_tc['ttc_r_target'] = '0';
						}
						
						if($post_tc['tca_area'] == 'Low case burden area')
						{
							if($target_count_val[0]->ttc_r_target != 0)
							{
								$post_tc['ttc_r_lca_target'] = $target_count_val[0]->ttc_r_lca_target - 1;
							}
							else
							{
								$post_tc['ttc_r_lca_target'] = '0';
							}
							
						}
						else
						{
							if($target_count_val[0]->ttc_r_target != 0)
							{
								$post_tc['ttc_r_hca_target'] = $target_count_val[0]->ttc_r_hca_target - 1;
							}
							else
							{
								$post_tc['ttc_r_hca_target'] = '0';
							}
						}
						$this->taskassign_model->updateTaskTargetCount($post_tc);

						$taskassign_edit = $this->taskassign_model->editTaskAssign($ta_id);
						if(!empty($taskassign_edit))
						{
							if($taskassign_edit[0]->ta_remaining_task != 0)
							{
								$post_t_a_tc['ta_remaining_task'] = $taskassign_edit[0]->ta_remaining_task - 1;
								$post_t_a_tc['ta_id'] = $ta_id;
								$this->taskassign_model->updateTaskAssignTargetCount($post_t_a_tc);
							}
 						}

					}
					$msg = 'Task Assign Report added successfully!!';					
					$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
					redirect(base_url().'admin/taskAssign/sendTaskReport/'.$ta_id.'/'.$task_id);
				}
				else
				{
					$msg = 'Whoops, looks like something went wrong!';					
					$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
					redirect(base_url().'admin/taskAssign/addTaskAssignedReport/'.$tca_id.'/'.$ta_id.'/'.$task_id);
				}	
			}
			else
			{	
				$this->data['ta_id'] = $ta_id;
				$this->data['task_id'] = $task_id;
				$this->data['stakeholder_list'] = $this->taskassign_model->getAllStakeholder();
				$this->data['helthpost_area_list'] = $this->taskassign_model->getAllHelthPostArea();
				$this->show_view_admin('admin/task/taskAssignSendReportDetails_add', $this->data);
			}
		}
	}

	/* Delete */
	public function delete_taskASsignedSendReport()
	{
		$ta_id = $this->uri->segment(4);
		$task_id = $this->uri->segment(5);
		$tca_id = $this->uri->segment(6);
		
		$this->taskassign_model->delete_taskASsignedSendReport($tca_id);
		if ($this->db->_error_number() == 1451)
		{		
			$msg = 'You need to delete child category first';
			$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
			redirect(base_url().'admin/taskAssign/sendTaskReport/'.$ta_id.'/'.$task_id);
		}
		else
		{
			$msg = 'Task assign remove successfully...!';					
			$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
			redirect(base_url().'admin/taskAssign/sendTaskReport/'.$ta_id.'/'.$task_id);
		}	
	}

/*---------------AMIT CODE START------------------*/
	public function get_assignTask()
	{ 
	    $sakshamid = $this->uri->segment(4);
		$user_id = $this->data['session'][0]->user_id;
		
		if($sakshamid){
		$a = array();$b = array();$c = array();$d = array();
		//$getTaskAssignTo = $this->taskassign_model->getTaskAssignTo($user_id);		
		$get_reminder = $this->taskassign_model->get_reminder($sakshamid);
		//$get_meetings = $this->taskassign_model->get_meetings($user_id);
		$get_followup = $this->taskassign_model->get_followup($sakshamid);
		}//if($sakshamid)
		
		else{
		$a = array();$b = array();$c = array();$d = array();
		//$getTaskAssignTo = $this->taskassign_model->getTaskAssignTo($user_id);		
		$get_reminder = $this->taskassign_model->get_reminder($user_id);
		//$get_meetings = $this->taskassign_model->get_meetings($user_id);
		$get_followup = $this->taskassign_model->get_followup($user_id);
			}//else
		//foreach($getTaskAssignTo as $arr)
//		{
//			$a[] = array('start'=>$arr->ta_task_start_date,'end'=>$arr->ta_task_end_date,'editable'=>false,'title'=>$arr->task_name,"color"=>'#32127A',"textColor"=>'#fff','description'=>$arr->task_description);
//		}
			
		foreach($get_reminder as $arr)
		{
			$b[] = array('id'=>$arr->reminder_id,'start'=>$arr->reminder_start_date,'end'=>$arr->reminder_end_date,
			'editable'=>true,'title'=>$arr->reminder_time .' - '. $arr->reminder_title,"color"=>'red',"textColor"=>'#fff','description'=>$arr->reminder_title);
		}

		//foreach($get_meetings as $arr){
//			$c[] = array('start'=>$arr->shm_meeting_date,'end'=>$arr->shm_meeting_date,'editable'=>false,'title'=>'Meeting',"color"=>'green',"textColor"=>'#fff','description'=>'Location:'.$arr->shm_meting_location);
//		}

		foreach($get_followup as $arr){
			$d[] = array('start'=>$arr->pfud_date,'end'=>$arr->pfud_date,'editable'=>false,'title'=>'Followup',"color"=>'green',"textColor"=>'#fff','description'=>'Patient:'.$arr->patient_name);
		}
	  	echo json_encode(array_merge($b,$d));
	}
	
	public function add_reminder()
	{
		$post['reminder_time'] = $this->input->post('time');
		$post['reminder_title'] = $this->input->post('title');
		$post['reminder_start_date'] = $this->input->post('start');
		$post['reminder_end_date']   = $this->input->post('end');
		$post['user_id']   = $this->data['session'][0]->user_id;	
		$post['user_all_level']   = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;	
		$result = $this->taskassign_model->add_reminder($post);
	}
	
	public function update_reminder()
	{
		$post['reminder_start_date']  = $this->input->post('start');
		$post['reminder_end_date']   = $this->input->post('end');
		$post['reminder_id']     = $this->input->post('id');	
		$result = $this->taskassign_model->update_reminder($post);
	}

	public function delete_reminder()
	{
	    $reminder_id     = $this->input->post('id');
	    $this->taskassign_model->delete_reminder($reminder_id);
	}
	/*---------------AMIT CODE END------------------*/	
}

/* End of file */?>