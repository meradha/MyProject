<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Task extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/task_model');
	}
	
	/*	Validation Rules */
	 protected $validation_rules = array
        (
        'taskAdd' => array(
            array(
                'field' => 'taskform_id',
                'label' => 'task form',
                'rules' => 'trim|required'
            ),
			array(
                'field' => 'task_type',
                'label' => 'task type',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'task_name',
                'label' => 'task name',
                'rules' => 'trim|required'
            ),
            array(  
				'field' => 'task_description',
				'label' => 'task description', 
				'rules' => 'trim|required'
            )
        ),
		'taskUpdate' => array(
        	array(
                'field' => 'taskform_id',
                'label' => 'task form',
                'rules' => 'trim|required'
            ),
			array(
                'field' => 'task_type',
                'label' => 'task type',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'task_name',
                'label' => 'task name',
                'rules' => 'trim|required'
            ),
            array(  
				'field' => 'task_description',
				'label' => 'task description', 
				'rules' => 'trim|required'
            )  
        )
    );
	
	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{			
			$user_id = $this->data['session'][0]->user_id;
			$this->data['task_res'] = $this->task_model->getTask($user_id);	
			$this->show_view_admin('admin/task/task', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addTask()
	{
		$task_id = $this->uri->segment(4);
		if($task_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$this->form_validation->set_rules($this->validation_rules['taskUpdate']);
					if($this->form_validation->run())
					{
						$post['task_id'] = $task_id;
						$post['taskform_id'] = $this->input->post('taskform_id');
						$post['task_type'] = $this->input->post('task_type');
						$post['task_name'] = $this->input->post('task_name');
						$post['task_description'] = $this->input->post('task_description');
						$post['task_status'] = $this->input->post('task_status');
						$post['user_id'] =  $this->data['session'][0]->user_id;	
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$post['user_id'];
						$post['task_updated_date'] = date('Y-m-d');
						$this->task_model->updateTask($post);

						$msg = 'Task update successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/task');
					}
					else
					{
						$this->data['task_edit'] = $this->task_model->editTask($task_id);
						$this->data['taskform_res'] = $this->task_model->getTaskForm();
						$this->show_view_admin('admin/task/task_update', $this->data);
					}
				}
				else
				{
					$this->data['task_edit'] = $this->task_model->editTask($task_id);
					$this->data['taskform_res'] = $this->task_model->getTaskForm();
					$this->show_view_admin('admin/task/task_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$this->form_validation->set_rules($this->validation_rules['taskAdd']);
					if($this->form_validation->run())
					{
						$post['taskform_id'] = $this->input->post('taskform_id');
						$post['task_type'] = $this->input->post('task_type');
						$post['task_name'] = $this->input->post('task_name');
						$post['task_description'] = $this->input->post('task_description');
						$post['task_status'] = $this->input->post('task_status');
						$post['user_id'] =  $this->data['session'][0]->user_id;	
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$post['user_id'];
						$post['task_created_date'] = date('Y-m-d');
						$post['task_updated_date'] = date('Y-m-d');
						$task_id =  $this->task_model->addTask($post);
						if($task_id)
						{
							$msg = 'Task added successfully!!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/task');
						}
						else
						{
							$msg = 'Whoops, looks like something went wrong!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/task/addTask');
						}
					}
					else
					{
						$this->data['taskform_res'] = $this->task_model->getTaskForm();
						$this->show_view_admin('admin/task/task_add', $this->data);
					}		
				}
				else
				{						
					$this->data['taskform_res'] = $this->task_model->getTaskForm();
					$this->show_view_admin('admin/task/task_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}

	/* Delete */
	public function delete_task()
	{
		if($this->checkDeletePermission())
		{
			$task_id = $this->uri->segment(4);
			
			$this->task_model->delete_task($task_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/task'); 
			}
			else
			{
				$msg = 'Task remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/task');
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}

	/* Get State List */
	public function getAllUserByRoleID()
	{
		$role_id = $this->input->post('role_id');
		$user_id = $this->input->post('user_id');
		$user_list = $this->task_model->getAllUserByRoleID($role_id);

		$html = '';
		if(count($user_list) > 0)
		{
			foreach ($user_list as $u_list) 
			{
				$u_all_level = explode(',', $u_list->user_all_level);
				if(in_array($user_id, $u_all_level))
				{
					$html .= '<option value="'.$u_list->user_id.'">'.$u_list->user_name.'</option>';
				}
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}

}

/* End of file */?>