<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class MonthlyReport extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/monthlyreport_model');
	}
	
	/* Dashboard Show */
	public function index()
	{	
		$user_role_id = $this->data['session'][0]->user_role_id;
		$user_all_level = $this->data['session'][0]->user_all_level;
		$user_id = $this->data['session'][0]->user_id;

		if(isset($_POST['submit']) && $_POST['submit']=='submit')
		{
      $year = date('Y');
      $month = $this->input->post('month');
      $start_date = $year.'-'.$month.'-01';
      $end_date = date('Y-m-t', strtotime(date("Y").'-'.$month)); 

      /****************Monthly stakeholder meeting summary****************/
      $mapped_stakeholder = $this->monthlyreport_model->getTotalStakeHolderMapped($start_date, $end_date);
      $a=0;
      foreach ($mapped_stakeholder as $ms_res) 
      {
        $ms_levl_arr = explode(',', $ms_res->user_all_level);
        if(in_array($user_id, $ms_levl_arr))
        {
          $a++;
        }
      }
      $this->data['mapped_stakeholder'] = $a;
      $stakeholder_responsive = $this->monthlyreport_model->getTotalStakeHolderResponsive($start_date, $end_date);
      $b=0;
      foreach ($stakeholder_responsive as $sr_res) 
      {
        $sr_level_arr = explode(',', $sr_res->user_all_level);
        if(in_array($user_id, $sr_level_arr))
        {
          $b++;
        }
      }
      $this->data['stakeholder_responsive'] = $b;
      $stakeholder_un_responsive = $this->monthlyreport_model->getTotalStakeHolderUnResponsive($start_date, $end_date);
      $c = 0;
      foreach ($stakeholder_un_responsive as $sur_res) 
      {
        $sur_level_arr = explode(',', $sur_res->user_all_level);
        if(in_array($user_id, $sur_level_arr))
        {
          $c++;
        }
      }
      $this->data['stakeholder_un_responsive'] = $c;

      $stakeholder_meeting = $this->monthlyreport_model->getTotalStakeHolderMeetingInThisMonth($start_date, $end_date);
       $d = 0;
      foreach ($stakeholder_meeting as $sm_res) 
      {
        $sm_level_arr = explode(',', $sm_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $d++;
        }
      }
      $this->data['stakeholder_meetings'] = $d;



      
      $this->data['month'] = $month;  
			$this->show_view_admin('admin/monthlyReport', $this->data);
		}
		else
		{
			$year = date('Y');
			$month = date('m');
			$start_date = $year.'-'.$month.'-01';
      $end_date = date('Y-m-t', strtotime(date("Y").'-'.$month)); 

      /****************Monthly stakeholder meeting summary****************/
      $mapped_stakeholder = $this->monthlyreport_model->getTotalStakeHolderMapped($start_date, $end_date);
      $a=0;
      foreach ($mapped_stakeholder as $ms_res) 
      {
        $ms_levl_arr = explode(',', $ms_res->user_all_level);
        if(in_array($user_id, $ms_levl_arr))
        {
          $a++;
        }
      }
      $this->data['mapped_stakeholder'] = $a;
      $stakeholder_responsive = $this->monthlyreport_model->getTotalStakeHolderResponsive($start_date, $end_date);
      $b=0;
      foreach ($stakeholder_responsive as $sr_res) 
      {
        $sr_level_arr = explode(',', $sr_res->user_all_level);
        if(in_array($user_id, $sr_level_arr))
        {
          $b++;
        }
      }
      $this->data['stakeholder_responsive'] = $b;
      $stakeholder_un_responsive = $this->monthlyreport_model->getTotalStakeHolderUnResponsive($start_date, $end_date);
      $c = 0;
      foreach ($stakeholder_un_responsive as $sur_res) 
      {
        $sur_level_arr = explode(',', $sur_res->user_all_level);
        if(in_array($user_id, $sur_level_arr))
        {
          $c++;
        }
      }
      $this->data['stakeholder_un_responsive'] = $c;
      
      $stakeholder_meeting = $this->monthlyreport_model->getTotalStakeHolderMeetingInThisMonth($start_date, $end_date);
       $d = 0;
      foreach ($stakeholder_meeting as $sm_res) 
      {
        $sm_level_arr = explode(',', $sm_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $d++;
        }
      }
      $this->data['stakeholder_meetings'] = $d;


      /*********************************/
      $mth = date('Y-m-d');
      $previ_month = Date("m", strtotime($mth." last month"));
      $previous_month_start_date = $year.'-'.$previ_month.'-01';
      $previous_month_end_date = date('Y-m-t', strtotime(date("Y").'-'.$previ_month)); 

      $stakeholder_meeting_prev = $this->monthlyreport_model->getTotalStakeHolderMeetingInThisMonth($previous_month_start_date, $previous_month_end_date);
       $e = 0;
      foreach ($stakeholder_meeting_prev as $sm_res_prev) 
      {
        $sm_level_arr = explode(',', $sm_res_prev->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $e++;
        }
      }
      $this->data['stakeholder_meetings_prev'] = $e;


      $community_events = $this->monthlyreport_model->getTotalCommunityMeetingEvents($start_date, $end_date);
       $f = 0;
      foreach ($community_events as $cm_res) 
      {
        $sm_level_arr = explode(',', $cm_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $f++;
        }
      }
      $this->data['community_events'] = $f;


      $community_events_low_case = $this->monthlyreport_model->getTotalCommunityMeetingEventsLowCase($start_date, $end_date);
       $g = 0;
      foreach ($community_events_low_case as $cm_lc_res) 
      {
        $sm_level_arr = explode(',', $cm_lc_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $g++;
        }
      }
      $this->data['community_events_low_case'] = $g;


      $community_events_high_case = $this->monthlyreport_model->getTotalCommunityMeetingEventsHighCase($start_date, $end_date);
       $h = 0;
      foreach ($community_events_high_case as $cm_hc_res) 
      {
        $sm_level_arr = explode(',', $cm_hc_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $h++;
        }
      }
      $this->data['community_events_high_case'] = $h;

      $self_referral = $this->monthlyreport_model->getTotalSelfReferral($start_date, $end_date);
       $i = 0;
      foreach ($self_referral as $selr_refer_res) 
      {
        $sm_level_arr = explode(',', $selr_refer_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $i++;
        }
      }
      $this->data['self_referral'] = $i;

    
      $community_referral = $this->monthlyreport_model->getTotalCommunityReferral($start_date, $end_date);
       $j = 0;
      foreach ($community_referral as $comm_refer_res) 
      {
        $sm_level_arr = explode(',', $comm_refer_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $j++;
        }
      }
      $this->data['community_referral'] = $j;

      $cat1_cat2_patient_positive = $this->monthlyreport_model->getTotalCAT1CAR2($start_date, $end_date);
       $k = 0;
      foreach ($cat1_cat2_patient_positive as $cat1_cat2_res) 
      {
        $sm_level_arr = explode(',', $cat1_cat2_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $k++;
        }
      }
      $this->data['cat1_cat2_patient_positive'] = $k;

      $cat1_cat2_patient_counselling_service = $this->monthlyreport_model->getTotalCAT1CAR2CounsellingService($start_date, $end_date);
      $l = 0;
      foreach ($cat1_cat2_patient_counselling_service as $cat1_cat2_counselling_res) 
      {
        $sm_level_arr = explode(',', $cat1_cat2_counselling_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $l++;
        }
      }
      $this->data['cat1_cat2_patient_counselling_service'] = $l;


      $total_caregivers = $this->monthlyreport_model->getTotalCaregivers($start_date, $end_date);
      $m = 0;
      foreach ($total_caregivers as $caregiver_res) 
      {
        $sm_level_arr = explode(',', $caregiver_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $m++;
        }
      }
      $this->data['total_caregivers'] = $m;

      $total_dr_tb_positive_patient = $this->monthlyreport_model->getTotalDRTBPositivePatient($start_date, $end_date);
      $n = 0;
      foreach ($total_dr_tb_positive_patient as $dr_tb_positive_res) 
      {
        $sm_level_arr = explode(',', $dr_tb_positive_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $n++;
        }
      }
      $this->data['total_dr_tb_positive_patient'] = $n;

      $total_dr_tb_link_to_counsellor = $this->monthlyreport_model->getTotalDRTBPositivePatientLinkToCounseller($start_date, $end_date);
      $o = 0;
      foreach ($total_dr_tb_link_to_counsellor as $dr_tb_link_to_counsellor) 
      {
        $sm_level_arr = explode(',', $dr_tb_link_to_counsellor->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $o++;
        }
      }
      $this->data['total_dr_tb_link_to_counsellor'] = $o;

      $total_follow_up = $this->monthlyreport_model->getTotalFollowUps($start_date, $end_date);
      $p = 0;
      foreach ($total_follow_up as $follow_up_res) 
      {
        $sm_level_arr = explode(',', $follow_up_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $p++;
        }
      }
      $this->data['total_follow_up'] = $p;


      $total_follow_up_iteruption = $this->monthlyreport_model->getTotalIteruptionOfPatient($start_date, $end_date);
      $q = 0;
      foreach ($total_follow_up_iteruption as $follow_up_res) 
      {
        $sm_level_arr = explode(',', $follow_up_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $q++;
        }
      }
      $this->data['total_follow_up_iteruption'] = $q;

    $total_follow_up_iteruption_lost = $this->monthlyreport_model->getTotalIteruptionOfPatientLost($start_date, $end_date);
      $r = 0;
      foreach ($total_follow_up_iteruption_lost as $follow_up_res) 
      {
        $sm_level_arr = explode(',', $follow_up_res->user_all_level);
        if(in_array($user_id, $sm_level_arr))
        {
          $r++;
        }
      }
      $this->data['total_follow_up_iteruption_lost'] = $r;









      $this->data['month'] = $month;     	
			$this->show_view_admin('admin/monthlyReport', $this->data);
		}
  }
    
}

/* End of file */?>