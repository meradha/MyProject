<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Dashboard extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/dashboard_model');
		$this->load->model('admin/taskassign_model');
	}
	
	/* Dashboard Show */
	public function index()
	{	
		$this->data['role_list'] = $this->dashboard_model->getAllRole();
		$this->data['stakeholder_list'] = $this->dashboard_model->getAllStakeHolder();
		$this->data['saksham_sathi_list'] = $this->dashboard_model->getAllSakshamSathi();
		$this->data['presumptive_patient_list'] = $this->dashboard_model->getAllPresumptivePatient();
		$this->data['patient_list'] = $this->dashboard_model->getAllPatient();
		$this->data['referral_linkages_list'] = $this->dashboard_model->getAllReferralLinkages();
		$this->data['lab_list'] = $this->dashboard_model->getAllLabs();
		$this->data['stakeholder_meeting_list'] = $this->dashboard_model->getAllStakeholderMeeting();
		$this->data['community_meeting_list'] = $this->dashboard_model->getAllCommunityMeeting();
		$this->show_view_admin('admin/dashboard', $this->data);
    }
    
	/* Dashboard Show */
	public function error()
	{	
		$value = $this->uri->segment(4);
		if($value == '1')
		{
			$this->show_view_admin('admin/error/error_permission', $this->data);
		}		
    }


}

/* End of file */?>