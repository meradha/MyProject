<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class UserLiveLoc extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/map_model');
		$this->load->model('admin/taskassign_model');
	}
	
	/* Show */
	public function index()
	{	
		$this->show_view_admin('admin/map/mapLiveLoc', $this->data);
    }
	/*-- AMIT CODE STRAT--*/
    public function getUserCurrentLoc(){
		$user_id = $this->input->post('user_id');
		$result = $this->map_model->getUserCurrentLoc($user_id);
		$a = array();
foreach($result as $loc){
	  if($loc['location_lat'] != '0' && $loc['location_lat'] != NULL && $loc['location_long'] != '0' && $loc['location_long'] != NULL){
	   $lat = floatval($loc['location_lat']);
	   $lng = floatval($loc['location_long']);
	   
	   $fromRegAddress = $this->getAddressFromLatLng($lat,$lng);
		if($fromRegAddress)
		$fromRegAddress = $fromRegAddress;
		else
		$fromRegAddress = 'No Address Found';
					
	   $a[] = array($lat,$lng,'<p><b>Name: </b>'.$loc['user_name'].'</p><p><b>Address:</b> '.$fromRegAddress.'</p><p><b>Time:</b> '.$loc['location_date_time'].'</p>',base_url('webroot/admin/upload/common_img/current-loc.png')); 
	    }
	  }
		echo(json_encode($a));
		}
}
/* End of file */?>