<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class DiagnosisCenter extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/diagnosiscenter_model');
	}
	
	/*	Validation Rules */
	 protected $validation_rules = array
        (
        'diagnosisAdd' => array(
            array(
                'field' => 'diagnosis_name',
                'label' => 'name',
                'rules' => 'trim|required'
            ),
			array(
                'field' => 'diagnosis_owner_name',
                'label' => 'owner name',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'diagnosis_email',
                'label' => 'email',
                'rules' => 'trim|required'
            ),
            array(  
				'field' => 'diagnosis_mobile',
				'label' => 'mobile', 
				'rules' => 'trim|required'
            ), 
            array(  
				'field' => 'diagnosis_address',
				'label' => 'address', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'diagnosis_city',
				'label' => 'city', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'diagnosis_state_id',
				'label' => 'state', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'diagnosis_country_id',
				'label' => 'country', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'diagnosis_postal_code',
				'label' => 'postal code', 
				'rules' => 'trim|required'
            )
        ),
		'diagnosisUpdate' => array(
        	array(
                'field' => 'diagnosis_name',
                'label' => 'name',
                'rules' => 'trim|required'
            ),
			array(
                'field' => 'diagnosis_owner_name',
                'label' => 'owner name',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'diagnosis_email',
                'label' => 'email',
                'rules' => 'trim|required'
            ),
            array(  
				'field' => 'diagnosis_mobile',
				'label' => 'mobile', 
				'rules' => 'trim|required'
            ), 
            array(  
				'field' => 'diagnosis_address',
				'label' => 'address', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'diagnosis_city',
				'label' => 'city', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'diagnosis_state_id',
				'label' => 'state', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'diagnosis_country_id',
				'label' => 'country', 
				'rules' => 'trim|required'
            ),
			array(  
				'field' => 'diagnosis_postal_code',
				'label' => 'postal code', 
				'rules' => 'trim|required'
            )    
        )
    );
	
	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{			
			$this->data['diagnosis_center_res'] = $this->diagnosiscenter_model->getDiagnosisCenter();
			$this->show_view_admin('admin/diagnosisCenter/diagnosisCenter', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }

    /* Details */
	public function diagnosisCenterView()
	{
		if($this->checkViewPermission())
		{	
			$diagnosis_id = $this->uri->segment(4);		
			$this->data['diagnosisCenter_edit'] = $this->diagnosiscenter_model->editDiagnosisCenter($diagnosis_id);
			$this->data['country_list'] = $this->diagnosiscenter_model->getAllCountry();
			$this->data['state_list'] = $this->diagnosiscenter_model->getAllState();
			$this->show_view_admin('admin/diagnosisCenter/diagnosisCenterView', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addDiagnosisCenter()
	{
		$diagnosis_id = $this->uri->segment(4);
		if($diagnosis_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$this->form_validation->set_rules($this->validation_rules['diagnosisUpdate']);
					if($this->form_validation->run())
					{
						$post['diagnosis_id'] = $diagnosis_id;
						$post['diagnosis_name'] = $this->input->post('diagnosis_name');
						$post['diagnosis_owner_name'] = $this->input->post('diagnosis_owner_name');
						$post['diagnosis_email'] = $this->input->post('diagnosis_email');
						$post['diagnosis_phone'] = $this->input->post('diagnosis_phone');
						$post['diagnosis_mobile'] = $this->input->post('diagnosis_mobile');
						$post['diagnosis_address'] = $this->input->post('diagnosis_address');
						$post['diagnosis_city'] = $this->input->post('diagnosis_city');
						$post['diagnosis_state_id'] = $this->input->post('diagnosis_state_id');
						$post['diagnosis_country_id'] = $this->input->post('diagnosis_country_id');
						$post['diagnosis_postal_code'] = $this->input->post('diagnosis_postal_code');
						$post['diagnosis_status'] = $this->input->post('diagnosis_status');
						$post['diagnosis_added_by'] = $this->data['session'][0]->user_id;
						$post['diagnosis_added_by_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['diagnosis_created_date'] = date('Y-m-d');
						$post['diagnosis_updated_date'] = date('Y-m-d');
						$this->diagnosiscenter_model->updateDiagnosisCenter($post);

						$msg = 'Diagnosis center update successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/diagnosisCenter');
					}
					else
					{
						$this->data['diagnosisCenter_edit'] = $this->diagnosiscenter_model->editDiagnosisCenter($diagnosis_id);
						$this->data['country_list'] = $this->diagnosiscenter_model->getAllCountry();
						$this->data['state_list'] = $this->diagnosiscenter_model->getAllState();
						$this->show_view_admin('admin/diagnosisCenter/diagnosisCenter_update', $this->data);
					}
				}
				else
				{
					$this->data['diagnosisCenter_edit'] = $this->diagnosiscenter_model->editDiagnosisCenter($diagnosis_id);
					$this->data['country_list'] = $this->diagnosiscenter_model->getAllCountry();
					$this->data['state_list'] = $this->diagnosiscenter_model->getAllState();
					$this->show_view_admin('admin/diagnosisCenter/diagnosisCenter_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$this->form_validation->set_rules($this->validation_rules['diagnosisAdd']);
					if($this->form_validation->run())
					{
						$post['diagnosis_name'] = $this->input->post('diagnosis_name');
						$post['diagnosis_owner_name'] = $this->input->post('diagnosis_owner_name');
						$post['diagnosis_email'] = $this->input->post('diagnosis_email');
						$post['diagnosis_phone'] = $this->input->post('diagnosis_phone');
						$post['diagnosis_mobile'] = $this->input->post('diagnosis_mobile');
						$post['diagnosis_address'] = $this->input->post('diagnosis_address');
						$post['diagnosis_city'] = $this->input->post('diagnosis_city');
						$post['diagnosis_state_id'] = $this->input->post('diagnosis_state_id');
						$post['diagnosis_country_id'] = $this->input->post('diagnosis_country_id');
						$post['diagnosis_postal_code'] = $this->input->post('diagnosis_postal_code');
						$post['diagnosis_status'] = $this->input->post('diagnosis_status');
						$post['diagnosis_added_by'] = $this->data['session'][0]->user_id;
						$post['diagnosis_added_by_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['diagnosis_created_date'] = date('Y-m-d');
						$post['diagnosis_updated_date'] = date('Y-m-d');

						$diagnosis_id =  $this->diagnosiscenter_model->addDiagnosisCenter($post);
						if($diagnosis_id)
						{
							$msg = 'Diagnosis center added successfully!!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/diagnosisCenter');
						}
						else
						{
							$msg = 'Whoops, looks like something went wrong!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/diagnosisCenter/addDiagnosisCenter');
						}
					}
					else
					{
						$this->data['country_list'] = $this->diagnosiscenter_model->getAllCountry();
						$this->show_view_admin('admin/diagnosisCenter/diagnosisCenter_add', $this->data);
					}		
				}
				else
				{	
					$this->data['country_list'] = $this->diagnosiscenter_model->getAllCountry();
					$this->show_view_admin('admin/diagnosisCenter/diagnosisCenter_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}
	
	/* Delete */
	public function delete_diagnosisCenter()
	{
		if($this->checkDeletePermission())
		{
			$diagnosis_id = $this->uri->segment(4);
			
			$this->diagnosiscenter_model->delete_diagnosisCenter($diagnosis_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/diagnosisCenter'); 
			}
			else
			{
				$msg = 'Diagnosis center remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/diagnosisCenter');
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}

	/* Get State List */
	public function getStateList()
	{
		$country_id = $this->input->post('country_id');
		$state_list = $this->diagnosiscenter_model->getStateListByCountryId($country_id);

		$html = '';
		if(count($state_list) > 0)
		{
			foreach ($state_list as $s_list) 
			{
				$html .= '<option value="'.$s_list->state_id.'">'.$s_list->state_name.'</option>';
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}

	/* Get State List by Country id */
	public function getStateListByCountryID()
	{
		$country_id = $this->input->post('country_id');
		$state_list = $this->diagnosiscenter_model->getStateListByCountryID($country_id);

		$html = '';
		$html .= '<option value=""></option>';
		if(!empty($state_list))
		{
			foreach ($state_list as $s_list) 
			{
				$html .= '<option value="'.$s_list->state_id.'">'.$s_list->state_name.'</option>';
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}
}

/* End of file */?>