<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class LabData extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/labdata_model');
	}
	
	/* Dashboard Show */
	public function index()
	{	
		$user_role_id = $this->data['session'][0]->user_role_id;
		$user_all_level = $this->data['session'][0]->user_all_level;
		$user_id = $this->data['session'][0]->user_id;

		if(isset($_POST['submit']) && $_POST['submit']=='submit')
		{
			$year = $this->input->post('year');
			$month = $this->input->post('month');
			$start_date = $year.'-'.$month.'-01';
			$end_date = date('Y-m-t', strtotime(date("Y").'-'.$month)); 

			$this->data['lab_list'] = $this->labdata_model->getAllLab();
			$this->data['month'] = $month;  
			$this->data['year'] = $year;   
			$this->show_view_admin('admin/labData', $this->data);
		}
		else
		{
			$year = date('Y');
			$month = date('m');
			$start_date = $year.'-'.$month.'-01';
			$end_date = date('Y-m-t', strtotime(date("Y").'-'.$month)); 

			$this->data['lab_list'] = $this->labdata_model->getAllLab();
			$this->data['month'] = $month;    
			$this->data['year'] = $year;   
			$this->show_view_admin('admin/labData', $this->data);
		}
  	}
    
}

/* End of file */?>