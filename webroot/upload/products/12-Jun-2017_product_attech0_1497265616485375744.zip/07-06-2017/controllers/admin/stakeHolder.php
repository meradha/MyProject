<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class StakeHolder extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/stakeholder_model');
	}
	
	/*	Validation Rules */
	 protected $validation_rules = array
        (
        'stakeHolderAdd' => array(
           array(
                'field' => 'stakeholder_name',
                'label' => 'name',
                'rules' => 'trim|required'
            )
        ),
		'stakeHolderUpdate' => array(
        	array(
                'field' => 'stakeholder_name',
                'label' => 'name',
                'rules' => 'trim|required'
            )
        )
    );
	
	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{
			$this->data['stakeholder_res'] = $this->stakeholder_model->getStakeHolder();
			$this->show_view_admin('admin/stakeholder/stakeHolder', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }

    /* Details */
	public function stakeHolderView()
	{
		if($this->checkViewPermission())
		{
			$stakeHolder_id = $this->uri->segment(4);
			$this->data['healthpostarea_list'] = $this->stakeholder_model->getAllHealthpostArea();
			$this->data['stakeHolder_edit'] = $this->stakeholder_model->editStakeHolder($stakeHolder_id);
			$this->show_view_admin('admin/stakeholder/stakeHolderView', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addStakeHolder()
	{
		$stakeHolder_id = $this->uri->segment(4);
		if($stakeHolder_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$this->form_validation->set_rules($this->validation_rules['stakeHolderUpdate']);
					if($this->form_validation->run())
					{
						$post['stakeHolder_id'] = $stakeHolder_id;
						$post['stakeholder_mapping_date'] = $this->input->post('stakeholder_mapping_date');
						$post['stakeholder_name'] = $this->input->post('stakeholder_name');
						$post['stakeholder_phone'] = $this->input->post('stakeholder_phone');
						$post['stakeholder_country_id'] = '99';
						$post['stakeholder_state_id'] = '1493';
						$post['stakeholder_city'] = 'Mumbai';
						$post['stakeholder_address'] = $this->input->post('stakeholder_address');
						$post['stakeholder_landmark'] = $this->input->post('stakeholder_landmark');
						$post['stakeholder_postal_code'] = $this->input->post('stakeholder_postal_code');
						$post['stakeholder_type'] = $this->input->post('stakeholder_type');
						if($post['stakeholder_type'] == 'Other')
						{
							$post['stakeholder_type_other'] = $this->input->post('stakeholder_type_other');
						}
						else
						{
							$post['stakeholder_type_other'] = '';
						}
						$post['stakeholder_correspondance_person'] = $this->input->post('stakeholder_correspondance_person');
						
						$stakeholder_trust_area = $this->input->post('stakeholder_trust_area');
						for($i=0; $i<count($stakeholder_trust_area); $i++)
						{
							if($i==0)
							{
								if($stakeholder_trust_area[$i] == 'Other')
								{
									$post['stakeholder_trust_area_other'] = $this->input->post('stakeholder_trust_area_other');
									$a = $stakeholder_trust_area[$i];
								}
								else
								{
									$post['stakeholder_trust_area_other'] = '';
									$a = $stakeholder_trust_area[$i];
								}
							}
							else
							{
								if($stakeholder_trust_area[$i] == 'Other')
								{
									$post['stakeholder_trust_area_other'] = $this->input->post('stakeholder_trust_area_other');
									$a = $a.','.$stakeholder_trust_area[$i];
								}
								else
								{
									$post['stakeholder_trust_area_other'] = '';
									$a = $a.','.$stakeholder_trust_area[$i];
								}
							}
						}
						$post['stakeholder_trust_area'] = $a;

						$stakeholder_focus_population = $this->input->post('stakeholder_focus_population');
						for($j=0; $j<count($stakeholder_focus_population); $j++)
						{
							if($j==0)
							{
								if($stakeholder_focus_population[$j] == 'Other')
								{
									$post['stakeholder_focus_population_other'] = $this->input->post('stakeholder_focus_population_other');
									$b = $stakeholder_focus_population[$j]; 
								}
								else
								{
									$post['stakeholder_focus_population_other'] = '';
									$b = $stakeholder_focus_population[$j]; 
								}
							}
							else
							{
								if($stakeholder_focus_population[$j] == 'Other')
								{
									$post['stakeholder_focus_population_other'] = $this->input->post('stakeholder_focus_population_other');
									$b = $b.','.$stakeholder_focus_population[$j]; 
								}
								else
								{
									$post['stakeholder_focus_population_other'] = '';
									$b = $b.','.$stakeholder_focus_population[$j]; 
								}
							}
						}
						$post['stakeholder_focus_population'] = $b;

						$post['stakeholder_area'] = $this->input->post('stakeholder_area');
						$post['healthpostarea_id'] = $this->input->post('healthpostarea_id');
						$post['stakeholder_power_structure'] = $this->input->post('stakeholder_power_structure');
						$post['stakeholder_working_since'] = $this->input->post('stakeholder_working_since');
						$post['stakeholder_any_remarks'] = $this->input->post('stakeholder_any_remarks');
						$post['stakeholder_status'] = $this->input->post('stakeholder_status');


						$post['user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['stakeholder_updated_date'] = date('Y-m-d');
						$this->stakeholder_model->updateStakeHolder($post);

						$msg = 'stakeholder update successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/stakeHolder');
					}
					else
					{
						$this->data['healthpostarea_list'] = $this->stakeholder_model->getAllHealthpostArea();
						$this->data['stakeHolder_edit'] = $this->stakeholder_model->editStakeHolder($stakeHolder_id);
						$this->show_view_admin('admin/stakeholder/stakeHolder_update', $this->data);
					}
				}
				else
				{
					$this->data['healthpostarea_list'] = $this->stakeholder_model->getAllHealthpostArea();
					$this->data['stakeHolder_edit'] = $this->stakeholder_model->editStakeHolder($stakeHolder_id);
					$this->show_view_admin('admin/stakeholder/stakeHolder_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$this->form_validation->set_rules($this->validation_rules['stakeHolderAdd']);
					if($this->form_validation->run())
					{
						$post['stakeholder_let'] = $this->data['lat'];
						$post['stakeholder_long'] = $this->data['lon'];
						$post['stakeholder_mapping_date'] = $this->input->post('stakeholder_mapping_date');
						$post['stakeholder_name'] = $this->input->post('stakeholder_name');
						$post['stakeholder_phone'] = $this->input->post('stakeholder_phone');
						$post['stakeholder_country_id'] = '99';
						$post['stakeholder_state_id'] = '1493';
						$post['stakeholder_city'] = 'Mumbai';
						$post['stakeholder_address'] = $this->input->post('stakeholder_address');
						$post['stakeholder_landmark'] = $this->input->post('stakeholder_landmark');
						$post['stakeholder_postal_code'] = $this->input->post('stakeholder_postal_code');
						$post['stakeholder_type'] = $this->input->post('stakeholder_type');
						if($post['stakeholder_type'] == 'Other')
						{
							$post['stakeholder_type_other'] = $this->input->post('stakeholder_type_other');
						}
						else
						{
							$post['stakeholder_type_other'] = '';
						}
						$post['stakeholder_correspondance_person'] = $this->input->post('stakeholder_correspondance_person');
						
						$stakeholder_trust_area = $this->input->post('stakeholder_trust_area');
						for($i=0; $i<count($stakeholder_trust_area); $i++)
						{
							if($i==0)
							{
								if($stakeholder_trust_area[$i] == 'Other')
								{
									$post['stakeholder_trust_area_other'] = $this->input->post('stakeholder_trust_area_other');
									$a = $stakeholder_trust_area[$i];
								}
								else
								{
									$a = $stakeholder_trust_area[$i];
								}
							}
							else
							{
								if($stakeholder_trust_area[$i] == 'Other')
								{
									$post['stakeholder_trust_area_other'] = $this->input->post('stakeholder_trust_area_other');
									$a = $a.','.$stakeholder_trust_area[$i];
								}
								else
								{
									$a = $a.','.$stakeholder_trust_area[$i];
								}
							}
						}
						$post['stakeholder_trust_area'] = $a;

						$stakeholder_focus_population = $this->input->post('stakeholder_focus_population');
						for($j=0; $j<count($stakeholder_focus_population); $j++)
						{
							if($j==0)
							{
								if($stakeholder_focus_population[$j] == 'Other')
								{
									$post['stakeholder_focus_population_other'] = $this->input->post('stakeholder_focus_population_other');
									$b = $stakeholder_focus_population[$j]; 
								}
								else
								{
									$b = $stakeholder_focus_population[$j]; 
								}
							}
							else
							{
								if($stakeholder_focus_population[$j] == 'Other')
								{
									$post['stakeholder_focus_population_other'] = $this->input->post('stakeholder_focus_population_other');
									$b = $b.','.$stakeholder_focus_population[$j]; 
								}
								else
								{
									$b = $b.','.$stakeholder_focus_population[$j]; 
								}
							}
						}
						$post['stakeholder_focus_population'] = $b;

						$post['stakeholder_area'] = $this->input->post('stakeholder_area');
						$post['healthpostarea_id'] = $this->input->post('healthpostarea_id');
						$post['stakeholder_power_structure'] = $this->input->post('stakeholder_power_structure');
						$post['stakeholder_working_since'] = $this->input->post('stakeholder_working_since');
						$post['stakeholder_any_remarks'] = $this->input->post('stakeholder_any_remarks');
						$post['stakeholder_status'] = $this->input->post('stakeholder_status');


						$post['user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['stakeholder_created_date'] = date('Y-m-d');
						$post['stakeholder_updated_date'] = date('Y-m-d');

						$stakeHolder_id =  $this->stakeholder_model->addStakeHolder($post);
						if($stakeHolder_id)
						{
							$msg = 'stakeholder added successfully!!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/stakeHolder');
						}
						else
						{
							$msg = 'Whoops, looks like something went wrong!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/stakeHolder/addStakeHolder');
						}
					}
					else
					{
						$this->data['healthpostarea_list'] = $this->stakeholder_model->getAllHealthpostArea();
						$this->show_view_admin('admin/stakeholder/stakeHolder_add', $this->data);
					}		
				}
				else
				{	
					$this->data['healthpostarea_list'] = $this->stakeholder_model->getAllHealthpostArea();
					$this->show_view_admin('admin/stakeholder/stakeHolder_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}
	
	/* Delete */
	public function delete_stakeHolder()
	{
		if($this->checkDeletePermission())
		{
			$stakeHolder_id = $this->uri->segment(4);
			
			$this->stakeholder_model->delete_stakeHolder($stakeHolder_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/stakeHolder'); 
			}
			else
			{
				$msg = 'stake holder remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/stakeHolder');
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}	
}

/* End of file */?>