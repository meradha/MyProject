<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Map extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/map_model');
		$this->load->model('admin/taskassign_model');
	}
	
	/* Show */
	public function index()
	{	
		$this->show_view_admin('admin/map/mapView', $this->data);
    }
	/*-- AMIT CODE STRAT--*/
    public function getAllpatient(){
		$user_id = $this->input->post('user_id');
		$result = $this->map_model->getAllpatient($user_id);
		$a = array();
		foreach($result as $arr)
		{
			
			if($arr->patient_let != '0' && $arr->patient_let != NULL && $arr->patient_long != '0' && $arr->patient_long != NULL)
			{
			 $lat = floatval($arr->patient_let);
			 $lng = floatval($arr->patient_long);
			 $a[] = array($lat,$lng,'<p><b>Patient Name:</b> '.$arr->patient_name.'</p>',base_url('webroot/admin/upload/common_img/p.png')); 
			 
			 }
		}
		print(json_encode($a));
		}
		
	public function getCommunityawareness(){
		$user_id = $this->input->post('user_id');
		$result = $this->map_model->getCommunityawareness($user_id);
		$a = array();
		foreach($result as $arr)
		{
			
			if($arr->tca_let != '0' && $arr->tca_let != NULL && $arr->tca_long != '0' && $arr->tca_long != NULL)
			{
			 $lat = floatval($arr->tca_let);
			 $lng = floatval($arr->tca_long);
			 $a[] = array($lat,$lng,'<p><b>Place:</b> '.$arr->tca_activity_place.'</p><p>Date: '.$arr->tca_activity_date.'</p>',base_url('webroot/admin/upload/common_img/c.png')); 
			 }
		}
		print(json_encode($a));
		}
		
	public function getStakeholdermeeting(){
		$user_id = $this->input->post('user_id');
		$result = $this->map_model->getStakeholdermeeting($user_id);
		$a = array();
		foreach($result as $arr)
		{
			
			if($arr->shm_let != '0' && $arr->shm_let != NULL && $arr->shm_long != '0' && $arr->shm_long != NULL)
			{
			 $lat = floatval($arr->shm_let);
			 $lng = floatval($arr->shm_long);
			 $a[] = array($lat,$lng,'<p><b>Location:</b> '.$arr->shm_meting_location.'</p><p>Date: '.$arr->shm_meeting_date.'</p>',base_url('webroot/admin/upload/common_img/s.png')); 
			 }
		}
		print(json_encode($a));
		}
	/*-- AMIT CODE END--*/
}
/* End of file */?>