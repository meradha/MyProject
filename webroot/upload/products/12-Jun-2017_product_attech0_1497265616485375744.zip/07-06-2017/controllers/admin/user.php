<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/user_model');
	}
	
	/*	Validation Rules */
	 protected $validation_rules = array
        (
        'userAdd' => array(
            array(
                'field' => 'user_role_id',
                'label' => 'user role',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'user_name',
                'label' => 'name',
                'rules' => 'trim|required'
            ),
			array(
                'field' => 'user_email',
                'label' => 'email',
                'rules' => 'trim|required|is_unique[tbl_user.user_email]'
            ),
            array(
                'field' => 'user_uname',
                'label' => 'username',
                'rules' => 'trim|required|is_unique[tbl_user.user_uname]'
            ),
			array(
                'field' => 'user_phone',
                'label' => 'phone',
                'rules' => 'trim|required'
            ),
             array( 
				'field' => 'user_password', 
				'label' => 'Password',   
				'rules' => 'trim|required'  
			),
			array(  
				'field' => 'user_cpassword',
				'label' => 'Confirm Password', 
				'rules' => 'trim|required|matches[user_password]'
            ),
            array(  
				'field' => 'user_gender',
				'label' => 'gender', 
				'rules' => 'trim|required'
            ),
            array(  
				'field' => 'user_dob',
				'label' => 'date of birth', 
				'rules' => 'trim|required'
            ),			
                   
        ),
		'userUpdate' => array(
        	array(
                'field' => 'user_role_id',
                'label' => 'user role',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'user_name',
                'label' => 'name',
                'rules' => 'trim|required'
            ),
			array(
                'field' => 'user_phone',
                'label' => 'phone',
                'rules' => 'trim|required'
            ),
            array(  
				'field' => 'user_gender',
				'label' => 'gender', 
				'rules' => 'trim|required'
            ),
            array(  
				'field' => 'user_dob',
				'label' => 'date of birth', 
				'rules' => 'trim|required'
            ), 
        )
    );
	
	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{			
			$user_role_id = $this->data['session'][0]->user_role_id;
			$this->data['role_res'] = $this->user_model->getRoleByLoginRole($user_role_id);			
			$this->show_view_admin('admin/user', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addUser()
	{
		$r_user_id = $this->uri->segment(4);
		if($r_user_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$this->form_validation->set_rules($this->validation_rules['userUpdate']);
					if($this->form_validation->run())
					{
						$post['user_id'] = $r_user_id;
						$user_id = $this->data['session'][0]->user_id;
						$post['user_role_id'] = $this->input->post('user_role_id');
						$post['Change_Level'] = $this->input->post('change_level');
						if($post['Change_Level'] == 'Change_Level')
						{
							$user_all_level_s = $this->data['session'][0]->user_all_level;
							$user_parent_u_id = $this->input->post('user_parent_u_id');					
							$u_all_level = '';
							$user_parent_id = '';
							$t_parent_user = count($user_parent_u_id) -1;
							$u_de = $this->user_model->getUserByID($user_parent_u_id[$t_parent_user]);
							if(!empty($u_de))
							{
								$post['user_all_level'] = $u_de[0]->user_all_level.','.$u_de[0]->user_id;
								$user_parent_id = $u_de[0]->user_id;
							}
							else
							{
								$u_de = $this->user_model->getUserByID($user_id);
								if($u_de[0]->user_all_level == 0)
								{
									$post['user_all_level'] = $u_de[0]->user_id;
									$user_parent_id = $u_de[0]->user_id;
								}
								else
								{
									$post['user_all_level'] = $u_de[0]->user_all_level.','.$u_de[0]->user_id;
									$user_parent_id = $user_id;
								}
								
							}
							$post['user_parent_user_id'] = $user_parent_id;
						}

						$post['user_name'] = $this->input->post('user_name');
						$post['user_phone'] = $this->input->post('user_phone');
						$post['user_gender'] = $this->input->post('user_gender');
						$post['user_dob'] = $this->input->post('user_dob');
						$post['user_level'] = $this->input->post('user_role_id');
						$post['user_status'] = $this->input->post('user_status');
						$post['added_by'] = $this->data['session'][0]->user_id;
						//$post['user_created_date'] = date('Y-m-d');
						$post['user_updated_date'] = date('Y-m-d');

						if($_FILES["user_img"]["name"]) 
						{
							$image_name = $_FILES["user_img"]["name"];
		                    $Path = 'webroot/admin/upload/user/'.$image_name;
		                    move_uploaded_file($_FILES['user_img']['tmp_name'],$Path);
		                    $post['user_img'] = base_url().''.$Path.''.$image_name;
                        }

						$this->user_model->updateUser($post);

						$msg = 'User update successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/user');
					}
					else
					{
						$user_role_id = $this->data['session'][0]->user_role_id;					
						$this->data['role_list'] = $this->user_model->getRoleByLoginRole($user_role_id);

						$this->data['all_user'] = $this->user_model->getAllUsers();

						$user_level = $this->data['session'][0]->user_level + 1;
						$this->data['user_list'] = $this->user_model->getAllUser($user_level);
						$this->data['user_edit'] = $this->user_model->editUser($r_user_id);
						$this->show_view_admin('admin/user_update', $this->data);
					}
				}
				else
				{
					$user_role_id = $this->data['session'][0]->user_role_id;					
					$this->data['role_list'] = $this->user_model->getRoleByLoginRole($user_role_id);

					$this->data['all_user'] = $this->user_model->getAllUsers();

					$user_level = $this->data['session'][0]->user_level + 1;
					$this->data['user_list'] = $this->user_model->getAllUser($user_level);
					$this->data['user_edit'] = $this->user_model->editUser($r_user_id);
					$this->show_view_admin('admin/user_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$this->form_validation->set_rules($this->validation_rules['userAdd']);
					if($this->form_validation->run())
					{
						
						$user_id = $this->data['session'][0]->user_id;
						$post['user_role_id'] = $this->input->post('user_role_id');
						$user_all_level_s = $this->data['session'][0]->user_all_level;
						$user_parent_u_id = $this->input->post('user_parent_u_id');					
						$u_all_level = '';
						$user_parent_id = '';
						$t_parent_user = count($user_parent_u_id) -1;
						$u_de = $this->user_model->getUserByID($user_parent_u_id[$t_parent_user]);
						if(!empty($u_de))
						{
							$post['user_all_level'] = $u_de[0]->user_all_level.','.$u_de[0]->user_id;
							$user_parent_id = $u_de[0]->user_id;
						}
						else
						{
							$u_de = $this->user_model->getUserByID($user_id);
							if($u_de[0]->user_all_level == 0)
							{
								$post['user_all_level'] = $u_de[0]->user_id;
								$user_parent_id = $u_de[0]->user_id;
							}
							else
							{
								$post['user_all_level'] = $u_de[0]->user_all_level.','.$u_de[0]->user_id;
								$user_parent_id = $user_id;
							}
							
						}
						$post['user_parent_user_id'] = $user_parent_id;
						$post['user_name'] = $this->input->post('user_name');
						$post['user_email'] = $this->input->post('user_email');
						$post['user_phone'] = $this->input->post('user_phone');
						$post['user_uname'] = $this->input->post('user_uname');
						$post['user_password'] = md5($this->input->post('user_password'));
						$post['user_gender'] = $this->input->post('user_gender');
						$post['user_dob'] = $this->input->post('user_dob');
						$post['user_level'] = $this->input->post('user_role_id');
						$post['user_status'] = $this->input->post('user_status');
						$post['added_by'] = $this->data['session'][0]->user_id;
						$post['user_created_date'] = date('Y-m-d');
						$post['user_updated_date'] = date('Y-m-d');

						if($_FILES["user_img"]["name"]) 
						{
							$image_name = $_FILES["user_img"]["name"];
		                    $Path = 'webroot/admin/upload/user/'.$image_name;
		                    move_uploaded_file($_FILES['user_img']['tmp_name'],$Path);
		                    $post['user_img'] = base_url().''.$Path.''.$image_name;
                        }
                        else
                        {
                        	$post['user_img'] = $post['user_img'] = base_url().'webroot/admin/upload/common_img/avatar3.png';
                        }

						$user_id =  $this->user_model->addUser($post);
						if($user_id)
						{
							$msg = 'user added successfully!!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/user');
						}
						else
						{
							$msg = 'Whoops, looks like something went wrong!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/user/user_add');
						}
					}
					else
					{
						$user_role_id = $this->data['session'][0]->user_role_id;					
						$this->data['role_res'] = $this->user_model->getRoleByLoginRole($user_role_id);

						$user_level = $this->data['session'][0]->user_level + 1;
						$this->data['user_list'] = $this->user_model->getAllUser($user_level);
						$this->show_view_admin('admin/user_add', $this->data);
					}		
				}
				else
				{
					$user_role_id = $this->data['session'][0]->user_role_id;					
					$this->data['role_res'] = $this->user_model->getRoleByLoginRole($user_role_id);

					$user_level = $this->data['session'][0]->user_level + 1;
					$this->data['user_list'] = $this->user_model->getAllUser($user_level);
					$this->show_view_admin('admin/user_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}
	
	/* Delete */
	public function delete_user()
	{
		if($this->checkDeletePermission())
		{
			$user_id = $this->uri->segment(4);
			
			$this->user_model->delete_user($user_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/user'); 
			}
			else
			{
				$msg = 'user remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/user');
			}
			
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}

	/* Get State List */
	public function getStateList()
	{
		$country_id = $this->input->post('country_id');
		$state_list = $this->user_model->getStateListByCountryId($country_id);

		$html = '';
		if(count($state_list) > 0)
		{
			foreach ($state_list as $s_list) 
			{
				$html .= '<option value="'.$s_list->state_id.'">'.$s_list->state_name.'</option>';
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}

	/* get child user */
	public function getChildUser()
	{
		$user_id = $this->input->post('user_id');
		$role_id = $this->input->post('role_id');

		$user_res = $this->user_model->getChildUser($user_id);		
		
		$html = '';
		if(!empty($user_res))
		{
			if($role_id != $user_res[0]->user_role_id)
			{
				$html .= '<div class="form-group col-md-4"><div class="input text"><label>Child User<span class="text-danger">*</span></label><select class="form-control"  name="user_parent_u_id[]" id="user_parent_u_id" onchange="getChildUser1(this.value, '.$user_id.');"><option value=""></option>';
				foreach ($user_res as $value)
				{
					$html .= '<option value="'.$value->user_id.'">'.$value->user_name.'</option>';
				}
				$html .= '</select></div></div><div id="ch_user_'.$user_id.'"></div>';
			}
		}
		echo $html;
	}

















	/* Get Chile Role List */
	public function getChildUserByParentUserId()
	{
		$user_id = $this->input->post('user_id');
		$c_user_list = $this->user_model->getChildUserByParentUserId($user_id);

		$html = '';
		if(count($c_user_list) > 0)
		{
			$html = '<div class="form-group col-md-4"><div class="input text"><label>Child User</label><select class="form-control"  name="user_parent[]" id="user_parent_'.$c_user_list[0]->user_level.'" onchange="getChildUserByParentUserId(this.value, '.$c_user_list[0]->user_level.')"><option value=""></option>';
			foreach ($c_user_list as $u_list) 
			{
				$html .= '<option value="'.$u_list->user_id.'">'.$u_list->user_name.'</option>';
			}
			$html .= '</select></div></div><div id="add_child_div_';
				if(!empty($c_user_list))
				{ 
					$html .= $c_user_list[0]->user_level; 
				} 
			$html .= '">';
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}
}

/* End of file */?>