<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Leave extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/leave_model');
	}
	
	/*	Validation Rules */
	 protected $validation_rules = array
        (
        'leaveAdd' => array(
            array(
                'field' => 'leave_start_date',
                'label' => 'leave start date',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'leave_end_date',
                'label' => 'leave end date',
                'rules' => 'trim|required'
            ),
			array(
                'field' => 'leave_reason',
                'label' => 'leave reason',
                'rules' => 'trim|required'
            ),           
        ),
		'leaveUpdate' => array(
        	array(
                'field' => 'leave_start_date',
                'label' => 'leave start date',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'leave_end_date',
                'label' => 'leave end date',
                'rules' => 'trim|required'
            ),
			array(
                'field' => 'leave_reason',
                'label' => 'leave reason',
                'rules' => 'trim|required'
            ),
        ),
        'leaveApproved' => array(
        	array(
                'field' => 'leave_approved_status',
                'label' => 'approved leave',
                'rules' => 'trim|required'
            )
        )
    );
	
	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{
			$user_id = $this->data['session'][0]->user_id;		
			$this->data['apply_leave_res'] = $this->leave_model->getApplyLeave($user_id);
			$this->data['applied_leave_res'] = $this->leave_model->getAppliedLeave();
			// echo "<pre>";
			// print_r($this->data['applied_leave_res']);
			// die();
			$this->show_view_admin('admin/leave/leave', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }

    /* Details */
	public function leaveView()
	{
		if($this->checkViewPermission())
		{
			$leave_id = $this->uri->segment(4);
			$this->data['leave_edit'] = $this->leave_model->editLeave($leave_id);
			$this->show_view_admin('admin/leave/leaveView', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addLeave()
	{
		$leave_id = $this->uri->segment(4);
		if($leave_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$this->form_validation->set_rules($this->validation_rules['leaveUpdate']);
					if($this->form_validation->run())
					{
						$post['leave_id'] = $leave_id;
						$post['leave_start_date'] = $this->input->post('leave_start_date');
						$post['leave_end_date'] = $this->input->post('leave_end_date');
						
						$leave_start_date = $post['leave_start_date'];
						$leave_end_date = $post['leave_end_date'];
						$days_remain1 = (strtotime($leave_end_date) - strtotime($leave_start_date)) / (60 * 60 * 24);
						$days_remain = round($days_remain1);
						
						$post['leave_day_count'] = $days_remain + 1;

						$post['leave_reason'] = $this->input->post('leave_reason');
						$post['leave_status'] = '1';
						$post['leave_approved_status'] = '0';
						if($post['leave_day_count'] <= 2)
						{
							$post['leave_approved_by'] = $this->data['session'][0]->user_parent_user_id;
						}
						else
						{
							$user_parent_user_id = $this->data['session'][0]->user_parent_user_id;
							$user_detail = $this->leave_model->getParentUserDetails($user_parent_user_id);
							$post['leave_approved_by'] = $user_detail[0]->user_parent_user_id;
						}
						$post['leave_user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['leave_updated_date'] = date('Y-m-d');
						$this->leave_model->updateLeave($post);

						$msg = 'Leave update successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/leave');
					}
					else
					{
						$this->data['leave_edit'] = $this->leave_model->editLeave($leave_id);
						$this->show_view_admin('admin/leave/leave_update', $this->data);
					}
				}
				else
				{
					$this->data['leave_edit'] = $this->leave_model->editLeave($leave_id);
					$this->show_view_admin('admin/leave/leave_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$this->form_validation->set_rules($this->validation_rules['leaveAdd']);
					if($this->form_validation->run())
					{
						$post['leave_start_date'] = $this->input->post('leave_start_date');
						$post['leave_end_date'] = $this->input->post('leave_end_date');

						$leave_start_date = $post['leave_start_date'];
						$leave_end_date = $post['leave_end_date'];
						$days_remain1 = (strtotime($leave_end_date) - strtotime($leave_start_date)) / (60 * 60 * 24);
						$days_remain = round($days_remain1);

						$post['leave_day_count'] = $days_remain + 1;
						$post['leave_reason'] = $this->input->post('leave_reason');
						$post['leave_status'] = '1';
						$post['leave_approved_status'] = '0';
						if($post['leave_day_count'] <= 2)
						{
							$post['leave_approved_by'] = $this->data['session'][0]->user_parent_user_id;
						}
						else
						{
							$user_parent_user_id = $this->data['session'][0]->user_parent_user_id;
							$user_detail = $this->leave_model->getParentUserDetails($user_parent_user_id);
							$post['leave_approved_by'] = $user_detail[0]->user_parent_user_id;
						}
						
						$post['leave_user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['leave_created_date'] = date('Y-m-d');
						$post['leave_updated_date'] = date('Y-m-d');

						$leave_id =  $this->leave_model->addLeave($post);
						if($leave_id)
						{
							$msg = 'Leave added successfully!!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/leave');
						}
						else
						{
							$msg = 'Whoops, looks like something went wrong!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/leave/addLeave');
						}
					}
					else
					{
						$this->show_view_admin('admin/leave/leave_add', $this->data);
					}		
				}
				else
				{	
					$this->show_view_admin('admin/leave/leave_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}

	public function approveLeave()
	{
		$leave_id = $this->uri->segment(4);
		if (isset($_POST['Submit']) && $_POST['Submit'] == "Approved_leave")
		{
			$this->form_validation->set_rules($this->validation_rules['leaveApproved']);
			if($this->form_validation->run())
			{
				$post['leave_approved_status'] = $this->input->post('leave_approved_status');
				$post['leave_id'] = $leave_id;
				$post['leave_updated_date'] = date('Y-m-d');
				// echo "<pre>";
				// print_r($post);
				// die();
				$this->leave_model->updateApproveLeaveStatus($post);

				$msg = 'Leave approved successfully!!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/leave');
			}
			else
			{
				$this->show_view_admin('admin/leave/leave_approved', $this->data);
			}
		}
		else
		{
			$this->show_view_admin('admin/leave/leave_approved', $this->data);
		}
	}
	
	/* Delete */
	public function delete_leave()
	{
		if($this->checkDeletePermission())
		{
			$leave_id = $this->uri->segment(4);
			
			$this->leave_model->delete_leave($leave_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/leave'); 
			}
			else
			{
				$msg = 'Leave remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/leave');
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}
}

/* End of file */?>