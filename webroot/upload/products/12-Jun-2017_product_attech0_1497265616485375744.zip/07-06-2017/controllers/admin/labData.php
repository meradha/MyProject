<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class LabData extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/labdata_model');
	}

	/*	Validation Rules */
	 protected $validation_rules = array
        (
        'labDataAdd' => array(
            array(
                'field' => 'ld_year',
                'label' => 'year',
                'rules' => 'trim|required'
            ),
			array(
                'field' => 'ld_month',
                'label' => 'month',
                'rules' => 'trim|required'
            ),
            array(
                'field' => 'diagnosis_id',
                'label' => 'lab',
                'rules' => 'trim|required'
            ),
        )
    );
	
	/* Dashboard Show */
	public function index()
	{	
		if($this->checkViewPermission())
		{	
			$this->data['lab_data'] = $this->labdata_model->getAllLabData();
			$this->show_view_admin('admin/labData/labData', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		} 
  	}

  	/* Add and Update */
	public function addLabData()
	{
		if($this->checkEditPermission() && $this->checkAddPermission())
		{
			if (isset($_POST['Submit']) && $_POST['Submit'] == "AddEdit") 
			{
				$this->form_validation->set_rules($this->validation_rules['labDataAdd']);
				if($this->form_validation->run())
				{
					$addData = $this->input->post('addData');
					if($addData == 'addData')
					{
						$post['ld_year'] = $this->input->post('ld_year');
						$post['ld_month'] = $this->input->post('ld_month');
						$post['diagnosis_id'] = $this->input->post('diagnosis_id');
						$post['ld_presumptive_tested'] = $this->input->post('ld_presumptive_tested');
						$post['ld_presumptive_tested_positive'] = $this->input->post('ld_presumptive_tested_positive');
						$post['ld_referred_by_saksham_sathi'] = $this->input->post('ld_referred_by_saksham_sathi');
						$post['ld_tested_out_referred_by_saksham_sathi'] = $this->input->post('ld_tested_out_referred_by_saksham_sathi');
						$post['ld_positive_referred_by_saksham_sathi'] = $this->input->post('ld_positive_referred_by_saksham_sathi');
						$post['user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['ld_created_date'] = date('Y-m-d');
						$post['ld_updated_date'] = date('Y-m-d');
						$this->labdata_model->addLabData($post);

						$msg = 'lab data added successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/labData');

					}
					else
					{
						$post['ld_id'] = $addData ;
						$post['ld_year'] = $this->input->post('ld_year');
						$post['ld_month'] = $this->input->post('ld_month');
						$post['diagnosis_id'] = $this->input->post('diagnosis_id');
						$post['ld_presumptive_tested'] = $this->input->post('ld_presumptive_tested');
						$post['ld_presumptive_tested_positive'] = $this->input->post('ld_presumptive_tested_positive');
						$post['ld_referred_by_saksham_sathi'] = $this->input->post('ld_referred_by_saksham_sathi');
						$post['ld_tested_out_referred_by_saksham_sathi'] = $this->input->post('ld_tested_out_referred_by_saksham_sathi');
						$post['ld_positive_referred_by_saksham_sathi'] = $this->input->post('ld_positive_referred_by_saksham_sathi');
						$post['user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level.','.$this->data['session'][0]->user_id;
						$post['ld_updated_date'] = date('Y-m-d');
						$this->labdata_model->updateLabData($post);

						$msg = 'lab data updated successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/labData');
					}
				}
				else
				{
					$this->data['lab_list'] = $this->labdata_model->getAllLabList();
					$this->show_view_admin('admin/labData/labData_add', $this->data);
				}
			}
			else
			{
				$this->data['lab_list'] = $this->labdata_model->getAllLabList();
				$this->show_view_admin('admin/labData/labData_add', $this->data);
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}
	}


	public function getLabDataByMonthYearLabID()
	{
		$diagnosis_id = $this->input->post('diagnosis_id');
		$ld_year = $this->input->post('ld_year');
		$ld_month = $this->input->post('ld_month');
		$labdata_res = $this->labdata_model->getLabDataByMonthYearLabID($diagnosis_id, $ld_year, $ld_month);
		if(!empty($labdata_res))
		{
			echo json_encode(array('labdata_res'=>$labdata_res));
		}
		else
		{
			echo 1;
		}
	} 

    
}

/* End of file */?>