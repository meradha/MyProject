<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Chat extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/chat_model');
	}
	
	/* Show */
	public function index()
	{	
		$this->data['chat_res'] = $this->chat_model->getAllChat();
		$this->show_view_admin('admin/chat/chatView', $this->data);
    }


    /* add chat */
	public function addChat()
	{	
		$post['chat_avatar_name'] = $this->input->post('chat_avatar_name');
		$post['chat_text_message'] = $this->input->post('chat_text_message');
		$post['chat_user_name'] = $this->input->post('chat_user_name');
		$post['user_id'] = $this->input->post('user_id');
		$post['user_all_level'] = $this->input->post('user_all_level');
		$post['chat_let'] = $this->input->post('chat_let');
		$post['chat_long'] = $this->input->post('chat_long');
		$post['chat_date'] = $this->input->post('chat_date');
		$post['chat_time'] = $this->input->post('chat_time');
		$chat_id = $this->chat_model->addChat($post);
		if($chat_id)
		{
			echo 1;
		}
		else
		{
			echo 0;
		}
    }
    
}

/* End of file */?>