<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class TaskForm extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/taskform_model');
	}
	
	/*	Validation Rules */
	 protected $validation_rules = array
        (
        'taskFormAdd' => array(
            array(
                'field' => 'taskform_name',
                'label' => 'form name',
                'rules' => 'trim|required|is_unique[tbl_taskform.taskform_name]'
            )
        ),
		'taskFormUpdate' => array(
        	array(
                'field' => 'taskform_name',
                'label' => 'form name',
                'rules' => 'trim|required'
            )   
        )
    );
	
	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{			
			$user_id = $this->data['session'][0]->user_id;
			$this->data['taskform_res'] = $this->taskform_model->getTaskForm($user_id);
			$this->show_view_admin('admin/task/taskForm', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addTaskForm()
	{
		$taskform_id = $this->uri->segment(4);
		if($taskform_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$this->form_validation->set_rules($this->validation_rules['taskFormUpdate']);
					if($this->form_validation->run())
					{
						$post['taskform_id'] = $taskform_id;
						$post['taskform_name'] = $this->input->post('taskform_name');
						$post['taskform_status'] = $this->input->post('taskform_status');
						$post['user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level;
						$post['taskform_updated_date'] = date('Y-m-d');
						$this->taskform_model->updateTaskForm($post);

						$msg = 'Task Form update successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/taskForm');
					}
					else
					{
						$this->data['taskForm_edit'] = $this->taskform_model->editTaskForm($taskform_id);
						$this->show_view_admin('admin/task/taskForm_update', $this->data);
					}
				}
				else
				{
					$this->data['taskForm_edit'] = $this->taskform_model->editTaskForm($taskform_id);
					$this->show_view_admin('admin/task/taskForm_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$this->form_validation->set_rules($this->validation_rules['taskFormAdd']);
					if($this->form_validation->run())
					{
						$post['taskform_name'] = $this->input->post('taskform_name');
						$post['taskform_status'] = $this->input->post('taskform_status');
						$post['user_id'] = $this->data['session'][0]->user_id;
						$post['user_all_level'] = $this->data['session'][0]->user_all_level;
						$post['taskform_created_date'] = date('Y-m-d');
						$post['taskform_updated_date'] = date('Y-m-d');

						$taskform_id =  $this->taskform_model->addTaskForm($post);
						if($taskform_id)
						{
							$msg = 'Task form added successfully!!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/taskForm');
						}
						else
						{
							$msg = 'Whoops, looks like something went wrong!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/taskForm/addTaskForm');
						}
					}
					else
					{
						$this->show_view_admin('admin/task/taskForm_add', $this->data);
					}		
				}
				else
				{	
					$this->show_view_admin('admin/task/taskForm_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}

	/* Delete */
	public function delete_taskForm()
	{
		if($this->checkDeletePermission())
		{
			$taskform_id = $this->uri->segment(4);
			
			$this->taskform_model->delete_taskForm($taskform_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/taskForm'); 
			}
			else
			{
				$msg = 'Task form remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/taskForm');
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}

	/* Get State List */
	public function getAllUserByRoleID()
	{
		$role_id = $this->input->post('role_id');
		$user_id = $this->input->post('user_id');
		$user_list = $this->taskform_model->getAllUserByRoleID($role_id);

		$html = '';
		if(count($user_list) > 0)
		{
			foreach ($user_list as $u_list) 
			{
				$u_all_level = explode(',', $u_list->user_all_level);
				if(in_array($user_id, $u_all_level))
				{
					$html .= '<option value="'.$u_list->user_id.'">'.$u_list->user_name.'</option>';
				}
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}

}

/* End of file */?>