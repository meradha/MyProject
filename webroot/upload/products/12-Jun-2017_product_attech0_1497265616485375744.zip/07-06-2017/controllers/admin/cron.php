<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Cron extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/cron_model');
	}
	
	/* Task end date stop task */
	/* this cron run daily*/
	public function stopTaskWorkStatus()
	{	
		$task_res = $this->cron_model->stopTaskWorkStatus();
		$c_date = date('Y-m-d');
		foreach ($task_res as $value) 
		{
			if($c_date == $value->ta_task_end_date)
			{
				$post['ta_work_status'] = '1';
				$post['ta_id'] = $value->ta_id;
				$this->cron_model->updateTaskWorkStatus($post);

				// $post_tc['ttc_target_status'] = '1';
				// $post_tc['ta_id'] = $value->ta_id;
				// $this->cron_model->updateTaskCountTargetStatus($post);
			}
		}
    }

    
}

/* End of file */?>