<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Knowledgebase extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/knowledgebase_model');
	}
	
	/*	Validation Rules */
	 protected $validation_rules = array
        (
        'knowledgebaseAdd' => array(
           
            array(
                'field' => 'kb_title',
                'label' => 'title',
                'rules' => 'trim|required'
            ),
            array(  
				'field' => 'kb_description',
				'label' => 'descritpion', 
				'rules' => 'trim|required'
            )
        ),
		'knowledgebaseUpdate' => array(
            array(
                'field' => 'kb_title',
                'label' => 'title',
                'rules' => 'trim|required'
            ),
            array(  
				'field' => 'kb_description',
				'label' => 'descritpion', 
				'rules' => 'trim|required'
            )
        )
    );
	
	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{			
			$user_id = $this->data['session'][0]->user_id;
			$this->data['add_knowledgebase_res'] = $this->knowledgebase_model->getKnowledgebaseAdded($user_id);
			$this->data['knowledgebase_res'] = $this->knowledgebase_model->getknowledgebase($user_id);	
			
			$this->show_view_admin('admin/knowledgebase/knowledgebase', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }

    /* Details */
	public function knowledgebaseView()
	{
		if($this->checkViewPermission())
		{			
			$kb_id = $this->uri->segment(4);
			$this->data['knowledgebase_res'] = $this->knowledgebase_model->editKnowledgebase($kb_id);
			$this->data['img_video_res'] = $this->knowledgebase_model->getKnowledgebaseImagesVideo($kb_id);

			// echo "<pre>";
			// print_r($this->data['img_video_res'] );
			// die();
			$this->show_view_admin('admin/knowledgebase/knowledgebaseView', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addKnowledgebase()
	{
		$kb_id = $this->uri->segment(4);
		if($kb_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					$this->form_validation->set_rules($this->validation_rules['knowledgebaseUpdate']);
					if($this->form_validation->run())
					{
						$post['kb_id'] = $kb_id;
						$post['kb_title'] = $this->input->post('kb_title');
						$post['kb_description'] = $this->input->post('kb_description');
						$post['kb_status'] = $this->input->post('kb_status');
						$post['kb_updated'] = date('Y-m-d');
						$this->knowledgebase_model->updateKnowledgebase($post);

						$kb_img = $_FILES["kb_img"]['name'];
	                    for($i = 0; $i < count($kb_img); $i++)
	 					{	 
	                   		//$imagedetails = getimagesize($_FILES["kb_img"]['tmp_name'][$i]);
	        				$image_name = $_FILES["kb_img"]["name"][$i];

	                      	$Path = 'webroot/admin/upload/knowledgebase/';
	                      	
	                       	move_uploaded_file($_FILES['kb_img']['tmp_name'][$i],$Path.''.$image_name);

	                       	$post_img['kb_img_video'] = base_url().''.$Path.''.$image_name;
							$post_img['kb_id'] =  $kb_id;

							$post_img['kb_iv_type'] =  'IMAGE';
							$post_img['kb_iv_status'] = '1';
							$post_img['kb_iv_created_date'] = date('Y-m-d');
							$post_img['kb_iv_updated_date'] = date('Y-m-d');
							$this->knowledgebase_model->addKnowledgebaseImagesVideo($post_img);
						}

						$this->knowledgebase_model->deleteKnowledgebaseVideo($kb_id);
						$kb_video = $this->input->post('kb_video');	
	                    for($j = 0; $j < count($kb_video); $j++)
	 					{	 
	                       	$post_video['kb_img_video'] = $kb_video[$j];
	                       	$post_video['kb_id'] =  $kb_id;
							$post_video['kb_iv_type'] =  'VIDEO';
							$post_video['kb_iv_status'] = '1';
							$post_video['kb_iv_created_date'] = date('Y-m-d');
							$post_video['kb_iv_updated_date'] = date('Y-m-d');
							$this->knowledgebase_model->addKnowledgebaseImagesVideo($post_video);
						}


						$msg = 'Knowledgebase update successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/knowledgebase');
					}
					else
					{
						$this->data['knowledgebase_edit'] = $this->knowledgebase_model->editKnowledgebase($kb_id);
						$this->data['img_video_res'] = $this->knowledgebase_model->getKnowledgebaseImagesVideo($kb_id);
						// $user_role_id = $this->data['session'][0]->user_role_id;					
						// $this->data['role_list'] = $this->knowledgebase_model->getRoleByLoginRole($user_role_id);

						// $this->data['all_user'] = $this->knowledgebase_model->getAllUsers();

						// $user_level = $this->data['session'][0]->user_level + 1;
						// $this->data['user_list'] = $this->knowledgebase_model->getAllUser($user_level);
						$this->show_view_admin('admin/knowledgebase/knowledgebase_update', $this->data);
					}
				}
				else
				{
					$this->data['knowledgebase_edit'] = $this->knowledgebase_model->editKnowledgebase($kb_id);
					$this->data['img_video_res'] = $this->knowledgebase_model->getKnowledgebaseImagesVideo($kb_id);
					// $user_role_id = $this->data['session'][0]->user_role_id;					
					// $this->data['role_list'] = $this->knowledgebase_model->getRoleByLoginRole($user_role_id);

					// $this->data['all_user'] = $this->knowledgebase_model->getAllUsers();

					// $user_level = $this->data['session'][0]->user_level + 1;
					// $this->data['user_list'] = $this->knowledgebase_model->getAllUser($user_level);
					$this->show_view_admin('admin/knowledgebase/knowledgebase_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
					$this->form_validation->set_rules($this->validation_rules['knowledgebaseAdd']);
					if($this->form_validation->run())
					{
						//$post['user_role_id'] = $this->input->post('user_role_id');
						//$post['kb_assign_by'] = $this->data['session'][0]->user_id;

						//$user_parent_u_id = $this->input->post('user_parent_u_id');					
						//$i = count($user_parent_u_id)-1;
						//$post['kb_assign_to'] = $user_parent_u_id[$i];

						//$user_d = $this->knowledgebase_model->getUserAllLevel($user_parent_u_id[$i]);
						// if(!empty($user_d))
						// {
						// 	$post['kb_assign_level'] = $user_d[0]->user_all_level.','.$post['kb_assign_to'];
						// }

						$post['kb_title'] = $this->input->post('kb_title');
						$post['kb_description'] = $this->input->post('kb_description');						
						$post['kb_created_date'] = date('Y-m-d');
						$post['kb_updated'] = date('Y-m-d');					
						$kb_id =  $this->knowledgebase_model->addKnowledgebase($post);

						if($kb_id)
						{
							$kb_img = $_FILES["kb_img"]['name'];
							if(!empty($kb_img[0]))
							{
								for($i = 0; $i < count($kb_img); $i++)
			 					{	 
			                   		$_FILES['new_file']['name'] = $_FILES['kb_img']['name'][$i];
			        				$_FILES['new_file']['type'] = $_FILES['kb_img']['type'][$i];
					                $_FILES['new_file']['tmp_name'] = $_FILES['kb_img']['tmp_name'][$i];
					                $_FILES['new_file']['error'] = $_FILES['kb_img']['error'][$i];
					                $_FILES['new_file']['size'] = $_FILES['kb_img']['size'][$i];
			                      
			                      	$name = 'kb_img';
			                      	$imagePath = 'webroot/admin/upload/knowledgebase/';
			                       	$temp = explode(".",$_FILES['new_file']['name']);
									$extension = end($temp);
									$filenew =  date('d-M-Y').'_'.str_replace($_FILES['new_file']['name'],$name,$_FILES['new_file']['name']).'_'.time().''.rand(). "." .$extension;  		
									$config['file_name'] = $filenew;
									$config['upload_path'] = $imagePath;
									$config['allowed_types'] = 'GIF | gif | JPE | jpe | JPEG | jpeg | JPG | jpg | PNG | png';
									$this->upload->initialize($config);
									$this->upload->set_allowed_types('*');
									$this->upload->set_filename($config['upload_path'],$filenew);
									if(!$this->upload->do_upload('new_file'))
									{
										$data = array('msg' => $this->upload->display_errors());
									}
									else 
									{ 
										$data = $this->upload->data();	
										$imageName = $data['file_name'];
									}	
			                       	$post_img['kb_img_video'] = base_url().''.$imagePath.''.$imageName;
									$post_img['kb_id'] =  $kb_id;
									$post_img['kb_iv_type'] =  'IMAGE';
									$post_img['kb_iv_status'] = '1';
									$post_img['kb_iv_created_date'] = date('Y-m-d');
									$post_img['kb_iv_updated_date'] = date('Y-m-d');
									$this->knowledgebase_model->addKnowledgebaseImagesVideo($post_img);
									if($i=='0')
									{
										$post_u['kb_thumb_img'] = $post_img['kb_img_video'];
										$post_u['kb_id'] = $kb_id;
										$this->knowledgebase_model->updateThumbnailImg($post_u);
									}
								}


								$kb_video = $this->input->post('kb_video');	
			                    for($j = 0; $j < count($kb_video); $j++)
			 					{	 
			                       	$post_video['kb_img_video'] = $kb_video[$j];
			                       	$post_video['kb_id'] =  $kb_id;
									$post_video['kb_iv_type'] =  'VIDEO';
									$post_video['kb_iv_status'] = '1';
									$post_video['kb_iv_created_date'] = date('Y-m-d');
									$post_video['kb_iv_updated_date'] = date('Y-m-d');
									$this->knowledgebase_model->addKnowledgebaseImagesVideo($post_video);
								}
							}
							else
							{
								$post_u['kb_thumb_img'] = base_url().'webroot/admin/upload/common_img/dummy.png';
								$post_u['kb_id'] = $kb_id;
								$this->knowledgebase_model->updateThumbnailImg($post_u);
							}
		                    

							$msg = 'Knowledgebase added successfully!!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/knowledgebase');
						}
						else
						{
							$msg = 'Whoops, looks like something went wrong!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/knowledgebase/addKnowledgebase');
						}
					}
					else
					{
						$user_role_id = $this->data['session'][0]->user_role_id;					
						$this->data['role_res'] = $this->knowledgebase_model->getRoleByLoginRole($user_role_id);
						$user_level = $this->data['session'][0]->user_level + 1;
						$this->data['user_list'] = $this->knowledgebase_model->getAllUser($user_level);
						$this->show_view_admin('admin/knowledgebase/knowledgebase_add', $this->data);
					}		
				}
				else
				{	
					$user_role_id = $this->data['session'][0]->user_role_id;					
					$this->data['role_res'] = $this->knowledgebase_model->getRoleByLoginRole($user_role_id);
					$user_level = $this->data['session'][0]->user_level + 1;
					$this->data['user_list'] = $this->knowledgebase_model->getAllUser($user_level);
					$this->show_view_admin('admin/knowledgebase/knowledgebase_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}

	/* Delete */
	public function delete_knowledgebase()
	{
		if($this->checkDeletePermission())
		{
			$kb_id = $this->uri->segment(4);
			
			$this->knowledgebase_model->delete_knowledgebase($kb_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/knowledgebase'); 
			}
			else
			{
				$msg = 'Knowledgebase remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/knowledgebase');
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}

	/* Get State List */
	public function getAllUserByRoleID()
	{
		$role_id = $this->input->post('role_id');
		$user_id = $this->input->post('user_id');
		$user_list = $this->knowledgebase_model->getAllUserByRoleID($role_id);

		$html = '';
		if(count($user_list) > 0)
		{
			foreach ($user_list as $u_list) 
			{
				$u_all_level = explode(',', $u_list->user_all_level);
				if(in_array($user_id, $u_all_level))
				{
					$html .= '<option value="'.$u_list->user_id.'">'.$u_list->user_name.'</option>';
				}
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}


	/* get child user */
	public function getChildUser()
	{
		$user_id = $this->input->post('user_id');
		$role_id = $this->input->post('role_id') + 1;

		$user_res = $this->knowledgebase_model->getChildUser($user_id);		
		// echo "<pre>";
		// print_r($user_res);
		// die();
		$html = '';
		if(!empty($user_res))
		{
			if($role_id != $user_res[0]->user_role_id)
			{
				$html .= '<div class="form-group col-md-4"><div class="input text"><label>Child User<span class="text-danger">*</span></label><select class="form-control"  name="user_parent_u_id[]" id="user_parent_u_id" onchange="getChildUser1(this.value, '.$user_id.');"><option value=""></option>';
				foreach ($user_res as $value)
				{
					$html .= '<option value="'.$value->user_id.'">'.$value->user_name.'</option>';
				}
				$html .= '</select></div></div><div id="ch_user_'.$user_id.'"></div>';
			}
		}
		echo $html;
	}

}

/* End of file */?>