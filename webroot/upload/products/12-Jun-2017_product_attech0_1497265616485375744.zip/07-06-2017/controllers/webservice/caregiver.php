<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Caregiver extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/caregiver_model');
	}
	
	/* Details */
	public function viewData()
	{
		$patient_id = $_POST['patient_id'];	
		$pp_id = $_POST['pp_id'];	
		$caregiver_res = $this->caregiver_model->getAllCaregiver($patient_id);
		if(!empty($caregiver_res))
		{
			echo json_encode(array("status"=>1, "caregiver_res"=>$caregiver_res, "patient_id"=>$patient_id, "pp_id"=>$pp_id)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

    public function patientDetailsByID()
	{
		$patient_id = $_POST['patient_id'];	
		$patient_res = $this->caregiver_model->patientDetailsByID($patient_id);
		if(!empty($patient_res))
		{
			echo json_encode(array("status"=>1, "patient_res"=>$patient_res)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

     /* add stakeholder */
	public function addCaregiver()
	{
		$post_cg['pcg_let'] = $_POST['pcg_let'];
		$post_cg['pcg_long'] = $_POST['pcg_long'];
		$post_cg['patient_id'] = $_POST['patient_id'];
		$post_cg['pp_id'] = $_POST['pp_id'];
		$post_cg['user_id'] = $_POST['user_id'];
		$post_cg['user_all_level'] = $_POST['user_all_level'].','.$post_cg['user_id'];
		$post_cg['pcg_patient_name'] = $_POST['pcg_patient_name'];
		$post_cg['pcg_patient_father_name'] = $_POST['pcg_patient_father_name'];
		$post_cg['pcg_patient_dob'] = $_POST['pcg_patient_dob'];
		$post_cg['patient_saksham_id'] = $_POST['patient_saksham_id'];
		$post_cg['pcg_date_of_registration'] = $_POST['pcg_date_of_registration'];
		$post_cg['pcg_place_for_registration'] = $_POST['pcg_place_for_registration'];
		$post_cg['pcg_share_detail_status'] = $_POST['pcg_share_detail_status'];
		$post_cg['pcg_caregiver_name'] = $_POST['pcg_caregiver_name'];
		$post_cg['pcg_relationship_with_patient'] = $_POST['pcg_relationship_with_patient'];
		$post_cg['pcg_caregiver_age'] = $_POST['pcg_caregiver_age'];
		$post_cg['pcg_caregiver_gender'] = $_POST['pcg_caregiver_gender'];
		$post_cg['pcg_past_history_of_TB'] = $_POST['pcg_past_history_of_TB'];
		$post_cg['pcg_suffer_from_TB'] = $_POST['pcg_suffer_from_TB'];
		$post_cg['pcg_category_of_TB'] = $_POST['pcg_category_of_TB'];
		$post_cg['pcg_organ_affected_from_TB'] = $_POST['pcg_organ_affected_from_TB'];
		$post_cg['pcg_treatment_present_outcome'] = $_POST['pcg_treatment_present_outcome'];
		$post_cg['pcg_self_substance_abuse'] = $_POST['pcg_self_substance_abuse'];
		$pcg_self_substance_abuse = explode(',', $post_cg['pcg_self_substance_abuse']);
		if(in_array('Other', $pcg_self_substance_abuse))
		{
			$post_cg['pcg_self_substance_abuse_other'] = $_POST['pcg_self_substance_abuse_other'];
		}
		$post_cg['pcg_patient_substance_abuse'] = $_POST['pcg_patient_substance_abuse'];
		$pcg_patient_substance_abuse = explode(',', $post_cg['pcg_patient_substance_abuse']);
		if(in_array('Other', $pcg_patient_substance_abuse))
		{
			$post_cg['pcg_patient_substance_abuse_other'] = $_POST['pcg_patient_substance_abuse_other'];
		}		
		$post_cg['pcg_counselling_topics'] = $_POST['pcg_counselling_topics'];
		$pcg_counselling_topics = explode(',', $post_cg['pcg_counselling_topics']);
		if(in_array('Other', $pcg_counselling_topics))
		{
			$post_cg['pcg_counselling_topics_other'] = $_POST['pcg_counselling_topics_other'];
		}
		$post_cg['pcg_csw_remarks'] = $_POST['pcg_csw_remarks'];
		$post_cg['pcg_created_date'] = date('Y-m-d');
		$post_cg['pcg_updated_date'] = date('Y-m-d');
		$caregiver_id = $this->caregiver_model->addPatientCaregiverDetails($post_cg);

        if(!empty($caregiver_id))
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

	public function editPatientCareGiver()
	{
		$pcg_id = $_POST['pcg_id'];
		$patient_caregiver_edit = $this->caregiver_model->editPatientCareGiver($pcg_id);
        if(!empty($patient_caregiver_edit))
        {
            echo json_encode(array("status"=>1, "patient_caregiver_edit"=>$patient_caregiver_edit)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

    public function updatePatientCareGiver()
	{
		$post_cg['pcg_id'] = $_POST['pcg_id'];
		$post_cg['patient_id'] = $_POST['patient_id'];
		$post_cg['pp_id'] = $_POST['pp_id'];
		$post_cg['user_id'] = $_POST['user_id'];
		$post_cg['user_all_level'] = $_POST['user_all_level'].','.$post_cg['user_id'];
		$post_cg['pcg_patient_name'] = $_POST['pcg_patient_name'];
		$post_cg['pcg_patient_father_name'] = $_POST['pcg_patient_father_name'];
		$post_cg['pcg_patient_dob'] = $_POST['pcg_patient_dob'];
		$post_cg['patient_saksham_id'] = $_POST['patient_saksham_id'];
		$post_cg['pcg_date_of_registration'] = $_POST['pcg_date_of_registration'];
		$post_cg['pcg_place_for_registration'] = $_POST['pcg_place_for_registration'];
		$post_cg['pcg_share_detail_status'] = $_POST['pcg_share_detail_status'];
		$post_cg['pcg_caregiver_name'] = $_POST['pcg_caregiver_name'];
		$post_cg['pcg_relationship_with_patient'] = $_POST['pcg_relationship_with_patient'];
		$post_cg['pcg_caregiver_age'] = $_POST['pcg_caregiver_age'];
		$post_cg['pcg_caregiver_gender'] = $_POST['pcg_caregiver_gender'];
		$post_cg['pcg_past_history_of_TB'] = $_POST['pcg_past_history_of_TB'];
		$post_cg['pcg_suffer_from_TB'] = $_POST['pcg_suffer_from_TB'];
		$post_cg['pcg_category_of_TB'] = $_POST['pcg_category_of_TB'];
		$post_cg['pcg_organ_affected_from_TB'] = $_POST['pcg_organ_affected_from_TB'];
		$post_cg['pcg_treatment_present_outcome'] = $_POST['pcg_treatment_present_outcome'];
		$post_cg['pcg_self_substance_abuse'] = $_POST['pcg_self_substance_abuse'];
		$pcg_self_substance_abuse = explode(',', $post_cg['pcg_self_substance_abuse']);
		if(in_array('Other', $pcg_self_substance_abuse))
		{
			$post_cg['pcg_self_substance_abuse_other'] = $_POST['pcg_self_substance_abuse_other'];
		}
		else
		{
			$post_cg['pcg_self_substance_abuse_other'] = '';
		}
		$post_cg['pcg_patient_substance_abuse'] = $_POST['pcg_patient_substance_abuse'];
		$pcg_patient_substance_abuse = explode(',', $post_cg['pcg_patient_substance_abuse']);
		if(in_array('Other', $pcg_patient_substance_abuse))
		{
			$post_cg['pcg_patient_substance_abuse_other'] = $_POST['pcg_patient_substance_abuse_other'];
		}	
		else
		{
			$post_cg['pcg_patient_substance_abuse_other'] = '';
		}	
		$post_cg['pcg_counselling_topics'] = $_POST['pcg_counselling_topics'];
		$pcg_counselling_topics = explode(',', $post_cg['pcg_counselling_topics']);
		if(in_array('Other', $pcg_counselling_topics))
		{
			$post_cg['pcg_counselling_topics_other'] = $_POST['pcg_counselling_topics_other'];
		}
		else
		{
			$post_cg['pcg_counselling_topics_other'] = '';
		}
		$post_cg['pcg_csw_remarks'] = $_POST['pcg_csw_remarks'];
		$post_cg['pcg_updated_date'] = date('Y-m-d');
		$pcg_id = $this->caregiver_model->updatePatientCareGiver($post_cg);

        if($pcg_id == '1')
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

	/* Delete */
	public function deletePatientCaregiver()
	{
		$pcg_id = $_POST['pcg_id'];
		$del_res = $this->caregiver_model->delete_patientCaregiver($pcg_id);
        if($del_res == '1')
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
	}	

}

/* End of file */?>