<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Leave extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/leave_model');
	}
	
	/* Details */
	public function viewData()
	{
		$user_id = $_POST['user_id'];		
		$apply_leave_res = $this->leave_model->getApplyLeave($user_id);
		$applied_leave_res = $this->leave_model->getAppliedLeave();
		if(!empty($apply_leave_res) || !empty($applied_leave_res))
		{
			echo json_encode(array("status"=>1, "apply_leave_res"=>$apply_leave_res, "applied_leave_res"=>$applied_leave_res)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

    public function addLeave()
    {
    	
    	$post['leave_lat'] = $_POST['leave_lat'];
    	$post['leave_long'] = $_POST['leave_long'];
    	$post['leave_start_date'] = $_POST['leave_start_date'];
    	$post['leave_end_date'] = $_POST['leave_end_date'];

    	$days_remain1 = (strtotime($post['leave_end_date']) - strtotime($post['leave_start_date'])) / (60 * 60 * 24);
		$days_remain = round($days_remain1);
		$post['leave_day_count'] = $days_remain + 1;
    	$post['leave_reason'] = $_POST['leave_reason'];
		$post['leave_status'] = '1';
		$post['leave_approved_status'] = '0';
		if($post['leave_day_count'] <= 2)
		{
			$post['leave_approved_by'] = $this->data['session'][0]->user_parent_user_id;
		}
		else
		{
			$user_parent_user_id = $this->data['session'][0]->user_parent_user_id;
			$user_detail = $this->leave_model->getParentUserDetails($user_parent_user_id);
			$post['leave_approved_by'] = $user_detail[0]->user_parent_user_id;
		}
		//$post['leave_approved_by'] = $_POST['user_parent_user_id'];
		$post['leave_user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$post['leave_created_date'] = date('Y-m-d');
		$post['leave_updated_date'] = date('Y-m-d');

		$leave_id =  $this->leave_model->addLeave($post);
		if($leave_id)
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

    public function editLeave()
    {
    	$leave_id = $_POST['leave_id'];
    	$leave_edit = $this->leave_model->editLeave($leave_id);
    	if($leave_edit)
		{
			echo json_encode(array("status"=>1, "leave_edit"=>$leave_edit)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

    public function updateLeave()
    {
    	$post['leave_id'] = $_POST['leave_id'];
    	$post['leave_start_date'] = $_POST['leave_start_date'];
    	$post['leave_end_date'] = $_POST['leave_end_date'];
    	$days_remain1 = (strtotime($leave_end_date) - strtotime($leave_start_date)) / (60 * 60 * 24);
		$days_remain = round($days_remain1);
		$post['leave_day_count'] = $days_remain + 1;
    	$post['leave_reason'] = $_POST['leave_reason'];
		$post['leave_status'] = '1';
		$post['leave_approved_status'] = '0';
		if($post['leave_day_count'] <= 2)
		{
			$post['leave_approved_by'] = $this->data['session'][0]->user_parent_user_id;
		}
		else
		{
			$user_parent_user_id = $this->data['session'][0]->user_parent_user_id;
			$user_detail = $this->leave_model->getParentUserDetails($user_parent_user_id);
			$post['leave_approved_by'] = $user_detail[0]->user_parent_user_id;
		}
		$post['leave_user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$post['leave_updated_date'] = date('Y-m-d');
		$update_status =  $this->leave_model->updateLeave($post);
		if($update_status == '1')
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

    /* Delete */
	public function delete_leave()
	{
		$leave_id = $_POST['leave_id'];		
		$del_status = $this->leave_model->delete_leave($leave_id);	
		if($del_status == '1')
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}

	public function approveLeave()
	{
		$leave_id = $_POST['leave_id'];
		$post['leave_approved_status'] = $_POST['leave_approved_status'];
		$post['leave_id'] = $leave_id;
		$post['leave_updated_date'] = date('Y-m-d');
		$appr_status = $this->leave_model->updateApproveLeaveStatus($post);
		if($appr_status == '1')
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}
	
	
}

/* End of file */?>