<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class SakshamPravah extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/sakshampravah_model');
	}
	
	/* Details */
	public function viewData()
	{
		$sakshamPravah_res = $this->sakshampravah_model->getSakshamPravah();
		if(!empty($sakshamPravah_res))
		{
			echo json_encode(array("status"=>1, "sakshamPravah_res"=>$sakshamPravah_res)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

    public function addSakshamPravah()
    {
    	$post['sp_name'] = $_POST['sp_name'];
		$post['sp_owner_name'] = $_POST['sp_owner_name'];
		$post['sp_email'] = $_POST['sp_email'];
		$post['sp_phone'] = $_POST['sp_phone'];
		$post['sp_mobile'] = $_POST['sp_mobile'];
		$post['sp_address'] = $_POST['sp_address'];
		$post['sp_city'] = $_POST['sp_city'];
		$post['sp_state_id'] = $_POST['sp_state_id'];
		$post['sp_country_id'] = $_POST['sp_country_id'];
		$post['sp_postal_code'] = $_POST['sp_postal_code'];
		$post['sp_status'] = $_POST['sp_status'];
		$post['sp_added_by'] = $_POST['sp_added_by'];
		$post['sp_added_by_level'] = $_POST['sp_added_by_level'].','.$post['sp_added_by'];
		$post['sp_created_date'] = date('Y-m-d');
		$post['sp_updated_date'] = date('Y-m-d');
		$sp_id =  $this->sakshampravah_model->addSakshamPravah($post);
		if(!empty($sp_id))
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

    /* Details */
	public function editSakshamPravah()
	{
		$post['sp_id'] = $_POST['sp_id'];
		$sakshamPravah_edit = $this->sakshampravah_model->editSakshamPravah($sp_id);
		if(!empty($sakshamPravah_edit))
		{
			echo json_encode(array("status"=>1, "sakshamPravah_edit"=>$sakshamPravah_edit)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

    public function updateSakshamPravah()
    {
    	$post['sp_id'] = $_POST['sp_id'];
    	$post['sp_name'] = $_POST['sp_name'];
		$post['sp_owner_name'] = $_POST['sp_owner_name'];
		$post['sp_email'] = $_POST['sp_email'];
		$post['sp_phone'] = $_POST['sp_phone'];
		$post['sp_mobile'] = $_POST['sp_mobile'];
		$post['sp_address'] = $_POST['sp_address'];
		$post['sp_city'] = $_POST['sp_city'];
		$post['sp_state_id'] = $_POST['sp_state_id'];
		$post['sp_country_id'] = $_POST['sp_country_id'];
		$post['sp_postal_code'] = $_POST['sp_postal_code'];
		$post['sp_status'] = $_POST['sp_status'];
		$post['sp_added_by'] = $_POST['sp_added_by'];
		$post['sp_added_by_level'] = $_POST['sp_added_by_level'].','.$post['sp_added_by'];
		$post['sp_updated_date'] = date('Y-m-d');
		$sp_id =  $this->sakshampravah_model->updateSakshamPravah($post);
		if(!empty($sp_id))
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

	/* Delete */
	public function delete_sakshamPravah()
	{
		$sp_id = $_POST['sp_id'];			
		$del_status = $this->sakshampravah_model->delete_sakshamPravah($sp_id);
		if($del_status == '1')
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 	
	}

}

/* End of file */?>