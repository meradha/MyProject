<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Knowledgebase extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/knowledgebase_model');
	}
	
	/* Details */
	public function viewData()
	{
		$add_knowledgebase_res = $this->knowledgebase_model->getKnowledgebaseAdded();
		$knowledgebase_res = $this->knowledgebase_model->getknowledgebase();
		
        if(!empty($add_knowledgebase_res) || !empty($knowledgebase_res))
        {
            echo json_encode(array("status"=>1, "add_knowledgebase_res"=>$add_knowledgebase_res, "knowledgebase_res"=>$knowledgebase_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

    public function getknowledgebaseVideoImages()
	{
		$kb_id = $_POST['kb_id'];
		$knowledgebase_video_img_res = $this->knowledgebase_model->getknowledgebaseVideoImages($kb_id);
        if(!empty($knowledgebase_video_img_res))
        {
            echo json_encode(array("status"=>1, "knowledgebase_video_img_res"=>$knowledgebase_video_img_res,)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

     /* Details */
	public function getknowledgebaseViewById()
	{
		$kb_id = $_POST['kb_id'];
		$knowledgebase_res = $this->knowledgebase_model->getknowledgebaseViewById($kb_id);
		$knowledgebase_video_img_res = $this->knowledgebase_model->getknowledgebaseVideoImages($kb_id);		
		 if(!empty($knowledgebase_res))
        {
        	
            echo json_encode(array("status"=>1, "knowledgebase_video_img_res"=>$knowledgebase_video_img_res,"knowledgebase_result"=>$knowledgebase_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }



    /* add stakeholder */
	public function addKnowledgebase()
	{
		
		$post['kb_title'] = $_POST['kb_title'];
		$post['kb_description'] = $_POST['kb_description'];
		$post['kb_status'] = $_POST['kb_status'];
		$post['kb_created_date'] = date('Y-m-d');
		$post['kb_updated'] = date('Y-m-d');		
		$kb_id =  $this->knowledgebase_model->addKnowledgebase($post);

		if(!empty($kb_id))
        {
        	$kb_img = $_FILES["kb_img"]['name'];
            for($i = 0; $i < count($kb_img); $i++)
			{	 
	       		$_FILES['new_file']['name'] = $_FILES['kb_img']['name'][$i];
				$_FILES['new_file']['type'] = $_FILES['kb_img']['type'][$i];
	            $_FILES['new_file']['tmp_name'] = $_FILES['kb_img']['tmp_name'][$i];
	            $_FILES['new_file']['error'] = $_FILES['kb_img']['error'][$i];
	            $_FILES['new_file']['size'] = $_FILES['kb_img']['size'][$i];
	          
	          	$name = 'kb_img';
	          	$imagePath = 'webroot/admin/upload/knowledgebase/';
	           	$temp = explode(".",$_FILES['new_file']['name']);
				$extension = end($temp);
				$filenew =  date('d-M-Y').'_'.str_replace($_FILES['new_file']['name'],$name,$_FILES['new_file']['name']).'_'.time().''.rand(). "." .$extension;  		
				$config['file_name'] = $filenew;
				$config['upload_path'] = $imagePath;
				$config['allowed_types'] = 'GIF | gif | JPE | jpe | JPEG | jpeg | JPG | jpg | PNG | png';
				$this->upload->initialize($config);
				$this->upload->set_allowed_types('*');
				$this->upload->set_filename($config['upload_path'],$filenew);
				if(!$this->upload->do_upload('new_file'))
				{
					$data = array('msg' => $this->upload->display_errors());
				}
				else 
				{ 
					$data = $this->upload->data();	
					$imageName = $data['file_name'];
				}	
	           	$post_img['kb_img_video'] = base_url().''.$imagePath.''.$imageName;
				$post_img['kb_id'] =  $kb_id;
				$post_img['kb_iv_type'] =  'IMAGE';
				$post_img['kb_iv_status'] = '1';
				$post_img['kb_iv_created_date'] = date('Y-m-d');
				$post_img['kb_iv_updated_date'] = date('Y-m-d');
				$this->knowledgebase_model->addKnowledgebaseImagesVideo($post_img);
				if($i=='0')
				{
					$post_u['kb_thumb_img'] = $post_img['kb_img_video'];
					$post_u['kb_id'] = $kb_id;
					$this->knowledgebase_model->updateThumbnailImg($post_u);
				}
			}

			$kb_video = $_POST['kb_video'];
            for($j = 0; $j < count($kb_video); $j++)
			{	 
               	$post_video['kb_img_video'] = $kb_video[$j];
               	$post_video['kb_id'] =  $kb_id;
				$post_video['kb_iv_type'] =  'VIDEO';
				$post_video['kb_iv_status'] = '1';
				$post_video['kb_iv_created_date'] = date('Y-m-d');
				$post_video['kb_iv_updated_date'] = date('Y-m-d');
				$this->knowledgebase_model->addKnowledgebaseImagesVideo($post_video);
			}
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }


	/* Details */
	public function editKnowledgebase()
	{
		$kb_id = $_POST['kb_id'];
		$knowledgebase_edit = $this->knowledgebase_model->editKnowledgebase($kb_id);
		$img_video_res = $this->knowledgebase_model->getKnowledgebaseImagesVideo($kb_id);
        if(!empty($knowledgebase_edit))
        {
            echo json_encode(array("status"=>1, "knowledgebase_edit"=>$knowledgebase_edit, "img_video_res"=>$img_video_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

    public function updateKnowledgebase()
	{
		$post['kb_id'] = $_POST['kb_id'];
		$post['kb_title'] = $_POST['kb_title'];
		$post['kb_description'] = $_POST['kb_description'];
		$post['kb_status'] = $_POST['kb_status'];
		$post['kb_updated'] = date('Y-m-d');
		$update_status = $this->knowledgebase_model->updateKnowledgebase($post);

		$kb_img = $_FILES["kb_img"]['name'];
        for($i = 0; $i < count($kb_img); $i++)
		{	 
       		$_FILES['new_file']['name'] = $_FILES['kb_img']['name'][$i];
			$_FILES['new_file']['type'] = $_FILES['kb_img']['type'][$i];
            $_FILES['new_file']['tmp_name'] = $_FILES['kb_img']['tmp_name'][$i];
            $_FILES['new_file']['error'] = $_FILES['kb_img']['error'][$i];
            $_FILES['new_file']['size'] = $_FILES['kb_img']['size'][$i];
          
          	$name = 'kb_img';
          	$imagePath = 'webroot/admin/upload/knowledgebase/';
           	$temp = explode(".",$_FILES['new_file']['name']);
			$extension = end($temp);
			$filenew =  date('d-M-Y').'_'.str_replace($_FILES['new_file']['name'],$name,$_FILES['new_file']['name']).'_'.time().''.rand(). "." .$extension;  		
			$config['file_name'] = $filenew;
			$config['upload_path'] = $imagePath;
			$config['allowed_types'] = 'GIF | gif | JPE | jpe | JPEG | jpeg | JPG | jpg | PNG | png';
			$this->upload->initialize($config);
			$this->upload->set_allowed_types('*');
			$this->upload->set_filename($config['upload_path'],$filenew);
			if(!$this->upload->do_upload('new_file'))
			{
				$data = array('msg' => $this->upload->display_errors());
			}
			else 
			{ 
				$data = $this->upload->data();	
				$imageName = $data['file_name'];
			}	
           	$post_img['kb_img_video'] = base_url().''.$imagePath.''.$imageName;
			$post_img['kb_id'] = $_POST['kb_id'];
			$post_img['kb_iv_type'] =  'IMAGE';
			$post_img['kb_iv_status'] = '1';
			$post_img['kb_iv_created_date'] = date('Y-m-d');
			$post_img['kb_iv_updated_date'] = date('Y-m-d');
			$this->knowledgebase_model->addKnowledgebaseImagesVideo($post_img);
			if($i=='0')
			{
				$post_u['kb_thumb_img'] = $post_img['kb_img_video'];
				$post_u['kb_id'] = $_POST['kb_id'];
				$this->knowledgebase_model->updateThumbnailImg($post_u);
			}
		}

		$this->knowledgebase_model->deleteKnowledgebaseVideo($_POST['kb_id']);
		$kb_video = $_POST['kb_video'];
        for($j = 0; $j < count($kb_video); $j++)
		{	 
           	$post_video['kb_img_video'] = $kb_video[$j];
           	$post_video['kb_id'] =  $_POST['kb_id'];
			$post_video['kb_iv_type'] =  'VIDEO';
			$post_video['kb_iv_status'] = '1';
			$post_video['kb_iv_created_date'] = date('Y-m-d');
			$post_video['kb_iv_updated_date'] = date('Y-m-d');
			$this->knowledgebase_model->addKnowledgebaseImagesVideo($post_video);
		}
		if($update_status)
		{
		 	echo json_encode(array("status"=>1)); 
		}
        else
        {
            echo json_encode(array("status"=>0)); 
        } 

	}

	/* Delete */
	public function delete_knowledgebase()
	{
		$kb_id = $_POST['kb_id'];
		$dal_status = $this->knowledgebase_model->delete_knowledgebase($kb_id);	
		if($dal_status)
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}

	/* Get State List */
	public function getAllUserByRoleID()
	{
		$role_id = $_POST['role_id'];
		$user_id = $_POST['user_id'];
		$user_list = $this->knowledgebase_model->getAllUserByRoleID($role_id);
		if($user_list)
		{
			echo json_encode(array("status"=>1, "user_list"=>$user_list)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}		
	}


	/* get child user */
	public function getChildUser()
	{
		$role_id = $_POST['role_id'];
		$user_id = $_POST['user_id'] + 1;
		$user_res = $this->knowledgebase_model->getChildUser($user_id);		
		if($user_res)
		{
			echo json_encode(array("status"=>1, "user_res"=>$user_res)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}	
	}

}

/* End of file */?>