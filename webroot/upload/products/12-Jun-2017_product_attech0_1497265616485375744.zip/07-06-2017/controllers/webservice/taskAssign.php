<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class TaskAssign extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/taskassign_model');
	}
	
	
	/* Details */
	public function viewData()
	{
		$user_id = $_POST['user_id'];
		$assign_by_task_res = $this->taskassign_model->getTaskAssignBy($user_id);
		$approved_task_res = $this->taskassign_model->getTaskAssignApproved();
		if(!empty($assign_by_task_res) || $approved_task_res)
		{
			echo json_encode(array("status"=>1, "assign_by_task_res"=>$assign_by_task_res, "approved_task_res"=>$approved_task_res)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

    public function getTaskUser()
    {
    	$user_role_id = $_POST['user_role_id'];					
		$role_res = $this->taskassign_model->getRoleByLoginRole($user_role_id);
		$task_res = $this->taskassign_model->getAllTask();
		if(!empty($role_res) || !empty($task_res))
		{
			echo json_encode(array("status"=>1, "role_res"=>$role_res, "task_res"=>$task_res)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

    public function getAllUserByRoleID()
	{
		$role_id = $_POST['role_id'];
		//$user_id = $_POST['user_id'];
		$user_list = $this->taskassign_model->getAllUserByRoleID($role_id);
		if(!empty($user_list))
		{
			echo json_encode(array("status"=>1, "user_list"=>$user_list)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}

	public function addTaskAssign()
	{
		$post['ta_let'] = $_POST['ta_let'];
		$post['ta_long'] = $_POST['ta_long'];

		$ta_assign_to_user = $_POST['ta_assign_to'];
		$post['ta_assign_to_role_id'] = $_POST['ta_assign_to_role_id'];
		$post['ta_assign_to'] = $_POST['ta_assign_to'];
		$post['ta_assign_by'] =  $_POST['user_id'];
		$post['task_id'] = $_POST['task_id'];
		$task_form_res = $this->taskassign_model->getTaskFormByTaskID($post['task_id']);
		$post['taskform_id'] = $task_form_res[0]->taskform_id;
		$post['ta_task_start_date'] = $_POST['ta_task_start_date'];
		$post['ta_task_end_date'] = $_POST['ta_task_end_date'];
		$post['ta_low_case_area_task'] = $_POST['ta_low_case_area_task'];
		$post['ta_high_case_area_task'] = $_POST['ta_high_case_area_task'];
		$post['ta_total_task'] = $_POST['ta_total_task'];
		$post['ta_remaining_task'] = $_POST['ta_total_task'];
		$post['ta_status'] = $_POST['ta_status'];
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$post['user_id'];
		$user_level_res = $this->taskassign_model->getUserLevel($post['ta_assign_to']);
		$post['user_all_level_assign_to'] = $user_level_res[0]->user_all_level.','.$post['ta_assign_to'];
		$post['ta_created_date'] = date('Y-m-d');
		$post['ta_updated_date'] = date('Y-m-d');
		$ta_id =  $this->taskassign_model->addTaskAssign($post);
		
		$post_t['task_id'] = $post['task_id'];
		$post_t['taskform_id'] = $task_form_res[0]->taskform_id;
		$post_t['ttc_asign_user_id'] = $post['ta_assign_to'];
		$post_t['ta_id'] = $ta_id;
		$post_t['ttc_total_target'] = $post['ta_total_task'];
		$post_t['ttc_hca_total_target'] = $post['ta_high_case_area_task'];
		$post_t['ttc_lca_total_target'] = $post['ta_low_case_area_task'];
		$old_task_res = $this->taskassign_model->getTaskTargetCountByAssignUserId($ta_assign_to_user, $post_t['taskform_id']);
		if(!empty($old_task_res))
		{
			$post_t['ttc_r_target'] = $old_task_res[0]->ttc_r_target + $post_t['ttc_total_target'];
			$post_t['ttc_r_hca_target'] = $old_task_res[0]->ttc_r_hca_target + $post_t['ttc_hca_total_target'];
			$post_t['ttc_r_lca_target'] = $old_task_res[0]->ttc_r_lca_target + $post_t['ttc_lca_total_target'];
			$post_t['ttc_o_total'] = $old_task_res[0]->ttc_o_total;
			$post_t['ttc_o_lca_target'] = $old_task_res[0]->ttc_o_lca_target;
			$post_t['ttc_o_hca_target'] = $old_task_res[0]->ttc_o_hca_target;
		}
		else
		{
			$post_t['ttc_r_target'] = $post_t['ttc_total_target'];
			$post_t['ttc_r_hca_target'] = $post_t['ttc_hca_total_target'];
			$post_t['ttc_r_lca_target'] = $post_t['ttc_lca_total_target'];
		}
		$this->taskassign_model->addTaskTarget($post_t);
		if($ta_id)
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}

	public function editTaskAssign()
	{
		$user_role_id = $_POST['user_role_id'];
		$ta_id = $_POST['ta_id'];
		$taskassign_edit = $this->taskassign_model->editTaskAssign($ta_id);
		$role_res = $this->taskassign_model->getRoleByLoginRole($user_role_id);
		$task_res = $this->taskassign_model->getAllTask();
		if(!empty($taskassign_edit))
		{
			echo json_encode(array("status"=>1, "taskassign_edit"=>$taskassign_edit, "role_res"=>$role_res, "task_res"=>$task_res)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}

	public function updateTaskAssign()
	{
		$post['ta_id'] = $_POST['ta_id'];
		$post['task_id'] = $_POST['task_id'];
		$post['ta_task_start_date'] = $_POST['ta_task_start_date'];
		$post['ta_task_end_date'] = $_POST['ta_task_end_date'];
		$post['ta_total_task'] = $_POST['ta_total_task'];
		$post['ta_low_case_area_task'] = $_POST['ta_low_case_area_task'];
		$post['ta_high_case_area_task'] = $_POST['ta_high_case_area_task'];
		$post['ta_status'] = $_POST['ta_status'];
		$post['ta_remaining_task'] = $_POST['ta_total_task'];
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$post['user_id'];
		$post['ta_updated_date'] = date('Y-m-d');
		$update_status = $this->taskassign_model->updateTaskAssign($post);
		if($update_status == '1')
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}
	
	/* Delete */
	public function delete_taskAssign()
	{
		$ta_id = $_POST['ta_id'];		
		$del_status = $this->taskassign_model->delete_taskAssign($ta_id);	
		if($del_status == '1')
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}

	public function getTaskDetailsByTaskID()
	{
		$task_id = $_POST['task_id'];
		$task_details = $this->taskassign_model->getTaskDetailsByTaskID($task_id);
		if(!empty($task_details))
		{
			echo json_encode(array("status"=>1, "task_details"=>$task_details)); 
		}
		else
		{
			echo json_encode(array("status"=>0, "task_details"=>array())); 
		}
	}
	
	public function getTaskFormDetail()
	{
		$ta_id = $_POST['ta_id'];
		$task_id = $_POST['task_id'];
		$task_form_details = $this->taskassign_model->getTaskFormDetail($task_id);
		if(!empty($task_form_details))
		{
			echo json_encode(array("status"=>1, "task_form_details"=>$task_form_details)); 
		}
		else
		{
			echo json_encode(array("status"=>0, "task_form_details"=>array())); 
		}
	}


	public function sendTaskReportDetails()
	{
		$ta_id = $_POST['ta_id'];
		$task_id = $_POST['task_id'];
		$task_form_details = $this->taskassign_model->getTaskFormDetail($task_id);
		$send_report_res = $this->taskassign_model->getAllSendReport($ta_id);
		if(!empty($send_report_res))
		{
			echo json_encode(array("status"=>1, "send_report_res"=>$send_report_res, "task_form_details"=>$task_form_details)); 
		}
		else
		{
			echo json_encode(array("status"=>0, "send_report_res"=>array(), "task_form_details"=>array())); 
		}
	}


	public function getAllHelthPostArea()
	{
		$health_post_area = $this->taskassign_model->getAllHelthPostArea();
		if(!empty($health_post_area))
		{
			echo json_encode(array("status"=>1, "health_post_area"=>$health_post_area)); 
		}
		else
		{
			echo json_encode(array("status"=>0, "health_post_area"=>array())); 
		}
	}


	public function addTaskAssignedReport()
	{
		$post['tca_let'] = $_POST['tca_let'];
		$post['tca_long'] = $_POST['tca_long'];
		$post['ta_id'] = $_POST['ta_id'];
		$post['task_id'] = $_POST['task_id'];
		$post['tca_activity_place'] = $_POST['tca_activity_place'];
		$post['tca_activity_subarea'] = $_POST['tca_activity_subarea'];
		$post['tca_activity_date'] = $_POST['tca_activity_date'];
		$post['tca_activity_start_time'] = $_POST['tca_activity_start_time'];
		$post['tca_activity_end_time'] = $_POST['tca_activity_end_time'];
		$post['tca_type_of_community_activity'] = $_POST['tca_type_of_community_activity'];
		$post['tca_type_of_community_activity_other'] = $_POST['tca_type_of_community_activity_other'];
		$post['tca_focus_population'] = $_POST['tca_focus_population'];
		$post['tca_name_of_stakeholder'] = $_POST['tca_name_of_stakeholder'];
		$post['tca_area'] = $_POST['tca_area'];
		$post['helthpostarea_id'] = $_POST['helthpostarea_id'];
		$post['tca_total_no_attendess'] = $_POST['tca_total_no_attendess'];
		$post['tca_no_of_presumptive_tb_case'] = $_POST['tca_no_of_presumptive_tb_case'];
		$post['tca_covered_topics'] = $_POST['tca_covered_topics'];
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$post['user_id'];
		$post['tca_created_date'] = date('Y-m-d');
		$post['tca_updated_date'] = date('Y-m-d');
		$tca_id =  $this->taskassign_model->addTaskAssignedReport($post);
		if($tca_id)
		{
			$target_count_val = $this->taskassign_model->getTaskTargetCount($ta_id);
			if(!empty($target_count_val))
			{

				$post_tc['tca_area'] = $post['tca_area'];
				$post_tc['ta_id'] = $ta_id;
				if($target_count_val[0]->ttc_r_target != 0)
				{
					$post_tc['ttc_r_target'] = $target_count_val[0]->ttc_r_target - 1;
				}
				else
				{
					$post_tc['ttc_r_target'] = '0';
				}
				
				if($post_tc['tca_area'] == 'Low case burden area')
				{
					if($target_count_val[0]->ttc_r_target != 0)
					{
						$post_tc['ttc_r_lca_target'] = $target_count_val[0]->ttc_r_lca_target - 1;
					}
					else
					{
						$post_tc['ttc_r_lca_target'] = '0';
					}
					
				}
				else
				{
					if($target_count_val[0]->ttc_r_target != 0)
					{
						$post_tc['ttc_r_hca_target'] = $target_count_val[0]->ttc_r_hca_target - 1;
					}
					else
					{
						$post_tc['ttc_r_hca_target'] = '0';
					}
				}
				$this->taskassign_model->updateTaskTargetCount($post_tc);

				$taskassign_edit = $this->taskassign_model->editTaskAssign($ta_id);
				if(!empty($taskassign_edit))
				{
					if($taskassign_edit[0]->ta_remaining_task != 0)
					{
						$post_t_a_tc['ta_remaining_task'] = $taskassign_edit[0]->ta_remaining_task - 1;
						$post_t_a_tc['ta_id'] = $ta_id;
						$this->taskassign_model->updateTaskAssignTargetCount($post_t_a_tc);
					}
					}

			}
			echo json_encode(array("status"=>1, "tca_id"=>$tca_id)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}

	public function addImages()
	{
		$image_name = urldecode($_FILES["tca_img_name"]["name"]);
		$name = 'tca_img_name';
      	$imagePath = 'webroot/admin/upload/task/CommunityAwareness/';
       	$temp = explode(".",$_FILES['tca_img_name']['name']);
		$extension = end($temp);
		$filenew =  date('d-M-Y').'_'.str_replace($_FILES['tca_img_name']['name'],$name,$_FILES['tca_img_name']['name']).'_'.time().''.rand(). "." .$extension;  		
		$config['file_name'] = $filenew;
		$config['upload_path'] = $imagePath;
		$config['allowed_types'] = 'GIF | gif | JPE | jpe | JPEG | jpeg | JPG | jpg | PNG | png';
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		$this->upload->set_filename($config['upload_path'],$filenew);
		
		if(!$this->upload->do_upload('tca_img_name'))
		{
			$data = array('msg' => $this->upload->display_errors());
		}
		else 
		{ 
			$data = $this->upload->data();	
			$imageName = $data['file_name'];
		}			
		$post_img['tca_img_name'] = $imagePath.''.$image_name;
		$post_img['tca_id'] =  $_GET['tca_id'];
		$post_img['tca_img_status'] = '1';
		$post_img['tca_let'] = $_GET['tca_let'];
		$post_img['tca_long'] = $_GET['tca_long'];
		$post_img['tca_img_created_date'] = date('Y-m-d');
		$post_img['tca_img_updated_date'] = date('Y-m-d');
		$this->taskassign_model->addTaskAssignedReportImg($post_img);
	}

	public function editTaskAssignedReport()
	{
		$tca_id = $_POST['tca_id'];
		$taskassignreport_edit = $this->taskassign_model->editTaskAssignReport($tca_id);
		$taskassignreport_edit_img = $this->taskassign_model->editTaskAssignReportImg($tca_id);
		if(!empty($taskassignreport_edit) || !empty($taskassignreport_edit_img))
		{
			echo json_encode(array("status"=>1, "taskassignreport_edit"=>$taskassignreport_edit, "taskassignreport_edit_img"=>$taskassignreport_edit_img)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}

	public function updateTaskAssignedReport()
	{
		$post['tca_id'] = $_POST['tca_id'];
		$post['ta_id'] = $_POST['ta_id'];
		$post['task_id'] = $_POST['task_id'];
		$post['tca_activity_place'] = $_POST['tca_activity_place'];
		$post['tca_activity_subarea'] = $_POST['tca_activity_subarea'];
		$post['tca_activity_date'] = $_POST['tca_activity_date'];
		$post['tca_activity_start_time'] = $_POST['tca_activity_start_time'];
		$post['tca_activity_end_time'] = $_POST['tca_activity_end_time'];
		$post['tca_type_of_community_activity'] = $_POST['tca_type_of_community_activity'];
		$post['tca_type_of_community_activity_other'] = $_POST['tca_type_of_community_activity_other'];
		$post['tca_focus_population'] = $_POST['tca_focus_population'];
		$post['tca_name_of_stakeholder'] = $_POST['tca_name_of_stakeholder'];
		$post['tca_area'] = $_POST['tca_area'];
		$post['helthpostarea_id'] = $_POST['helthpostarea_id'];
		$post['tca_total_no_attendess'] = $_POST['tca_total_no_attendess'];
		$post['tca_no_of_presumptive_tb_case'] = $_POST['tca_no_of_presumptive_tb_case'];
		$post['tca_covered_topics'] = $_POST['tca_covered_topics'];
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$post['user_id'];
		$post['tca_updated_date'] = date('Y-m-d');
		$update_status = $this->taskassign_model->updateTaskAssignReport($post);
		if($update_status == '1')
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}

	/* Delete */
	public function delete_taskASsignedSendReport()
	{
		$ta_id = $_POST['ta_id'];
		$task_id = $_POST['task_id'];
		$tca_id = $_POST['tca_id'];
		$del_status = $this->taskassign_model->delete_taskASsignedSendReport($tca_id);
		if($del_status == '1')
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}
}

/* End of file */?>