<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Chat extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/chat_model');
	}
	
	/* Dashboard Show */
	public function viewData()
	{	
		$chat_res = $this->chat_model->getAllChat();
		if(!empty($chat_res))
		{
			echo json_encode(array("status"=>1, "chat_res"=>$chat_res)); 
		}
		else
		{
			echo json_encode(array("status"=>0, "chat_res"=>array())); 
		}
    }

    public function addChat()
	{
		$post['chat_let'] = $_POST['chat_let'];
		$post['chat_long'] = $_POST['chat_long'];
		$post['chat_avatar_name'] = $_POST['chat_avatar_name'];
		$post['chat_text_message'] = $_POST['chat_text_message'];
		$post['chat_user_name'] = $_POST['chat_user_name'];
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'];
		$post['chat_date'] = $_POST['chat_date'];
		$post['chat_time'] = $_POST['chat_time'];
		$chat_id = $this->chat_model->addChat($post);
        if(!empty($chat_id))
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
	}
    
}

/* End of file */?>