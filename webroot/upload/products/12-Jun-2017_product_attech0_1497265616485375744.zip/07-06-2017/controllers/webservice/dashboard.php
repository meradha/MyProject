<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Dashboard extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/dashboard_model');
	}

	public function viewData()
	{	
		$role_list = $this->dashboard_model->getAllRole();
		$stakeholder_list = $this->dashboard_model->getAllStakeHolder();
		$saksham_sathi_list = $this->dashboard_model->getAllSakshamSathi();
		if(!empty($role_list) || !empty($stakeholder_list) || !empty($saksham_sathi_list))
		{
			echo json_encode(array("status"=>1, "role_list"=>$role_list, "stakeholder_list"=>$stakeholder_list, "saksham_sathi_list"=>$saksham_sathi_list)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

	public function userListByRoleID()
	{	
		$role_id = $_POST['role_id'];
		$user_list = $this->dashboard_model->getUserByRoleID($role_id);
		if(!empty($user_list))
		{
			echo json_encode(array("status"=>1, "user_list"=>$user_list)); 
		}
		else
		{
			echo json_encode(array("status"=>0, "user_list"=>array())); 
		}
    }

	public function stakeHolderBySakshamSathi()
	{	
		$user_id = $_POST['user_id'];
		$stakeholder_res = $this->dashboard_model->getAllStakeHolderBySakshamSathiID($user_id);
		if(!empty($stakeholder_res))
		{
			echo json_encode(array("status"=>1, "stakeholder_res"=>$stakeholder_res)); 
		}
		else
		{
			echo json_encode(array("status"=>0, "stakeholder_res"=>array())); 
		}
    }

	public function powerStucture()
	{	
		$power_structure_hh = $this->dashboard_model->getPowerStuctureHH();
        $power_structure_hl = $this->dashboard_model->getPowerStuctureHL();
        $power_structure_lh = $this->dashboard_model->getPowerStuctureLH();
        $power_structure_ll = $this->dashboard_model->getPowerStuctureLL();
		if(!empty($power_structure_hh) || !empty($power_structure_hl) || !empty($power_structure_lh) || !empty($power_structure_ll))
		{
			echo json_encode(array("status"=>1, "power_structure_hh"=>$power_structure_hh, "power_structure_hl"=>$power_structure_hl, "power_structure_lh"=>$power_structure_lh, "power_structure_ll"=>$power_structure_ll)); 
		}
		else
		{
			echo json_encode(array("status"=>0, "power_structure_hh"=>array(), "power_structure_hl"=>array(), "power_structure_lh"=>array(), "power_structure_ll"=>array())); 
		}
    }

    public function focusPopulation()
	{	
		$focus_population_res = $this->dashboard_model->getFocusPopulation();
		if(!empty($focus_population_res))
		{
			echo json_encode(array("status"=>1, "focus_population_res"=>$focus_population_res)); 
		}
		else
		{
			echo json_encode(array("status"=>0, "focus_population_res"=>array())); 
		}
    }
	
	public function nameOfWard()
	{	
		$name_of_ward_e = $this->dashboard_model->getNameOfWardCountEast();
        $name_of_ward_w = $this->dashboard_model->getNameOfWardCountWest();
		if(!empty($name_of_ward_e) || !empty($name_of_ward_w))
		{
			echo json_encode(array("status"=>1, "name_of_ward_e"=>$name_of_ward_e, "name_of_ward_w"=>$name_of_ward_w)); 
		}
		else
		{
			echo json_encode(array("status"=>0, "name_of_ward_e"=>array(), "name_of_ward_w"=>array())); 
		}
    }

}

/* End of file */?>