<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/user_model');
	}
	
    /* Login */
    public function login()
    {       
        $post['user_email'] = $_GET['user_email'];
        $post['user_password'] = md5($_GET['user_password']);
        $post['user_device_id'] = $_GET['user_device_id']; 
        $user_details_status = $this->user_model->CheckUserStatus($post);
        // echo "<pre>";
        // print_r($user_details_status);die();

        if(!empty($user_details_status))
        {
            $user_login_check = $this->user_model->CheckUserLogin($post);   
            if(!empty($user_login_check))
            {
                $post['user_id'] = $user_login_check[0]->user_id;
                $post['user_login_status'] = 1; 
                $this->user_model->updateDeviceId($post);
                $user_details = $this->user_model->getUserDetails($post['user_id']); 
                echo json_encode(array("status"=>1,"details"=>$user_details));
            }
            else
            {
                echo json_encode(array("status"=>0));
            }
        }
        else
        {
            echo json_encode(array("status"=>2));
        }
    }

    public function menus()
    {
        $role_id = $_GET['role_id']; 

        if($role_id)
        {
            $menu_list = $this->user_model->getAllTabAsPerRole($role_id);
            if(!empty($menu_list))
            {
                echo json_encode(array("status"=>1,"menu_list"=>$menu_list));
            }
            else
            {
                echo json_encode(array("status"=>0));
            }
        }
        else
        {
            echo json_encode(array("status"=>2));
        }
    }

    public function logout()
    {
        $post['user_device_id'] = $_GET['user_device_id']; 
        $post['user_id'] = $_GET['user_id'];
        $post['user_log_status'] = 0; 
        $res = $this->user_model->updateDeviceId($post);
        if($res=='1')
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
    }


    // public function redirectService()
    // {
    //     $webservice_base_url = 'http://192.168.0.119/tiss/webservice/';
    //     $controller_name = $_GET['controller_name']; 
    //     $user_role_id = $_GET['user_role_id']; 
    //     // echo $webservice_base_url;
    //     // die();
    //     $controller_res = $this->user_model->checkControllerName($controller_name);
    //     if(!empty($controller_res))
    //     {
    //         redirect($webservice_base_url.''.$controller_name.'/viewData/'.$user_role_id);
    //     }
    //     else
    //     {
    //         echo json_encode(array("status"=>0)); 
    //     }
    // }



    /**************** USER CONTROLLER **************/
    public function viewData()
    {         
        $role_list = $this->user_model->getAllRole();
        if(!empty($role_list))
        {
            echo json_encode(array("status"=>1, "role_list"=>$role_list)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }


    public function getAllUserByRole()
    {
        $role_id = $_REQUEST['role_id']; 
        $user_res = $this->user_model->getAllUserByRole($role_id);
        if(!empty($user_res))
        {
            echo json_encode(array("status"=>1, "user_details"=>$user_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
    }

    public function getParentUserName()
    {
        $user_parent_user_id = $_REQUEST['user_parent_user_id']; 
        $parent_user_name = $this->user_model->getParentUserName($user_parent_user_id);
        if(!empty($parent_user_name))
        {
            echo json_encode(array("status"=>1, "parent_user_name"=>$parent_user_name)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
    }

    public function getAllRole()
    {
        $role_list = $this->user_model->getAllRole();
        if(!empty($role_list))
        {
            echo json_encode(array("status"=>1, "role_list"=>$role_list)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }


    public function getAllUserByLevel()
    {
        $user_level = $_REQUEST['user_level'] + 1; 
        $user_res = $this->user_model->getAllUser($user_level);
        if(!empty($user_res))
        {
            echo json_encode(array("status"=>1, "user_details"=>$user_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
    }

    public function getChildUser()
    {
        $user_id = $_POST['user_id']; 
        $user_res = $this->user_model->getChildUser($user_id);
        if(!empty($user_res))
        {
            echo json_encode(array("status"=>1, "user_details"=>$user_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
    }

    public function addUser()
    {
        $user_id = $_POST['user_id'];
        $post['user_role_id'] = $_POST['user_role_id'];

        $user_parent_u_id = $_POST['user_parent_u_id'];  

        $u_all_level = '';
        $user_parent_id = '';
        $t_parent_user = count($user_parent_u_id) -1;
        $u_de = $this->user_model->getUserDetails($user_parent_u_id[$t_parent_user]);

        if(!empty($u_de))
        {
            $post['user_all_level'] = $u_de[0]->user_all_level.','.$u_de[0]->user_id;
            $user_parent_id = $u_de[0]->user_id;
        }
        else
        {
            $u_de = $this->user_model->getUserDetails($user_id);
            if($u_de[0]->user_all_level == 0)
            {
                $post['user_all_level'] = $u_de[0]->user_id;
                $user_parent_id = $u_de[0]->user_id;
            }
            else
            {
                $post['user_all_level'] = $u_de[0]->user_all_level.','.$u_de[0]->user_id;
                $user_parent_id = $user_id;
            }
            
        }
        $post['user_parent_user_id'] = $user_parent_id;
        $post['user_let'] = $_POST['user_let'];
        $post['user_long'] = $_POST['user_long'];
        $post['user_email'] = $_POST['user_email'];
        $post['user_phone'] = $_POST['user_phone'];
        $post['user_uname'] = $_POST['user_uname'];
        $post['user_password'] = md5($_POST['user_password']);
        $post['user_gender'] = $_POST['user_gender'];
        $post['user_dob'] = $_POST['user_dob'];
        $post['user_level'] = $_POST['user_role_id'];
        $post['user_status'] = $_POST['user_status'];
        $post['added_by'] = $_POST['user_id']; 
        $post['user_created_date'] = date('Y-m-d');
        $post['user_updated_date'] = date('Y-m-d');
        $new_user_id =  $this->user_model->addUser($post);
        if(!empty($new_user_id))
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
    }

    public function editUser()
    {
        $user_id = $_POST['user_id']; 
        $edit_user_res = $this->user_model->editUser($user_id);
        if(!empty($edit_user_res))
        {
            echo json_encode(array("status"=>1, "user_details"=>$edit_user_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
    }

    public function updateUser()
    {
        $user_id = $_POST['user_id'];
        $post['user_id']  = $_POST['user_id'];
        $post['user_role_id'] = $_POST['user_role_id'];

        $user_parent_u_id = $_POST['user_parent_u_id'];  
        $u_all_level = '';
        $user_parent_id = '';
        $t_parent_user = count($user_parent_u_id) -1;
        $u_de = $this->user_model->getUserDetails($user_parent_u_id[$t_parent_user]);

        if(!empty($u_de))
        {
            $post['user_all_level'] = $u_de[0]->user_all_level.','.$u_de[0]->user_id;
            $user_parent_id = $u_de[0]->user_id;
        }
        else
        {
            $u_de = $this->user_model->getUserDetails($user_id);
            if($u_de[0]->user_all_level == 0)
            {
                $post['user_all_level'] = $u_de[0]->user_id;
                $user_parent_id = $u_de[0]->user_id;
            }
            else
            {
                $post['user_all_level'] = $u_de[0]->user_all_level.','.$u_de[0]->user_id;
                $user_parent_id = $user_id;
            }
            
        }
        $post['user_parent_user_id'] = $user_parent_id; 
        $post['user_name'] = $_POST['user_name'];
        $post['user_email'] = $_POST['user_email'];
        $post['user_phone'] = $_POST['user_phone'];
        $post['user_uname'] = $_POST['user_uname'];        
        $post['user_gender'] = $_POST['user_gender'];
        $post['user_dob'] = $_POST['user_dob'];
        $post['user_level'] = $_POST['user_role_id'];
        $post['user_status'] = $_POST['user_status'];
        $post['added_by'] = $_POST['user_id']; 
        $post['user_updated_date'] = date('Y-m-d');
        $new_user_id =  $this->user_model->updateUser($post);
        if($new_user_id == '1')
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
    }

    public function deleteUser()
    {
        $user_id = $_POST['user_id']; 
        $del_res = $this->user_model->deleteUser($user_id);
        if($del_res == '1')
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }


   /* Add User Live Location */
   public function addLiveLocation()
   {
       $post['user_id'] = $_POST['user_id']; 
       $post['location_date'] = date('Y-m-d H:i:s');   
       $post['location_lat'] = $_POST['location_lat']; 
       $post['location_long'] = $_POST['location_long']; 
       $location_result = $this->user_model->addLiveLocation($post);
       if(!empty($location_result))
       {
           echo json_encode(array("status"=>1)); 
       }
       else
       {
           echo json_encode(array("status"=>0)); 
       }
   }
}
/* End of file */