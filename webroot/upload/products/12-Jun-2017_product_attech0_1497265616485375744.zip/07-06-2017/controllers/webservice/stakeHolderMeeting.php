<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class StakeHolderMeeting extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/stakeholdermeeting_model');
	}
		
	/* Details */
	public function viewData()
	{
		if(!empty($_POST['stakeholder_id']))
		{
			$stakeholder_id = $_POST['stakeholder_id']; 
			$stakeholder_meeting_res = $this->stakeholdermeeting_model->getStakeHolderMeetingByStakeHolderID($stakeholder_id);
		}
		else
		{
			$stakeholder_meeting_res = $this->stakeholdermeeting_model->getStakeHolderMeeting();
		}
        if(!empty($stakeholder_meeting_res))
        {
            echo json_encode(array("status"=>1, "stakeholder_meeting_res"=>$stakeholder_meeting_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
    }
	
    /* Details */
	public function getStakeholderList()
	{
		if(!empty($_POST['stakeholder_id']))
		{
			$stakeholder_id = $_POST['stakeholder_id']; 
			$stakeholder_res = $this->stakeholdermeeting_model->getStakeHolderDetails($stakeholder_id);
			$healthpostarea_list = $this->stakeholdermeeting_model->getAllHealthpostArea();
		}
		else
		{
			$stakeholder_res = $this->stakeholdermeeting_model->getAllStakeHolderList();
			$healthpostarea_list = $this->stakeholdermeeting_model->getAllHealthpostArea();
		}
        if(!empty($stakeholder_res))
        {
            echo json_encode(array("status"=>1, "stakeholder_res"=>$stakeholder_res, "healthpostarea_list"=>$healthpostarea_list)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
    }

    public function addMeeting()
    {    	
    	$post['shm_let'] = $_POST['shm_let'];
    	$post['shm_long'] = $_POST['shm_long'];    	
    	$post['stakeholder_id'] = $_POST['stakeholder_id'];
    	$post['shm_no_of_participants'] = $_POST['shm_no_of_participants'];
		$post['shm_meting_location'] = $_POST['shm_meting_location'];
		$post['shm_meeting_date'] = $_POST['shm_meeting_date'];
		$post['shm_meeting_time_from'] = $_POST['shm_meeting_time_from'];
		$post['shm_meeting_time_to'] = $_POST['shm_meeting_time_to'];
		$post['shm_order_of_meeting_this_month'] = $_POST['shm_order_of_meeting_this_month'];
		$post['shm_no_of_meeting_before_month'] = $_POST['shm_no_of_meeting_before_month'];
		$post['shm_met_status_before_month'] = $_POST['shm_met_status_before_month'];
		$post['shm_purpose_of_meeting'] = $_POST['shm_purpose_of_meeting'];
		$post['shm_purpose_of_meeting_other'] = $_POST['shm_purpose_of_meeting_other'];
		$post['shm_point_of_discussion'] = $_POST['shm_point_of_discussion'];
		$post['shm_point_of_discussion_other'] = $_POST['shm_point_of_discussion_other'];
		$post['shm_track_with_agenda'] = $_POST['shm_track_with_agenda'];
		$post['shm_participated_status'] = $_POST['shm_participated_status'];
		$post['shm_achived_purpose'] = $_POST['shm_achived_purpose'];
		$post['shm_clearified_next_step'] = $_POST['shm_clearified_next_step'];
		$post['shm_stakeholde_work_status'] = $_POST['shm_stakeholde_work_status'];
		
		$post['shm_meeting_time_wroth_spent'] = $_POST['shm_meeting_time_wroth_spent'];
		$post['shm_power'] = $_POST['shm_power'];
		$post['shm_interest'] = $_POST['shm_interest'];
		$post['shm_organization_classified'] = $_POST['shm_organization_classified'];
		$post['shm_application_social_protection_scheme_status'] = $_POST['shm_application_social_protection_scheme_status'];
		$post['shm_application_social_protection_scheme'] = $_POST['shm_application_social_protection_scheme'];
		$post['shm_purpose_of_next_meeting'] = $_POST['shm_purpose_of_next_meeting'];
		$post['shm_date_of_next_meeting'] = $_POST['shm_date_of_next_meeting'];
		$post['shm_time_of_next_meeting'] = $_POST['shm_time_of_next_meeting'];
		$post['shm_date_of_community_activity'] = $_POST['shm_date_of_community_activity'];
		$post['shm_time_of_community_activity'] = $_POST['shm_time_of_community_activity'];
		$post['shm_venue_of_community_activity'] = $_POST['shm_venue_of_community_activity'];
		$post['shm_stakeholder_help'] = $_POST['shm_stakeholder_help'];		
		$post['helthpostarea_id'] = $_POST['helthpostarea_id'];		
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];    	
		$post['shm_created_date'] = date('Y-m-d');
		$post['shm_updated_date'] = date('Y-m-d');
		$shm_id =  $this->stakeholdermeeting_model->addStakeHolderMeeting($post);
		if(!empty($shm_id))
        {
            echo json_encode(array("status"=>1, "shm_id"=>$shm_id)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
    }

    public function addImages()
	{
		// $image_name = urldecode($_FILES["shmi_img"]["name"]);
		$name = 'shm_img';
      	$imagePath = 'webroot/admin/upload/stekeholder/meeting/';
       	$temp = explode(".",$_FILES['shmi_img']['name']);
		$extension = end($temp);
		$filenew =  date('d-M-Y').'_'.str_replace($_FILES['shmi_img']['name'],$name,$_FILES['shmi_img']['name']).'_'.time().''.rand(). "." .$extension;  		
		$config['file_name'] = $filenew;
		$config['upload_path'] = $imagePath;
		$config['allowed_types'] = 'GIF | gif | JPE | jpe | JPEG | jpeg | JPG | jpg | PNG | png';
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		$this->upload->set_filename($config['upload_path'],$filenew);
		
		if(!$this->upload->do_upload('shmi_img'))
		{
			$data = array('msg' => $this->upload->display_errors());
		}
		else 
		{ 
			$data = $this->upload->data();	
			$imageName = $data['file_name'];
		}

		$post_img['shmi_img'] = $imagePath.''.$imageName;
		$post_img['shm_id'] =  $_GET['shm_id'];
		$post_img['shmi_status'] = '1';
		$post_img['shmi_let'] = $_GET['shmi_let'];
		$post_img['shmi_long'] = $_GET['shmi_long'];
		$post_img['shmi_created_date'] = date('Y-m-d');
		$post_img['shmi_updated_date'] = date('Y-m-d');
		$this->stakeholdermeeting_model->addStakeHolderMeetingImg($post_img);
	}

     /* Details */
	public function editStakeHolderMeeting()
	{
		$shm_id = $_POST['shm_id']; 
		$stakeholder_meeting_res = $this->stakeholdermeeting_model->editStakeHolderMeeting($shm_id);
		$stakeholder_meeting_res_img = $this->stakeholdermeeting_model->editStakeHolderMeetingImg($shm_id);
        if(!empty($stakeholder_meeting_res))
        {
            echo json_encode(array("status"=>1, "stakeholder_meeting_res"=>$stakeholder_meeting_res, "stakeholder_meeting_res_img"=>$stakeholder_meeting_res_img)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
    }

    public function updateMeeting()
    {
    	$post['shm_id'] = $_POST['shm_id']; 
    	$post['stakeholder_id'] = $_POST['stakeholder_id'];
    	$post['shm_no_of_participants'] = $_POST['shm_no_of_participants'];
		$post['shm_meting_location'] = $_POST['shm_meting_location'];
		$post['shm_meeting_date'] = $_POST['shm_meeting_date'];
		$post['shm_meeting_time_from'] = $_POST['shm_meeting_time_from'];
		$post['shm_meeting_time_to'] = $_POST['shm_meeting_time_to'];
		$post['shm_order_of_meeting_this_month'] = $_POST['shm_order_of_meeting_this_month'];
		$post['shm_no_of_meeting_before_month'] = $_POST['shm_no_of_meeting_before_month'];
		$post['shm_met_status_before_month'] = $_POST['shm_met_status_before_month'];
		$post['shm_purpose_of_meeting'] = $_POST['shm_purpose_of_meeting'];
		$post['shm_purpose_of_meeting_other'] = $_POST['shm_purpose_of_meeting_other'];
		$post['shm_point_of_discussion'] = $_POST['shm_point_of_discussion'];
		$post['shm_point_of_discussion_other'] = $_POST['shm_point_of_discussion_other'];
		$post['shm_track_with_agenda'] = $_POST['shm_track_with_agenda'];
		$post['shm_participated_status'] = $_POST['shm_participated_status'];
		$post['shm_achived_purpose'] = $_POST['shm_achived_purpose'];
		$post['shm_clearified_next_step'] = $_POST['shm_clearified_next_step'];
		$post['shm_stakeholde_work_status'] = $_POST['shm_stakeholde_work_status'];
		$post['shm_meeting_time_wroth_spent'] = $_POST['shm_meeting_time_wroth_spent'];
		$post['shm_power'] = $_POST['shm_power'];
		$post['shm_interest'] = $_POST['shm_interest'];
		$post['shm_organization_classified'] = $_POST['shm_organization_classified'];
		$post['shm_application_social_protection_scheme_status'] = $_POST['shm_application_social_protection_scheme_status'];
		$post['shm_application_social_protection_scheme'] = $_POST['shm_application_social_protection_scheme'];
		$post['shm_purpose_of_next_meeting'] = $_POST['shm_purpose_of_next_meeting'];
		$post['shm_date_of_next_meeting'] = $_POST['shm_date_of_next_meeting'];
		$post['shm_time_of_next_meeting'] = $_POST['shm_time_of_next_meeting'];
		$post['shm_date_of_community_activity'] = $_POST['shm_date_of_community_activity'];
		$post['shm_time_of_community_activity'] = $_POST['shm_time_of_community_activity'];
		$post['shm_venue_of_community_activity'] = $_POST['shm_venue_of_community_activity'];
		$post['shm_stakeholder_help'] = $_POST['shm_stakeholder_help'];		
		$post['helthpostarea_id'] = $_POST['helthpostarea_id'];		
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];   
		$post['shm_updated_date'] = date('Y-m-d');
		$update_status = $this->stakeholdermeeting_model->updateStakeHolderMeeting($post);
    	if($update_status == '1')
    	{
    		echo json_encode(array("status"=>1));
    	}
    	else
    	{
    		echo json_encode(array("status"=>0));
    	}    
    }

	/* Delete */
	public function deleteStakeHolderMeeting()
	{
		$shm_id = $_POST['shm_id'];
		$del_status = $this->stakeholdermeeting_model->deleteStakeHolderMeeting($shm_id);		
		if($del_status == '1')
    	{
    		echo json_encode(array("status"=>1));
    	}
    	else
    	{
    		echo json_encode(array("status"=>0));
    	}  
	}	
}

/* End of file */?>