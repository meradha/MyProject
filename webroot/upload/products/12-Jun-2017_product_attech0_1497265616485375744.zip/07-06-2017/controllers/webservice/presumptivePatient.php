<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class PresumptivePatient extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/presumptivepatient_model');
	}
	
	/* Details */
	public function viewData()
	{
		$presumptivePatient_res = $this->presumptivepatient_model->getAllPresumptivePatient();
        if(!empty($presumptivePatient_res))
        {
            echo json_encode(array("status"=>1, "presumptivePatient_res"=>$presumptivePatient_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

	/* Details */
	public function getAllDiagnosis()
	{
		$diagnosis_res = $this->presumptivepatient_model->getAllDiagnosis();
		$stakeholder_list = $this->presumptivepatient_model->getAllStakeholder();
        if(!empty($diagnosis_res) || !empty($diagnosis_res))
        {
            echo json_encode(array("status"=>1, "diagnosis_res"=>$diagnosis_res, "stakeholder_list"=>$stakeholder_list)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

    public function addPresumptivePatient()
    {
    	$post['pp_let'] = $_POST['pp_let'];
    	$post['pp_long'] = $_POST['pp_long'];
    	$post['pp_referral_date'] = $_POST['pp_referral_date'];
		$post['pp_referral_type'] = $_POST['pp_referral_type'];
		$post['pp_community_activity_name'] = $_POST['pp_community_activity_name'];
		$post['pp_date_of_activity'] = $_POST['pp_date_of_activity'];
		$post['pp_sputum_date'] = $_POST['pp_sputum_date'];
		$post['pp_stakeholder_name'] = $_POST['pp_stakeholder_name'];
		$post['pp_patient_name'] = $_POST['pp_patient_name'];
		$post['pp_age'] = $_POST['pp_age'];
		$post['pp_sex'] = $_POST['pp_sex'];
		$post['pp_address'] = $_POST['pp_address'];
		$post['pp_postal_code'] = $_POST['pp_postal_code'];
		$post['pp_phone_no'] = $_POST['pp_phone_no'];
		$post['country_id'] = '99';
		$post['state_id'] = '1043';
		$post['pp_city'] = 'Mumbai';
		$post['diagnosis_id'] = $_POST['diagnosis_id'];
		$post['pp_landmark'] = $_POST['pp_landmark'];
    	$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$post['user_id'];
		$post['pp_created_date'] = date('Y-m-d');
		$post['pp_updated_date'] = date('Y-m-d');
    	
		$pp_id =  $this->presumptivepatient_model->addPresumptivePatient($post);
		if($pp_id)
		{
			$post_u['pp_id'] = $pp_id;
			$post_u['pp_saksham_patient_id'] = 'SKP'.$pp_id;
			$this->presumptivepatient_model->updateSakshamID($post_u);
			echo json_encode(array("status"=>1)); 
		}		
		else
		{
			echo json_encode(array("status"=>0)); 
		}	
    }

    /* Details */
	public function editPresumptivePatient()
	{
		$pp_id = $_POST['pp_id'];
		$editPresumptivePatient_res = $this->presumptivepatient_model->editPresumptivePatient($pp_id);
        if(!empty($editPresumptivePatient_res))
        {
            echo json_encode(array("status"=>1, "editPresumptivePatient_res"=>$editPresumptivePatient_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

    public function updatePresumptivePatient()
    {
    	$post['pp_id'] = $_POST['pp_id'];
    	$post['pp_referral_date'] = $_POST['pp_referral_date'];
		$post['pp_referral_type'] = $_POST['pp_referral_type'];
		$post['pp_community_activity_name'] = $_POST['pp_community_activity_name'];
		$post['pp_date_of_activity'] = $_POST['pp_date_of_activity'];
		$post['pp_sputum_date'] = $_POST['pp_sputum_date'];
		$post['pp_stakeholder_name'] = $_POST['pp_stakeholder_name'];
		$post['pp_patient_name'] = $_POST['pp_patient_name'];
		$post['pp_age'] = $_POST['pp_age'];
		$post['pp_sex'] = $_POST['pp_sex'];
		$post['pp_address'] = $_POST['pp_address'];
		$post['pp_postal_code'] = $_POST['pp_postal_code'];
		$post['pp_phone_no'] = $_POST['pp_phone_no'];
		$post['country_id'] = '99';
		$post['state_id'] = '1043';
		$post['pp_city'] = 'Mumbai';
		$post['diagnosis_id'] = $_POST['diagnosis_id'];
		$post['pp_landmark'] = $_POST['pp_landmark'];
    	$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$post['user_id'];
		$post['pp_updated_date'] = date('Y-m-d');
		$update_status =  $this->presumptivepatient_model->updatePresumptivePatient($post);
		if($update_status == '1')
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}			
    }
	
	/* Delete */
	public function deletePresumptivePatient()
	{
		$pp_id = $_POST['pp_id'];
		$del_status = $this->presumptivepatient_model->delete_presumptivePatient($pp_id);	
		if($del_status == '1')
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}		
	}

	/* Delete */
	public function presumptivePatientDetailsByID()
	{
		$pp_id = $_POST['pp_id'];
		$presumptivePatientDetails = $this->presumptivepatient_model->presumptivePatientDetailsByID($pp_id);	
		$saksham_pravah_list = $this->presumptivepatient_model->getSakshamPravahList();
		if($presumptivePatientDetails)
		{
			echo json_encode(array("status"=>1, "presumptivePatientDetails"=>$presumptivePatientDetails, "saksham_pravah_list"=>$saksham_pravah_list)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}		
	}

	public function addPresumptiveResult()
	{
		$post['pp_id'] = $_POST['pp_id'];
		$post['pp_reached_status'] = $_POST['pp_reached_status'];
		if($post['pp_reached_status'] == 'Yes')
		{
			$post['pp_testing_status'] = $_POST['pp_testing_status'];
			if($post['pp_testing_status'] == 'Yes')
			{
				$post['pp_testing_date'] = $_POST['pp_testing_date'];
				$post['pp_testing_number'] = $_POST['pp_testing_number'];
				$post['pp_testing_result'] = $_POST['pp_testing_result'];
				if($post['pp_testing_result'] == 'Positive')
				{
					$post['pp_diagnosis_date'] = $_POST['pp_diagnosis_date'];
					$post['pp_drug_resistance_status'] = $_POST['pp_drug_resistance_status'];
					if($post['pp_drug_resistance_status'] == 'Drug Sensitive')
					{
						$post['pp_drug_sensitive_type'] = $_POST['pp_drug_sensitive_type'];
						$post['pp_drug_sensitive_type_other'] = $_POST['pp_drug_sensitive_type_other'];
						if($post['pp_drug_sensitive_type'])
						{
							$post['pp_report_status'] = '1';
						}
					}
					else
					{
						$post['pp_drug_resistance_type'] = $_POST['pp_drug_resistance_type'];
						$post['pp_drug_resistance_type_other'] = $_POST['pp_drug_resistance_type_other'];
						$post['pp_comments'] = $_POST['pp_comments'];
						$post['pp_report_status'] = '1';
					}
				}
				elseif($post['pp_testing_result'] == 'Negative')
				{
					$post['pp_report_status'] = '1';
				}
			}
			else
			{
				$post['pp_testing_reason'] = $_POST['pp_testing_reason'];
			}
		}
		$post['pp_updated_date'] = date('Y-m-d');
		$update_result_status = $this->presumptivepatient_model->updatePresumptivePatientReportStatus($post);
		if($update_result_status == '1')
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}

	/* submit to sakasham pravah */
	public function sendToShakshamPravah()
	{
		$pp_id = $_POST['pp_id'];
		$post['pp_id'] = $pp_id;
		$post['pp_patient_nikshay_id'] = $_POST['pp_patient_nikshay_id'];
		$post['pp_date_of_saksham_counsellor'] = $_POST['pp_date_of_saksham_counsellor'];
		$post['pp_helth_post_area'] = $_POST['pp_helth_post_area'];
		$post['saksham_pravah_id'] = $_POST['saksham_pravah_id'];
		$post['pp_send_pravah_status'] = '2';
		$post['pp_report_status'] = '1';
		$this->presumptivepatient_model->updatePresumptivePatientSendSakshamPravah($post);

		$sakasham_pravah_res = $this->presumptivepatient_model->getSakshamPravahData($post['saksham_pravah_id']);
		if(!empty($sakasham_pravah_res))
		{
			$presumptivePatient_details = $this->presumptivepatient_model->presumptivePatientDetailsByID($pp_id);
			
			$email = $sakasham_pravah_res[0]->sp_email;
			$subject = 'Patient details';
			$message = '';
			$message .= 'Patient name : '.$presumptivePatient_details[0]->pp_patient_name.'<br>';
			$message .= 'Patient age : '.$presumptivePatient_details[0]->pp_age.'<br>';
			$message .= 'Patient gender : '.$presumptivePatient_details[0]->pp_sex.'<br>';
			$message .= 'Patient phone number : '.$presumptivePatient_details[0]->pp_postal_code.'<br>';
			$message .= 'Diagnosis name : '.$presumptivePatient_details[0]->diagnosis_name.'<br>';
			$message .= 'Referred By : '.$presumptivePatient_details[0]->user_name.'<br>';

			$message .= 'Accept Patient to ';

			$message .= '<a href="'.base_url().'admin/presumptivePatient/acceptPatient/'.$pp_id.'/'.$sakasham_pravah_res[0]->sp_id.'">Click Here</a>';
			$mail = $this->send_mail($email, $subject, $message);
			if($mail)
			{
				echo json_encode(array("status"=>1));
			}
			else
			{
				echo json_encode(array("status"=>0));
			}
		}
	}

	/* Accept Patient */
	public function acceptPatient()
	{
		$pp_id = $_POST['pp_id'];
		$sp_id = $_POST['sp_id'];
		$post['pp_send_pravah_status'] = '1';
		$post['pp_id'] = $pp_id;
		$update_res = $this->presumptivepatient_model->updateAcceptanceBySakshamPravah($post);
		if($update_res == '1')
		{
			echo json_encode(array("status"=>1));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
		
	}

	/* Delete */
	public function showSendSakhamPravahData()
	{
		$post['pp_id'] = $_POST['pp_id'];
		$presumptivePatientDetails = $this->presumptivepatient_model->showSendSakhamPravahData($pp_id);
		if($presumptivePatientDetails == '1')
		{
			echo json_encode(array("status"=>1, "presumptivePatientDetails"=>$presumptivePatientDetails)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}		
	}

	public function setPermissionStatus()
	{
		$post['pp_id'] = $_POST['pp_id'];
		$post['pp_permission_presumptive_status'] = $_POST['pp_permission_presumptive_status'];
		if($this->presumptivepatient_model->setStatus($post))
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}
}

/* End of file */?>