<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Patient extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/patient_model');
		$this->load->model('webservice/common_model');
	}

	/* Details */
	public function viewData()
	{
		$patient_res = $this->patient_model->getAllPatient();
        if(!empty($patient_res))
        {
            echo json_encode(array("status"=>1, "patient_res"=>$patient_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

    /* Details */
	public function countryList()
	{
		$country_res = $this->common_model->getAllCountry();
        if(!empty($country_res))
        {
            echo json_encode(array("status"=>1, "country_res"=>$country_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

     /* Details */
	public function stateListByCountryID()
	{
		$country_id = $_POST['country_id'];
		$state_res = $this->common_model->getStateListByCountryID($country_id);
		
        if(!empty($state_res))
        {
            echo json_encode(array("status"=>1, "state_res"=>$state_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

     /* Details */
	public function stateList()
	{
		$state_res = $this->common_model->getAllState();
        if(!empty($state_res))
        {
            echo json_encode(array("status"=>1, "state_res"=>$state_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }


    /* Details */
	public function presumptivePatientDetails()
	{
		$pp_id = $_POST['pp_id'];
		$presumptive_patient_res = $this->patient_model->presumptivePatientDetailsByID($pp_id);
        if(!empty($presumptive_patient_res))
        {
            echo json_encode(array("status"=>1, "presumptive_patient_res"=>$presumptive_patient_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

    /* add */
	public function addPatient()
	{
		/***************** TAB 1 *****************/
		$post['patient_let'] = $_POST['patient_let'];
		$post['patient_long'] = $_POST['patient_long'];			
		$post['patient_p_a_let'] = $_POST['patient_p_a_let'];	
		$post['patient_p_a_long'] = $_POST['patient_p_a_long'];	
		$post['patient_c_a_let'] = $_POST['patient_c_a_let'];	
		$post['patient_c_a_long'] = $_POST['patient_c_a_long'];
		$post['pp_id'] = $_POST['pp_id'];
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$post['saksham_patient_id'] = $_POST['saksham_patient_id'];
		$post['patient_name'] = $_POST['patient_name'];					
		$post['patient_father_name'] = $_POST['patient_father_name'];
		$post['patient_dob'] = $_POST['patient_dob'];
		$post['patient_age'] = $_POST['patient_age'];
		$post['patient_contact_no'] = $_POST['patient_contact_no'];
		$post['patient_alternat_contact_no'] = $_POST['patient_alternat_contact_no'];
		$post['patient_gender'] = $_POST['patient_gender'];
		$post['patient_c_country_id'] = '99';
		$post['patient_c_state_id'] = '1493';
		$post['patient_c_city'] = 'Mumbai';
		$post['patient_c_address'] = $_POST['patient_c_address'];
		$post['patient_c_landmark'] = $_POST['patient_c_landmark'];
		$post['patient_c_postal_code'] = $_POST['patient_c_postal_code'];
		$post['patient_p_country_id'] = '99';
		$post['patient_p_state_id'] = $_POST['patient_p_state_id'];
		$post['patient_p_city'] = $_POST['patient_p_city'];
		$post['patient_p_address'] = $_POST['patient_p_address'];
		$post['patient_p_postal_code'] = $_POST['patient_p_postal_code'];
		$post['patient_religion'] = $_POST['patient_religion'];
		$post['patient_religion_other'] = $_POST['patient_religion_other'];
		$post['patient_caste'] = $_POST['patient_caste'];
		$post['patient_aadhar_no'] = $_POST['patient_aadhar_no'];
		$post['patient_ration_card_no'] = $_POST['patient_ration_card_no'];
		$post['patient_type_of_locality'] = $_POST['patient_type_of_locality'];
		$post['patient_type_of_locality_other'] = $_POST['patient_type_of_locality_other'];				
		$post['patient_education'] = $_POST['patient_education'];
		$post['patient_education_other'] = $_POST['patient_education_other'];
		$post['patient_working_status'] = $_POST['patient_working_status'];
		$post['patient_employement_status'] = $_POST['patient_employement_status'];
		$post['patient_occupation'] = $_POST['patient_occupation'];
		$post['patient_occupation_other'] = $_POST['patient_occupation_other'];
		$post['patient_unemployed_reason'] = $_POST['patient_unemployed_reason'];
		$post['patient_unemployed_reason_other'] = $_POST['patient_unemployed_reason_other'];
		$post['patient_staying_with'] = $_POST['patient_staying_with'];
		$post['patient_total_house_member'] = $_POST['patient_total_house_member'];
		$post['patient_total_children_less_6'] = $_POST['patient_total_children_less_6'];
		$post['patient_earning_house_member'] = $_POST['patient_earning_house_member'];
		$post['patient_family_income'] = $_POST['patient_family_income'];
		$post['patient_marital_status'] = $_POST['patient_marital_status'];
		$post['patient_living_in_mumbai'] = $_POST['patient_living_in_mumbai'];
		$post['patient_created_date'] = date('Y-m-d');
		$post['patient_updated_date'] = date('Y-m-d');
		$patient_id =  $this->patient_model->addPatient($post);		
		
		/***************** TAB 2 *****************/
		$total_member = $_POST['total_member'];		
		$pf_name = explode(',', $_POST['pf_name']);
		$pf_age = explode(',', $_POST['pf_age']);
		$pf_sex = explode(',', $_POST['pf_sex']);
		$pf_relationship = explode(',', $_POST['pf_relationship']);
		$pf_household_is_caregiver = explode(',', $_POST['pf_household_is_caregiver']);
		$pf_household_history_tb = explode(',', $_POST['pf_household_history_tb']);
		$pf_household_treatment = explode(',', $_POST['pf_household_treatment']);

		// echo "<pre>";
		// print_r($pf_name);die();


		if($total_member != '')
		{
			for($i=0; $i<$total_member; $i++)
			{
				$post_f['patient_id'] = $patient_id;
				$post_f['pp_id'] = $_POST['pp_id'];
				$post_f['user_id'] = $_POST['user_id'];
				$post_f['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
				$post_f['pf_name'] = $pf_name[$i];
				$post_f['pf_age'] = $pf_age[$i];
				$post_f['pf_sex'] = $pf_sex[$i];
				$post_f['pf_relationship'] = $pf_relationship[$i];
				$post_f['pf_household_is_caregiver'] = $pf_household_is_caregiver[$i];
				$post_f['pf_household_history_tb'] = $pf_household_history_tb[$i];
				$post_f['pf_household_treatment'] = $pf_household_treatment[$i];
				$post_f['pf_created_date'] = date('Y-m-d');
				$post_f['pf_updated_date'] = date('Y-m-d');
				$this->patient_model->addPatientFamily($post_f);
			}
		}

		/***************** TAB 3 & TAB 4 *****************/
		$post_tb['patient_id'] = $patient_id;
		$post_tb['pp_id'] = $_POST['pp_id'];
		$post_tb['user_id'] = $_POST['user_id'];
		$post_tb['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$post_tb['patient_saksham_id'] = $_POST['patient_saksham_id'];
		$post_tb['ptb_saksham_registration_date'] = $_POST['ptb_saksham_registration_date'];
		$post_tb['ptb_name_ward'] = $_POST['ptb_name_ward'];
		$post_tb['ptb_referral_type'] = $_POST['ptb_referral_type'];
		$post_tb['ptb_referral_type_other'] = $_POST['ptb_referral_type_other'];
		$post_tb['ptb_share_details_status'] = $_POST['ptb_share_details_status'];
		$post_tb['ptb_consent_for_counselling_status'] = $_POST['ptb_consent_for_counselling_status'];
		$post_tb['ptb_place_of_registration'] = $_POST['ptb_place_of_registration'];
		$post_tb['ptb_place_of_registration_other'] = $_POST['ptb_place_of_registration_other'];
		$post_tb['ptb_type_of_tb_by_card'] = $_POST['ptb_type_of_tb_by_card'];
		$post_tb['ptb_extra_organ_affected_by_card'] = $_POST['ptb_extra_organ_affected_by_card'];
		$post_tb['ptb_drug_sensitive_status_by_card'] = $_POST['ptb_drug_sensitive_status_by_card'];
		$post_tb['ptb_current_phase_of_treatment_card'] = $_POST['ptb_current_phase_of_treatment_card'];
		$post_tb['ptb_name_of_PHC'] = $_POST['ptb_name_of_PHC'];
		$post_tb['ptb_PMDT_no'] = $_POST['ptb_PMDT_no'];
		$post_tb['ptb_RNTCP_registration_date'] = $_POST['ptb_RNTCP_registration_date'];
		$post_tb['ptb_diagnosis_date'] = $_POST['ptb_diagnosis_date'];
		$post_tb['ptb_treatement_history'] = $_POST['ptb_treatement_history'];
		$post_tb['ptb_start_treatment_date'] = $_POST['ptb_start_treatment_date'];
		$post_tb['ptb_HIV_status'] = $_POST['ptb_HIV_status'];
		$post_tb['ptb_HIV_treatment_status'] = $_POST['ptb_HIV_treatment_status'];
		$post_tb['ptb_diabetes_status'] = $_POST['ptb_diabetes_status'];
		$post_tb['ptb_diabetes_treatment_status'] = $_POST['ptb_diabetes_treatment_status'];
		$post_tb['ptb_other_diseas'] = $_POST['ptb_other_diseas'];
		$post_tb['ptb_substance_abuse'] = $_POST['ptb_substance_abuse'];
		$post_tb['ptb_substance_abuse_other'] = $_POST['ptb_substance_abuse_other'];
		$post_tb['ptb_home_visit_status'] = $_POST['ptb_home_visit_status'];
		$post_tb['ptb_worklace_status'] = $_POST['ptb_worklace_status'];
		$post_tb['ptb_counselling_topics']  = $_POST['ptb_counselling_topics'];
		$post_tb['ptb_counselling_topics_other'] = $_POST['ptb_counselling_topics_other'];
		$post_tb['ptb_counselling_tool'] = $_POST['ptb_counselling_tool'];
		$post_tb['ptb_need_referral_linkage_identified'] = $_POST['ptb_need_referral_linkage_identified'];
		$post_tb['ptb_referral_service_linkage_towords'] = $_POST['ptb_referral_service_linkage_towords'];
		$post_tb['ptb_referral_service_linkage_towords_other'] = $_POST['ptb_referral_service_linkage_towords_other'];
		$post_tb['ptb_name_of_referred_agency'] = $_POST['ptb_name_of_referred_agency'];
		$post_tb['ptb_csw_remarks'] = $_POST['ptb_csw_remarks'];
		$post_tb['ptb_next_follow_up_date'] = $_POST['ptb_next_follow_up_date'];
		$post_tb['ptb_next_follow_up_time'] = $_POST['ptb_next_follow_up_time'];
		$post_tb['ptb_next_follow_up_visit_place'] = $_POST['ptb_next_follow_up_visit_place'];
		$post_tb['ptb_next_follow_up_visit_place_other'] =$_POST['ptb_next_follow_up_visit_place_other'];
		$post_tb['ptb_created_date'] = date('Y-m-d');
		$post_tb['ptb_updated_date'] = date('Y-m-d');
		$this->patient_model->addPatientTBDetails($post_tb);

		/***************** TAB 5 *****************/
		$post_cg['cga_men_status'] = '1';
		$post_cg['patient_id'] = $patient_id;
		$post_cg['pp_id'] = $_POST['pp_id'];
		$post_cg['user_id'] = $_POST['user_id'];
		$post_cg['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$post_cg['pcg_patient_name'] = $_POST['pcg_patient_name'];
		$post_cg['pcg_patient_father_name'] = $_POST['pcg_patient_father_name'];
		$post_cg['pcg_patient_dob'] = $_POST['pcg_patient_dob'];
		$post_cg['patient_saksham_id'] = $_POST['patient_saksham_id'];
		$post_cg['pcg_date_of_registration'] = $_POST['pcg_date_of_registration'];
		$post_cg['pcg_place_for_registration'] = $_POST['pcg_place_for_registration'];
		$post_cg['pcg_share_detail_status'] = $_POST['pcg_share_detail_status'];
		$post_cg['pcg_caregiver_name'] = $_POST['pcg_caregiver_name'];
		$post_cg['pcg_relationship_with_patient'] = $_POST['pcg_relationship_with_patient'];
		$post_cg['pcg_caregiver_age'] = $_POST['pcg_caregiver_age'];
		$post_cg['pcg_caregiver_gender'] = $_POST['pcg_caregiver_gender'];
		$post_cg['pcg_past_history_of_TB'] = $_POST['pcg_past_history_of_TB'];
		$post_cg['pcg_suffer_from_TB'] = $_POST['pcg_suffer_from_TB'];
		$post_cg['pcg_category_of_TB'] = $_POST['pcg_category_of_TB'];
		$post_cg['pcg_organ_affected_from_TB'] = $_POST['pcg_organ_affected_from_TB'];
		$post_cg['pcg_treatment_present_outcome'] = $_POST['pcg_treatment_present_outcome'];
		$post_cg['pcg_self_substance_abuse'] = $_POST['pcg_self_substance_abuse'];
		$post_cg['pcg_self_substance_abuse_other'] = $_POST['pcg_self_substance_abuse_other'];
		$post_cg['pcg_patient_substance_abuse'] = $_POST['pcg_patient_substance_abuse'];
		$post_cg['pcg_patient_substance_abuse_other']= $_POST['pcg_patient_substance_abuse_other'];
		$post_cg['pcg_counselling_topics']  = $_POST['pcg_counselling_topics'];
		$post_cg['pcg_counselling_topics_other'] = $_POST['pcg_counselling_topics_other'];
		$post_cg['pcg_csw_remarks'] = $_POST['pcg_csw_remarks'];
		$post_cg['pcg_created_date'] = date('Y-m-d');
		$post_cg['pcg_updated_date'] = date('Y-m-d');
		$this->patient_model->addPatientCaregiverDetails($post_cg);		

		/********* Add patient follow up **********/
		$post_pfud['pfud_phase'] = $_POST['ptb_current_phase_of_treatment_card'];
		$post_pfud['pfud_date'] = $_POST['ptb_next_follow_up_date'];
		$post_pfud['patient_id'] = $patient_id;
		$post_pfud['pfud_no'] = 1;
		$post_pfud['user_id'] = $_POST['user_id'];
		$post_pfud['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$this->patient_model->addPatientFollowUpDate($post_pfud);

		$u_post['pp_id'] = $_POST['pp_id'];
		$u_post['pp_register_patient_Status'] = '1';
		$this->patient_model->updatePresumptivePatientRegistration($u_post);

		// echo "<pre>";
		// print_r($_POST);
		// die;
        if(!empty($patient_id))
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

     /* Details */
	public function editPatient()
	{
		$patient_id = $_POST['patient_id'];
		$pp_id = $_POST['pp_id'];
		$patient_edit = $this->patient_model->editPatient($patient_id, $pp_id);
		$patient_family_edit = $this->patient_model->editPatientFamily($patient_id, $pp_id);
		$patient_tb_details_edit = $this->patient_model->editPatientTBDetails($patient_id, $pp_id);
		$patient_caregiver_edit = $this->patient_model->editPatientCareGiver($patient_id, $pp_id);
		$country_list = $this->common_model->getAllCountry();
		$state_list = $this->common_model->getAllState();
		$presumptive_patient_res = $this->patient_model->presumptivePatientDetailsByID($pp_id);
        if(!empty($patient_edit))
        {
            echo json_encode(array("status"=>1, "patient_edit"=>$patient_edit, "patient_family_edit"=>$patient_family_edit, "patient_tb_details_edit"=>$patient_tb_details_edit, "patient_caregiver_edit"=>$patient_caregiver_edit, "country_list"=>$country_list, "state_list"=>$state_list, "presumptive_patient_res"=>$presumptive_patient_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

    /* add */
	public function updatePatient()
	{
		/***************** TAB 1 *****************/
		$patient_id = $_POST['patient_id'];
		$post['patient_id'] = $_POST['patient_id'];
		$post['pp_id'] = $_POST['pp_id'];
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$post['saksham_patient_id'] = $_POST['saksham_patient_id'];
		$post['patient_name'] = $_POST['patient_name'];					
		$post['patient_father_name'] = $_POST['patient_father_name'];
		$post['patient_dob'] = $_POST['patient_dob'];
		$post['patient_age'] = $_POST['patient_age'];
		$post['patient_contact_no'] = $_POST['patient_contact_no'];
		$post['patient_alternat_contact_no'] = $_POST['patient_alternat_contact_no'];
		$post['patient_gender'] = $_POST['patient_gender'];
		$post['patient_c_country_id'] = '99';
		$post['patient_c_state_id'] = '1493';
		$post['patient_c_city'] = 'Mumbai';
		$post['patient_c_address'] = $_POST['patient_c_address'];
		$post['patient_c_landmark'] = $_POST['patient_c_landmark'];
		$post['patient_c_postal_code'] = $_POST['patient_c_postal_code'];
		$post['patient_p_country_id'] = '99';
		$post['patient_p_state_id'] = $_POST['patient_p_state_id'];
		$post['patient_p_city'] = $_POST['patient_p_city'];
		$post['patient_p_address'] = $_POST['patient_p_address'];
		$post['patient_p_postal_code'] = $_POST['patient_p_postal_code'];
		$post['patient_religion'] = $_POST['patient_religion'];
		$post['patient_religion_other'] = $_POST['patient_religion_other'];
		$post['patient_caste'] = $_POST['patient_caste'];
		$post['patient_aadhar_no'] = $_POST['patient_aadhar_no'];
		$post['patient_ration_card_no'] = $_POST['patient_ration_card_no'];
		$post['patient_type_of_locality'] = $_POST['patient_type_of_locality'];
		$post['patient_type_of_locality_other'] = $_POST['patient_type_of_locality_other'];				
		$post['patient_education'] = $_POST['patient_education'];
		$post['patient_education_other'] = $_POST['patient_education_other'];
		$post['patient_working_status'] = $_POST['patient_working_status'];
		$post['patient_employement_status'] = $_POST['patient_employement_status'];
		$post['patient_occupation'] = $_POST['patient_occupation'];
		$post['patient_occupation_other'] = $_POST['patient_occupation_other'];
		$post['patient_unemployed_reason'] = $_POST['patient_unemployed_reason'];
		$post['patient_unemployed_reason_other'] = $_POST['patient_unemployed_reason_other'];
		$post['patient_staying_with'] = $_POST['patient_staying_with'];
		$post['patient_total_house_member'] = $_POST['patient_total_house_member'];
		$post['patient_total_children_less_6'] = $_POST['patient_total_children_less_6'];
		$post['patient_earning_house_member'] = $_POST['patient_earning_house_member'];
		$post['patient_family_income'] = $_POST['patient_family_income'];
		$post['patient_marital_status'] = $_POST['patient_marital_status'];
		$post['patient_living_in_mumbai'] = $_POST['patient_living_in_mumbai'];
		$post['patient_updated_date'] = date('Y-m-d');
		$update_status = $this->patient_model->updatePatient($post);

		/***************** TAB 2 *****************/
		$patient_family_edit = $this->patient_model->editPatientFamily($post['patient_id'], $post['pp_id']);	
	
		$pf_name = explode(',', $_POST['pf_name_u']);
		$pf_age = explode(',', $_POST['pf_age_u']);
		$pf_sex = explode(',', $_POST['pf_sex_u']);
		$pf_relationship = explode(',', $_POST['pf_relationship_u']);
		$pf_household_is_caregiver = explode(',', $_POST['pf_household_is_caregiver_u']);
		$pf_household_history_tb = explode(',', $_POST['pf_household_history_tb_u']);
		$pf_household_treatment = explode(',', $_POST['pf_household_treatment_u']);

		for($j=0; $j<count($patient_family_edit); $j++)
		{
			$post_f['patient_id'] = $patient_id;
			$post_f['pp_id'] = $_POST['pp_id'];
			$post_f['user_id'] = $_POST['user_id'];
			$post_f['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
			$post_f['pf_name'] = $pf_name[$i];
			$post_f['pf_age'] = $pf_age[$i];
			$post_f['pf_sex'] = $pf_sex[$i];
			$post_f['pf_relationship'] = $pf_relationship[$i];
			$post_f['pf_household_is_caregiver'] = $pf_household_is_caregiver[$i];
			$post_f['pf_household_history_tb'] = $pf_household_history_tb[$i];
			$post_f['pf_household_treatment'] = $pf_household_treatment[$i];
			$post_f['pf_updated_date'] = date('Y-m-d');
			$this->patient_model->updatePatientFamily($post_f_u);
		}

		$total_member = $_POST['total_member'];		
		$pf_name = explode(',', $_POST['pf_name']);
		$pf_age = explode(',', $_POST['pf_age']);
		$pf_sex = explode(',', $_POST['pf_sex']);
		$pf_relationship = explode(',', $_POST['pf_relationship']);
		$pf_household_is_caregiver = explode(',', $_POST['pf_household_is_caregiver']);
		$pf_household_history_tb = explode(',', $_POST['pf_household_history_tb']);
		$pf_household_treatment = explode(',', $_POST['pf_household_treatment']);

		if($total_member != '')
		{
			for($i=0; $i<$total_member; $i++)
			{
				$post_f['patient_id'] = $patient_id;
				$post_f['pp_id'] = $_POST['pp_id'];
				$post_f['user_id'] = $_POST['user_id'];
				$post_f['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
				$post_f['pf_name'] = $pf_name[$i];
				$post_f['pf_age'] = $pf_age[$i];
				$post_f['pf_sex'] = $pf_sex[$i];
				$post_f['pf_relationship'] = $pf_relationship[$i];
				$post_f['pf_household_is_caregiver'] = $pf_household_is_caregiver[$i];
				$post_f['pf_household_history_tb'] = $pf_household_history_tb[$i];
				$post_f['pf_household_treatment'] = $pf_household_treatment[$i];
				$post_f['pf_created_date'] = date('Y-m-d');
				$post_f['pf_updated_date'] = date('Y-m-d');
				$this->patient_model->addPatientFamily($post_f);
			}
		}

		/***************** TAB 3 & TAB 4 *****************/
		$post_tb['patient_id'] = $patient_id;
		$post_tb['pp_id'] = $_POST['pp_id'];
		$post_tb['user_id'] = $_POST['user_id'];
		$post_tb['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$post_tb['patient_saksham_id'] = $_POST['patient_saksham_id'];
		$post_tb['ptb_saksham_registration_date'] = $_POST['ptb_saksham_registration_date'];
		$post_tb['ptb_name_ward'] = $_POST['ptb_name_ward'];
		$post_tb['ptb_referral_type'] = $_POST['ptb_referral_type'];
		$post_tb['ptb_referral_type_other'] = $_POST['ptb_referral_type_other'];
		$post_tb['ptb_share_details_status'] = $_POST['ptb_share_details_status'];
		$post_tb['ptb_consent_for_counselling_status'] = $_POST['ptb_consent_for_counselling_status'];
		$post_tb['ptb_place_of_registration'] = $_POST['ptb_place_of_registration'];
		$post_tb['ptb_place_of_registration_other'] = $_POST['ptb_place_of_registration_other'];
		$post_tb['ptb_type_of_tb_by_card'] = $_POST['ptb_type_of_tb_by_card'];
		$post_tb['ptb_extra_organ_affected_by_card'] = $_POST['ptb_extra_organ_affected_by_card'];
		$post_tb['ptb_drug_sensitive_status_by_card'] = $_POST['ptb_drug_sensitive_status_by_card'];
		$post_tb['ptb_current_phase_of_treatment_card'] = $_POST['ptb_current_phase_of_treatment_card'];
		$post_tb['ptb_name_of_PHC'] = $_POST['ptb_name_of_PHC'];
		$post_tb['ptb_PMDT_no'] = $_POST['ptb_PMDT_no'];
		$post_tb['ptb_RNTCP_registration_date'] = $_POST['ptb_RNTCP_registration_date'];
		$post_tb['ptb_diagnosis_date'] = $_POST['ptb_diagnosis_date'];
		$post_tb['ptb_treatement_history'] = $_POST['ptb_treatement_history'];
		$post_tb['ptb_HIV_status'] = $_POST['ptb_HIV_status'];
		$post_tb['ptb_HIV_treatment_status'] = $_POST['ptb_HIV_treatment_status'];
		$post_tb['ptb_diabetes_status'] = $_POST['ptb_diabetes_status'];
		$post_tb['ptb_diabetes_treatment_status'] = $_POST['ptb_diabetes_treatment_status'];
		$post_tb['ptb_other_diseas'] = $_POST['ptb_other_diseas'];
		$post_tb['ptb_start_treatment_date'] = $_POST['ptb_start_treatment_date'];
		$post_tb['ptb_substance_abuse'] = $_POST['ptb_substance_abuse'];
		$post_tb['ptb_substance_abuse_other'] = $_POST['ptb_substance_abuse_other'];
		$post_tb['ptb_home_visit_status'] = $_POST['ptb_home_visit_status'];
		$post_tb['ptb_worklace_status'] = $_POST['ptb_worklace_status'];
		$post_tb['ptb_counselling_topics']  = $_POST['ptb_counselling_topics'];
		$post_tb['ptb_counselling_topics_other'] = $_POST['ptb_counselling_topics_other'];
		$post_tb['ptb_counselling_tool'] = $_POST['ptb_counselling_tool'];
		$post_tb['ptb_need_referral_linkage_identified'] = $_POST['ptb_need_referral_linkage_identified'];
		$post_tb['ptb_referral_service_linkage_towords'] = $_POST['ptb_referral_service_linkage_towords'];
		$post_tb['ptb_referral_service_linkage_towords_other'] = $_POST['ptb_referral_service_linkage_towords_other'];
		$post_tb['ptb_name_of_referred_agency'] = $_POST['ptb_name_of_referred_agency'];
		$post_tb['ptb_csw_remarks'] = $_POST['ptb_csw_remarks'];
		$post_tb['ptb_next_follow_up_date'] = $_POST['ptb_next_follow_up_date'];
		$post_tb['ptb_next_follow_up_time'] = $_POST['ptb_next_follow_up_time'];
		$post_tb['ptb_next_follow_up_visit_place'] = $_POST['ptb_next_follow_up_visit_place'];
		$post_tb['ptb_next_follow_up_visit_place_other'] =$_POST['ptb_next_follow_up_visit_place_other'];
		$post_tb['ptb_updated_date'] = date('Y-m-d');
		$this->patient_model->updatePatientTBDetails($post_tb);

		/***************** TAB 5 *****************/
		$post_cg['cga_men_status'] = '1';
		$post_cg['patient_id'] = $patient_id;
		$post_cg['pp_id'] = $_POST['pp_id'];
		$post_cg['user_id'] = $_POST['user_id'];
		$post_cg['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$post_cg['pcg_patient_name'] = $_POST['pcg_patient_name'];
		$post_cg['pcg_patient_father_name'] = $_POST['pcg_patient_father_name'];
		$post_cg['pcg_patient_dob'] = $_POST['pcg_patient_dob'];
		$post_cg['patient_saksham_id'] = $_POST['patient_saksham_id'];
		$post_cg['pcg_date_of_registration'] = $_POST['pcg_date_of_registration'];
		$post_cg['pcg_place_for_registration'] = $_POST['pcg_place_for_registration'];
		$post_cg['pcg_share_detail_status'] = $_POST['pcg_share_detail_status'];
		$post_cg['pcg_caregiver_name'] = $_POST['pcg_caregiver_name'];
		$post_cg['pcg_relationship_with_patient'] = $_POST['pcg_relationship_with_patient'];
		$post_cg['pcg_caregiver_age'] = $_POST['pcg_caregiver_age'];
		$post_cg['pcg_caregiver_gender'] = $_POST['pcg_caregiver_gender'];
		$post_cg['pcg_past_history_of_TB'] = $_POST['pcg_past_history_of_TB'];
		$post_cg['pcg_suffer_from_TB'] = $_POST['pcg_suffer_from_TB'];
		$post_cg['pcg_category_of_TB'] = $_POST['pcg_category_of_TB'];
		$post_cg['pcg_organ_affected_from_TB'] = $_POST['pcg_organ_affected_from_TB'];
		$post_cg['pcg_treatment_present_outcome'] = $_POST['pcg_treatment_present_outcome'];
		$post_cg['pcg_self_substance_abuse'] = $_POST['pcg_self_substance_abuse'];
		$post_cg['pcg_self_substance_abuse_other'] = $_POST['pcg_self_substance_abuse_other'];
		$post_cg['pcg_patient_substance_abuse'] = $_POST['pcg_patient_substance_abuse'];
		$post_cg['pcg_patient_substance_abuse_other']= $_POST['pcg_patient_substance_abuse_other'];
		$post_cg['pcg_counselling_topics']  = $_POST['pcg_counselling_topics'];
		$post_cg['pcg_counselling_topics_other'] = $_POST['pcg_counselling_topics_other'];
		$post_cg['pcg_csw_remarks'] = $_POST['pcg_csw_remarks'];
		$post_cg['pcg_updated_date'] = date('Y-m-d');
		$this->patient_model->updatePatientCareGiver($post_cg);

        if($update_status == '1')
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

    /* Delete */
	public function delete_patient()
	{		
		$patient_id = $_POST['patient_id'];
		$del_status = $this->patient_model->delete_patient($patient_id);		
		if($del_status == '1')
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
	}

	/* show followup */
	public function showFollowUp()
	{		
		$patient_id = $_POST['patient_id'];
		$patient_followup_res = $this->patient_model->getFollowUpDetailsByPatientID($patient_id);	
		if($patient_followup_res)
        {
            echo json_encode(array("status"=>1, "patient_followup_res"=>$patient_followup_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
	}

	/* show patient */
	public function patientDeails()
	{		
		$patient_id = $_POST['patient_id'];
		$patient_res = $this->patient_model->getPatientDeails($patient_id);
		if($patient_res)
        {
            echo json_encode(array("status"=>1, "patient_res"=>$patient_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
	}

	/* Add FollowUp */
	public function addPatientFollowUp()
	{	
		$post['pfu_let'] = $_POST['pfu_let'];
		$post['pfu_long'] = $_POST['pfu_long'];	
		$post['pfu_a_let'] = $_POST['pfu_a_let'];
		$post['pfu_a_long'] = $_POST['pfu_a_long'];
		$post['patient_id'] = $_POST['patient_id'];
		$patient_id = $_POST['patient_id'];
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$post['saksham_patient_id'] = $_POST['saksham_patient_id'];
		$post['pfu_patient_name'] = $_POST['pfu_patient_name'];
		$post['pfu_patient_father_name'] = $_POST['pfu_patient_father_name'];
		$post['pfu_patient_dob'] = $_POST['pfu_patient_dob'];
		$post['pfu_follow_up_visit'] = $_POST['pfu_follow_up_visit'];
		$post['pfu_follow_up_visit_no'] = $_POST['pfu_follow_up_visit_no'];
		$post['pfu_share_detail_status'] = $_POST['pfu_share_detail_status'];
		$post['pfu_visited_at'] = $_POST['pfu_visited_at'];
		$post['pfu_visited_at_other'] = $_POST['pfu_visited_at_other'];
		$post['pfu_country_id'] ='99';
		$post['pfu_state_id'] ='1493';
		$post['pfu_city'] = $_POST['pfu_city'];
		$post['pfu_address'] = $_POST['pfu_address'];
		$post['pfu_landmark'] = $_POST['pfu_landmark'];
		$post['pfu_postal_code'] = $_POST['pfu_postal_code'];
		$post['pfu_contact_no'] = $_POST['pfu_contact_no'];
		$post['pfu_name_of_caregiver'] = $_POST['pfu_name_of_caregiver'];
		$post['pfu_treatment_status'] = $_POST['pfu_treatment_status'];
		$post['pfu_name_of_ADR'] = $_POST['pfu_name_of_ADR'];
		$post['pfu_approch_for_ADR'] = $_POST['pfu_approch_for_ADR'];
		$post['pfu_approch_for_ADR_other'] = $_POST['pfu_approch_for_ADR_other'];
		$post['pfu_ADR_occurance_last_visit'] = $_POST['pfu_ADR_occurance_last_visit'];
		$post['pfu_outcome_approch_for_ADR'] = $_POST['pfu_outcome_approch_for_ADR'];
		$post['pfu_refer_any_medical_advice'] = $_POST['pfu_refer_any_medical_advice'];
		$post['pfu_instance_of_stigma'] = $_POST['pfu_instance_of_stigma'];
		$post['pfu_addressed_by_counselling'] = $_POST['pfu_addressed_by_counselling'];
		$post['pfu_treatment_iterruption_last_visit'] = $_POST['pfu_treatment_iterruption_last_visit'];
		$post['pfu_number_of_doses_missed'] = $_POST['pfu_number_of_doses_missed'];
		$post['pfu_duration_of_iterruption'] = $_POST['pfu_duration_of_iterruption'];
		$post['pfu_last_counselling_iteraction'] = $_POST['pfu_last_counselling_iteraction'];
		$post['pfu_reason_of_iterruption'] = $_POST['pfu_reason_of_iterruption'];
		$post['pfu_reason_of_iterruption_other'] = $_POST['pfu_reason_of_iterruption_other'];
		$post['pfu_counselling_topic_covered'] = $_POST['pfu_counselling_topic_covered'];
		$post['pfu_counselling_topic_covered_other'] = $_POST['pfu_counselling_topic_covered_other'];
		$post['pfu_linkage_identified'] = $_POST['pfu_linkage_identified'];
		$post['pfu_linkage_made_towards'] = $_POST['pfu_linkage_made_towards'];
		$post['pfu_linkage_made_towards_other'] = $_POST['pfu_linkage_made_towards_other'];
		$post['pfu_number_of_caregiver_testing'] = $_POST['pfu_number_of_caregiver_testing'];
		$post['pfu_caregiver_diagnosed_TB_positive'] = $_POST['pfu_caregiver_diagnosed_TB_positive'];
		$post['pfu_household_member_started_treatment'] = $_POST['pfu_household_member_started_treatment'];
		$post['pfu_month_of_treatment'] = $_POST['pfu_month_of_treatment'];
		$post['pfu_number_of_doses_in_month'] = $_POST['pfu_number_of_doses_in_month'];
		$post['pfu_number_of_doses_missed_in_month'] = $_POST['pfu_number_of_doses_missed_in_month'];
		$post['pfu_mention_the_treatment_regimen'] = $_POST['pfu_mention_the_treatment_regimen'];
		$post['pfu_next_follo_up_date'] = $_POST['pfu_next_follo_up_date'];
		$post['pfu_next_follow_up_visit_place'] = $_POST['pfu_next_follow_up_visit_place'];
		$post['pfu_next_follow_up_visit_place_other'] = $_POST['pfu_next_follow_up_visit_place_other'];
		
		$post['pfu_csw_remarks'] = $_POST['pfu_csw_remarks'];
		$post['pfu_created_date'] = date('Y-m-d');
		$post['pfu_updated_date'] = date('Y-m-d');
		$patient_followup_id = $this->patient_model->addPatientFollowUp($post);
		if($patient_followup_id)
        {
        	$last_follow_up_data = $this->patient_model->getPatientFollowUpDate($patient_id);
			if(!empty($last_follow_up_data))
			{
				$post_pfud['pfud_phase'] = $last_follow_up_data[0]->pfud_phase;
				$post_pfud['pfud_date'] = $post['pfu_next_follo_up_date'];
				$post_pfud['patient_id'] = $patient_id;
				$post_pfud['pfud_no'] = $post['pfu_follow_up_visit_no'] + 1;
				$post_pfud['user_id'] = $_POST['user_id'];;
				$post_pfud['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
				$this->patient_model->addPatientFollowUpDate($post_pfud);
			}
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
	}

	/* show patient */
	public function editPatientFollowUp()
	{		
		$patient_id = $_POST['patient_id'];
		$pfu_id = $_POST['pfu_id'];
		$edit_patient_followup_res = $this->patient_model->editPatientFollowUp($patient_id, $pfu_id);
		if($edit_patient_followup_res)
        {
            echo json_encode(array("status"=>1, "edit_patient_followup_res"=>$edit_patient_followup_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
	}

	/* Add FollowUp */
	public function updatePatientFollowUp()
	{		
		$post['pfu_id'] = $_POST['pfu_id'];
		$post['patient_id'] = $_POST['patient_id'];
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$post['saksham_patient_id'] = $_POST['saksham_patient_id'];
		$post['pfu_patient_name'] = $_POST['pfu_patient_name'];
		$post['pfu_patient_father_name'] = $_POST['pfu_patient_father_name'];
		$post['pfu_patient_dob'] = $_POST['pfu_patient_dob'];
		$post['pfu_follow_up_visit'] = $_POST['pfu_follow_up_visit'];
		$post['pfu_follow_up_visit_no'] = $_POST['pfu_follow_up_visit_no'];
		$post['pfu_share_detail_status'] = $_POST['pfu_share_detail_status'];
		$post['pfu_visited_at'] = $_POST['pfu_visited_at'];
		$post['pfu_visited_at_other'] = $_POST['pfu_visited_at_other'];
		$post['pfu_country_id'] ='99';
		$post['pfu_state_id'] ='1493';
		$post['pfu_city'] = $_POST['pfu_city'];
		$post['pfu_address'] = $_POST['pfu_address'];
		$post['pfu_landmark'] = $_POST['pfu_landmark'];
		$post['pfu_postal_code'] = $_POST['pfu_postal_code'];
		$post['pfu_contact_no'] = $_POST['pfu_contact_no'];
		$post['pfu_name_of_caregiver'] = $_POST['pfu_name_of_caregiver'];
		$post['pfu_treatment_status'] = $_POST['pfu_treatment_status'];
		$post['pfu_name_of_ADR'] = $_POST['pfu_name_of_ADR'];
		$post['pfu_approch_for_ADR'] = $_POST['pfu_approch_for_ADR'];
		$post['pfu_approch_for_ADR_other'] = $_POST['pfu_approch_for_ADR_other'];
		$post['pfu_ADR_occurance_last_visit'] = $_POST['pfu_ADR_occurance_last_visit'];
		$post['pfu_outcome_approch_for_ADR'] = $_POST['pfu_outcome_approch_for_ADR'];
		$post['pfu_refer_any_medical_advice'] = $_POST['pfu_refer_any_medical_advice'];
		$post['pfu_instance_of_stigma'] = $_POST['pfu_instance_of_stigma'];
		$post['pfu_addressed_by_counselling'] = $_POST['pfu_addressed_by_counselling'];
		$post['pfu_treatment_iterruption_last_visit'] = $_POST['pfu_treatment_iterruption_last_visit'];
		$post['pfu_number_of_doses_missed'] = $_POST['pfu_number_of_doses_missed'];
		$post['pfu_duration_of_iterruption'] = $_POST['pfu_duration_of_iterruption'];
		$post['pfu_last_counselling_iteraction'] = $_POST['pfu_last_counselling_iteraction'];
		$post['pfu_reason_of_iterruption'] = $_POST['pfu_reason_of_iterruption'];
		$post['pfu_reason_of_iterruption_other'] = $_POST['pfu_reason_of_iterruption_other'];
		$post['pfu_counselling_topic_covered'] = $_POST['pfu_counselling_topic_covered'];
		$post['pfu_counselling_topic_covered_other'] = $_POST['pfu_counselling_topic_covered_other'];
		$post['pfu_linkage_identified'] = $_POST['pfu_linkage_identified'];
		$post['pfu_linkage_made_towards'] = $_POST['pfu_linkage_made_towards'];
		$post['pfu_linkage_made_towards_other'] = $_POST['pfu_linkage_made_towards_other'];
		$post['pfu_number_of_caregiver_testing'] = $_POST['pfu_number_of_caregiver_testing'];
		$post['pfu_caregiver_diagnosed_TB_positive'] = $_POST['pfu_caregiver_diagnosed_TB_positive'];
		$post['pfu_household_member_started_treatment'] = $_POST['pfu_household_member_started_treatment'];
		$post['pfu_month_of_treatment'] = $_POST['pfu_month_of_treatment'];
		$post['pfu_number_of_doses_in_month'] = $_POST['pfu_number_of_doses_in_month'];
		$post['pfu_number_of_doses_missed_in_month'] = $_POST['pfu_number_of_doses_missed_in_month'];
		$post['pfu_mention_the_treatment_regimen'] = $_POST['pfu_mention_the_treatment_regimen'];
		$post['pfu_next_follo_up_date'] = $_POST['pfu_next_follo_up_date'];
		$post['pfu_next_follow_up_visit_place'] = $_POST['pfu_next_follow_up_visit_place'];
		$post['pfu_next_follow_up_visit_place_other'] = $_POST['pfu_next_follow_up_visit_place_other'];
		$post['pfu_csw_remarks'] = $_POST['pfu_csw_remarks'];
		$post['pfu_updated_date'] = date('Y-m-d');
		$update_statue = $this->patient_model->updatePatientFollowUp($post);
		if($update_statue == '1')
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
	}

	/* show patient */
	public function delete_patientFollowUp()
	{	
		$pfu_id = $_POST['pfu_id'];
		$del_status = $this->patient_model->delete_patientFollowUp($pfu_id);
		if($del_status == '1')
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
	}

	/* Set Active / Inactive Status */
	public function setPermissionStatus()
	{
		$post['patient_id'] = $_POST['patient_id'];
		$post['patient_followup_permission'] = $_POST['patient_followup_permission'];
		if($this->patient_model->setStatus($post))
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}

	/* getFollowUpdate */
	public function getFollowUpdate()
	{
		$patient_id = $_POST['patient_id'];
		$last_follow_up_data = $this->patient_model->getPatientFollowUpDate($patient_id);
		if($del_status == '1')
        {
            echo json_encode(array("status"=>1, 'last_follow_up_data'=>$last_follow_up_data)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
	}

	/* getFollowUpdate */
	public function getCaregiversList()
	{
		$patient_id = $_POST['patient_id'];
		$caregiver_list = $this->patient_model->getCaregiversList($patient_id);
		if($del_status == '1')
        {
            echo json_encode(array("status"=>1, 'caregiver_list'=>$caregiver_list)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        }
	}
}

/* End of file */?>