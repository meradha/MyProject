<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class LabData extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/labdata_model');
	}

	/* Dashboard Show */
	public function viewData()
	{	
		$lab_data = $this->labdata_model->getAllLabData();
		if(!empty($lab_data))
		{
			echo json_encode(array("status"=>1, "lab_data"=>$lab_data)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
  	}

	/* Dashboard Show */
	public function labList()
	{	
		$lab_list = $this->labdata_model->getAllLabList();		
		if(!empty($lab_list))
		{
			echo json_encode(array("status"=>1, "lab_list"=>$lab_list)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
  	}

  	/* Add and Update */
	public function addLabData()
	{		
		$addData = $_POST['addData'];
		if($addData == 'addData')
		{
			$post['ld_year'] = $_POST['ld_year'];
			$post['ld_month'] = $_POST['ld_month'];
			$post['diagnosis_id'] = $_POST['diagnosis_id'];
			$post['ld_presumptive_tested'] = $_POST['ld_presumptive_tested'];
			$post['ld_presumptive_tested_positive'] = $_POST['ld_presumptive_tested_positive'];
			$post['ld_referred_by_saksham_sathi'] = $_POST['ld_referred_by_saksham_sathi'];
			$post['ld_tested_out_referred_by_saksham_sathi'] = $_POST['ld_tested_out_referred_by_saksham_sathi'];
			$post['ld_positive_referred_by_saksham_sathi'] = $_POST['ld_positive_referred_by_saksham_sathi'];
			$post['user_id'] = $_POST['user_id'];
			$post['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
			$post['ld_created_date'] = date('Y-m-d');
			$post['ld_updated_date'] = date('Y-m-d');
			$lab_data_id = $this->labdata_model->addLabData($post);
			if(!empty($lab_data_id))
			{
				echo json_encode(array("status"=>1)); 
			}
			else
			{
				echo json_encode(array("status"=>0)); 
			}
		}
		else
		{
			$post['ld_id'] = $addData ;
			$post['ld_year'] = $_POST['ld_year'];
			$post['ld_month'] = $_POST['ld_month'];
			$post['diagnosis_id'] = $_POST['diagnosis_id'];
			$post['ld_presumptive_tested'] = $_POST['ld_presumptive_tested'];
			$post['ld_presumptive_tested_positive'] = $_POST['ld_presumptive_tested_positive'];
			$post['ld_referred_by_saksham_sathi'] = $_POST['ld_referred_by_saksham_sathi'];
			$post['ld_tested_out_referred_by_saksham_sathi'] = $_POST['ld_tested_out_referred_by_saksham_sathi'];
			$post['ld_positive_referred_by_saksham_sathi'] = $_POST['ld_positive_referred_by_saksham_sathi'];
			$post['user_id'] = $_POST['user_id'];
			$post['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
			$post['ld_updated_date'] = date('Y-m-d');
			$lab_data_id = $this->labdata_model->updateLabData($post);
			if($lab_data_id == '1')
			{
				echo json_encode(array("status"=>1)); 
			}
			else
			{
				echo json_encode(array("status"=>0)); 
			}
		}
	}


	public function getLabDataByMonthYearLabID()
	{
		$diagnosis_id = $_POST['diagnosis_id'];
		$ld_year = $_POST['ld_year'];
		$ld_month = $_POST['ld_month'];
		$labdata_res = $this->labdata_model->getLabDataByMonthYearLabID($diagnosis_id, $ld_year, $ld_month);
		if(!empty($labdata_res))
		{
			echo json_encode(array("status"=>1, "labdata_res"=>$labdata_res)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	} 

    
}

/* End of file */?>