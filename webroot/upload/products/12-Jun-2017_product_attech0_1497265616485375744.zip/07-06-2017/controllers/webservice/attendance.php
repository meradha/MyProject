<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Attendance extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/attendance_model');
	}
	
	/* Details */
	public function addAttendance()
	{
		$post['user_id'] = $_POST['user_id'];	
		$post['user_all_levels'] = $_POST['user_all_level'].','.$_POST['user_id'];
		if(isset($_POST['attendance_login_time']) && $_POST['attendance_login_time'] != '')
		{
			$post['attendance_login_time'] = $_POST['attendance_login_time'];	
		}
		else
		{
			$post['attendance_logout_time'] = $_POST['attendance_logout_time'];	
		}
		$post['attendance_date'] = $_POST['attendance_date'];	
		$post['attendance_lat'] = $_POST['attendance_lat'];	
		$post['attendance_long'] = $_POST['attendance_long'];	
		$post['attendance_status'] = '1';	
		$post['attendance_created_date'] = date('Y-m-d');	
		$post['attendance_update_date'] = date('Y-m-d');	
		$attendance_result = $this->attendance_model->addAttendance($post);
		if(!empty($attendance_result))
		{
			echo json_encode(array("status"=>1, "attendance_id"=>$attendance_result)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
    }

}

/* End of file */?>