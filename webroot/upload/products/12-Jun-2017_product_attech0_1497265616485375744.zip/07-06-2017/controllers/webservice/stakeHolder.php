<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class StakeHolder extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/stakeholder_model');
	}

    /* Details */
	public function viewData()
	{
		$stakeholder_res = $this->stakeholder_model->getStakeHolder();
        if(!empty($stakeholder_res))
        {
            echo json_encode(array("status"=>1, "stakeholder_res"=>$stakeholder_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

    /* Details */
	public function healthpostArea()
	{
		$healthpostarea_list = $this->stakeholder_model->getAllHealthpostArea();
        if(!empty($healthpostarea_list))
        {
            echo json_encode(array("status"=>1, "healthpostarea_list"=>$healthpostarea_list)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

    /* add stakeholder */
	public function addStakeholder()
	{
		$post['stakeholder_let'] = $_POST['stakeholder_let'];
		$post['stakeholder_long'] = $_POST['stakeholder_long'];
		$post['stakeholder_mapping_date'] = $_POST['stakeholder_mapping_date'];
		$post['stakeholder_name'] = $_POST['stakeholder_name'];
		$post['stakeholder_phone'] = $_POST['stakeholder_phone'];
		$post['stakeholder_country_id'] = '99';
		$post['stakeholder_state_id'] = '1493';
		$post['stakeholder_city'] = 'Mumbai';
		$post['stakeholder_address'] = $_POST['stakeholder_address'];
		$post['stakeholder_landmark'] = $_POST['stakeholder_landmark'];
		$post['stakeholder_postal_code'] = $_POST['stakeholder_postal_code'];
		$post['stakeholder_type'] = $_POST['stakeholder_type'];
		$post['stakeholder_type_other'] = $_POST['stakeholder_type_other'];
		$post['stakeholder_correspondance_person'] = $_POST['stakeholder_correspondance_person'];		
		$post['stakeholder_trust_area'] = $_POST['stakeholder_trust_area'];
		$post['stakeholder_trust_area_other'] = $_POST['stakeholder_trust_area_other'];
		$post['stakeholder_focus_population'] = $_POST['stakeholder_focus_population'];
		$post['stakeholder_focus_population_other'] = $_POST['stakeholder_focus_population_other'];
		$post['stakeholder_area'] = $_POST['stakeholder_area'];
		$post['healthpostarea_id'] = $_POST['healthpostarea_id'];
		$post['stakeholder_power_structure'] = $_POST['stakeholder_power_structure'];
		$post['stakeholder_working_since'] = $_POST['stakeholder_working_since'];
		$post['stakeholder_any_remarks'] = $_POST['stakeholder_any_remarks'];
		$post['stakeholder_status'] = $_POST['stakeholder_status'];
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$post['stakeholder_created_date'] = date('Y-m-d');
		$post['stakeholder_updated_date'] = date('Y-m-d');
		$stakeHolder_id =  $this->stakeholder_model->addStakeHolder($post);
        if(!empty($stakeHolder_id))
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

	public function editStakeHolder()
	{
		$stakeHolder_id = $_POST['stakeHolder_id'];
		$stakeholder_res = $this->stakeholder_model->editStakeHolder($stakeHolder_id);
        if(!empty($stakeholder_res))
        {
            echo json_encode(array("status"=>1, "stakeholder_res"=>$stakeholder_res)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

    public function updateStakeholder()
	{
		$post['stakeHolder_id'] = $_POST['stakeHolder_id'];
		$post['stakeholder_mapping_date'] = $_POST['stakeholder_mapping_date'];
		$post['stakeholder_name'] = $_POST['stakeholder_name'];
		$post['stakeholder_phone'] = $_POST['stakeholder_phone'];
		$post['stakeholder_country_id'] = '99';
		$post['stakeholder_state_id'] = '1493';
		$post['stakeholder_city'] = 'Mumbai';
		$post['stakeholder_address'] = $_POST['stakeholder_address'];
		$post['stakeholder_landmark'] = $_POST['stakeholder_landmark'];
		$post['stakeholder_postal_code'] = $_POST['stakeholder_postal_code'];
		$post['stakeholder_type'] = $_POST['stakeholder_type'];
		$post['stakeholder_type_other'] = $_POST['stakeholder_type_other'];
		$post['stakeholder_correspondance_person'] = $_POST['stakeholder_correspondance_person'];		
		$post['stakeholder_trust_area'] = $_POST['stakeholder_trust_area'];
		$post['stakeholder_trust_area_other'] = $_POST['stakeholder_trust_area_other'];
		$post['stakeholder_focus_population'] = $_POST['stakeholder_focus_population'];
		$post['stakeholder_focus_population_other'] = $_POST['stakeholder_focus_population_other'];
		$post['stakeholder_area'] = $_POST['stakeholder_area'];
		$post['healthpostarea_id'] = $_POST['healthpostarea_id'];
		$post['stakeholder_power_structure'] = $_POST['stakeholder_power_structure'];
		$post['stakeholder_working_since'] = $_POST['stakeholder_working_since'];
		$post['stakeholder_any_remarks'] = $_POST['stakeholder_any_remarks'];
		$post['stakeholder_status'] = $_POST['stakeholder_status'];
		$post['user_id'] = $_POST['user_id'];
		$post['user_all_level'] = $_POST['user_all_level'].','.$_POST['user_id'];
		$post['stakeholder_updated_date'] = date('Y-m-d');
		$update_status =  $this->stakeholder_model->updateStakeHolder($post);
        if($stakeHolder_id == '1')
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
    }

	/* Delete */
	public function deleteStakeholder()
	{
		$stakeHolder_id = $_POST['stakeHolder_id'];
		$del_res = $this->stakeholder_model->deleteStakeholder($stakeHolder_id);
        if($del_res == '1')
        {
            echo json_encode(array("status"=>1)); 
        }
        else
        {
            echo json_encode(array("status"=>0)); 
        } 
	}	
}

/* End of file */?>