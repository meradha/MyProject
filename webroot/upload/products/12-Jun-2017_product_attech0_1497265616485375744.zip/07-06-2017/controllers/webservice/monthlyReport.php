<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class MonthlyReport extends MY_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('webservice/monthlyreport_model');
    }
    
    public function viewData()
    {
      $user_role_id   = $_POST['user_role_id'];
      $user_all_level = $_POST['user_all_level'];
      $user_id        = $_POST['user_id'];
      $start_date     = $_POST['start_date'];
      $end_date       = $_POST['end_date'];

      $stakeholder_res = $this->monthlyreport_model->getStakeholders($start_date, $end_date);
      $st              = 0;
      foreach ($stakeholder_res as $st_res) {
          $st_u_l_arr = explode(',', $st_res->user_all_level);
          if (in_array($user_id, $st_u_l_arr)) {
              $st++;
          }
      }
      $t_n_stakeholder = $st;
      
      $responsive_st_res = $this->monthlyreport_model->getResponsiveStakeholders($start_date, $end_date);
      $resp_st           = 0;
      foreach ($responsive_st_res as $resp_st_res) {
          $resp_st_u_l_arr = explode(',', $resp_st_res->user_all_level);
          if (in_array($user_id, $resp_st_u_l_arr)) {
              $resp_st++;
          }
      }
      $t_n_responsive_stakeholder = $resp_st;
      
      $un_responsive_st_res = $this->monthlyreport_model->getUnResponsiveStakeholders($start_date, $end_date);
      $un_resp_st           = 0;
      foreach ($un_responsive_st_res as $un_resp_st_res) {
          $un_resp_st_u_l_arr = explode(',', $un_resp_st_res->user_all_level);
          if (in_array($user_id, $un_resp_st_u_l_arr)) {
              $un_resp_st++;
          }
      }
      $t_n_un_responsive_stakeholder = $un_resp_st;
      
      $self_referral_res = $this->monthlyreport_model->getTotalSelfReferral($start_date, $end_date);
      $self              = '0';
      foreach ($self_referral_res as $self_res) {
          $self_u_l_arr = explode(',', $self_res->user_all_level);
          if (in_array($user_id, $self_u_l_arr)) {
              $self++;
          }
      }
      $t_n_self_referral = $self;
      

      $community_referral_res = $this->monthlyreport_model->getTotalCommunityReferral($start_date, $end_date);
      $community              = '0';
      foreach ($community_referral_res as $community_res) {
          $community_u_l_arr = explode(',', $community_res->user_all_level);
          if (in_array($user_id, $community_u_l_arr)) {
              $community++;
          }
      }
      $t_n_community_referral = $community;
      
      $lab_res = $this->monthlyreport_model->getLabName();

      $referred_case = $this->monthlyreport_model->getAllReferredCase($start_date, $end_date);
      $referred_case_positive = $this->monthlyreport_model->getAllReferredCasePositive($start_date, $end_date);

      if(!empty($lab_res) || !empty($t_n_community_referral) || !empty($t_n_self_referral) || !empty($t_n_un_responsive_stakeholder) || !empty($t_n_responsive_stakeholder) || !empty($t_n_stakeholder) || !empty($referred_case) || !empty($referred_case_positive) )
      {
        echo json_encode(array("status"=>1, "lab_res"=>$lab_res, "t_n_community_referral"=>$t_n_community_referral, "t_n_self_referral"=>$t_n_self_referral, "t_n_un_responsive_stakeholder"=>$t_n_un_responsive_stakeholder, "t_n_responsive_stakeholder"=>$t_n_responsive_stakeholder, "t_n_stakeholder"=>$t_n_stakeholder, "referred_case"=>$referred_case, "referred_case_positive"=>$referred_case_positive)); 
      }
      else
      {
        echo json_encode(array("status"=>1, "lab_res"=>array(), "t_n_community_referral"=>array(), "t_n_self_referral"=>array(), "t_n_un_responsive_stakeholder"=>array(), "t_n_responsive_stakeholder"=>array(), "t_n_stakeholder"=>array(), "referred_case"=>array(), "referred_case_positive"=>array())); 
      }
    }

}

/* End of file */
?>