
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>webroot/admin/css/chat/style.css">
<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			Chat	<small>Control panel</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Chat</li>
        </ol>
    </section>
    <section class="content">       
      <div class="box">
        <!-- /.box-header -->
        <div class="box-body">
            <div class="row">
              <div class="col-md-12">
                <?php 
                $user_id = $this->data['session'][0]->user_id;
                $user_all_level = $this->data['session'][0]->user_all_level;
                foreach ($chat_res as $value) 
                {
                  if($value->user_id == $user_id)
                  {
                  ?>
                  <div class="row">
                    <div class="col-md-8 pull-right">
                      <div id="output">
                        <div class="col-md-12 col-sm-12 col-xs-12 chat_streep">
                          <div class="col-md-2 col-sm-2 col-xs-3 chat_streep_image">
                              <i class="<?php echo $value->chat_avatar_name; ?>"></i>
                          </div>
                          <div class="col-md-10 col-sm-10 col-xs-9 chat_streep_text">
                              <p class="leftt">
                                  <b><?php echo $value->chat_user_name; ?></b><br>
                                  <?php echo $value->chat_text_message; ?><br>
                                  <span class="rightt"><?php echo $value->chat_date.' '.$value->chat_time; ?></span>
                              </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php
                  }
                  else
                  {
                  ?>
                  <div class="row">
                    <div class="col-md-8 pull-left">
                      <div id="output">
                        <div class="col-md-12 col-sm-12 col-xs-12 chat_streep">
                          <div class="col-md-2 col-sm-2 col-xs-3 chat_streep_image">
                              <i class="<?php echo $value->chat_avatar_name; ?>"></i>
                          </div>
                          <div class="col-md-10 col-sm-10 col-xs-9 chat_streep_text">
                              <p class="leftt">
                                  <b><?php echo $value->chat_user_name; ?></b><br>
                                  <?php echo $value->chat_text_message; ?><br>
                                  <span class="rightt"><?php echo $value->chat_date.' '.$value->chat_time; ?></span>
                              </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <?php
                  }
                }
                ?>
                <p id="presence" style="text-align:right;"></p>
                <div class="row">
                  <div class="col-md-8 col-md-offset-4">
                    <div id="output"></div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- /.box-body -->      
        <div class="box-footer">
          <div class="col-md-1">
            <i id="avatar" class="face12"></i>
          </div>
          <div class="form-group col-md-6">
            <div class="input text">
              <textarea style="padding: 2px 5px;" class="form-control" name="" id="input" placeholder="type your message"></textarea>
            </div>
          </div>
          <div class="col-md-2">
            <br>
            <button class="btn btn-success btn-sm" type="submit" name="Submit" id="button">Submit</button>
          </div>
        </div>
        <div class="clearfix">&nbsp;</div>
      </div>
      <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<script src="http://cdn.pubnub.com/pubnub.min.js"></script>
<script type="text/javascript">

  var i = 0;
  var output = PUBNUB.$('output');
  var input = PUBNUB.$('input');
  var button = PUBNUB.$('button');
  var avatar = PUBNUB.$('avatar');
  var presence = PUBNUB.$('presence');
  var channel = 'mchat';

  (function() 
  {
    avatar.className = 'face-' + ((Math.random() * 13 + 1) >>> 0) + ' color-' + ((Math.random() * 10 + 1) >>> 0);
    var p = PUBNUB.init({
      uuid: '<?php echo $this->user; ?>',
      subscribe_key: 'sub-c-4b02d3d2-decc-11e6-9090-0619f8945a4f',
      publish_key:   'pub-c-e4d7c5ef-978f-46c6-ba3d-5ee24cf2f9dd', 
      ssl:true
    });

    p.subscribe({
      channel  : channel,
      callback : function(m)
      {
        var dt = new Date();
        var str = 'chat_avatar_name='+m.avatar+'&chat_text_message='+m.text.replace( /[<>]/ig, '' )+'&chat_user_name='+"<?php echo $this->user; ?>"+'&user_id='+"<?php echo $user_id; ?>"+'&user_all_level='+"<?php echo $user_all_level; ?>"+'&chat_let='+"<?php echo $this->data['lat']; ?>"+'&chat_long='+"<?php echo $this->data['lon']; ?>"+'&chat_date='+convert(dt)+'&chat_time='+tConv24(convert(new Date().toString("hh:mm tt")));
        var PAGE = '<?php echo base_url(); ?>admin/chat/addChat';
        // alert(str);return false;
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {   
              
                if(data != "0")
                {
                  location.reload();
                }
            } 
        });
        i++;
      },
      presence: function(m){
        if(m.occupancy > 1) {
          presence.textContent = m.occupancy + ' people online';
        } 
        else {
          presence.textContent = 'Nobody else is online';
        }
      }
    });

    p.bind('keyup', input, function(e)
    {
      (e.keyCode || e.charCode) === 13 && publish()
    });

    p.bind('click', button, publish);
    function publish()
    {
      p.publish({
        channel : channel, 
        message : {avatar: avatar.className, text: input.value,uuid:'<?php echo $this->user; ?>'},
        x : (input.value='')
      });
    }
  })();


  function convert(str) 
  {
    var date = new Date(str),
    mnth = ("0" + (date.getMonth()+1)).slice(-2),
    day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth,day].join("-");
  }
  

  function formatDate(date) 
  {
    var d = new Date(date);
    var hh = d.getHours();
    var m = d.getMinutes();
    var s = d.getSeconds();
    var dd = "AM";
    var h = hh;
    if (h >= 12) 
    {
      h = hh - 12;
      dd = "PM";
    }
    if (h == 0) 
    {
      h = 12;
    }
    m = m < 10 ? "0" + m : m;
    s = s < 10 ? "0" + s : s;
    var pattern = new RegExp("0?" + hh + ":" + m + ":" + s);
    var replacement = h + ":" + m;
    replacement += " " + dd;
    return date.replace(pattern, replacement);
  }

  function convert(str) 
  {
    var date = new Date(str),
    hour = date.getHours(),
    minute  = date.getMinutes(),
    second = date.getSeconds();
    return [hour,minute].join(":");
  }

  function tConv24(time24) 
  {
    var ts = time24;
    var H = +ts.substr(0, 2);
    var h = (H % 12) || 12;
    h = (h < 10)?("0"+h):h;  // leading 0 at the left for 1 digit hours
    var ampm = H < 12 ? " AM" : " PM";
    ts = h + ts.substr(2, 3) + ampm;
    return ts;
  };

  function getImage() 
  {
    navigator.camera.getPicture(uploadPhoto, function(message) {
      alert('get picture failed');
    }, 
    {
    quality: 100,
    destinationType: navigator.camera.DestinationType.DATA_URL,
    sourceType: navigator.camera.PictureSourceType.PHOTOLIBRARY
    });
  }

  function uploadPhoto(imageURI)
  {
    console.log("imageURI==="+imageURI);
  }
</script>
<!-- <script src="<?php echo base_url();?>webroot/admin/css/chat/app.js"></script> -->