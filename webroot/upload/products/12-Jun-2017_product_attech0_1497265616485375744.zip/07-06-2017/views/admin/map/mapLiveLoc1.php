<?php
  $user_role_id = $this->data['session'][0]->user_role_id;
  $user_id      = $this->data['session'][0]->user_id;
  
  $user_ids = array();$loc_arr = array();
  
  $getChildUser = $this->taskassign_model->getUserByRoleAndLevel($user_id,7);
  
  foreach($getChildUser as $user){
	  $user_ids[] = $user->user_id;
	  }
  $user_ids_imp = implode(',',$user_ids);
  
  $getUserCurrentLoc = $this->map_model->getUserCurrentLoc($user_ids_imp);
  
  foreach($getUserCurrentLoc as $loc){
	  if($loc['location_lat'] != '0' && $loc['location_lat'] != NULL && $loc['location_long'] != '0' && $loc['location_long'] != NULL){
	   $lat = floatval($loc['location_lat']);
	   $lng = floatval($loc['location_long']);
	   
	   $fromRegAddress = $welcome->getAddressFromLatLng($lat,$lng);
		if($fromRegAddress)
		$fromRegAddress = $fromRegAddress;
		else
		$fromRegAddress = 'No Address Found';
					
	   $loc_arr[] = array($lat,$lng,'<p><b>Name:</b> '.$loc['user_name'].'</p><p><b>Address:</b> '.$fromRegAddress.'</p><p><b>Time:</b> '.$loc['location_date_time'].'</p>',base_url('webroot/admin/upload/common_img/current-loc.png')); 
	    }
	  }
   $loc_arr_json = json_encode($loc_arr);
  
?>

<script type="text/javascript">
var loc = [];

loc = <?php echo $loc_arr_json ?>;

function initialize(str='') 
  {
	if(str!=''){
		
		 $.ajax({
				url: '<?php base_url() ?>userLiveLoc/getUserCurrentLoc',
				data: 'user_id='+ str,
				type: "POST",
				dataType:"json",
				async:false,
				
				success: function(data)	
				 { 
			   loc = data;
			   console.log(loc);
	     	     } 
		       }); 
	}
	
    var myOptions = {
      center: new google.maps.LatLng(19.075984, 72.877656),
      zoom: 10,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(document.getElementById("map"), myOptions);
    setMarkers(map,loc);
 
 }
  function setMarkers(map,locations)
  {
    var marker, i;

  for (i = 0; i < locations.length; i++)
  {  
    var lat          = locations[i][0];
    var long         = locations[i][1];
    var str          = locations[i][2];
    var custom_icons = locations[i][3];
    latlngset        = new google.maps.LatLng(lat, long);

	
	
    var marker = new google.maps.Marker({  
      map: map, title: str , position: latlngset,
      icon: custom_icons
    });
	
	
     
    map.setCenter(marker.getPosition())

    
 
    var infowindow = new google.maps.InfoWindow()
    google.maps.event.addListener(marker,'click', (function(marker,str,infowindow){ 
      return function(){
        infowindow.setContent(str);
        infowindow.open(map,marker);
      };
    })(marker,str,infowindow)); 
  }
}
  </script>
 
<script src="//maps.googleapis.com/maps/api/js?key=AIzaSyA47YEA7hkdrE6PJYe91NawcsmvW9DL3ss&callback=initialize" async defer></script>

<aside onload="" class="right-side">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>  
         <?php echo $welcome->loadPo('Map'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
      </h1>
      <ol class="breadcrumb">
         <li><a href="#"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
         <li class="active"><?php echo $welcome->loadPo('Map'); ?></li>
      </ol>
   </section>
   <section class="content">
      <div class="box">
         <!-- /.box-header -->
         <div class="box-body">
            <div class="row">
               <div class="col-md-12">
		<?php if($user_role_id!=7){
              $getUserByRoleAndLevel = $this->taskassign_model->getUserByRoleAndLevel($user_id,7); ?>
                   <select style="width:50%;margin: 0 auto 0;" onchange="initialize(this.value)" class="form-control" id="saksham_id">
                    <option value="">---SELECT SAKSHAM---</option>
                    <?php
                        foreach($getUserByRoleAndLevel as $userlist){?>
                        <option value="<?php echo $userlist->user_id; ?>"><?php echo $userlist->user_name ?></option>
                        <?php }
                        ?>
                   </select>
                   <br>
                <?php } ?>
                  <div id="map" style="height:500px;width: 100%;">
                  </div>
               </div>
            </div>
         </div>
         <div class="clearfix">&nbsp;</div>
      </div>
      <!-- /.box -->
   </section>
   <!-- /.content -->
</aside>