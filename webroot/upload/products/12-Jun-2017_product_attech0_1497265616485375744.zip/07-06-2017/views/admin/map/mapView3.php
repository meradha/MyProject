<?php
  $user_role_id              = $this->data['session'][0]->user_role_id;
  $user_id                   = $this->data['session'][0]->user_id;
  $get_patient               = $this->map_model->getAllpatient($user_id);
  $get_communities           = $this->map_model->getCommunityawareness($user_id);
  $get_stack_holder_meetings = $this->map_model->getStakeholdermeeting($user_id);
  $loc_arr1 = array();$loc_arr2 = array();$loc_arr3 = array();
  foreach($get_patient as $list1){
	  if($list1->patient_let != '0' && $list1->patient_let != NULL && $list1->patient_long != '0' && $list1->patient_long != NULL){
	   $lat = floatval($list1->patient_let);
	   $lng = floatval($list1->patient_long);
	   $loc_arr1[] = array($lat,$lng,'<p><b>Patient Name:</b> '.$list1->patient_name.'</p>',base_url('webroot/admin/upload/common_img/p.png')); 
	    }
	  }
   $loc_arr_json1 = json_encode($loc_arr1);
   
   /*------------------------------*/
   
   foreach($get_communities as $list2)
    {
      if($list2->tca_let != '0' && $list2->tca_let != NULL && $list2->tca_long != '0' && $list2->tca_long != NULL)
      {
	   $lat = floatval($list2->tca_let);
	   $lng = floatval($list2->tca_long);
	   $loc_arr2[] = array($lat,$lng,'<p><b>Place:</b> '.$list2->tca_activity_place.'</p><p>Date: '.$list2->tca_activity_date.'</p>',base_url('webroot/admin/upload/common_img/c.png')); 
      } 
    }
  $loc_arr_json2 = json_encode($loc_arr2);
  
  /*------------------------------*/
  foreach($get_stack_holder_meetings as $list3)
    {
      if($list3->shm_let != '0' && $list3->shm_let != NULL && $list3->shm_long != '0' && $list3->shm_long != NULL)
      {
		$lat = floatval($list3->shm_let);
	    $lng = floatval($list3->shm_long);
		$loc_arr3[] = array($lat,$lng,'<p><b>Location:</b> '.$list3->shm_meting_location.'</p><p>Date: '.$list3->shm_meeting_date.'</p>',base_url('webroot/admin/upload/common_img/s.png')); 
      } 
    }
  $loc_arr_json3 = json_encode($loc_arr3);
?>

<script type="text/javascript">
  var patient = [];
      patient = <?php echo $loc_arr_json1 ?>;
    
  var comm_meetings = [];
      comm_meetings = <?php echo $loc_arr_json2 ?>;
   
  var stack_meetings = [];
      stack_meetings = <?php echo $loc_arr_json3 ?>;
   
 
  function initialize(str='') 
  {
	if(str!=''){
		
		 $.ajax({
				url: '<?php base_url() ?>map/getAllpatient',
				data: 'user_id='+ str,
				type: "POST",
				dataType:"json",
				async:false,
				//cache: false,
				success: function(data)	
				 { 
			patient = data;
	     	     } 
		       }); 

          $.ajax({
				url: '<?php base_url() ?>map/getCommunityawareness',
				data: 'user_id='+ str,
				type: "POST",
				dataType:"json",
				//cache: false,
				async:false,
				success: function(data)	
				 { 
				  comm_meetings = data;
			     } 
		        });

           $.ajax({
				url: '<?php base_url() ?>map/getStakeholdermeeting',
				data: 'user_id='+ str,
				type: "POST",
				dataType:"json",
				//cache: false,
				async:false,
				success: function(data)	
				 { 
				  stack_meetings = data;
			     } 
		        });   							
			
		}
	
    var myOptions = {
      center: new google.maps.LatLng(19.075984, 72.877656),
      zoom: 12,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(document.getElementById("map"), myOptions);
    setMarkers(map,patient);
    setMarkers(map,comm_meetings);
    setMarkers(map,stack_meetings);
 }
  function setMarkers(map,locations)
  {
    var marker, i;

  for (i = 0; i < locations.length; i++)
  {  
    var lat          = locations[i][0];
    var long         = locations[i][1];
    var str          = locations[i][2];
    var custom_icons = locations[i][3];
    latlngset        = new google.maps.LatLng(lat, long);

	
	
    var marker = new google.maps.Marker({  
      map: map, title: str , position: latlngset,
      icon: custom_icons
    });
	
     
    map.setCenter(marker.getPosition())

   
    var infowindow = new google.maps.InfoWindow()
    google.maps.event.addListener(marker,'click', (function(marker,str,infowindow){ 
      return function(){
        infowindow.setContent(str);
        infowindow.open(map,marker);
      };
    })(marker,str,infowindow)); 
  }
}
</script>
 
<script src="//maps.googleapis.com/maps/api/js?key=AIzaSyA47YEA7hkdrE6PJYe91NawcsmvW9DL3ss&callback=initialize" async defer></script>

<aside onload="" class="right-side">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>  
         <?php echo $welcome->loadPo('Map'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
      </h1>
      <ol class="breadcrumb">
         <li><a href="#"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
         <li class="active"><?php echo $welcome->loadPo('Map'); ?></li>
      </ol>
   </section>
   <section class="content">
      <div class="box">
         <!-- /.box-header -->
         <div class="box-body">
            <div class="row">
               <div class="col-md-12">
		<?php if($user_role_id!=7){
              $getUserByRoleAndLevel = $this->taskassign_model->getUserByRoleAndLevel($user_id,7); ?>
                   <select style="width:50%;margin: 0 auto 0;" onchange="initialize(this.value)" class="form-control" id="saksham_id">
                    <option value="">---SELECT SAKSHAM---</option>
                    <?php
                        foreach($getUserByRoleAndLevel as $userlist){?>
                        <option value="<?php echo $userlist->user_id; ?>"><?php echo $userlist->user_name ?></option>
                        <?php }
                        ?>
                   </select>
                   <br>
                <?php } ?>
                  <div id="map" style="height:500px;width: 100%;">
                  </div>
               </div>
            </div>
         </div>
         <div class="clearfix">&nbsp;</div>
      </div>
      <!-- /.box -->
   </section>
   <!-- /.content -->
</aside>