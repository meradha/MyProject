<?php
  $user_id = $this->data['session'][0]->user_id;
  $get_patient = $this->map_model->getAllpatient($user_id);
  $get_communities = $this->map_model->getCommunityawareness($user_id);
  $get_stack_holder_meetings = $this->map_model->getStakeholdermeeting($user_id);
?>

<script type="text/javascript">
  var patient = [
    <?php
    foreach($get_patient as $list)
    {
      if($list->patient_let != '0' && $list->patient_let != NULL && $list->patient_long != '0' && $list->patient_long != NULL)
      {
        echo '['.$list->patient_let.','.$list->patient_long.',"'.$list->patient_name.'","p"'.',"'.base_url('webroot/admin/upload/common_img/p.png').'"],';
      }
    } 
    ?>
  ];

  var comm_meetings = [
    <?php
    foreach($get_communities as $list)
    {
      if($list->tca_let != '0' && $list->tca_let != NULL && $list->tca_long != '0' && $list->tca_long != NULL)
      {
        echo '['.$list->tca_let.','.$list->tca_long .',"'.$list->tca_activity_place.'","c"'.',"'.base_url('webroot/admin/upload/common_img/c.png').'"],';
      } 
    } 
    ?>
  ];

  var stack_meetings = [
    <?php
    foreach($get_stack_holder_meetings as $list)
    {
      if($list->shm_let != '0' && $list->shm_let != NULL && $list->shm_long != '0' && $list->shm_long != NULL)
      {
        echo '['.$list->shm_let.','.$list->shm_long .',"'.$list->shm_meting_location.'","s"'.',"'.base_url('webroot/admin/upload/common_img/s.png').'"],';
      } 
    } 
    ?>
  ];

  function initialize() 
  {
    var myOptions = {
      center: new google.maps.LatLng(19.075984, 72.877656),
      zoom: 12,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    var map = new google.maps.Map(document.getElementById("map"), myOptions);
    setMarkers(map,patient);
    setMarkers(map,comm_meetings);
    setMarkers(map,stack_meetings);
  }

  function setMarkers(map,locations)
  {
    var marker, i;

  for (i = 0; i < locations.length; i++)
  {  
    var lat  = locations[i][0];
    var long = locations[i][1];
    var str =  locations[i][2];
    var name =  locations[i][2];
    var indenti = locations[i][3];
    var custom_icons = locations[i][4];
    latlngset = new google.maps.LatLng(lat, long);

    var marker = new google.maps.Marker({  
      map: map, title: str , position: latlngset,
      icon: custom_icons
    });
    map.setCenter(marker.getPosition())

    if(indenti=='p')
    {
      var content = "Patient Name: " + str
    }
    else if(indenti=='c')
    {
      var content = "Place: " + str
    }
    else if(indenti=='s')
    {
      var content = "Place: " + str
    }
    var infowindow = new google.maps.InfoWindow()
    google.maps.event.addListener(marker,'click', (function(marker,content,infowindow){ 
      return function(){
        infowindow.setContent(content);
        infowindow.open(map,marker);
      };
    })(marker,content,infowindow)); 
  }
}
  </script>
 <script src="//maps.googleapis.com/maps/api/js?key=AIzaSyA47YEA7hkdrE6PJYe91NawcsmvW9DL3ss&callback=initialize" async defer></script> 

<aside onload="" class="right-side">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>  
         <?php echo $welcome->loadPo('Map'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
      </h1>
      <ol class="breadcrumb">
         <li><a href="#"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
         <li class="active"><?php echo $welcome->loadPo('Map'); ?></li>
      </ol>
   </section>
   <section class="content">
      <div class="box">
         <!-- /.box-header -->
         <div class="box-body">
            <div class="row">
               <div class="col-md-12">
                  <div id="map" style="height:500px;width: 100%;">
                  </div>
               </div>
            </div>
         </div>
         <div class="clearfix">&nbsp;</div>
      </div>
      <!-- /.box -->
   </section>
   <!-- /.content -->
</aside>