<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Referral Unit Details'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Referral Unit Details'); ?></li>
        </ol>
    </section>   
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <div class="pull-left">
                    <h3 class="box-title"><?php echo $welcome->loadPo('Referral Unit Details'); ?></h3>
                </div>
                <div class="pull-right box-tools">
                    <?php
                        foreach($getAllTabAsPerRole as $role)
                        {
                            if($this->uri->segment(2) == $role->controller_name && $role->userAdd == '1')
                            {
                                ?>
                                    <a href="<?php echo base_url();?>admin/diagnosisCenter/addDiagnosisCenter" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Add New'); ?></a>              
                                <?php
                            }
                        }
                    ?>                    
                </div>
            </div>           
            <!-- /.box-header -->
            <div class="box-body">
                <div>
                    <div id="msg_div">
                        <?php echo $this->session->flashdata('message');?>
                    </div>
                </div>
                <table id="example2" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th><?php echo $welcome->loadPo('Owner Name'); ?></th>
                            <th><?php echo $welcome->loadPo('Lab Name'); ?></th>
                            <th><?php echo $welcome->loadPo('Email'); ?></th>
                            <th><?php echo $welcome->loadPo('Phone'); ?></th>
                            <th><?php echo $welcome->loadPo('Address'); ?></th>
                            <th><?php echo $welcome->loadPo('City'); ?></th>
                            <th><?php echo $welcome->loadPo('Postal Code'); ?></th>
                            <th><?php echo $welcome->loadPo('Status'); ?></th>
                            <th><?php echo $welcome->loadPo('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if(!empty($diagnosis_center_res))
                            {
                                foreach($diagnosis_center_res as $res)
                                {
                                    ?>
                                    <tr>
                                        <td><?php echo $res->diagnosis_owner_name; ?></td>
                                        <td><?php echo $res->diagnosis_name; ?></td>
                                        <td><?php echo $res->diagnosis_email; ?></td>
                                        <td><?php echo $res->diagnosis_mobile; ?></td>
                                        <td><?php echo $res->diagnosis_address; ?></td>
                                        <td><?php echo $res->diagnosis_city; ?></td>
                                        <td><?php echo $res->diagnosis_postal_code; ?></td>
                                        <td  width="10%">
                                            <?php
                                                if($res->diagnosis_status == '1')
                                                {
                                                    ?>
                                                    <span class="text-success"><?php echo $welcome->loadPo('Responsive'); ?></span>
                                                    <?php
                                                }
                                                else
                                                {
                                                    ?>
                                                    <span class="text-danger"><?php echo $welcome->loadPo('Unresponsive'); ?></span>
                                                    <?php
                                                }
                                            ?>
                                        </td>
                                        <td width="20%">
                                            <?php
                                                foreach($getAllTabAsPerRole as $role)
                                                {
                                                    if($this->uri->segment(2) == $role->controller_name && $role->userEdit == '1')
                                                    {
                                                        ?>
                                                            <a href="<?php echo base_url();?>admin/diagnosisCenter/addDiagnosisCenter/<?php echo $res->diagnosis_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp;                
                                                        <?php
                                                    }
                                                    if($this->uri->segment(2) == $role->controller_name && $role->userDelete == '1')
                                                    {
                                                        ?>
                                                            <a class="confirm" onclick="return delete_diagnosisCenter(<?php echo $res->diagnosis_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>                                      
                                                        <?php
                                                    }
                                                }
                                            ?>&nbsp;&nbsp;   
                                            <a href="<?php echo base_url();?>admin/diagnosisCenter/diagnosisCenterView/<?php echo $res->diagnosis_id; ?>" title="Edit"><i class="fa fa-eye fa-2x "></i></a>&nbsp;&nbsp;     
                                        </td>
                                    </tr>
                                    <?php
                                }
                            }
                            else
                            {
                                ?>
                                <tr>
                                    <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                </tr>
                                <?php
                            }
                            
                        ?>
                       
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function delete_diagnosisCenter(diagnosis_id)
    {
        bootbox.confirm("Are you sure you want to delete referral unit details",function(confirmed){
            if(confirmed)
            {
                location.href="<?php echo base_url();?>admin/diagnosisCenter/delete_diagnosisCenter/"+diagnosis_id;
            }
        });
    }    
</script>>