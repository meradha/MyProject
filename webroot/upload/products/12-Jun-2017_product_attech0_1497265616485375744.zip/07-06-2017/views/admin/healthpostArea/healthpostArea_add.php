<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			<?php echo $welcome->loadPo('Healthpost Area'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/healthpostArea"><?php echo $welcome->loadPo('Healthpost Area'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Healthpost Area Add'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Healthpost Area Add</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/healthpostArea" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div>                     
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Healthpost Area Name'); ?><span class="text-danger">*</span></label>
                                <input name="helthpostarea_name" class="form-control" type="text" id="helthpostarea_name" value="<?php echo set_value('helthpostarea_name'); ?>" />
                                <?php echo form_error('helthpostarea_name','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>                     
                    </div>                   
                    <div class="row">    
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Status'); ?></label>
                                <select name="helthpostarea_status" id="helthpostarea_status" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('select'); ?> --</option>
                                    <option value="1"><?php echo $welcome->loadPo('Responsive'); ?></option>
                                    <option value="0"><?php echo $welcome->loadPo('Unresponsive'); ?></option>
                                </select>
                                <?php echo form_error('helthpostarea_status','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Add" ><?php echo $welcome->loadPo('Submit'); ?></button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/healthpostArea"><?php echo $welcome->loadPo('Cancel'); ?></a>
                </div>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->