<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('User'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/user"><?php echo $welcome->loadPo('User'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('User Add'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <div class="pull-left">
                    <h3 class="box-title"><?php echo $welcome->loadPo('User Add'); ?></h3>
                </div>
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/user" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
               <?php
               foreach ($user_edit as $u_res)
               {
                   ?>
                   <!-- /.box-header -->
                    <div class="box-body">
                        <div>
                            <div id="msg_div">
                                <?php echo $this->session->flashdata('message');?>
                            </div>
                        </div> 
                        <div class="row"> 
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Email'); ?><span class="text-danger">*</span></label>
                                    <input disabled name="user_email" class="form-control" type="email" id="user_email" value="<?php echo $u_res->user_email; ?>" />
                                    <?php echo form_error('user_email','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Username'); ?><span class="text-danger">*</span></label>
                                    <input disabled name="user_uname" class="form-control" min="0" type="text" id="user_uname" value="<?php echo $u_res->user_uname; ?>" />
                                    <?php echo form_error('user_uname','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div>  
                        </div>
                        <?php $user_role_id = $this->data['session'][0]->user_role_id; ?>

                        <div class="row">                         
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('User Role'); ?><span class="text-danger">*</span></label>
                                    <select class="form-control"  name="user_role_id" id="user_role_id" onchange="selectRole(this.value, <?php echo $user_role_id; ?>)">
                                        <?php 
                                            foreach ($role_list as $r_list)
                                            {
                                                ?>
                                                <option <?php if($u_res->user_role_id == $r_list->role_id){ echo 'selected'; } ?> value="<?php echo $r_list->role_id; ?>"><?php echo $r_list->role_name; ?></option>
                                                <?php
                                            }
                                        ?>
                                    </select>
                                    <?php echo form_error('user_role_id','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="row" id="p_user1"> 
                        <?php
                            $all_user_level = explode(',', $u_res->user_all_level);
                           
                            for($i=0; $i<count($all_user_level); $i++)
                            {
                                if($all_user_level[$i])
                                {
                                    foreach ($all_user as $all_u_res) 
                                    {
                                        if($all_u_res->user_id == $all_user_level[$i])
                                        { 
                                            $user_id = $this->data['session'][0]->user_id;

                                            ?>

                                            <div class="form-group col-md-4">
                                                <div class="input text">
                                                    <label><?php if($i==1){ echo 'Parent User'; }else{ echo 'Child User'; } ?></label>
                                                    <input disabled class="form-control" type="text"  value="<?php echo $all_u_res->user_name; ?>" />
                                                </div>
                                            </div>
                                            <?php
                                            if($i==count($all_user_level)-1)
                                            {
                                                ?>
                                                <span class="btn btn-sm btn-info" id="change"><?php echo $welcome->loadPo('Change'); ?></span>
                                                <input type="hidden" name="change_level" value="" id="change_level">
                                                <span class="btn btn-sm btn-danger" style="display: none" id="cancel"><?php echo $welcome->loadPo('Cancel'); ?></span>
                                                <?php
                                            }
                                        }
                                    }
                                }
                            }
                        ?>
                            
                        </div>

                        <div class="row" id="p_user" style="display: none">                         
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Parent User'); ?><span class="text-danger">*</span></label>
                                    <select class="form-control"  name="user_parent_u_id[]" id="user_parent_u_id" onchange="getChildUser(this.value);">
                                       <option value="">-- Select --</option>
                                        <?php 
                                            foreach ($user_list as $u_list)
                                            {
                                                $user_id = $this->data['session'][0]->user_id;
                                                $u_parent_id = explode(',', $u_list->user_all_level);
                                                if(in_array($user_id , $u_parent_id))
                                                {
                                                    ?>
                                                    <option value="<?php echo $u_list->user_id; ?>"><?php echo $u_list->user_name; ?></option>
                                                    <?php
                                                }
                                            }
                                        ?>
                                    </select>
                                    <?php echo form_error('user_parent_u_id','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div>
                            <div id="ch_user"></div>
                        </div>

                        <div class="row">
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Full Name'); ?><span class="text-danger">*</span></label>
                                    <input name="user_name" class="form-control" type="text" id="user_name" value="<?php echo $u_res->user_name; ?>" />
                                    <?php echo form_error('user_name','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Phone'); ?><span class="text-danger">*</span></label>
                                    <input name="user_phone" class="form-control" min="0" type="number" id="user_phone" value="<?php echo $u_res->user_phone; ?>" />
                                    <?php echo form_error('user_phone','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div> 
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Date of Birth'); ?></label>
                                    <div class='input-group date' id='user_dob'>
                                        <input type="text" class="form-control" name="user_dob" id="user_dob" placeholder="" value="<?php echo $u_res->user_dob; ?>">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                    <?php echo form_error('user_dob','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div> 
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Gender'); ?><span class="text-danger">*</span></label>
                                     <select class="form-control"  name="user_gender" id="user_gender">
                                        <option value="">-- Select --</option>                                   
                                        <option <?php if($u_res->user_gender == 'Male'){ echo 'selected'; } ?> value="Male"><?php echo $welcome->loadPo('Male'); ?></option>
                                        <option <?php if($u_res->user_gender == 'Female'){ echo 'selected'; } ?> value="Female"><?php echo $welcome->loadPo('Female'); ?></option>
                                         <option <?php if($u_res->user_gender == 'Transgender'){ echo 'selected'; } ?> value="Transgender"><?php echo $welcome->loadPo('Transgender'); ?></option>
                                    </select>
                                    <?php echo form_error('user_gender','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div> 
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label>Status</label>
                                    <select name="user_status" id="user_status" class="form-control">
                                        <option <?php if($u_res->user_status == '1'){ echo 'selected'; } ?> value="1"><?php echo $welcome->loadPo('Responsive'); ?></option>
                                        <option <?php if($u_res->user_status == '0'){ echo 'selected'; } ?> value="0"><?php echo $welcome->loadPo('Unresponsive'); ?></option>
                                    </select>
                                    <?php echo form_error('user_status','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div>                            
                        </div>
                        <div class="row">
                            <div class="form-group col-md-1">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Image'); ?></label><br/>
                                    <img width="70px" src="<?php echo $u_res->user_img; ?>" >
                                </div>
                            </div>  
                            <div class="form-group col-md-2">
                                <div class="input text">
                                    <label>&nbsp;</label><br/><br/>
                                    <input name="user_img" type="file" id="user_img" value="<?php echo set_value('user_img'); ?>" />
                                    <?php echo form_error('user_img','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div>  
                        </div>
                    </div>
                    <!-- /.box-body -->      
                    <div class="box-footer">
                        <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Edit" ><?php echo $welcome->loadPo('Submit'); ?></button>
                        <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/user"><?php echo $welcome->loadPo('Cancel'); ?></a>
                    </div>
                    <?php
               }
               ?>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->

<script type="text/javascript">
    $(function () {
       
        $('#user_dob').datetimepicker({
             format: 'Y-M-D'
        });    
    });

    function getStateList(country_id)
    {
        var str = 'country_id='+country_id;
        var PAGE = '<?php echo base_url(); ?>admin/user/getStateList';
        
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {           
                if(data != "")
                {
                    $('#user_state_id').html(data);
                }
                else
                {
                    $('#user_state_id').html('<option value="">-- Select --</option>');
                }
            } 
        });
    }

    $('#change').on('click',function(){
        $('#p_user').show();
        $('#cancel').show();
        $('#change').hide();
        $('#change_level').val('Change_Level');
    });

    $('#cancel').on('click',function(){
       $('#p_user').hide(); 
       $('#cancel').hide(); 
       $('#change').show(); 
       $('#change_level').val('');
    });

    function selectRole(role_id, user_role_id)
    {
        var user_rol_id = parseInt(user_role_id) + 1;
        if(role_id)
        {
            if(role_id == user_rol_id)
            {
                $('#p_user').hide();
                $('#p_user1').remove();
            }
            else
            {
                $('#p_user').show();
                $('#p_user1').remove();
            }
        }
        else
        {
            $('#p_user').hide();
            $('#p_user1').remove();
        }
    }

    function getChildUser(user_id, i)
    {
        if(i == 1)
        {
            var ii = parseInt(i) + 1;
            $('#c_user_'+ii).remove();
        }
        var role_id = $('#user_role_id').val();
        var str = 'user_id='+user_id+'&role_id='+role_id;
        var PAGE = '<?php echo base_url(); ?>admin/user/getChildUser';
        
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {
                if(data != "")
                {
                    $('#ch_user').html(data);
                }
                else
                {
                    $('#ch_user').remove();
                }
            } 
        });
    }

     function getChildUser1(user_id, ref_id)
    {
        var role_id = $('#user_role_id').val();
        var str = 'user_id='+user_id+'&role_id='+role_id;
        var PAGE = '<?php echo base_url(); ?>admin/user/getChildUser';
        
        
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {
                if(data != "")
                {
                    $('#ch_user_'+ref_id).html(data);
                }
                else
                {
                    $('#ch_user_'+ref_id).remove();
                }
            } 
        });
    }
</script>