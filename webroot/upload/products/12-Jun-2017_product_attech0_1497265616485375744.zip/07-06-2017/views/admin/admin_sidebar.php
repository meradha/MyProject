<!-- Left side column. contains the logo and sidebar -->
<aside class="left-side sidebar-offcanvas">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo base_url();?>webroot/admin/img/avatar3.png" class="img-circle" alt="User Image" />
            </div>
			<div class="pull-left info">
				<p><?php echo $welcome->loadPo('Hello'); ?>, 
					<?php echo $this->user;?>
				</p>
			</div>
            </div>
          
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <ul class="sidebar-menu">
                <!--********************	Show Dashboard Tab First ********************-->
                <?php 
                    foreach ($getAllTabAsPerRole as $value) 
                    {
                        if($value->userView == '1')
                        {
                            if($value->child_status == '0' && $value->child_id == '0')
                            {
                                ?>
                                    <li class="<?php echo ($this->uri->segment(2)== $value->controller_name)?'active':''?>">
                                        <a href="<?php echo base_url(); ?>admin/<?php echo $value->controller_name; ?>">
                                            <i class="fa fa-dashboard"></i>
                                            <span><?php echo $value->tabname; ?></span>
                                        </a>
                                    </li>
                                <?php
                            }
                            else
                            {
                                if($value->child_status == '1' && $value->child_id == '0')
                                {
                                    $child_tab = $this->home_model->getSiderbarTabByRoleAndParentID($value->tab_id, $value->role_id);                                   
                                   ?>
                                    <li class="treeview">
                                        <a href="#"><i class="fa fa-dashboard"></i> <span><?php echo $value->tabname; ?></span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                                        <ul class="treeview-menu" style="display: none;">
                                            <?php
                                            foreach ($child_tab as $c_t_res) 
                                            {
                                                ?>
                                                <li class="<?php echo ($this->uri->segment(2)== $c_t_res->controller_name)?'active':''?>">
                                                    <a href="<?php echo base_url(); ?>admin/<?php echo $c_t_res->controller_name; ?>">
                                                        <i class="fa fa-dashboard"></i>
                                                        <span><?php echo $c_t_res->tabname; ?></span>
                                                    </a>
                                                </li>
                                                <?php
                                            }
                                            ?>
                                        </ul>
                                    </li>
                                   <?php
                                }                                
                            }
                        }
                    }
                ?>                
				<br/><br/><br/><br/>
            </ul>
        </section>
        <!-- /.sidebar -->
    </aside>

    <!-- 
    <li class="<?php echo ($this->uri->segment(2)== $value->controller_name)?'active':''?>">
                                    <a href="<?php echo base_url(); ?>admin/<?php echo $value->controller_name; ?>">
                                        <i class="fa fa-dashboard"></i>
                                        <span><?php echo $value->tabname; ?></span>
                                    </a>
                                </li>
    -->
    <!-- 
 <li class="treeview">
                                    <a href="#"><i class="fa fa-edit"></i> <span>Forms</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
                                    <ul class="treeview-menu" style="display: none;">
                                        <li class=""><a href="general.html"><i class="fa fa-circle-o"></i> General Elements</a></li>
                                        <li><a href="advanced.html"><i class="fa fa-circle-o"></i> Advanced Elements</a></li>
                                        <li><a href="editors.html"><i class="fa fa-circle-o"></i> Editors</a></li>
                                    </ul>
                                </li>
     -->