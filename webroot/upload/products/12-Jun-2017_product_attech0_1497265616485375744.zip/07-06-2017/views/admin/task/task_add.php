<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Task'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/task"><?php echo $welcome->loadPo('Task'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Task Add'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Task Add</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/task" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div> 
                    <?php $user_id = $this->data['session'][0]->user_id; ?>
                    <div class="row">                         
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Task Form'); ?><span class="text-danger">*</span></label>
                                <select class="form-control"  name="taskform_id" id="taskform_id" >
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <?php 
                                        foreach ($taskform_res as $tf_list)
                                        {
                                            ?>
                                            <option value="<?php echo $tf_list->taskform_id; ?>"><?php echo $tf_list->taskform_name; ?></option>
                                            <?php
                                        }
                                    ?>
                                </select>
                                <?php echo form_error('taskform_id','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Task Type'); ?></label>
                                <select name="task_type" id="task_type" class="form-control">
                                    <option value="Daily"><?php echo $welcome->loadPo('Daily'); ?></option>
                                    <option value="Weekly"><?php echo $welcome->loadPo('Weekly'); ?></option>
                                    <option value="Monthly"><?php echo $welcome->loadPo('Monthly'); ?></option>
                                </select>
                                <?php echo form_error('task_type','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>   
                    </div>
                    <div class="row">
                        <div class="form-group col-md-8">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Task Name'); ?><span class="text-danger">*</span></label>
                                <input name="task_name" class="form-control" type="text" id="task_name" value="<?php echo set_value('task_name'); ?>" />
                                <?php echo form_error('task_name','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                                       
                    </div>
                    <div class="row"> 
                        <div class="form-group col-md-8">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Task Description'); ?><span class="text-danger">*</span></label>
                                <textarea name="task_description" rows="8" class="form-control" id="task_description" ></textarea>
                                <?php echo form_error('task_description','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                    </div>
                    <div class="row">                           
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Status'); ?></label>
                                <select name="task_status" id="task_status" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="1"><?php echo $welcome->loadPo('Responsive'); ?></option>
                                    <option value="0"><?php echo $welcome->loadPo('Unresponsive'); ?></option>
                                </select>
                                <?php echo form_error('task_status','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Add" ><?php echo $welcome->loadPo('Submit'); ?></button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/task"><?php echo $welcome->loadPo('Cancel'); ?></a>
                </div>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>