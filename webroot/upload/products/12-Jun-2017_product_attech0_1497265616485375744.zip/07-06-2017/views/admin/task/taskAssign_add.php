<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('My task'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/taskAssign"><?php echo $welcome->loadPo('My task'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('My task Add'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">My task Add</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/taskAssign" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
             <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div> 
                    <?php $user_id = $this->data['session'][0]->user_id; ?>
                    <div class="row">                         
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('User Role'); ?><span class="text-danger">*</span></label>
                                <select class="form-control"  name="ta_assign_to_role_id" id="ta_assign_to_role_id" onchange="getAllUserByRoleID(this.value, <?php echo $user_id; ?>);" >
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <?php 
                                        foreach ($role_res as $r_list)
                                        {
                                            ?>
                                            <option value="<?php echo $r_list->role_id; ?>"><?php echo $r_list->role_name; ?></option>
                                            <?php
                                        }
                                    ?>
                                </select>
                                <?php echo form_error('ta_assign_to_role_id','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Assign To User'); ?><span class="text-danger">*</span></label>
                                <select class="form-control"  name="ta_assign_to" id="ta_assign_to">
                                    
                                </select>
                                <?php echo form_error('ta_assign_to','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Task'); ?><span class="text-danger">*</span></label>
                                <div class="form-group">
                                    <select class="selectpicker form-control"  name="task_id" id="task_id" onchange="getTaskDetailsByTaskID(this.value);" data-live-search="true">
                                        <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                        <?php 
                                            foreach ($task_res as $t_list)
                                            {
                                                ?>
                                                <option value="<?php echo $t_list->task_id; ?>"><?php echo $t_list->task_name; ?></option>
                                                <?php
                                            }
                                        ?>
                                    </select>
                                    <?php echo form_error('task_id','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row task_val_div" style="display: none;">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Task Type'); ?></label>
                                <input class="form-control" readonly="" type="text" id="task_type" value="" />
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Task Form'); ?></label>
                                <input class="form-control" readonly="" type="text" id="task_form" value="" />
                            </div>
                        </div> 
                    </div> 
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Low case area target'); ?><span class="text-danger">*</span></label>
                                    <input type="number" min="0" class="form-control" name="ta_low_case_area_task" id="ta_low_case_area_task" placeholder="" value="">
                                <?php echo form_error('ta_low_case_area_task','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>  
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('High case area target'); ?><span class="text-danger">*</span></label>
                                    <input type="number" min="0" class="form-control" name="ta_high_case_area_task" id="ta_high_case_area_task" placeholder="" value="">
                                <?php echo form_error('ta_high_case_area_task','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Total Target'); ?><span class="text-danger">*</span></label>
                                    <input readonly type="number" min="0" class="form-control" name="ta_total_task" id="ta_total_task" placeholder="" value="">
                                <?php echo form_error('ta_total_task','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>               
                    </div>
                    <div class="row task_val_div" style="display: none;">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Task Start Date'); ?><span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" onchange="getEnddateValue(this.value)" name="ta_task_start_date" id="t_task_start_date1" value="">                                   
                                <?php echo form_error('ta_task_start_date','<span class="text-danger">','</span>'); ?>
                            </div>
                         </div>
                        <div id="show_end_date"></div>                        
                    </div>
                    <div class="row">                           
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Status'); ?></label>
                                <select name="ta_status" id="ta_status" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="1"><?php echo $welcome->loadPo('Responsive'); ?></option>
                                    <option value="0"><?php echo $welcome->loadPo('Unresponsive'); ?></option>
                                </select>
                                <?php echo form_error('ta_status','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Add" ><?php echo $welcome->loadPo('Submit'); ?></button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/taskAssign"><?php echo $welcome->loadPo('Cancel'); ?></a>
                </div>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>

<!-- /.right-side -->
<script type="text/javascript">
    $('#ta_low_case_area_task').on('change', function(){
        var ta_low_case_area_task = $('#ta_low_case_area_task').val();
        var ta_high_case_area_task = $('#ta_high_case_area_task').val();
        var ta_total_task = parseInt(ta_low_case_area_task) + parseInt(ta_high_case_area_task);
        $('#ta_total_task').val(ta_total_task);
    });
    $('#ta_high_case_area_task').on('change', function(){
        var ta_low_case_area_task = $('#ta_low_case_area_task').val();
        var ta_high_case_area_task = $('#ta_high_case_area_task').val();
        var ta_total_task = parseInt(ta_low_case_area_task) + parseInt(ta_high_case_area_task);
        $('#ta_total_task').val(ta_total_task);
    });

    $(function() {
       $( "#t_task_start_date1" ).datepicker({
            minDate: 0,
           dateFormat : 'yy-mm-dd',
           changeMonth : true,
           changeYear : true,
           
       });
       $( "#task_perform_date" ).datepicker({
            minDate: 0,
           dateFormat : 'yy-mm-dd',
           changeMonth : true,
           changeYear : true,
           
       });
   });
 </script>
<script type="text/javascript">
    function getAllUserByRoleID(role_id, user_id)
    {
        var str = 'role_id='+role_id+'&user_id='+user_id;
        var PAGE = '<?php echo base_url(); ?>admin/taskAssign/getAllUserByRoleID';
        
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {           
                if(data != "")
                {
                    // alert(data);
                    $('#ta_assign_to').html(data);
                }
                else
                {
                    $('#ta_assign_to').html('<option value="">-- Select --</option>');
                }
            } 
        });
    }

    function getTaskDetailsByTaskID(task_id)
    {
        $('#t_task_start_date1').val('');
        $('#show_end_date').html('');        
        var str = 'task_id='+task_id;
        var PAGE = '<?php echo base_url(); ?>admin/taskAssign/getTaskDetailsByTaskID';
        
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {           
                if(data != "")
                {
                    newData = data.split(',');
                    $('.task_val_div').show();
                    $('#task_type').val(newData[0]);
                    $('#task_form').val(newData[1]);
                }
                else
                {
                    $('.task_val_div').hide();
                    $('#task_type').val();
                }
            } 
        });
    }  
    function getEnddateValue(str)
    {
        var task_type = $('#task_type').val();  
        if(task_type == 'Daily')
        {
            $('#show_end_date').html('<div class="form-group col-md-4"><div class="input text"><label>Task End Date<span class="text-danger">*</span></label><input type="text" class="form-control" name="ta_task_end_date" id="ta_task_end_date" value=""><?php echo form_error('ta_task_end_date','<span class="text-danger">','</span>'); ?></div></div>');
            min1 = new Date(str);
            min = new Date(str);
            var numberOfDaysToAdd = 0;
            min.setDate(min.getDate() + numberOfDaysToAdd);
            var dd = min.getDate();
            var mm = min.getMonth() + 1;
            var y = min.getFullYear();
            var aa = y+'-'+mm+'-'+dd;
            max = new Date(aa); 

            $( "#ta_task_end_date" ).datepicker({ 
               minDate: min1,
               //maxDate: max,
               dateFormat : 'yy-mm-dd',
               changeMonth : true,
               changeYear : true,
            });
        }
        if(task_type == 'Weekly')
        {
            min1 = new Date(str);
            min = new Date(str);
            var numberOfDaysToAdd = 6;
            min.setDate(min.getDate() + numberOfDaysToAdd);
            var dd = min.getDate();
            var mm = min.getMonth() + 1;
            var y = min.getFullYear();
            var aa = y+'-'+mm+'-'+dd;
            max = new Date(aa);

            $('#show_end_date').html('<div class="form-group col-md-4"><div class="input text"><label>Task End Date<span class="text-danger">*</span></label><input type="text" class="form-control" name="ta_task_end_date" id="ta_task_end_date" value=""><?php echo form_error('ta_task_end_date','<span class="text-danger">','</span>'); ?></div></div>');
           // jQuery("#ta_task_end_date").removeAttr("disabled");
            $( "#ta_task_end_date" ).datepicker({ 
               minDate: min1,
               //maxDate: max,
               dateFormat : 'yy-mm-dd',
               changeMonth : true,
               changeYear : true,
            });
           
        }
        if(task_type == 'Monthly')
        {
            $('#show_end_date').html('<div class="form-group col-md-4"><div class="input text"><label>Task End Date<span class="text-danger">*</span></label><input type="text" class="form-control" name="ta_task_end_date" id="ta_task_end_date" value=""><?php echo form_error('ta_task_end_date','<span class="text-danger">','</span>'); ?></div></div>');
            min1 = new Date(str);
            min = new Date(str);
            var numberOfDaysToAdd = 29;
            min.setDate(min.getDate() + numberOfDaysToAdd);
            var dd = min.getDate();
            var mm = min.getMonth() + 1;
            var y = min.getFullYear();
            var aa = y+'-'+mm+'-'+dd;
            max = new Date(aa);

            $( "#ta_task_end_date" ).datepicker({ 
                minDate: min1,
                //maxDate: max,
                dateFormat : 'yy-mm-dd',
                changeMonth : true,
                changeYear : true,
            });
        }
    }

    
</script>