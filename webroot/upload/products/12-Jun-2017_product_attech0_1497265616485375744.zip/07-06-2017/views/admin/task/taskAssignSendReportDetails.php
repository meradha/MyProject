<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Task Send Report'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Task Send Report'); ?> </li>
        </ol>
    </section>   
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Task Send Report Details</h3>
                </div> -->
                <div class="pull-right box-tools">
                   <!--  <?php
                        foreach($getAllTabAsPerRole as $role)
                        {
                            if($this->uri->segment(2) == $role->controller_name && $role->userAdd == '1')
                            {
                                ?>
                                                  
                                <?php
                            }
                        }
                    ?>          -->    
                    <a href="<?php echo base_url();?>admin/taskAssign/addTaskAssignedReport/<?php echo $ta_id; ?>/<?php echo $task_id; ?>" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Add New'); ?></a>       
                </div>
            </div>           
            <!-- /.box-header -->
            <div class="box-body">
                <div>
                    <div id="msg_div">
                        <?php echo $this->session->flashdata('message');?>
                    </div>
                </div>
                <table id="example2" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th><?php echo $welcome->loadPo('Task Name'); ?></th>
                            <th><?php echo $welcome->loadPo('Activity Place'); ?></th>
                            <th><?php echo $welcome->loadPo('Activity Date'); ?></th>
                            <th><?php echo $welcome->loadPo('Start Time'); ?></th>
                            <th><?php echo $welcome->loadPo('End Time'); ?></th>
                            <th><?php echo $welcome->loadPo('Number of attandees'); ?></th>
                            <th><?php echo $welcome->loadPo('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if(!empty($send_report_res))
                            {
                                foreach($send_report_res as $res)
                                {
                                    ?>
                                    <tr>
                                        <td><?php echo $res->task_name; ?></td>
                                        <td><?php echo $res->tca_activity_place; ?></td>
                                        <td><?php echo $res->tca_activity_date; ?></td>
                                        <td><?php echo $res->tca_activity_start_time; ?></td>
                                        <td><?php echo $res->tca_activity_end_time; ?></td>
                                        <td><?php echo $res->tca_total_no_attendess; ?></td>
                                        <td width="20%">
                                            <a href="<?php echo base_url();?>admin/taskAssign/addTaskAssignedReport/<?php echo $res->ta_id; ?>/<?php echo $res->task_id; ?>/<?php echo $res->tca_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp; 
                                            <a class="confirm" onclick="return delete_taskASsignedSendReport(<?php echo $res->ta_id; ?>, <?php echo $res->task_id; ?>, <?php echo $res->tca_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>&nbsp;&nbsp; 
                                            <a href="<?php echo base_url();?>admin/taskAssign/sendTaskReportView/<?php echo $res->ta_id; ?>/<?php echo $res->task_id; ?>/<?php echo $res->tca_id; ?>" title="Edit"><i class="fa fa-eye fa-2x "></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            }
                            else
                            {
                                ?>
                                <tr>
                                    <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                </tr>
                                <?php
                            }
                            
                        ?>
                       
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function delete_taskASsignedSendReport(ta_id, task_id, tca_id)
    {
        bootbox.confirm("Are you sure you want to delete task send report details",function(confirmed){
            if(confirmed)
            {
                location.href="<?php echo base_url();?>admin/taskAssign/delete_taskASsignedSendReport/"+ta_id+'/'+task_id+'/'+tca_id;
            }
        });
    }    
</script>>