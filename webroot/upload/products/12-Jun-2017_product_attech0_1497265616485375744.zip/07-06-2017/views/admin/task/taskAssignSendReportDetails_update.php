<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Task Send Report'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/taskAssign/sendTaskReport/<?php echo $ta_id; ?>/<?php echo $task_id; ?>">Task</a></li>
            <li class="active"><?php echo $welcome->loadPo('Task Send Report Update'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Task Send Report Update</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/taskAssign/sendTaskReport/<?php echo $ta_id; ?>/<?php echo $task_id; ?>" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <?php
                foreach ($taskassignreport_edit as $value) 
                {
                    ?>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <div>
                                <div id="msg_div">
                                    <?php echo $this->session->flashdata('message');?>
                                </div>
                            </div> 
                            <div class="row">
                                <div class="form-group col-md-5">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Activity Place(along with detailed address)'); ?><span class="text-danger">*</span></label>
                                        <textarea name="tca_activity_place" class="form-control" id="tca_activity_place" ><?php echo $value->tca_activity_place; ?></textarea>
                                        <?php echo form_error('tca_activity_place','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class='input-group'>
                                        <label> <?php echo $welcome->loadPo('Community activity/ community meeting subarea'); ?><span class="text-danger">*</span></label>
                                        <input name="tca_activity_subarea" class="form-control" type="text" id="tca_activity_subarea" value="<?php echo $value->tca_activity_subarea; ?>" />
                                    </div>
                                    <?php echo form_error('tca_activity_subarea','<span class="text-danger">','</span>'); ?>
                                </div> 
                                <div class="form-group col-md-3">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Date of activity'); ?><span class="text-danger">*</span></label>
                                        <div class='input-group'>
                                            <input name="tca_activity_date" class="form-control" type="text" id="tca_activity_date" value="<?php echo $value->tca_activity_date; ?>" />
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                        <?php echo form_error('tca_activity_date','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                            </div> 
                            <div class="row">
                                <div class="form-group col-md-5">
                                    <div class="bootstrap-timepicker">
                                        <div class="form-group">
                                            <label><?php echo $welcome->loadPo('Start time of activity'); ?><span class="text-danger">*</span></label>
                                            <div class="input-group">
                                                <input name="tca_activity_start_time" class="form-control timepicker" type="text" id="tca_activity_start_time" value="<?php echo $value->tca_activity_start_time; ?>" />
                                                <div class="input-group-addon">
                                                <i class="fa fa-clock-o"></i>
                                                </div>
                                            </div>
                                            <?php echo form_error('tca_activity_start_time','<span class="text-danger">','</span>'); ?>
                                        </div>
                                    </div>
                                </div> 
                                <div class="form-group col-md-5">
                                    <div class="bootstrap-timepicker">
                                        <div class="form-group">
                                            <label><?php echo $welcome->loadPo('End time of activity'); ?><span class="text-danger">*</span></label>
                                            <div class="input-group">
                                                <input name="tca_activity_end_time" class="form-control timepicker" type="text" id="tca_activity_end_time" value="<?php echo $value->tca_activity_end_time; ?>" />
                                                <div class="input-group-addon">
                                                <i class="fa fa-clock-o"></i>
                                                </div>
                                            </div>
                                            <?php echo form_error('tca_activity_end_time','<span class="text-danger">','</span>'); ?>
                                        </div>
                                    </div>
                                </div>         
                            </div>
                            <div class="row">
                                <div class="form-group col-md-5">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Type of community Activity'); ?><span class="text-danger">*</span></label><br/>
                                        <?php
                                        $a_arr = explode(',', $value->tca_type_of_community_activity);
                                        ?>
                                        <input <?php if(in_array('Street Play', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity[]" value="Street Play" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Street Play'); ?><br/>
                                        
                                        <input <?php if(in_array('Health Game', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity[]" value="Health Game" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Health Game'); ?><br/>
                                        
                                        <input <?php if(in_array('Kiosk / Exhibition / IEC stall', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity[]" value="Kiosk / Exhibition / IEC stall" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Kiosk / Exhibition / IEC stall'); ?><br/>
                                        
                                        <input <?php if(in_array('Activity conducted in collaboration with health camp', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity[]" value="Activity conducted in collaboration with health camp" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Activity conducted in collaboration with health camp'); ?><br/>
                                        
                                        <input <?php if(in_array('Sharing success stories', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity[]" value="Sharing success stories" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Sharing success stories'); ?><br/>
                                        
                                        <input <?php if(in_array('Group discussions', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity[]" value="Group discussions" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Group discussions'); ?><br/>
                                        
                                        <input <?php if(in_array('Activity conducted through small child/children', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity[]" value="Activity conducted through small child/children" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Activity conducted through small child/children'); ?><br/>
                                        
                                        <input <?php if(in_array('SHG formation', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity[]" value="SHG formation" />&nbsp;&nbsp;<?php echo $welcome->loadPo('SHG formation'); ?><br/>
                                        
                                        <input <?php if(in_array('BC activity', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity[]" value="BC activity" />&nbsp;&nbsp;<?php echo $welcome->loadPo('BC activity'); ?><br/>
                                        
                                        <input <?php if(in_array('Puppet show', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity[]" value="Puppet show" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Puppet show'); ?><br/>
                                        
                                        <input <?php if(in_array('Movies screening', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity[]" value="Movies screening" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Movies screening'); ?><br/>
                                        
                                        <input <?php if(in_array('Health Talk', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity[]" value="Health Talk" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Health Talk'); ?><br/>
                                        
                                        <input <?php if(in_array('Other', $a_arr)){ echo "checked"; } ?> name="tca_type_of_community_activity[]" type="checkbox" id="tca_type_of_community_activity" value="Other" onclick="addInputField(this.value, 'tca_type_of_community_activity')"/>&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                        <input type="text" style="<?php if(in_array('Other', $a_arr)){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="tca_type_of_community_activity_other" name="tca_type_of_community_activity_other" class="form-control" value="<?php echo $value->tca_type_of_community_activity_other; ?>" />
                                        <?php echo form_error('tca_type_of_community_activity[]','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                                <div class="form-group col-md-5">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Focus population/Target group'); ?><span class="text-danger">*</span></label><br/>
                                        <select name="tca_focus_population" id="tca_focus_population" class="form-control">
                                            <option <?php if($value->tca_focus_population == 'General Population'){ echo "selected"; } ?> value="General Population"><?php echo $welcome->loadPo('General Population'); ?></option>
                                            <option <?php if($value->tca_focus_population == 'Young population'){ echo "selected"; } ?> value="Young population"><?php echo $welcome->loadPo('Young population'); ?></option>
                                            <option <?php if($value->tca_focus_population == 'Old aged'){ echo "selected"; } ?> value="Old aged"><?php echo $welcome->loadPo('Old aged'); ?></option>
                                            <option <?php if($value->tca_focus_population == 'Poorest among poor'){ echo "selected"; } ?> value="Poorest among poor"><?php echo $welcome->loadPo('Poorest among poor'); ?></option>
                                            <option <?php if($value->tca_focus_population == 'Religion specific population'){ echo "selected"; } ?> value="Religion specific population"><?php echo $welcome->loadPo('Religion specific population'); ?></option>
                                            <option <?php if($value->tca_focus_population == 'Migrant workers'){ echo "selected"; } ?> value="Migrant workers"><?php echo $welcome->loadPo('Migrant workers'); ?></option>
                                            <option <?php if($value->tca_focus_population == 'Females'){ echo "selected"; } ?> value="Females"><?php echo $welcome->loadPo('Females'); ?></option>
                                        </select>
                                        <?php echo form_error('tca_focus_population','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Name of stakeholders facilitating the activity:(if we are conducting activity in co-ordination with any stakeholders)'); ?><span class="text-danger">*</span></label>
                                        <select class="form-control selectpicker" name="tca_name_of_stakeholder" id="tca_name_of_stakeholder" data-live-search="true">
                                            <?php
                                            $user_id = $this->data['session'][0]->user_id;
                                            foreach ($stakeholder_list as $st_res) 
                                            {
                                                $st_res_arr = explode(',', $st_res->user_all_level);
                                                if(in_array($user_id, $st_res_arr))
                                                {
                                                ?>
                                                    <option <?php if($st_res->stakeholder_id == $value->tca_name_of_stakeholder){ echo "selected"; } ?> value="<?php echo $st_res->stakeholder_id; ?>"><?php echo $st_res->stakeholder_name; ?></option>
                                                <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                        
                                        <?php echo form_error('tca_name_of_stakeholder','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Area'); ?><span class="text-danger">*</span></label><br><br>
                                        <select name="tca_area" id="tca_area" class="form-control">
                                            <option <?php if($value->tca_area == 'Low case burden area'){ echo "selected"; } ?> value="Low case burden area"><?php echo $welcome->loadPo('Low case burden area'); ?></option>
                                            <option <?php if($value->tca_area == 'High case burden area'){ echo "selected"; } ?> value="High case burden area"><?php echo $welcome->loadPo('High case burden area'); ?></option>
                                        </select>
                                        <?php echo form_error('tca_area','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Health post'); ?><span class="text-danger">*</span></label><br><br>
                                        <select name="helthpostarea_id" id="helthpostarea_id" class="form-control selectpicker" data-live-search="true">
                                            <?php 
                                            foreach ($helthpost_area_list as $hp_res) 
                                            {
                                                ?>
                                                <option <?php if($hp_res->helthpostarea_id == $value->helthpostarea_id){ echo "selected"; } ?> value="<?php echo $hp_res->helthpostarea_id; ?>"><?php echo $hp_res->helthpostarea_name; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php echo form_error('helthpostarea_id','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row"> 
                                <div class="form-group col-md-5">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Total number of attendees'); ?><span class="text-danger">*</span></label><br><br>
                                        <input name="tca_total_no_attendess" class="form-control" type="text" id="tca_total_no_attendess" value="<?php echo $value->tca_total_no_attendess; ?>" />
                                        <?php echo form_error('tca_total_no_attendess','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                                <div class="form-group col-md-5">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Number of self referral by presumptive TB cases during community activity'); ?><span class="text-danger">*</span></label>
                                        <input name="tca_no_of_presumptive_tb_case" class="form-control" type="text" id="tca_no_of_presumptive_tb_case" value="<?php echo $value->tca_no_of_presumptive_tb_case; ?>" />
                                        <?php echo form_error('tca_no_of_presumptive_tb_case','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>         
                            </div>
                            <div class="row"> 
                                <div class="form-group col-md-5">
                                    <h3><u><?php echo $welcome->loadPo('Topics covered during activity'); ?></u></h3>
                                </div>
                            </div>
                            <div class="row"> 
                                <div class="form-group col-md-6">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Topics covered during activity'); ?><span class="text-danger">*</span></label><br/>
                                        <?php
                                        $b_arr = explode('/', $value->tca_covered_topics);
                                        ?>
                                        <input <?php if(in_array('Self Introduction', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Self Introduction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Self Introduction'); ?><br/>
                                        
                                        <input <?php if(in_array('Introduction about Saksham and Repport building', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Introduction about Saksham and Repport building" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Introduction about Saksham and Repport building'); ?><br/>
                                        
                                        <input <?php if(in_array('Objectives of saksham JU and activities carried out by JU', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Objectives of saksham JU and activities carried out by JU" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Objectives of saksham JU and activities carried out by JU'); ?><br/>
                                        
                                        <input <?php if(in_array('Introduction about TB as illness', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Introduction about TB as illness" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Introduction about TB as illness'); ?><br/>
                                        
                                        <input <?php if(in_array('Signs and Symptoms of Tuberculosis', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Signs and Symptoms of Tuberculosis" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Signs and Symptoms of Tuberculosis'); ?><br/>
                                        
                                        <input <?php if(in_array('Mode of Transmission of TB bacteria', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="
                                        tca_covered_topics[]" value="Mode of Transmission of TB bacteria" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Mode of Transmission of TB bacteria'); ?><br/>
                                        
                                        <input <?php if(in_array('Prevention method', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Prevention method" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Prevention method'); ?><br/>
                                        
                                        <input <?php if(in_array('Role of hygiene and cough hygiene in prevention and spread of TB', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Role of hygiene and cough hygiene in prevention and spread of TB" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Role of hygiene and cough hygiene in prevention and spread of TB'); ?><br/>
                                        
                                        <input <?php if(in_array('Myths and Misconception regarding TB', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Myths and Misconception regarding TB" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Myths and Misconception regarding TB'); ?><br/>
                                        
                                        <input <?php if(in_array('Addressing stigma related to TB in the society', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Addressing stigma related to TB in the society" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Addressing stigma related to TB in the society'); ?><br/>
                                        
                                        <input <?php if(in_array('Discussion about treatment details', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Discussion about treatment details" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Discussion about treatment details'); ?><br/>
                                        
                                        <input <?php if(in_array('Introduction about available treatment facilities within the area', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Introduction about available treatment facilities within the area" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Introduction about available treatment facilities within the area'); ?><br/>
                                        
                                        <input <?php if(in_array('Awareness about right procedure of availing the public health facilities', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Awareness on accessing lab and TU services" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Awareness on accessing lab and TU services'); ?><br/>
                                        
                                        <input <?php if(in_array('Awareness about right procedure of availing the public health facilities', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Awareness about right procedure of availing the public health facilities" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Awareness about right procedure of availing the public health facilities'); ?><br/>
                                        
                                        <input <?php if(in_array('Importance of treatment completion', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Importance of treatment completion" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Importance of treatment completion'); ?><br/>
                                        
                                        <input <?php if(in_array('Awareness about MDR, XDR, TDR in case of non compliance to the treatment', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Awareness about MDR, XDR, TDR in case of non compliance to the treatment" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Awareness about MDR, XDR, TDR in case of non compliance to the treatment'); ?><br/>
                                        
                                        <input <?php if(in_array('Addressing the TB contact vulnerability factors', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Addressing the TB contact vulnerability factors" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Addressing the TB contact vulnerability factors'); ?><br/>
                                        
                                        <input <?php if(in_array('Knowledge on home based care to be taken', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Knowledge on home based care to be taken" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Knowledge on home based care to be taken'); ?><br/>
                                        
                                        <input <?php if(in_array('Self referral registration', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Self referral registration" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Self referral registration'); ?><br/>
                                        
                                        <input <?php if(in_array('Announcement of partner community based organization in that particular area for community referral of presumptive TB cases', $b_arr)){ echo "checked"; } ?> name="tca_covered_topics[]" type="checkbox" id="tca_covered_topics[]" value="Announcement of partner community based organization in that particular area for community referral of presumptive TB cases" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Announcement of partner community based organization in that particular area for community referral of presumptive TB cases'); ?><br/>
                                       
                                        <?php echo form_error('tca_covered_topics[]','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row"> 
                                <div class="form-group col-md-10">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Images'); ?> <span style="font-size: 12px;"><?php echo $welcome->loadPo('(select one or more than one)'); ?></span></label><br/>
                                        <div class="form-group col-md-10">
                                        <?php
                                        foreach ($taskassignreport_edit_img as $v_img_r) 
                                        {
                                            ?>
                                            <div style='float:left;border:4px solid #303641;padding:5px;margin:5px;'>
                                                <img height='80' src="<?php echo base_url().''.$v_img_r->tca_img_name; ?>">
                                            </div>
                                            <?php
                                        }
                                        ?><br><br>
                                        </div>
                                        <input type="file" multiple name="tca_img_name[]" id="tca_img_name">
                                        <?php echo form_error('tca_img_name[]','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                                <div class="form-group col-md-12">
                                    <div id="previewImg"></div>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->     
                        <div class="box-footer">
                            <button class="btn btn-success btn-sm" type="submit" name="Submit" value="EditReport" ><?php echo $welcome->loadPo('Submit'); ?></button>
                            <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/taskAssign/sendTaskReport/<?php echo $ta_id; ?>/<?php echo $task_id; ?>"><?php echo $welcome->loadPo('Cancel'); ?></a>
                        </div>
                    <?php
                }
                ?>
                        
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<script type="text/javascript">    
    $('#tca_activity_start_time').datetimepicker({
        format:'HH:mm A',
    });
    $('#tca_activity_end_time').datetimepicker({
        format:'HH:mm A',
    });  
</script>
<link rel="stylesheet" href="<?php echo base_url();?>webroot/admin/calendar/jquery-ui.css">
<script src="<?php echo base_url();?>webroot/admin/calendar/jquery-1.10.2.js"></script>
<script src="<?php echo base_url();?>webroot/admin/calendar/jquery-ui.js"></script>
<script type="text/javascript">
$(function() {
   $( "#tca_activity_date" ).datepicker({
    minDate: 0,
       dateFormat : 'yy-mm-dd',
       changeMonth : true,
       changeYear : true,
       
   });
});


function addInputField(f_val, f_id)
{
    if(document.getElementById(f_id).checked)
    {
        $('#'+f_id+'_other').css('display', 'block');
    }
    else
    {
        $('#'+f_id+'_other').css('display', 'none');
    }
}

$("#tca_img_name").on("change", function (e) {
   var files = e.target.files,
   filesLength = files.length;
   for (var i = 0; i < filesLength; i++) {
      // $('#img_valid').css('display', 'none');
       var f = files[i]
       var fileReader = new FileReader();
       fileReader.onload = (function (e) {
          var file = e.target;
               var img = new Image();
               img.src = e.target.result;
               var res = null;
               img.onload = function() {                                                             
               $("#previewImg").append("<div style='float:left;border:4px solid #303641;padding:5px;margin:5px;'><img height='80' src='" + e.target.result + "'></div>").insertAfter("#previewImg");
               }
       });
       fileReader.readAsDataURL(f);
   }
});
</script>