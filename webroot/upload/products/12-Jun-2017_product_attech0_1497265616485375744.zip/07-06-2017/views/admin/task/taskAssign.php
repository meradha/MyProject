<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('My task'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('My task'); ?></li>
        </ol>
    </section>   
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
               <!--  <div class="pull-left">
                    <h3 class="box-title">My task Details</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <?php
                        foreach($getAllTabAsPerRole as $role)
                        {
                            if($this->uri->segment(2) == $role->controller_name && $role->userAdd == '1')
                            {
                                ?>
                                    <a href="<?php echo base_url();?>admin/taskAssign/addTaskAssign" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Add New'); ?></a>              
                                <?php
                            }
                        }
                    ?>                    
                </div>
            </div>           
            <!-- /.box-header -->
            <div class="box-body">
                <div>
                    <div id="msg_div">
                        <?php echo $this->session->flashdata('message');?>
                    </div>
                </div>
                <ul class="nav nav-tabs">
                    <?php
                    $user_role_id = $this->data['session'][0]->user_role_id;
                    if($user_role_id == '7')
                    {
                        ?>
                        <li class="active"><a data-toggle="tab" href="#community_activity_task"><?php echo $welcome->loadPo('Community Activity Meeting'); ?></a></li>
                        <li><a data-toggle="tab" href="#stakeholder_meeting_task"><?php echo $welcome->loadPo('Stakeholder Meeting'); ?></a></li>
                        <?php
                    }
                    else
                    {
                        ?>
                        <li class="active"><a data-toggle="tab" href="#added_task"><?php echo $welcome->loadPo('Approved Task'); ?></a></li>
                        <li><a data-toggle="tab" href="#community_activity_task"><?php echo $welcome->loadPo('Community Activity Meeting'); ?></a></li>
                        <li><a data-toggle="tab" href="#stakeholder_meeting_task"><?php echo $welcome->loadPo('Stakeholder Meeting'); ?></a></li>
                        <?php
                    }
                    ?>
                    
                </ul>

                <div class="tab-content">
                    <!-- ******************************************************************** -->
                    <?php
                    $user_role_id = $this->data['session'][0]->user_role_id;
                    if($user_role_id == '7')
                    {
                        ?>
                        <div id="community_activity_task" class="tab-pane fade in active"><br/>
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
										<th><?php echo $welcome->loadPo('Assign By'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task Name'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task Start Date'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task End Date'); ?></th>
                                        <th><?php echo $welcome->loadPo('Total Target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Low case area target'); ?></th>
                                        <th><?php echo $welcome->loadPo('High case area target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Remaining target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Report'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if($approved_task_res)
                                    {
                                        foreach ($approved_task_res as $a_task_res) 
                                        {
                                            $user_all_level = explode(',', $a_task_res->user_all_level_assign_to);
                                            $user_id = $this->data['session'][0]->user_id;
                                            if(in_array($user_id, $user_all_level))
                                            {
                                                if($a_task_res->taskform_id == '1')
                                                {
                                                ?>
                                                <tr>
                                                    <td><?php echo $a_task_res->assign_by; ?></td>
                                                    <td><?php echo $a_task_res->task_name; ?></td>
                                                    <td><?php echo $a_task_res->ta_task_start_date; ?></td>
                                                    <td><?php echo $a_task_res->ta_task_end_date; ?></td>
                                                    <td><?php echo $a_task_res->ta_total_task; ?></td>
                                                    <td><?php echo $a_task_res->ta_low_case_area_task; ?></td>
                                                    <td><?php echo $a_task_res->ta_high_case_area_task; ?></td>
                                                    <td><?php echo $a_task_res->ta_remaining_task; ?></td>
                                                    <td>
                                                        <?php
                                                        $c_date = date('Y-m-d');
                                                        if($a_task_res->ta_task_end_date >= $c_date)
                                                        {
                                                            ?>
                                                            <a href="<?php echo base_url();?>admin/taskAssign/sendTaskReport/<?php echo $a_task_res->ta_id; ?>/<?php echo $a_task_res->task_id; ?>" title="Send Task Report"><i class="fa fa-plus-square fa-2x" aria-hidden="true"></i></a>
                                                            <?php
                                                        }
                                                        ?>
                                                        &nbsp;&nbsp;<a href="<?php echo base_url();?>admin/taskAssign/taskAssignApprovedView/<?php echo $a_task_res->ta_id; ?>" title="Edit"><i class="fa fa-eye fa-2x "></i></a>
                                                    </td>
                                                </tr>
                                                <?php
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        ?>
                                        <tr>
                                            <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <div id="stakeholder_meeting_task" class="tab-pane fade"><br/>
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th><?php echo $welcome->loadPo('Assign By'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task Name'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task Start Date'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task End Date'); ?></th>
                                        <th><?php echo $welcome->loadPo('Total Target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Low case area target'); ?></th>
                                        <th><?php echo $welcome->loadPo('High case area target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Remaining target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Report'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if($approved_task_res)
                                    {
                                        foreach ($approved_task_res as $a_task_res) 
                                        {
                                            $user_all_level = explode(',', $a_task_res->user_all_level_assign_to);
                                            $user_id = $this->data['session'][0]->user_id;
                                            if(in_array($user_id, $user_all_level))
                                            {
                                                if($a_task_res->taskform_id == '2')
                                                {
                                                ?>
                                                <tr>
                                                    <td><?php echo $a_task_res->assign_by; ?></td>
                                                    <td><?php echo $a_task_res->task_name; ?></td>
                                                    <td><?php echo $a_task_res->ta_task_start_date; ?></td>
                                                    <td><?php echo $a_task_res->ta_task_end_date; ?></td>
                                                    <td><?php echo $a_task_res->ta_total_task; ?></td>
                                                    <td><?php echo $a_task_res->ta_low_case_area_task; ?></td>
                                                    <td><?php echo $a_task_res->ta_high_case_area_task; ?></td>
                                                    <td><?php echo $a_task_res->ta_remaining_task; ?></td>
                                                    <td><?php
                                                        $c_date = date('Y-m-d');
                                                        if($a_task_res->ta_task_end_date >= $c_date)
                                                        {
                                                            ?>
                                                           <a href="<?php echo base_url();?>admin/taskAssign/sendTaskReport/<?php echo $a_task_res->ta_id; ?>/<?php echo $a_task_res->task_id; ?>" title="Send Task Report"><i class="fa fa-plus-square fa-2x" aria-hidden="true"></i></a>
                                                            <?php
                                                        }
                                                        ?>
                                                        &nbsp;&nbsp;<a href="<?php echo base_url();?>admin/taskAssign/taskAssignApprovedView/<?php echo $a_task_res->ta_id; ?>" title="Edit"><i class="fa fa-eye fa-2x "></i></a>
                                                    </td>
                                                </tr>
                                                <?php
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        ?>
                                        <tr>
                                            <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <?php
                    }
                    else
                    {
                        ?>
                        <!-- ****************************************************** -->
                        <!-- ****************************************************** -->
                        <div id="added_task" class="tab-pane fade in active"><br/>
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
										<th><?php echo $welcome->loadPo('Assign To'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task Name'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task Start Date'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task End Date'); ?></th>
                                        <th><?php echo $welcome->loadPo('Total Target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Low case area target'); ?></th>
                                        <th><?php echo $welcome->loadPo('High case area target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Action'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        if(!empty($assign_by_task_res))
                                        {
                                            foreach($assign_by_task_res as $res)
                                            {
                                                ?>
                                                <tr>
                                                    <td><?php echo $res->user_name; ?></td>
                                                    <td><?php echo $res->task_name; ?></td>
                                                    <td><?php echo $res->ta_task_start_date; ?></td>
                                                    <td><?php echo $res->ta_task_end_date; ?></td>     
                                                    <td><?php echo $res->ta_total_task; ?></td>     
                                                    <td><?php echo $res->ta_low_case_area_task; ?></td>
                                                    <td><?php echo $res->ta_high_case_area_task; ?></td>     
                                                    <td width="12%">
                                                        <?php
                                                            foreach($getAllTabAsPerRole as $role)
                                                            {
                                                                
                                                                if($this->uri->segment(2) == $role->controller_name && $role->userEdit == '1')
                                                                {
                                                                    ?>
                                                                        <a href="<?php echo base_url();?>admin/taskAssign/addTaskAssign/<?php echo $res->ta_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp;                
                                                                    <?php
                                                                }
                                                                if($this->uri->segment(2) == $role->controller_name && $role->userDelete == '1')
                                                                {
                                                                    ?>
                                                                        <a class="confirm" onclick="return delete_taskAssign(<?php echo $res->ta_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>                                      
                                                                    <?php
                                                                }
                                                            }
                                                        ?>  
                                                        &nbsp;&nbsp;<a href="<?php echo base_url();?>admin/taskAssign/taskAssignApprovedView/<?php echo $res->ta_id; ?>" title="Edit"><i class="fa fa-eye fa-2x "></i></a>    
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            ?>
                                            <tr>
                                                <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                            </tr>
                                            <?php
                                        }
                                        
                                    ?>
                                   
                                </tbody>
                            </table>
                        </div>
                        <div id="community_activity_task" class="tab-pane fade"><br/>
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
										<th><?php echo $welcome->loadPo('Assign By'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task Name'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task Start Date'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task End Date'); ?></th>
                                        <th><?php echo $welcome->loadPo('Total Target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Low case area target'); ?></th>
                                        <th><?php echo $welcome->loadPo('High case area target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Remaining target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Report'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if($approved_task_res)
                                    {
                                        foreach ($approved_task_res as $a_task_res) 
                                        {
                                            $user_all_level = explode(',', $a_task_res->user_all_level_assign_to);
                                            $user_id = $this->data['session'][0]->user_id;
                                            if(in_array($user_id, $user_all_level))
                                            {
                                                if($a_task_res->taskform_id == '1')
                                                {
                                                ?>
                                                <tr>
                                                    <td><?php echo $a_task_res->assign_by; ?></td>
                                                    <td><?php echo $a_task_res->task_name; ?></td>
                                                    <td><?php echo $a_task_res->ta_task_start_date; ?></td>
                                                    <td><?php echo $a_task_res->ta_task_end_date; ?></td>
                                                    <td><?php echo $a_task_res->ta_total_task; ?></td>
                                                    <td><?php echo $a_task_res->ta_low_case_area_task; ?></td>
                                                    <td><?php echo $a_task_res->ta_high_case_area_task; ?></td>
                                                    <td><?php echo $a_task_res->ta_remaining_task; ?></td>
                                                    <td>
                                                        <?php
                                                        $c_date = date('Y-m-d');
                                                        if($a_task_res->ta_task_end_date >= $c_date)
                                                        {
                                                            ?>
                                                            <a href="<?php echo base_url();?>admin/taskAssign/sendTaskReport/<?php echo $a_task_res->ta_id; ?>/<?php echo $a_task_res->task_id; ?>" title="Send Task Report"><i class="fa fa-plus-square fa-2x" aria-hidden="true"></i></a>
                                                            <?php
                                                        }
                                                        ?>
                                                        &nbsp;&nbsp;<a href="<?php echo base_url();?>admin/taskAssign/taskAssignApprovedView/<?php echo $a_task_res->ta_id; ?>" title="Edit"><i class="fa fa-eye fa-2x "></i></a>
                                                    </td>
                                                </tr>
                                                <?php
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        ?>
                                        <tr>
                                            <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <div id="stakeholder_meeting_task" class="tab-pane fade"><br/>
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th><?php echo $welcome->loadPo('Assign By'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task Name'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task Start Date'); ?></th>
                                        <th><?php echo $welcome->loadPo('Task End Date'); ?></th>
                                        <th><?php echo $welcome->loadPo('Total Target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Low case area target'); ?></th>
                                        <th><?php echo $welcome->loadPo('High case area target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Remaining target'); ?></th>
                                        <th><?php echo $welcome->loadPo('Report'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if($approved_task_res)
                                    {
                                        foreach ($approved_task_res as $a_task_res) 
                                        {
                                            $user_all_level = explode(',', $a_task_res->user_all_level_assign_to);
                                            $user_id = $this->data['session'][0]->user_id;
                                            if(in_array($user_id, $user_all_level))
                                            {
                                                if($a_task_res->taskform_id == '2')
                                                {
                                                ?>
                                                <tr>
                                                    <td><?php echo $a_task_res->assign_by; ?></td>
                                                    <td><?php echo $a_task_res->task_name; ?></td>
                                                    <td><?php echo $a_task_res->ta_task_start_date; ?></td>
                                                    <td><?php echo $a_task_res->ta_task_end_date; ?></td>
                                                    <td><?php echo $a_task_res->ta_total_task; ?></td>
                                                    <td><?php echo $a_task_res->ta_low_case_area_task; ?></td>
                                                    <td><?php echo $a_task_res->ta_high_case_area_task; ?></td>
                                                    <td><?php echo $a_task_res->ta_remaining_task; ?></td>
                                                    <td>
                                                        <?php
                                                        $c_date = date('Y-m-d');
                                                        if($a_task_res->ta_task_end_date >= $c_date)
                                                        {
                                                            ?>
                                                            <a href="<?php echo base_url();?>admin/taskAssign/sendTaskReport/<?php echo $a_task_res->ta_id; ?>/<?php echo $a_task_res->task_id; ?>" title="Send Task Report"><i class="fa fa-plus-square fa-2x" aria-hidden="true"></i></a>
                                                            <?php
                                                        }
                                                        ?>
                                                         &nbsp;&nbsp;<a href="<?php echo base_url();?>admin/taskAssign/taskAssignApprovedView/<?php echo $a_task_res->ta_id; ?>" title="Edit"><i class="fa fa-eye fa-2x "></i></a>
                                                    </td>
                                                </tr>
                                                <?php
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        ?>
                                        <tr>
                                            <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                        <?php
                    }
                    ?>
                    
                </div>                
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function delete_taskAssign(ta_id)
    {
        bootbox.confirm("Are you sure you want to delete community activities details",function(confirmed){
            if(confirmed)
            {
                location.href="<?php echo base_url();?>admin/taskAssign/delete_taskAssign/"+ta_id;
            }
        });
    }    
</script>>