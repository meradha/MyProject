<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Task Form'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/taskForm"><?php echo $welcome->loadPo('Task Form'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Task Form Add'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
               <!--  <div class="pull-left">
                    <h3 class="box-title">Task Form Add</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/taskForm" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div>
                    <div class="row">  
                        <div class="form-group col-md-6">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Form Name'); ?><span class="text-danger">*</span></label>
                                <input name="taskform_name" class="form-control" type="text" id="taskform_name" value="<?php echo set_value('taskform_name'); ?>" />
                                <?php echo form_error('taskform_name','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>                   
                    </div>
                    <div class="row">                           
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Status'); ?></label>
                                <select name="taskform_status" id="taskform_status" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="1"><?php echo $welcome->loadPo('Responsive'); ?></option>
                                    <option value="0"><?php echo $welcome->loadPo('Unresponsive'); ?></option>
                                </select>
                                <?php echo form_error('taskform_status','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Add" ><?php echo $welcome->loadPo('Submit'); ?></button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/taskForm"><?php echo $welcome->loadPo('Cancel'); ?></a>
                </div>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->