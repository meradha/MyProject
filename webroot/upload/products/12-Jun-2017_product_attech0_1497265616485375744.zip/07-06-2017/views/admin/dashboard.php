<?php
    $user_role_id = $this->data['session'][0]->user_role_id;
    $user_all_level = $this->data['session'][0]->user_all_level;
    $user_id = $this->data['session'][0]->user_id;
?>
<!--************************** CSW wise count stakeholders ***************************-->
<script type="text/javascript">
  window.onload = function () {
        <?php
            if($user_role_id != '7')
            {
            ?>
            var chart = new CanvasJS.Chart("chartContainer", {
                title: {
                    text: "CSW wise count of Stakeholders",
                    fontFamily: "Verdana",
                    fontColor: "Peru",
                    fontSize: 20

                },
                animationEnabled: true,
                axisY: {
                    tickThickness: 0,
                    lineThickness: 2,
                    valueFormatString: " ",
                    gridThickness: 0                    
                },
                axisX: {
                    tickThickness: 2,
                    lineThickness: 2,
                    labelFontSize: 14,
                    labelFontColor: "Peru"
                },
                data: [
                    {
                        indexLabelFontSize: 18,
                        toolTipContent: "<span style='\"'color: {color};'\"'><strong>{indexLabel}</strong></span><span style='\"'font-size: 20px; color:peru '\"'><strong>{y}</strong></span>",

                        indexLabelPlacement: "inside",
                        indexLabelFontColor: "white",
                        indexLabelFontWeight: 400,
                        indexLabelFontFamily: "Verdana",
                        color: "#62C9C3",
                        type: "bar",
                        dataPoints: [
                            <?php

                            foreach ($saksham_sathi_list as $ss_list) 
                            {
                                $stakeholder_res = $this->dashboard_model->getAllStakeHolderBySakshamSathiID($ss_list->user_id);
                                $ii=0;
                                $ss_u_l_arr = explode(',', $ss_list->user_all_level);
                                if(in_array($user_id, $ss_u_l_arr))
                                {
                                    foreach ($stakeholder_res as $value) 
                                    {
                                        $u_l_arr = explode(',', $value->user_all_level); 
                                        if (in_array($user_id, $u_l_arr)) 
                                        {
                                             $ii++;                          
                                        }    
                                    }
                                    ?>
                                     { y: <?php echo $ii; ?>, label: "<?php echo $ss_list->user_name; ?>", indexLabel: "<?php echo $ii; ?>" },
                                    <?php                          
                                }
                            }
                            // die;
                            ?>


                        ]
                    }
                ]
            });
            chart.render();
            <?php
        }
        ?>
        
        /************************** Powaer Structur ***************************/
         var chart2 = new CanvasJS.Chart("chartContainer2", {
            title: {
                text: "Power structure",
                fontFamily: "Verdana",
                fontColor: "Peru",
                fontSize: 20

            },
            animationEnabled: true,
            axisY: {
                tickThickness: 0,
                lineThickness: 2,
                valueFormatString: " ",
                gridThickness: 0                    
            },
            axisX: {
                tickThickness: 2,
                lineThickness: 2,
                labelFontSize: 14,
                labelFontColor: "Peru"
            },
            data: [
                {
                    indexLabelFontSize: 18,
                    toolTipContent: "<span style='\"'color: {color};'\"'><strong>{indexLabel}</strong></span><span style='\"'font-size: 20px; color:peru '\"'><strong>{y}</strong></span>",

                    indexLabelPlacement: "inside",
                    indexLabelFontColor: "white",
                    indexLabelFontWeight: 400,
                    indexLabelFontFamily: "Verdana",
                    color: "#62C9C3",
                    type: "bar",
                    dataPoints: [
                        <?php
                        $power_structure_hh = $this->dashboard_model->getPowerStuctureHH();
                        $power_structure_hl = $this->dashboard_model->getPowerStuctureHL();
                        $power_structure_lh = $this->dashboard_model->getPowerStuctureLH();
                        $power_structure_ll = $this->dashboard_model->getPowerStuctureLL();

                        $hh=0;
                        $hl=0;
                        $lh=0;
                        $ll=0;
                        foreach ($power_structure_hh as $hh_v) 
                        {
                            $hh_u_l_arr = explode(',', $hh_v->user_all_level);
                            if(in_array($user_id, $hh_u_l_arr))
                            {
                                $hh++;
                            }
                        }
                        foreach ($power_structure_hl as $hl_v) 
                        {
                            $hl_u_l_arr = explode(',', $hl_v->user_all_level);
                            if(in_array($user_id, $hl_u_l_arr))
                            {
                                $hl++;
                            }
                        }
                        foreach ($power_structure_lh as $lh_v) 
                        {
                            $lh_u_l_arr = explode(',', $lh_v->user_all_level);
                            if(in_array($user_id, $lh_u_l_arr))
                            {
                                $lh++;
                            }
                        }
                        foreach ($power_structure_ll as $ll_v) 
                        {
                            $ll_u_l_arr = explode(',', $ll_v->user_all_level);
                            if(in_array($user_id, $ll_u_l_arr))
                            {
                                $hh++;
                            }
                        }
                        ?>
                        { y: <?php echo $hh; ?>, label: "High power, High interest", indexLabel: "<?php echo $hh; ?>" },
                        { y: <?php echo $hl; ?>, label: "High power, Low interest", indexLabel: "<?php echo $hl; ?>" },
                        { y: <?php echo $lh; ?>, label: "Low power, High interest", indexLabel: "<?php echo $lh; ?>" },
                        { y: <?php echo $ll; ?>, label: "Low power, Low interest", indexLabel: "<?php echo $ll; ?>" },
                    ]
                }
            ]
        });
        chart2.render();
        /************************** Focus Population ***************************/
         var chart3 = new CanvasJS.Chart("chartContainer3", {
            title: {
                text: "Focus Population",
                fontFamily: "Verdana",
                fontColor: "Peru",
                fontSize: 20

            },
            animationEnabled: true,
            axisY: {
                tickThickness: 0,
                lineThickness: 2,
                valueFormatString: " ",
                gridThickness: 0                    
            },
            axisX: {
                tickThickness: 2,
                lineThickness: 2,
                labelFontSize: 14,
                labelFontColor: "Peru"
            },
            data: [
                {
                    indexLabelFontSize: 18,
                    toolTipContent: "<span style='\"'color: {color};'\"'><strong>{indexLabel}</strong></span><span style='\"'font-size: 20px; color:peru '\"'><strong>{y}</strong></span>",

                    indexLabelPlacement: "inside",
                    indexLabelFontColor: "white",
                    indexLabelFontWeight: 400,
                    indexLabelFontFamily: "Verdana",
                    color: "#62C9C3",
                    type: "bar",
                    dataPoints: [
                        <?php
                        $focus_population = $this->dashboard_model->getFocusPopulation();
                        $focus_population1 = '0';
                        $focus_population2 = '0';
                        $focus_population3 = '0';
                        $focus_population4 = '0';
                        $focus_population5 = '0';
                        $focus_population6 = '0';
                        $focus_population7 = '0';
                        $focus_population8 = '0';
                        foreach ($focus_population as $fp_res) 
                        {
                            $fp_res_u_l_arr = explode(',', $fp_res->user_all_level);
                            if(in_array($user_id, $fp_res_u_l_arr))
                            {
                                $stakeholder_focus_population_ar = explode(',', $fp_res->stakeholder_focus_population);
                                if(in_array('Male', $stakeholder_focus_population_ar))
                                {
                                   $focus_population1 = $focus_population1 + 1; 
                                }
                            }
                        }
                        foreach ($focus_population as $fp_res) 
                        {
                            $fp_res_u_l_arr = explode(',', $fp_res->user_all_level);
                            if(in_array($user_id, $fp_res_u_l_arr))
                            {
                                $stakeholder_focus_population_ar = explode(',', $fp_res->stakeholder_focus_population);
                                if(in_array('Women', $stakeholder_focus_population_ar))
                                {
                                   $focus_population2 = $focus_population2 + 1; 
                                }
                            }
                        }
                        foreach ($focus_population as $fp_res) 
                        {
                            $fp_res_u_l_arr = explode(',', $fp_res->user_all_level);
                            if(in_array($user_id, $fp_res_u_l_arr))
                            {
                                $stakeholder_focus_population_ar = explode(',', $fp_res->stakeholder_focus_population);
                                if(in_array('Children', $stakeholder_focus_population_ar))
                                {
                                   $focus_population3 = $focus_population3 + 1; 
                                } 
                            }
                        }
                        foreach ($focus_population as $fp_res) 
                        {
                            $fp_res_u_l_arr = explode(',', $fp_res->user_all_level);
                            if(in_array($user_id, $fp_res_u_l_arr))
                            {
                                $stakeholder_focus_population_ar = explode(',', $fp_res->stakeholder_focus_population);
                                if(in_array('Workers', $stakeholder_focus_population_ar))
                                {
                                   $focus_population4 = $focus_population4 + 1; 
                                }
                            }
                        }
                        foreach ($focus_population as $fp_res) 
                        {
                            $fp_res_u_l_arr = explode(',', $fp_res->user_all_level);
                            if(in_array($user_id, $fp_res_u_l_arr))
                            {
                                $stakeholder_focus_population_ar = explode(',', $fp_res->stakeholder_focus_population);
                                if(in_array('Health condition specific population(TB HIV)', $stakeholder_focus_population_ar))
                                {
                                   $focus_population5 = $focus_population5 + 1; 
                                }
                            }
                        }
                        foreach ($focus_population as $fp_res) 
                        {
                            $fp_res_u_l_arr = explode(',', $fp_res->user_all_level);
                            if(in_array($user_id, $fp_res_u_l_arr))
                            {
                                $stakeholder_focus_population_ar = explode(',', $fp_res->stakeholder_focus_population);
                                if(in_array('General Population', $stakeholder_focus_population_ar))
                                {
                                   $focus_population6 = $focus_population6 + 1; 
                                }
                            }
                        }
                        foreach ($focus_population as $fp_res) 
                        {
                            $fp_res_u_l_arr = explode(',', $fp_res->user_all_level);
                            if(in_array($user_id, $fp_res_u_l_arr))
                            {
                                $stakeholder_focus_population_ar = explode(',', $fp_res->stakeholder_focus_population);
                                if(in_array('Elderly', $stakeholder_focus_population_ar))
                                {
                                   $focus_population7 = $focus_population7 + 1; 
                                }
                            }
                        }
                        foreach ($focus_population as $fp_res) 
                        {
                            $fp_res_u_l_arr = explode(',', $fp_res->user_all_level);
                            if(in_array($user_id, $fp_res_u_l_arr))
                            {
                                $stakeholder_focus_population_ar = explode(',', $fp_res->stakeholder_focus_population);
                                if(in_array('LGBTQ', $stakeholder_focus_population_ar))
                                {
                                   $focus_population8 = $focus_population8 + 1; 
                                } 
                            }
                        }

                        ?>
                        { y: <?php echo $focus_population1; ?>, label: "Male", indexLabel: "<?php echo $focus_population1; ?>" },
                        { y: <?php echo $focus_population2; ?>, label: "Women", indexLabel: "<?php echo $focus_population2; ?>" },
                        { y: <?php echo $focus_population3; ?>, label: "Children", indexLabel: "<?php echo $focus_population3; ?>" },
                        { y: <?php echo $focus_population4; ?>, label: "Workers", indexLabel: "<?php echo $focus_population4; ?>" },
                        { y: <?php echo $focus_population5; ?>, label: "Health condition specific population(TB, HIV)", indexLabel: "<?php echo $focus_population5; ?>" },
                        { y: <?php echo $focus_population6; ?>, label: "General Population", indexLabel: "<?php echo $focus_population6; ?>" },
                        { y: <?php echo $focus_population7; ?>, label: "Elderly", indexLabel: "<?php echo $focus_population7; ?>" },
                        { y: <?php echo $focus_population8; ?>, label: "LGBTQ", indexLabel: "<?php echo $focus_population8; ?>" },
                    ]
                }
            ]
        });
        chart3.render();

        /************************** M-East/M-west ***************************/
        var chart1 = new CanvasJS.Chart("chartContainer1",
        {
            title: {
                text: "Ward",
                fontFamily: "Verdana",
                fontColor: "Peru",
                fontSize: 20

            },
            exportFileName: "Pie Chart",
            exportEnabled: true,
                    animationEnabled: true,
            legend:{
                verticalAlign: "bottom",
                horizontalAlign: "center"
            },
            data: [
                {    
                    <?php
                    $name_of_ward_e = $this->dashboard_model->getNameOfWardCountEast();
                    $name_of_ward_w = $this->dashboard_model->getNameOfWardCountWest();
                    $e=0;
                    $w=0;
                    foreach ($name_of_ward_w as $ward_w) 
                    {
                        $w_u_l_arr = explode(',', $ward_w->user_all_level);   
                        if(in_array($user_id, $w_u_l_arr))
                        {
                            $w++;
                        }
                    }
                    foreach ($name_of_ward_e as $ward_e) 
                    {
                        $e_u_l_arr = explode(',', $ward_e->user_all_level);   
                        if(in_array($user_id, $e_u_l_arr))
                        {
                            $e++;
                        }
                    }
                    ?> 
                    type: "pie",
                    showInLegend: true,
                    toolTipContent: "{name}: <strong>{y}</strong>",
                    indexLabel: "{name} {y}",
                    dataPoints: [
                        {  y: <?php echo $e; ?>, name: "M-East", exploded: true},
                        {  y: <?php echo $w; ?>, name: "M-West"},
                    ]
                }
            ]
        });
        chart1.render();
    }
</script>

<script src="<?php echo base_url(); ?>webroot/admin/js/canvas/canvasjs.min.js"></script>

<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            Welcome <small>Control panel</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Welcome</li>
        </ol>
    </section>
    <div>
        <div id="msg_div">
            <?php echo $this->session->flashdata('message');?>
        </div>
    </div>
   
    <!-- Main content -->
    <section class="content">
        <!-- Small boxes (Stat box) -->
        <div class="row">
            <?php
            $i=1;
            foreach ($role_list as $value) 
            {
                if($user_role_id < $value->role_id)
                {
                    $user_by_role = $this->dashboard_model->getUserByRoleID($value->role_id);
                    $j=0;
                    foreach ($user_by_role as $u_r_res) 
                    {
                        $user_all_level_ar = explode(',', $u_r_res->user_all_level);
                        if(in_array($user_id, $user_all_level_ar))
                        {
                            $j++;
                        }
                    }
                ?>
                <div class="col-lg-2">
                <!-- small box -->
                    <div class="small-box <?php if($i%2==0){ echo "bg-aqua"; }else{ echo "bg-red"; } ?>">
                        <div class="inner">
                            <h3><?php echo $j; ?></h3>
                            <p><?php echo $value->role_name; ?></p>
                        </div>
                    </div>
                </div>
                <!-- ./col -->
                <?php                    
                    $i++;
                }
            }
            ?>
        </div>
        <div class="row">
            <div class="col-lg-3">
                <?php
                $k=0;
                foreach ($stakeholder_list as $st_list) 
                {
                    $user_all_level_ar = explode(',', $st_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $k++;
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $k; ?></h3>
                        <p>Stakeholder</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $l=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $l++;
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $l; ?></h3>
                        <p>Presumptive Referrals</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $q=0;
                foreach ($patient_list as $p_list) 
                {
                    $user_all_level_ar = explode(',', $p_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $q++;
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $q; ?></h3>
                        <p>Patients</p>
                    </div>
                </div>
            </div> 
            <div class="col-lg-3">
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo count($referral_linkages_list); ?></h3>
                        <p>Referral linkages</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo count($lab_list); ?></h3>
                        <p>Labs</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a1=0;
                foreach ($stakeholder_meeting_list as $s_m_list) 
                {
                    $user_all_level_ar = explode(',', $s_m_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $a1++;
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a1; ?></h3>
                        <p>Stakeholder meetings</p>
                    </div>
                </div>
            </div> 
            <div class="col-lg-3">
                <?php
                $a2=0;
                foreach ($community_meeting_list as $c_m_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $a2++;
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a2; ?></h3>
                        <p>Community meetings</p>
                    </div>
                </div>
            </div> 
        </div>
        <div class="row">
            <div class="col-lg-3">
                <?php
                $a3=0;
                foreach ($community_meeting_list as $c_m_h_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_h_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_h_list->tca_area == 'High case burden area')
                        {
                            $a3++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a3; ?></h3>
                        <p>Community meetings in high case burden area</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a4=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                       if($c_m_l_list->tca_area == 'Low case burden area')
                        {
                            $a4++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a4; ?></h3>
                        <p>Community meetings in low case burden area</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a5=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'Low case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'General Population')
                            {
                                $a5++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a5; ?></h3>
                        <p>General population low case burden area</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a6=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'Low case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'Young population')
                            {
                                $a6++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a6; ?></h3>
                        <p>Young population low case burden area</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a7=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'Low case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'Old aged')
                            {
                                $a7++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a7; ?></h3>
                        <p>Old aged low case burden area<br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a8=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'Low case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'Poorest among poor')
                            {
                                $a8++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a8; ?></h3>
                        <p>Poorest among poor low case burden area</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a9=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'Low case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'Religion specific population')
                            {
                                $a9++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a9; ?></h3>
                        <p>Religion specific population low case burden area</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a10=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'Low case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'Migrant workers')
                            {
                                $a10++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a10; ?></h3>
                        <p>Migrant workers low case burden area</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a11=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'Low case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'Females')
                            {
                                $a11++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a11; ?></h3>
                        <p>Females low case burden area<br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a12=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'High case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'General Population')
                            {
                                $a12++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a12; ?></h3>
                        <p>General population high case burden area</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a13=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'High case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'Young population')
                            {
                                $a13++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a13; ?></h3>
                        <p>Young population high case burden area</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a14=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'High case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'Old aged')
                            {
                                $a14++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a14; ?></h3>
                        <p>Old aged high case burden area<br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a15=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'High case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'Poorest among poor')
                            {
                                $a15++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a15; ?></h3>
                        <p>Poorest among poor high case burden area</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a16=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'High case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'Religion specific population')
                            {
                                $a16++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a16; ?></h3>
                        <p>Religion specific population high case burden area</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a17=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'High case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'Migrant workers')
                            {
                                $a17++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a17; ?></h3>
                        <p>Migrant workers high case burden area</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a18=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($c_m_l_list->tca_area == 'High case burden area')
                        {
                            if($c_m_l_list->tca_focus_population == 'Females')
                            {
                                $a18++;
                            }
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a18; ?></h3>
                        <p>Females high case burden area<br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a19=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($pp_list->pp_testing_result == 'Positive')
                        {
                            $a19++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a19; ?></h3>
                        <p>Presumptive Referrals Positive</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a20=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($pp_list->pp_testing_result == 'Negative')
                        {
                            $a20++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a20; ?></h3>
                        <p>Presumptive Referrals Negative</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a21=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($pp_list->pp_testing_result == 'Not tested')
                        {
                            $a21++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a21; ?></h3>
                        <p>Presumptive Referrals Not tested</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a22=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($pp_list->pp_drug_sensitive_type == 'CAT-1')
                        {
                            $a22++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a22; ?></h3>
                        <p>Presumptive Referrals CAT-1</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a23=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($pp_list->pp_drug_sensitive_type == 'CAT-2')
                        {
                            $a23++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a23; ?></h3>
                        <p>Presumptive Referrals CAT-2</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a24=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($pp_list->pp_drug_resistance_type == 'MDR')
                        {
                            $a24++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a24; ?></h3>
                        <p>Presumptive Referrals MDR</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a25=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($pp_list->pp_drug_resistance_type == 'XDR')
                        {
                            $a25++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a25; ?></h3>
                        <p>Presumptive Referrals XDR</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a26=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($pp_list->pp_drug_resistance_type == 'TDR')
                        {
                            $a26++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a26; ?></h3>
                        <p>Presumptive Referrals TDR</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a27=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($pp_list->pp_referral_type == 'Self referral during community activity')
                        {
                            $a27++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a27; ?></h3>
                        <p>Self referral during community activity</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a28=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($pp_list->pp_referral_type == 'Referral during active case finding')
                        {
                            $a28++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a28; ?></h3>
                        <p>Referral during active case finding<br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a29=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($pp_list->pp_referral_type == 'Community referral')
                        {
                            $a29++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a29; ?></h3>
                        <p>Community referral<br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a30=0;
                foreach ($presumptive_patient_list as $pp_list) 
                {
                    $user_all_level_ar = explode(',', $pp_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        if($pp_list->pp_referral_type == 'Self referral during field visit')
                        {
                            $a30++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a30; ?></h3>
                        <p>Self referral during field visit<br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a31=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $tca_type_of_community_activity_arr = explode(',', $c_m_l_list->tca_type_of_community_activity);
                        if(in_array('Street Play', $tca_type_of_community_activity_arr))
                        {
                            $a31++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a31; ?></h3>
                        <p>Street Play activity<br><br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a32=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $tca_type_of_community_activity_arr = explode(',', $c_m_l_list->tca_type_of_community_activity);
                        if(in_array('Health Game', $tca_type_of_community_activity_arr))
                        {
                            $a32++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a32; ?></h3>
                        <p>Health Game activity<br><br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a33=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $tca_type_of_community_activity_arr = explode(',', $c_m_l_list->tca_type_of_community_activity);
                        if(in_array('Kiosk / Exhibition / IEC stall', $tca_type_of_community_activity_arr))
                        {
                            $a33++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a33; ?></h3>
                        <p>Kiosk / Exhibition / IEC stall activity<br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a34=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $tca_type_of_community_activity_arr = explode(',', $c_m_l_list->tca_type_of_community_activity);
                        if(in_array('Activity conducted in collaboration with health camp', $tca_type_of_community_activity_arr))
                        {
                            $a34++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a34; ?></h3>
                        <p>Activity conducted in collaboration with health camp activity</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a35=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $tca_type_of_community_activity_arr = explode(',', $c_m_l_list->tca_type_of_community_activity);
                        if(in_array('Sharing success stories', $tca_type_of_community_activity_arr))
                        {
                            $a35++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a35; ?></h3>
                        <p>Sharing success stories activity<br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a36=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $tca_type_of_community_activity_arr = explode(',', $c_m_l_list->tca_type_of_community_activity);
                        if(in_array('Group discussions', $tca_type_of_community_activity_arr))
                        {
                            $a36++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a36; ?></h3>
                        <p>Group discussions activity<br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a37=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $tca_type_of_community_activity_arr = explode(',', $c_m_l_list->tca_type_of_community_activity);
                        if(in_array('Activity conducted through small child/children', $tca_type_of_community_activity_arr))
                        {
                            $a37++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a37; ?></h3>
                        <p>Activity conducted through small child/children activity</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a38=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $tca_type_of_community_activity_arr = explode(',', $c_m_l_list->tca_type_of_community_activity);
                        if(in_array('SHG formation', $tca_type_of_community_activity_arr))
                        {
                            $a38++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a38; ?></h3>
                        <p>SHG formation activity<br><br></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a39=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $tca_type_of_community_activity_arr = explode(',', $c_m_l_list->tca_type_of_community_activity);
                        if(in_array('BC activity', $tca_type_of_community_activity_arr))
                        {
                            $a39++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a39; ?></h3>
                        <p>BC activity</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a40=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $tca_type_of_community_activity_arr = explode(',', $c_m_l_list->tca_type_of_community_activity);
                        if(in_array('Puppet show', $tca_type_of_community_activity_arr))
                        {
                            $a40++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <h3><?php echo $a40; ?></h3>
                        <p>Puppet show activity</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a41=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $tca_type_of_community_activity_arr = explode(',', $c_m_l_list->tca_type_of_community_activity);
                        if(in_array('Movies screening', $tca_type_of_community_activity_arr))
                        {
                            $a41++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h3><?php echo $a41; ?></h3>
                        <p>Movies screening activity</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <?php
                $a42=0;
                foreach ($community_meeting_list as $c_m_l_list) 
                {
                    $user_all_level_ar = explode(',', $c_m_l_list->user_all_level);
                    if(in_array($user_id, $user_all_level_ar))
                    {
                        $tca_type_of_community_activity_arr = explode(',', $c_m_l_list->tca_type_of_community_activity);
                        if(in_array('Health Talk', $tca_type_of_community_activity_arr))
                        {
                            $a42++;
                        }
                    }
                }
                ?>
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php echo $a42; ?></h3>
                        <p>Health Talk activity</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default box box-success">
                    <div class="panel-body">
                        <h5><i class="fa fa-angle-right"></i> <b>Task Calendar</b></h5>
                        <span style="width:20px;background-color: red;border:5px solid red;display: inline-block;"></span> - Reminder
                       <!-- <span style="width:20px;background-color: #32127A;border:5px solid #32127A;display: inline-block;"></span> - Task
                        <span style="width:20px;background-color: green;border:5px solid green;display: inline-block;"></span> - Meetings-->
                        <span style="width:20px;background-color: green;border:5px solid green;display: inline-block;"></span> - Followup
                        
                        <?php if($user_role_id!=7){
                        $getUserByRoleAndLevel = $this->taskassign_model->getUserByRoleAndLevel($user_id,7); ?>
                        <select style="float:right;width:50%" class="form-control" name="saksham_list" id="saksham_list">
                        <option value="">---Select Saskham---</option>
                        <?php
                        foreach($getUserByRoleAndLevel as $userlist){?>
                        <option value="<?php echo $userlist->user_id; ?>"><?php echo $userlist->user_name ?></option>
                        <?php }
                        ?>
                        </select>
                        <br><br>
                        <?php } ?>
                        <div class="row mt">
                            <aside style="" class="">
                                <section class="panel">
                                    <div class="panel-body">
                                        <div id="calendar" class="has-toolbar"></div>
                                    </div>
                                </section>
                            </aside>
                        </div>                          
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
        </div>
        <!-- /.row -->
        <div class="row">
            <?php
            if($user_role_id != '7')
            {
                ?>
                <div class="col-lg-6">
                    <div class="panel panel-default box box-success">
                        <div class="panel-body">
                            <div id="chartContainer" style="height: 400px; width: 100%;"></div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <?php
            }
            ?>
            <div class="col-lg-6">
                <div class="panel panel-default box box-success">
                    <div class="panel-body">
                        <div id="chartContainer2" style="height: 400px; width: 100%;"> </div>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>  
            <!--  -->  
        </div>
        
        <div class="row">
            <div class="col-lg-6">
                <div class="panel panel-default box box-success">
                    <div class="panel-body">
                        <div id="chartContainer3" style="height: 400px; width: 100%;"> </div>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>   
            <div class="col-lg-6">
                <div class="panel panel-default box box-success">
                    <div class="panel-body">
                        <div id="chartContainer1" style="height: 400px; "> </div>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- ./col -->            
        </div>
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<style>
.fc-toolbar h2{ font-size:18px; }
.tooltipevent{color:#fff;width:auto;height:auto;background:#000;position:absolute;z-index:10001;padding:4px;}

</style>
<script>
    $(document).ready(function() 
    {
    
        var calendar = $('#calendar').fullCalendar({
            
            eventLimit: true, // for all non-agenda views
            views: {
                month: {
                    eventLimit: 4 // adjust to 6 only for agendaWeek/agendaDay
                }
            },
            header: {
                left:   'title',
                center: '',
                right:  'today prev,next,prevYear,nextYear'
            },
            loading: function( isLoading, view ) {
                if(isLoading) {// isLoading gives boolean value
                 // $('#loading').show();
                    //show your loader here 
                } else {
                   //$('#loading').hide();
                    //hide your loader here
                }
            },
            events: "<?php base_url() ?>taskAssign/get_assignTask",
            
            eventAfterRender: function (event, element){
                //element.find('.fc-title').after("<br><span>"+event.description+"</span>");
                //element.find('.fc-title').attr('title',event.description);
                 //element.find('.fc-title').tooltip({title: event.description}); 
                //element.find('.fc-title').append('<span class="tooltiptext"><p>Tooltip text</p><p>Tooltip text</p></span>');
            },
            selectable: true,
            //selectHelper: true,
            
            select: function(start, end, allDay) {
                var title = prompt('Event Title:');
                var time = prompt('Enter time:');
                if (title) 
                {
                    var start = $.fullCalendar.moment(start).format("YYYY-MM-DD");
                    var end = $.fullCalendar.moment(end).format("YYYY-MM-DD");
                    $.ajax({
                        url: '<?php base_url() ?>taskAssign/add_reminder',
                        data: 'title='+ title+'&start='+ start +'&end='+ end +'&time='+ time,
                        type: "POST",
                        success: function(json) {      
                           calendar.fullCalendar('removeEvents');
                           calendar.fullCalendar('refetchEvents');
                        }
                    });   
                    calendar.fullCalendar('renderEvent',
                        {
                            title: title,
                            start: start,
                            end: end,
                            allDay: allDay
                        },
                        true // make the event "stick"
                    );
                }
                calendar.fullCalendar('unselect');
            },

            editable: true,

            eventDrop: function(event, delta) {
                var start = $.fullCalendar.moment(event.start).format("YYYY-MM-DD");
                var  end  = $.fullCalendar.moment(event.end).format("YYYY-MM-DD");

                $.ajax({
                    url: '<?php base_url() ?>taskAssign/update_reminder',
                    data: 'title='+ event.title+'&start='+ start +'&end='+ end +'&id='+ event.id ,
                    type: "POST",
                    success: function(json) {
                    // alert("Updated Successfully");
                    }
                });
            },
            editable: true,
            selectable: true,
            eventResize: function(event) {
                var start = $.fullCalendar.moment(event.start).format("YYYY-MM-DD");
                var end = $.fullCalendar.moment(event.end).format("YYYY-MM-DD");

                $.ajax({
                    url: '<?php base_url() ?>taskAssign/update_reminder',
                    data: 'title='+ event.title+'&start='+ start +'&end='+ end +'&id='+ event.id ,
                    type: "POST",
                    success: function(json) {
                    ///alert("Updated Successfully");
                    }
                });
            },
            
eventMouseover: function(calEvent, jsEvent) {
    var tooltip = '<div class="tooltipevent">' + calEvent.description + '</div>';
    $("body").append(tooltip);
    $(this).mouseover(function(e) {
        $(this).css('z-index', 10000);
        $('.tooltipevent').fadeIn('500');
        $('.tooltipevent').fadeTo('10', 1.9);
    }).mousemove(function(e) {
        $('.tooltipevent').css('top', e.pageY + 10);
        $('.tooltipevent').css('left', e.pageX + 20);
    });
},

eventMouseout: function(calEvent, jsEvent) {
     $(this).css('z-index', 8);
     $('.tooltipevent').remove();
},
                
            eventClick: function(event) {
                if(event.editable){
                    var decision = confirm("Do you really want to do delete?"); 
                    if (decision) {
                        $.ajax({
                            url: "<?php base_url() ?>taskAssign/delete_reminder",
                            data: "id=" + event.id,
                            type: "POST",
                        });
                        $('#calendar').fullCalendar('removeEvents', event.id);
                    } 
                }
            }
        });
    var source = '<?php base_url() ?>taskAssign/get_assignTask';
    
    $('#saksham_list').change(function(){
    
    var saksham_id = $('#saksham_list').val();
    var newSource = '<?php base_url() ?>taskAssign/get_assignTask/'+saksham_id;
    if( saksham_id != null ) {
    $('#calendar').fullCalendar('removeEventSource', source)
    $('#calendar').fullCalendar('refetchEvents')
    $('#calendar').fullCalendar('removeEvents');
    $('#calendar').fullCalendar('addEventSource', newSource)
    $('#calendar').fullCalendar('refetchEvents');
    source = newSource; 
     }
    }); 
 });

 
    function getEndDateValue(str)
    {
        min1 = new Date(str);
        min = new Date(str);
        var numberOfDaysToAdd = 0;
        min.setDate(min.getDate() + numberOfDaysToAdd);
        var dd = min.getDate();
        var mm = min.getMonth() + 1;
        var y = min.getFullYear();
        var aa = y+'-'+mm+'-'+dd;
        max = new Date(aa); 
        $( "#end_date" ).datepicker({ 
           minDate: min1,
           //maxDate: max,
           dateFormat : 'yy-mm-dd',
           changeMonth : true,
           changeYear : true,
        });
    }
 </script>