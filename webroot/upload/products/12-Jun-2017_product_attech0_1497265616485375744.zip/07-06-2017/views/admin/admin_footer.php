	<!-- Bootstrap -->
	<script src="<?php echo base_url();?>webroot/admin/js/bootstrap.min.js" type="text/javascript"></script>
	<!-- jQuery UI 1.10.3 -->
		<script src="<?php echo base_url();?>webroot/admin/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
	<script src="<?php echo base_url();?>webroot/admin/js/bootstrap-select.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>webroot/admin/js/plugins/morris/morris.min.js" type="text/javascript"></script>	
	<!-- bootbox.min.js -->	
	<script src="<?php echo base_url();?>webroot/admin/js/bootbox.min.js" type="text/javascript"></script>
	<!-- Date picker new -->
	<script src="<?php echo base_url();?>webroot/admin/calendar/jquery-1.10.2.js"></script>
 	<script src="<?php echo base_url();?>webroot/admin/calendar/jquery-ui.js"></script>
	<!-- bootstrap time picker -->
	<script src="<?php echo base_url(); ?>webroot/admin/js/plugins/timepicker/bootstrap-timepicker.min.js"></script>
	<!-- SlimScroll 1.3.0 -->
	<script src="<?php echo base_url(); ?>webroot/admin/js/plugins/slimScroll/jquery.slimscroll.min.js"></script>		
	<!-- AdminLTE App -->
	<script src="<?php echo base_url();?>webroot/admin/js/AdminLTE/app.js" type="text/javascript"></script>
	<!-- ************** Amit  ********************-->
	<script src='<?php echo base_url();?>webroot/admin/calfile/assets/js/moment.min.js'></script>
	
    <script src="<?php echo base_url();?>webroot/admin/calfile/assets/js/fullcalendar.min.js"></script>
    
    
	<!--********************************** Common for all *******************************-->
	<!-- Flash Message auto hide  -->
	<script type="text/javascript">
		$("#msg_div").fadeOut(10000);			
	</script>	
	<!-- Data Table -->
	<script src="<?php echo base_url();?>webroot/admin/js/datatables/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url();?>webroot/admin/js/datatables/dataTables.bootstrap.min.js"></script>		
	<script>
		$(function () {
			$('#example2').DataTable({
				"paging": true,
				"lengthChange": true,
				"searching": true,
				"ordering": false,
				"info": false,
				"autoWidth": false,
				"scrollX": true,
			});
		});
	</script>	
	
	<script type="text/javascript">
	    $(function() {
	        $( ".date_val" ).datepicker({
	            dateFormat : 'yy-mm-dd',
	            changeMonth : true,
	            changeYear : true,        
	        });
	        $( ".current_date" ).datepicker({
	            dateFormat : 'yy-mm-dd',
	            changeMonth : true,
	            changeYear : true, 
	            minDate: new Date()       
	        });
	        $( ".month_year" ).datepicker({
	            dateFormat : 'MM, yy',
	            changeMonth : true,
	            changeYear : true,        
	        });
	    });
	    //Timepicker
	    $(".timepicker").timepicker({
	      showInputs: false
	    });
	</script>
	<script type="text/javascript" src="<?php echo base_url();?>webroot/admin/js/plugins/tinymce/tinymce.min.js"></script>
	<script type="text/javascript">
		tinymce.init({
			selector: "textarea#kb_description",
			//you can add multiple plugins here from plugin folder
			plugins :"advlist autolink link image lists charmap print preview code fullscreen textcolor table media",
			tools: "inserttable",	
			relative_urls: false,
			toolbar: [ "undo redo | styleselect | bold italic | bullist numlist outdent indent | alignleft aligncenter alignright alignjustify  forecolor backcolor", ]
		});
	</script>
	<!-- Other input fields add  -->
	<script type="text/javascript">
	    function addInputFieldSelectBox(f_val, f_id)
	    {
	        if(f_val == 'Other')
	        {
	            $('#'+f_id+'_other').css('display', 'block');
	        }
	        else
	        {
	            $('#'+f_id+'_other').css('display', 'none');
	        }
	    }
	    function addInputFieldCheckBox(f_val, f_id)
	    {
	    	// alert(f_id);return false;
	        if(document.getElementById(f_id).checked)
	        {
	            $('#'+f_id+'_other').css('display', 'block');
	        }
	        else
	        {
	            $('#'+f_id+'_other').css('display', 'none');
	        }
	    }

	    function showHideInputField(f_val, f_id)
	    {
	        if(f_val == 'Yes')
	        {
	            $('#'+f_id+'_div').css('display', 'block');
	        }
	        else
	        {
	            $('#'+f_id+'_div').css('display', 'none');
	        }
	    }

</script>
    </body>
</html>