
<?php
$user_role_id = $this->data['session'][0]->user_role_id;
$user_all_level = $this->data['session'][0]->user_all_level;
$user_id = $this->data['session'][0]->user_id;
?>
<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Lab Data'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Lab Data'); ?></li>
        </ol>
    </section>
    <div>
        <div id="msg_div">
            <?php echo $this->session->flashdata('message');?>
        </div>
    </div>
   
    <!-- Main content -->
    <section class="content">
        <div class="box box-primary">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Lab Data</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <?php
                        foreach($getAllTabAsPerRole as $role)
                        {
                            if($this->uri->segment(2) == $role->controller_name && $role->userAdd == '1')
                            {
                                ?>
                                    <a href="<?php echo base_url();?>admin/labData/addLabData" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Add New'); ?></a>              
                                <?php
                            }
                        }
                    ?>                    
                </div>
            </div>
            <div class="box-body">
                <div class="row col-md-12">
                    <table id="example2" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="5%"><?php echo $welcome->loadPo('Month-Year'); ?></th>
                                <th width="8%"><?php echo $welcome->loadPo('Name of the Lab'); ?></th>
                                <th width="18%"><?php echo $welcome->loadPo('Total number of presumptive cases tested in the lab'); ?></th>
                                <th width="18%"><?php echo $welcome->loadPo('Total number of cases tested positive in the lab'); ?></th>
                                <th width="18%"><?php echo $welcome->loadPo('Total number of cases referred by Saksham sathi in the lab'); ?></th>
                                <th width="18%"><?php echo $welcome->loadPo('Total number of cases reached in the lab and tested out of all the cases referred by Saksham Sathis in the lab'); ?></th>
                                <th width="18%"><?php echo $welcome->loadPo('Number of cases tested positive referred by Saksham sathi in the lab'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                if(!empty($lab_data))
                                {
                                    foreach ($lab_data as $value) 
                                    {
                                        $user_all_level_arr = explode(',', $value->user_all_level);
                                        if(in_array($user_id, $user_all_level_arr))
                                        {
                                        ?>
                                        <tr>
                                            <td><?php echo $value->ld_month.'-'.$value->ld_year; ?></td>
                                            <td><?php echo $value->diagnosis_name; ?></td>
                                            <td><?php echo $value->ld_presumptive_tested; ?></td>
                                            <td><?php echo $value->ld_presumptive_tested_positive; ?></td>
                                            <td><?php echo $value->ld_referred_by_saksham_sathi; ?></td>
                                            <td><?php echo $value->ld_tested_out_referred_by_saksham_sathi  ; ?></td>
                                            <td><?php echo $value->ld_positive_referred_by_saksham_sathi; ?></td>
                                        </tr>
                                        <?php
                                        }
                                    }
                                }
                                else
                                {
                                    ?>
                                    <tr>
                                        <td colspan="7"><?php echo $welcome->loadPo('No recors found'); ?>...</td>
                                    </tr>
                                    <?php
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="clearfix"></div><br/><br/><br/>
            </div>
        </div>
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    $(function() {
        $( "#start_date" ).datepicker({
            dateFormat : 'yy-mm-dd',
            changeMonth : true,
            changeYear : true,           
        });
    });
    function setEndDate(str)
    {
        $( "#end_date" ).datepicker({
            minDate:str,
            dateFormat : 'yy-mm-dd',
            changeMonth : true,
            changeYear : true,           
        });
    }
</script>