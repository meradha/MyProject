
<?php
$user_role_id = $this->data['session'][0]->user_role_id;
$user_all_level = $this->data['session'][0]->user_all_level;
$user_id = $this->data['session'][0]->user_id;
?>
<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            Lab Data  <small>Control panel</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Lab Data</li>
        </ol>
    </section>
    <div>
        <div id="msg_div">
            <?php echo $this->session->flashdata('message');?>
        </div>
    </div>
   
    <!-- Main content -->
    <section class="content">
        <div class="box box-primary">
            <div class="box-header">
                <div class="pull-left">
                    <h3 class="box-title">Lab Data</h3>
                </div>
            </div>
            <div class="box-body">
                <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label>Year<span class="text-danger">*</span></label>
                                <select name="year" id="year" class="form-control">
                                    <?php 
                                    $c_year = date('Y');
                                    $n_year = date('Y',strtotime("-1 year"));
                                    for($i=$c_year; $i>=$n_year; $i--)
                                    {
                                        ?>
                                        <option <?php if($year == $i){ echo 'selected'; } ?> value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                        <?php
                                    }
                                    ?>
                                    
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label>Month<span class="text-danger">*</span></label>
                                <select name="month" id="month" class="form-control">
                                    <!-- <option value="">-- select --</option> -->
                                    <option <?php if($month == '01'){ echo 'selected'; } ?> value='01'>Janaury</option>
                                    <option <?php if($month == '02'){ echo 'selected'; } ?> value='02'>February</option>
                                    <option <?php if($month == '03'){ echo 'selected'; } ?> value='03'>March</option>
                                    <option <?php if($month == '04'){ echo 'selected'; } ?> value='04'>April</option>
                                    <option <?php if($month == '05'){ echo 'selected'; } ?> value='05'>May</option>
                                    <option <?php if($month == '06'){ echo 'selected'; } ?> value='06'>June</option>
                                    <option <?php if($month == '07'){ echo 'selected'; } ?> value='07'>July</option>
                                    <option <?php if($month == '08'){ echo 'selected'; } ?> value='08'>August</option>
                                    <option <?php if($month == '09'){ echo 'selected'; } ?> value='09'>September</option>
                                    <option <?php if($month == '10'){ echo 'selected'; } ?> value='10'>October</option>
                                    <option <?php if($month == '11'){ echo 'selected'; } ?> value='11'>November</option>
                                    <option <?php if($month == '12'){ echo 'selected'; } ?> value='12'>December</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label>&nbsp<br><br></label>
                                <button class="btn btn-primary" type="submit" name="submit" id="submit" value="submit">Submit</button>
                            </div>
                        </div>
                    </div>
                    <hr>
                </form>
                <div class="row col-md-12">
                    <h3><u>Lab Data</u></h3>
                </div>
                <div class="row col-md-12">
                    <table id="example2" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="10%">Name of the Lab</th>
                                <th width="18%">Total number of presumptive cases tested in the lab</th>
                                <th width="18%">Total number of cases tested positive in the lab</th>
                                <th width="18%">Total number of cases referred by Saksham sathi in the lab</th>
                                <th width="18%">Total number of cases reached in the lab and tested out of all the cases referred by Saksham Sathis in the lab</th>
                                <th width="18%">Number of cases tested positive referred by Saksham sathi in the lab</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                foreach ($lab_list as $value) 
                                {
                                    ?>
                                    <tr>
                                        <td><?php echo $value->diagnosis_name; ?></td>
                                        <td>
                                            <?php
                                            $start_date = $year.'-'.$month.'-01';
                                            $end_date = date('Y-m-t', strtotime(date("Y").'-'.$month)); 
                                            $presumptivePatient = $this->labdata_model->getPresumptivePatient($value->diagnosis_id, $start_date, $end_date);
                                            $t_pp = 0;
                                            foreach ($presumptivePatient as $pp_val) 
                                            {
                                                $user_all_level_arr = explode(',', $pp_val->user_all_level);
                                                if(in_array($user_id, $user_all_level_arr))
                                                {
                                                    $t_pp++;
                                                }
                                            }
                                            echo $t_pp;
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                            $start_date = $year.'-'.$month.'-01';
                                            $end_date = date('Y-m-t', strtotime(date("Y").'-'.$month)); 
                                            $presumptivePatient = $this->labdata_model->getPresumptivePatient($value->diagnosis_id, $start_date, $end_date);
                                            $t_pp_positive = 0;
                                            foreach ($presumptivePatient as $pp_val) 
                                            {
                                                $user_all_level_arr = explode(',', $pp_val->user_all_level);
                                                if(in_array($user_id, $user_all_level_arr))
                                                {
                                                    if($pp_val->pp_testing_result == 'Positive')
                                                    {
                                                        $t_pp_positive++;
                                                    }
                                                }
                                            }
                                            echo $t_pp_positive;
                                            ?>
                                        </td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <?php
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="clearfix"></div><br/><br/><br/>
            </div>
        </div>
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    $(function() {
        $( "#start_date" ).datepicker({
            dateFormat : 'yy-mm-dd',
            changeMonth : true,
            changeYear : true,           
        });
    });
    function setEndDate(str)
    {
        $( "#end_date" ).datepicker({
            minDate:str,
            dateFormat : 'yy-mm-dd',
            changeMonth : true,
            changeYear : true,           
        });
    }
</script>