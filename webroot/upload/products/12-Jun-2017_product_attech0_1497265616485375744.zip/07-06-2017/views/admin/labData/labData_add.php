<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			<?php echo $welcome->loadPo('Lab Data'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/labData"><?php echo $welcome->loadPo('Lab Data'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Lab Data Add'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Lab Data Add</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/labData" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div>           
                    <input type="hidden" name="addData" id="addData" value="">          
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label>Year<span class="text-danger">*</span></label>
                                <select name="ld_year" id="ld_year" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <?php 
                                    $c_year = date('Y');
                                    $n_year = date('Y',strtotime("-10 year"));
                                    for($i=$c_year; $i>=$n_year; $i--)
                                    {
                                        ?>
                                        <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                                        <?php
                                    }
                                    ?>
                                    
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Month'); ?><span class="text-danger">*</span></label>
                                <select name="ld_month" id="ld_month" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value='01'><?php echo $welcome->loadPo('Janaury'); ?></option>
                                    <option value='02'><?php echo $welcome->loadPo('February'); ?></option>
                                    <option value='03'><?php echo $welcome->loadPo('March'); ?></option>
                                    <option value='04'><?php echo $welcome->loadPo('April'); ?></option>
                                    <option value='05'><?php echo $welcome->loadPo('May'); ?></option>
                                    <option value='06'><?php echo $welcome->loadPo('June'); ?></option>
                                    <option value='07'><?php echo $welcome->loadPo('July'); ?></option>
                                    <option value='08'><?php echo $welcome->loadPo('August'); ?></option>
                                    <option value='09'><?php echo $welcome->loadPo('September'); ?></option>
                                    <option value='10'><?php echo $welcome->loadPo('October'); ?></option>
                                    <option value='11'><?php echo $welcome->loadPo('November'); ?></option>
                                    <option value='12'><?php echo $welcome->loadPo('December'); ?></option>
                                </select>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Lab'); ?><span class="text-danger">*</span></label>
                                <select name="diagnosis_id" id="diagnosis_id" class="form-control selectpicker" data-live-search="true" onchange="getLabDataByMonthYearLabID(this.value);">
                                    <option value="">-- select --</option>
                                    <?php 
                                    foreach ($lab_list as $value) 
                                    {
                                        ?>
                                        <option value="<?php echo $value->diagnosis_id; ?>"><?php echo $value->diagnosis_name; ?></option>
                                        <?php
                                    }
                                    ?>
                                    
                                </select>
                            </div>
                        </div>            
                    </div>
                    <div class="row div_labdata_count" style="display: none;">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Total number of presumptive cases tested in the lab'); ?><span class="text-danger">*</span></label><br><br>
                                <input name="ld_presumptive_tested" class="form-control" min="0" type="number" id="ld_presumptive_tested" value="<?php echo set_value('ld_presumptive_tested'); ?>" />
                                <?php echo form_error('ld_presumptive_tested','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Total number of cases tested positive in the lab'); ?><span class="text-danger">*</span></label><br><br>
                                <input name="ld_presumptive_tested_positive" class="form-control" min="0" type="number" id="ld_presumptive_tested_positive" value="<?php echo set_value('ld_presumptive_tested_positive'); ?>" />
                                <?php echo form_error('ld_presumptive_tested_positive','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Total number of cases referred by Saksham sathi in the lab'); ?><span class="text-danger">*</span></label>
                                <input name="ld_referred_by_saksham_sathi" class="form-control" min="0" type="number" id="ld_referred_by_saksham_sathi" value="<?php echo set_value('ld_referred_by_saksham_sathi'); ?>" />
                                <?php echo form_error('ld_referred_by_saksham_sathi','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                    </div>
                    <div class="row div_labdata_count" style="display: none;">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Total number of cases reached in the lab and tested out of all the cases referred by Saksham Sathis in the lab'); ?><span class="text-danger">*</span></label>
                                <input name="ld_tested_out_referred_by_saksham_sathi" class="form-control" min="0" type="number" id="ld_tested_out_referred_by_saksham_sathi" value="<?php echo set_value('ld_tested_out_referred_by_saksham_sathi'); ?>" />
                                <?php echo form_error('ld_tested_out_referred_by_saksham_sathi','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Number of cases tested positive referred by Saksham sathi in the lab'); ?><span class="text-danger">*</span></label><br><br>
                                <input name="ld_positive_referred_by_saksham_sathi" class="form-control" min="0" type="number" id="ld_positive_referred_by_saksham_sathi" value="<?php echo set_value('ld_positive_referred_by_saksham_sathi'); ?>" />
                                <?php echo form_error('ld_positive_referred_by_saksham_sathi','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                    </div>
                </div>
                <!-- /.box-body -->      
                <div class="box-footer div_labdata_count" style="display: none;">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="AddEdit" ><?php echo $welcome->loadPo('Submit'); ?></button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/diagnosisCenter"><?php echo $welcome->loadPo('Cancel'); ?></a>
                </div>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function  getLabDataByMonthYearLabID(diagnosis_id)
    {
        var ld_year = $('#ld_year').val();
        var ld_month = $('#ld_month').val();
        var str = 'ld_year='+ld_year+'&ld_month='+ld_month+'&diagnosis_id='+diagnosis_id;
        var PAGE = '<?php echo base_url(); ?>admin/labData/getLabDataByMonthYearLabID';
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            dataType: 'json',
            data : str,
            success:function(data)
            {  
                if(data == '1')
                {
                   $('#addData').val('addData');
                   $('.div_labdata_count').show();
                }
                else
                {
                    $('#ld_presumptive_tested').val(data.labdata_res[0].ld_presumptive_tested);
                    $('#ld_presumptive_tested_positive').val(data.labdata_res[0].ld_presumptive_tested_positive);
                    $('#ld_referred_by_saksham_sathi').val(data.labdata_res[0].ld_referred_by_saksham_sathi);
                    $('#ld_tested_out_referred_by_saksham_sathi').val(data.labdata_res[0].ld_tested_out_referred_by_saksham_sathi);
                    $('#ld_positive_referred_by_saksham_sathi').val(data.labdata_res[0].ld_positive_referred_by_saksham_sathi);
                    $('#addData').val(data.labdata_res[0].ld_id);
                    $('.div_labdata_count').show();
                }
            } 
        });
    }
</script>