<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			<?php echo $welcome->loadPo('User'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('User'); ?></li>
        </ol>
    </section>   
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <div class="pull-left">
                    <h3 class="box-title"><?php echo $welcome->loadPo('User Details'); ?></h3>
                </div>
                <div class="pull-right box-tools">
                    <?php
                        foreach($getAllTabAsPerRole as $role)
                        {
                            if($this->uri->segment(2) == $role->controller_name && $role->userAdd == '1')
                            {
                                ?>
                                    <a href="<?php echo base_url();?>admin/user/addUser" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Add New'); ?></a>              
                                <?php
                            }
                        }
                    ?>                    
                </div>
            </div>           
            <!-- /.box-header -->
            <div class="box-body">
                <div>
                    <div id="msg_div">
                        <?php echo $this->session->flashdata('message');?>
                    </div>
                </div>  
                <?php
                if(!empty($role_res))
                {
                    ?>
                    <ul class="nav nav-tabs">
                        <?php
                        $i=1;
                        foreach ($role_res as $r_res) 
                        {
                            ?>
                            <li <?php if($i == '1'){ echo 'class="active"'; } ?>><a data-toggle="tab" href="#role_<?php echo $r_res->role_id; ?>"><?php echo $r_res->role_name; ?></a></li>
                            <?php
                            $i++;
                        }
                        ?>
                    </ul>
                    <div class="tab-content"><br/><br/>
                        <?php
                        $j=1;
                        foreach ($role_res as $r_res) 
                        {
                            $user_result = $this->user_model->getAllUserByRole($r_res->role_id);
                            ?>
                            <div id="role_<?php echo $r_res->role_id; ?>" class="tab-pane <?php if($j=='1'){ echo 'fade in active'; } ?>">
                                <table id="example" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th><?php echo $welcome->loadPo('Role Name'); ?></th>                           
                                            <th><?php echo $welcome->loadPo('Parent Name'); ?></th>
                                            <th><?php echo $welcome->loadPo('Name'); ?></th>
                                            <th><?php echo $welcome->loadPo('Email'); ?></th>
                                            <th><?php echo $welcome->loadPo('Phone'); ?></th>
                                            <th><?php echo $welcome->loadPo('Status'); ?></th>
                                            <th><?php echo $welcome->loadPo('Action'); ?></th>
                                            <th><?php echo $welcome->loadPo('Location'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            if(!empty($user_result))
                                            {
                                                foreach($user_result as $u_res)
                                                {
                                                    $u_parent_id = explode(',', $u_res->user_all_level);
                                                    $user_id = $this->data['session'][0]->user_id;
                                                    if(in_array($user_id , $u_parent_id))
                                                    {
                                                    ?>    
                                                    <tr>
                                                        <td>
                                                            <?php 
                                                            if($r_res->role_id == $u_res->user_role_id)
                                                            {
                                                                echo $r_res->role_name; 
                                                            }
                                                            ?>           
                                                        </td>
                                                        <td>
                                                            <?php
                                                             $parent_u_name = $this->user_model->getParentUserName($u_res->user_parent_user_id);
                                                            if(!empty($parent_u_name))
                                                            {
                                                                echo $parent_u_name[0]->user_name; 
                                                            }
                                                            ?>
                                                        </td>
                                                        <td><?php echo $u_res->user_name; ?></td>
                                                        <td><?php echo $u_res->user_email; ?></td>
                                                        <td><?php echo $u_res->user_phone; ?></td>
                                                        <td  width="10%">
                                                            <?php
                                                                if($u_res->user_status == '1')
                                                                {
                                                                    ?>
                                                                    <span class="text-success"><?php echo $welcome->loadPo('Responsive'); ?></span>
                                                                    <?php
                                                                }
                                                                else
                                                                {
                                                                    ?>
                                                                    <span class="text-danger"><?php echo $welcome->loadPo('Unresponsive'); ?></span>
                                                                    <?php
                                                                }
                                                            ?>
                                                        </td>                                       
                                                        <td width="10%">

                                                            <?php
                                                                foreach($getAllTabAsPerRole as $role)
                                                                {
                                                                    if($this->uri->segment(2) == $role->controller_name && $role->userEdit == '1')
                                                                    {
                                                                        ?>
                                                                            <a href="<?php echo base_url();?>admin/user/addUser/<?php echo $u_res->user_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp;                
                                                                        <?php
                                                                    }
                                                                    if($this->uri->segment(2) == $role->controller_name && $role->userDelete == '1')
                                                                    {
                                                                        ?>
                                                                            <a class="confirm" onclick="return delete_user(<?php echo $u_res->user_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>                                      
                                                                        <?php
                                                                    }
                                                                }
                                                            ?>  
                                                        </td>
                                                        <td width="10%">
                                                            <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" onclick="initialize(<?php echo $u_res->user_let; ?>, <?php echo $u_res->user_long; ?>)">Open Modal</button>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                ?>
                                                <tr>
                                                    <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                                </tr>
                                                <?php
                                            }
                                            
                                        ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                            <?php
                            $j++;
                        }
                        ?>
                    </div>
                    <?php
                }
                else
                {
                    ?>
                        <h1>No Role Available...</h1>
                    <?php
                }
                ?>
               
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function delete_user(user_id)
    {
        bootbox.confirm("Are you sure you want to delete user details",function(confirmed){
            if(confirmed)
            {
                location.href="<?php echo base_url();?>admin/user/delete_user/"+user_id;
            }
        });
    }    
</script>



<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <div id="map">
        
        </div>  
      </div>
    </div>
  </div>
</div>

