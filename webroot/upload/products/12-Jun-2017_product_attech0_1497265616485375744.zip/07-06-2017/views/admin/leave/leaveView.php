<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			<?php echo $welcome->loadPo('Leave'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/leave"><?php echo $welcome->loadPo('Leave'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Leave Update'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
               <!--  <div class="pull-left">
                    <h3 class="box-title">Leave Update</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/leave" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <?php
                foreach ($leave_edit as $value) 
                {
                   ?>
                         <!-- /.box-header -->
                        <div class="box-body">
                            <div>
                                <div id="msg_div">
                                    <?php echo $this->session->flashdata('message');?>
                                </div>
                            </div> 
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Leave Start Date'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="leave_start_date" onchange="setEndDate(this.value)" id="leave_start_date" class="form-control" type="text" value="<?php echo $value->leave_start_date; ?>" />
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Leave End Date'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="leave_end_date" id="leave_end_date" class="form-control" type="text" value="<?php echo $value->leave_end_date; ?>" />
                                    </div>
                                </div>                   
                            </div>                   
                            <div class="row">
                                <div class="form-group col-md-10">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Leave Reason'); ?><span class="text-danger">*</span></label>
                                        <textarea disabled name="leave_reason" rows="5" class="form-control" id="leave_reason" ><?php echo $value->leave_reason; ?></textarea>
                                        <?php echo form_error('leave_reason','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>                       
                            </div>                   
                        </div>
                        <!-- /.box-body -->      
                        <div class="box-footer">
                            <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Edit" ><?php echo $welcome->loadPo('Submit'); ?></button>
                            <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/leave"><?php echo $welcome->loadPo('Cancel'); ?></a>
                        </div>
                   <?php
                }
                ?>

                       
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->

<script type="text/javascript">
    $(function() {
        $( "#leave_start_date" ).datepicker({
            minDate:0,
            dateFormat : 'yy-mm-dd',
            changeMonth : true,
            changeYear : true,           
        });
    });
    function setEndDate(str)
    {
        $( "#leave_end_date" ).datepicker({
            minDate:str,
            dateFormat : 'yy-mm-dd',
            changeMonth : true,
            changeYear : true,           
        });
    }
</script>