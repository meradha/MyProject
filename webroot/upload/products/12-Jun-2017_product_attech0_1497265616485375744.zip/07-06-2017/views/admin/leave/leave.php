<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Leave'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Leave'); ?></li>
        </ol>
    </section>   
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Leave Details</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <?php
                        foreach($getAllTabAsPerRole as $role)
                        {
                            if($this->uri->segment(2) == $role->controller_name && $role->userAdd == '1')
                            {
                                ?>
                                    <a href="<?php echo base_url();?>admin/leave/addLeave" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Add New'); ?></a>              
                                <?php
                            }
                        }
                    ?>                    
                </div>
            </div>           
            <!-- /.box-header -->
            <div class="box-body">
                <div>
                    <div id="msg_div">
                        <?php echo $this->session->flashdata('message');?>
                    </div>
                </div>
                <ul class="nav nav-tabs">
                    <?php
                        $user_role_id = $this->data['session'][0]->user_role_id;
                        if($user_role_id == '1' || $user_role_id == '2')
                        {
                            ?>
                                <li class="active"><a data-toggle="tab" href="#applied_leave"><?php echo $welcome->loadPo('Applied Leaves'); ?></a></li>
                            <?php
                        }
                        elseif($user_role_id == '7')
                        {
                            ?>
                                <li class="active"><a data-toggle="tab" href="#apply_leave"><?php echo $welcome->loadPo('Apply Leaves'); ?></a></li>
                            <?php
                        }
                        else
                        {
                            ?>
                                <!-- <li class="active"><a data-toggle="tab" href="#apply_leave">Apply Leaves</a></li> -->
                                <li class="active"><a data-toggle="tab" href="#applied_leave"><?php echo $welcome->loadPo('Applied Leaves'); ?></a></li>
                            <?php
                        }
                    ?>                    
                </ul>

                <div class="tab-content">
                    <?php
                        $user_role_id = $this->data['session'][0]->user_role_id;
                        if($user_role_id == '1' || $user_role_id == '2')
                        {
                            ?>
                                <div id="applied_leave" class="tab-pane fade in active">
                                   <table id="example2" class="table table-bordered table-striped"><br>
                                        <thead>
                                            <tr>
                                                <th><?php echo $welcome->loadPo('Leave Start Date'); ?></th>
                                                <th><?php echo $welcome->loadPo('Leave End Date'); ?></th>
                                                <th><?php echo $welcome->loadPo('Leave Reason'); ?></th>
                                                <th><?php echo $welcome->loadPo('Applied By'); ?></th>
                                                <th><?php echo $welcome->loadPo('Approved Status'); ?></th>
                                                <!-- <th>Action</th> -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if(!empty($applied_leave_res))
                                                {
                                                    foreach($applied_leave_res as $res)
                                                    {
                                                        $user_id = $this->data['session'][0]->user_id;  
                                                        $all_level = explode(',',$res->user_all_level);
                                                        if(in_array($user_id, $all_level))
                                                        {
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $res->leave_start_date; ?></td>
                                                                <td><?php echo $res->leave_end_date; ?></td>
                                                                <td><?php echo $res->leave_reason; ?></td>
                                                                <td><?php echo $res->user_name; ?></td>
                                                                <td  width="10%">
                                                                    <?php
                                                                        if($res->leave_approved_by == $user_id)
                                                                        {
                                                                           if($res->leave_approved_status == '0')
                                                                            {
                                                                                ?>
                                                                                <a href="<?php echo base_url();?>admin/leave/approveLeave/<?php echo $res->leave_id; ?>" title="Send Task Report"><i class="fa fa-plus-square fa-2x" aria-hidden="true"></i></a>
                                                                                <?php
                                                                            }
                                                                            else
                                                                            {
                                                                                 ?>
                                                                                <span class="text-success"><?php echo $welcome->loadPo('Approved'); ?></span>
                                                                                <?php
                                                                            }
                                                                        }
                                                                        else
                                                                        {

                                                                        }
                                                                    ?>
                                                                    &nbsp;&nbsp;
                                                                    <a href="<?php echo base_url();?>admin/leave/leaveView/<?php echo $res->leave_id; ?>"><i class="fa fa-eye fa-2x "></i></a> 
                                                                </td>
                                                            </tr>
                                                            <?php
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <tr>
                                                        <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                                    </tr>
                                                    <?php
                                                }
                                                
                                            ?>                                           
                                        </tbody>
                                    </table>
                                </div>
                            <?php
                        }
                        elseif($user_role_id == '7')
                        {
                            ?>
                                <div id="apply_leave" class="tab-pane fade in active"><br>
                                    <table id="example2" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th><?php echo $welcome->loadPo('Leave Start Date'); ?></th>
                                                <th><?php echo $welcome->loadPo('Leave End Date'); ?></th>
                                                <th><?php echo $welcome->loadPo('Leave Reason'); ?></th>
                                                <th><?php echo $welcome->loadPo('Approve By'); ?></th>
                                                <th><?php echo $welcome->loadPo('Approved Status'); ?></th>
                                                <th><?php echo $welcome->loadPo('Action'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if(!empty($apply_leave_res))
                                                {
                                                    foreach($apply_leave_res as $res)
                                                    {
                                                        ?>
                                                        <tr>
                                                            <td><?php echo $res->leave_start_date; ?></td>
                                                                <td><?php echo $res->leave_end_date; ?></td>
                                                            <td><?php echo $res->leave_reason; ?></td>
                                                            <td><?php echo $res->user_name; ?></td>
                                                            <td  width="10%">
                                                                <?php
                                                                    if($res->leave_approved_status == '1')
                                                                    {
                                                                        ?>
                                                                        <span class="text-success"><?php echo $welcome->loadPo('Approved'); ?></span>
                                                                        <?php
                                                                    }
                                                                    elseif($res->leave_approved_status == '0')
                                                                    {
                                                                        ?>
                                                                        <span class="text-primary"><?php echo $welcome->loadPo('Pending'); ?></span>
                                                                        <?php
                                                                    }
                                                                    else
                                                                    {
                                                                         ?>
                                                                        <span class="text-danger"><?php echo $welcome->loadPo('Cancel'); ?></span>
                                                                        <?php
                                                                    }
                                                                ?>
                                                            </td>
                                                            <td width="20%">
                                                                <?php
                                                                    if($res->leave_approved_status == '0')
                                                                    {
                                                                        foreach($getAllTabAsPerRole as $role)
                                                                        {
                                                                            if($this->uri->segment(2) == $role->controller_name && $role->userEdit == '1')
                                                                            {
                                                                                ?>
                                                                                    <a href="<?php echo base_url();?>admin/leave/addLeave/<?php echo $res->leave_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp;                
                                                                                <?php
                                                                            }
                                                                            if($this->uri->segment(2) == $role->controller_name && $role->userDelete == '1')
                                                                            {
                                                                                ?>
                                                                                    <a class="confirm" onclick="return delete_leave(<?php echo $res->leave_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>                                      
                                                                                <?php
                                                                            }
                                                                        }
                                                                    }
                                                                ?> &nbsp;&nbsp;
                                                                <a href="<?php echo base_url();?>admin/leave/leaveView/<?php echo $res->leave_id; ?>"><i class="fa fa-eye fa-2x "></i></a> 
                                                            </td>
                                                        </tr>
                                                        <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <tr>
                                                        <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                                    </tr>
                                                    <?php
                                                }
                                                
                                            ?>
                                           
                                        </tbody>
                                    </table>
                                </div>
                            <?php
                        }
                        else
                        {
                            ?>
                                <!-- <div id="apply_leave" class="tab-pane fade in active"><br>
                                    <table id="example2" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Leave Start Date</th>
                                                <th>Leave End Date</th>
                                                <th>Leave Reason</th>
                                                <th>Approved By</th>
                                                <th>Approved Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if(!empty($apply_leave_res))
                                                {
                                                    foreach($apply_leave_res as $res)
                                                    {
                                                        ?>
                                                        <tr>
                                                            <td><?php echo $res->leave_start_date; ?></td>
                                                                <td><?php echo $res->leave_end_date; ?></td>
                                                            <td><?php echo $res->leave_reason; ?></td>
                                                            <td><?php echo $res->user_name; ?></td>
                                                            <td  width="10%">
                                                                <?php
                                                                    if($res->leave_approved_status == '1')
                                                                    {
                                                                        ?>
                                                                        <span class="text-success">Approved</span>
                                                                        <?php
                                                                    }
                                                                    elseif($res->leave_approved_status == '0')
                                                                    {
                                                                        ?>
                                                                        <span class="text-primary">Pending</span>
                                                                        <?php
                                                                    }
                                                                    else
                                                                    {
                                                                         ?>
                                                                        <span class="text-danger">Cancel</span>
                                                                        <?php
                                                                    }
                                                                ?>
                                                            </td>
                                                            <td width="20%">
                                                                <?php
                                                                    if($res->leave_approved_status == '0')
                                                                    {
                                                                        foreach($getAllTabAsPerRole as $role)
                                                                        {
                                                                            if($this->uri->segment(2) == $role->controller_name && $role->userEdit == '1')
                                                                            {
                                                                                ?>
                                                                                    <a href="<?php echo base_url();?>admin/leave/addLeave/<?php echo $res->leave_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp;                
                                                                                <?php
                                                                            }
                                                                            if($this->uri->segment(2) == $role->controller_name && $role->userDelete == '1')
                                                                            {
                                                                                ?>
                                                                                    <a class="confirm" onclick="return delete_leave(<?php echo $res->leave_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>                                      
                                                                                <?php
                                                                            }
                                                                        }
                                                                    }
                                                                ?>  
                                                            </td>
                                                        </tr>
                                                        <?php
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <tr>
                                                        <td colspan="10">No records found...</td>
                                                    </tr>
                                                    <?php
                                                }
                                                
                                            ?>
                                           
                                        </tbody>
                                    </table>
                                </div> -->
                                <div id="applied_leave" class="tab-pane fade in active">
                                   <table id="example2" class="table table-bordered table-striped"><br>
                                        <thead>
                                            <tr>
                                                <th><?php echo $welcome->loadPo('Leave Start Date'); ?></th>
                                                <th><?php echo $welcome->loadPo('Leave End Date'); ?></th>
                                                <th><?php echo $welcome->loadPo('Leave Reason'); ?></th>
                                                <th><?php echo $welcome->loadPo('Applied By'); ?></th>
                                                <th><?php echo $welcome->loadPo('Approved Status'); ?></th>
                                                <th><?php echo $welcome->loadPo('Action'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if(!empty($applied_leave_res))
                                                {
                                                    foreach($applied_leave_res as $res)
                                                    {
                                                        $user_id = $this->data['session'][0]->user_id;  
                                                        $all_level = explode(',',$res->user_all_level);
                                                        if(in_array($user_id, $all_level))
                                                        {
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $res->leave_start_date; ?></td>
                                                                <td><?php echo $res->leave_end_date; ?></td>
                                                                <td><?php echo $res->leave_reason; ?></td>
                                                                <td><?php echo $res->user_name; ?></td>
                                                                <td  width="10%">
                                                                    <?php
                                                                        if($res->leave_approved_by == $user_id)
                                                                        {
                                                                           if($res->leave_approved_status == '0')
                                                                            {
                                                                                ?>
                                                                                <a href="<?php echo base_url();?>admin/leave/approveLeave/<?php echo $res->leave_id; ?>" ><i class="fa fa-plus-square fa-2x" aria-hidden="true"></i></a>
                                                                                <?php
                                                                            }
                                                                            else
                                                                            {
                                                                                 ?>
                                                                                <span class="text-success"><?php echo $welcome->loadPo('Approved'); ?></span>
                                                                                <?php
                                                                            }
                                                                        }
                                                                        else
                                                                        {

                                                                        }
                                                                    ?>
                                                                </td>
                                                                <td>
                                                                    &nbsp;&nbsp;
                                                                    <a href="<?php echo base_url();?>admin/leave/leaveView/<?php echo $res->leave_id; ?>"><i class="fa fa-eye fa-2x "></i></a> 
                                                                </td>
                                                                <!-- <td width="20%">
                                                                    <?php
                                                                        if($res->leave_approved_status == '0')
                                                                        {
                                                                            foreach($getAllTabAsPerRole as $role)
                                                                            {
                                                                                if($this->uri->segment(2) == $role->controller_name && $role->userEdit == '1')
                                                                                {
                                                                                    ?>
                                                                                        <a href="<?php echo base_url();?>admin/leave/addLeave/<?php echo $res->leave_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp;                
                                                                                    <?php
                                                                                }
                                                                                if($this->uri->segment(2) == $role->controller_name && $role->userDelete == '1')
                                                                                {
                                                                                    ?>
                                                                                        <a class="confirm" onclick="return delete_leave(<?php echo $res->leave_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>                                      
                                                                                    <?php
                                                                                }
                                                                            }
                                                                        }
                                                                    ?>  
                                                                </td> -->
                                                            </tr>
                                                            <?php
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    ?>
                                                    <tr>
                                                        <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                                    </tr>
                                                    <?php
                                                }
                                                
                                            ?>                                           
                                        </tbody>
                                    </table>
                                </div>
                            <?php
                        }
                    ?>   
                </div>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function delete_leave(leave_id)
    {
        bootbox.confirm("Are you sure you want to delete leave details",function(confirmed){
            if(confirmed)
            {
                location.href="<?php echo base_url();?>admin/leave/delete_leave/"+leave_id;
            }
        });
    }    
</script>>