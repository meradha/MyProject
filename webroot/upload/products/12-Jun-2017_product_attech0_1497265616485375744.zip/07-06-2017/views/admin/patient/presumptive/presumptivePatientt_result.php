<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			<?php echo $welcome->loadPo('Presumptive Referrals'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/presumptivePatient"><?php echo $welcome->loadPo('Presumptive Referrals'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Presumptive Referrals Report'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
               <!--  <div class="pull-left">
                    <h3 class="box-title">Presumptive Referrals Report</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/presumptivePatient" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div> 
                    <?php
                    foreach ($presumptivePatient_details as $value) 
                    {
                        ?>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Date of Referral'); ?></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_referral_date; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Type of Referral'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_referral_type; ?>">
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Facility where the presumptive case is referred'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->diagnosis_name; ?>">
                                    </div>
                                </div>                       
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If Self referral, then community activity through which case is referred'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_community_activity_name; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Date of activity'); ?><span class="text-danger">*</span></label><br><br>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_date_of_activity; ?>">
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If Community referral, then name of the stakeholder referring the case'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_stakeholder_name; ?>">
                                    </div>
                                </div>                       
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Name of the presumptive case referred'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_patient_name; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Age'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_age; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Gender'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_sex; ?>">
                                    </div>
                                </div> 
                            </div>
                            <div class="row">                         
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Country'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->country_name; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('State'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->state_name; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('City'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_city; ?>">
                                    </div>
                                </div>   
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Address'); ?><span class="text-danger">*</span></label>
                                        <textarea disabled class="form-control"><?php echo $value->pp_address; ?></textarea>
                                    </div>
                                </div>     
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Landmark'); ?><span class="text-danger">*</span></label>
                                        <textarea disabled class="form-control"><?php echo $value->pp_landmark; ?></textarea>
                                    </div>
                                </div>                        
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Postal Code'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_postal_code; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Phone'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_phone_no; ?>">
                                    </div>
                                </div>   
                            </div>
                            <!--****************************************************************************-->
                            <div class="row">                       
                                <div class="form-group col-md-5">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Has the patient reached to the referred facility'); ?><span class="text-danger">*</span></label>
                                        <select class="form-control" name="pp_reached_status" id="pp_reached_status"">
                                            <option <?php if($value->pp_reached_status == ''){ echo "selected"; } ?> value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                            <option <?php if($value->pp_reached_status == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>    
                                            <option <?php if($value->pp_reached_status == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>  
                                        </select>
                                        <?php echo form_error('pp_reached_status','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                                <div class="form-group col-md-5" id="pp_testing_status_div" <?php if($value->pp_reached_status == 'Yes'){ echo 'style="display: block;"'; }else{ echo 'style="display: none;"'; } ?> >
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If patient has reached, then whether sputum testing done'); ?> <span class="text-danger">*</span></label>
                                        <select class="form-control" name="pp_testing_status" id="pp_testing_status"">
                                            <option <?php if($value->pp_testing_status == ''){ echo "selected"; } ?> value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>    
                                            <option <?php if($value->pp_testing_status == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>    
                                            <option <?php if($value->pp_testing_status == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>

                                        </select>
                                        <?php echo form_error('pp_reached_status','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                            </div>
                            <div class="row" id="testing_result_div" <?php if($value->pp_testing_status == 'Yes'){ echo 'style="display: block;"'; }else{ echo 'style="display: none"'; } ?> >
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If the sputum testing done, then date of the test'); ?><span class="text-danger">*</span></label>
                                        <div class='input-group'>
                                            <input type="text" class="form-control date_val" name="pp_testing_date" id="pp_testing_date" value="<?php echo set_value('pp_testing_date'); ?>">
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                        <?php echo form_error('pp_testing_date','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Microscopy test number/ ID form the referred'); ?><span class="text-danger">*</span></label>
                                        <input name="pp_testing_number" class="form-control" type="text" id="pp_testing_number" value="<?php echo $value->pp_testing_number; ?>" />
                                        <?php echo form_error('pp_testing_number','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Result of the TB testing'); ?><span class="text-danger">*</span></label>
                                        <select class="form-control" name="pp_testing_result" id="pp_testing_result"">
                                            <option <?php if($value->pp_testing_result == ''){ echo "selected"; } ?> value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                            <option <?php if($value->pp_testing_result == 'Not tested'){ echo "selected"; } ?> value="Not tested"><?php echo $welcome->loadPo('Not tested'); ?></option>
                                            <option <?php if($value->pp_testing_result == 'Positive'){ echo "selected"; } ?> value="Positive"><?php echo $welcome->loadPo('Positive'); ?></option>
                                            <option <?php if($value->pp_testing_result == 'Negative'){ echo "selected"; } ?> value="Negative"><?php echo $welcome->loadPo('Negative'); ?></option>         
                                        </select>
                                        <?php echo form_error('pp_testing_result','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                            </div>
                            <div class="row" id="drug_resistance_status_div" <?php if($value->pp_testing_result == 'Positive'){ echo 'style="display: block;"'; }else{ echo 'style="display: none"'; } ?> >
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If patient is tested positive, then date of diagnosis'); ?><span class="text-danger">*</span></label>
                                        <div class='input-group'>
                                            <input type="text" class="form-control date_val" name="pp_diagnosis_date" id="pp_diagnosis_date" value="<?php echo set_value('pp_diagnosis_date'); ?>">
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                        <?php echo form_error('pp_diagnosis_date','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('if tested positive then drug resistance status'); ?><span class="text-danger">*</span></label>
                                        <select class="form-control" name="pp_drug_resistance_status" id="pp_drug_resistance_status"">
                                            <option <?php if($value->pp_drug_resistance_status == ''){ echo "selected"; } ?> value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>          
                                            <option <?php if($value->pp_drug_resistance_status == 'Drug Sensitive'){ echo "selected"; } ?> value="Drug Sensitive"><?php echo $welcome->loadPo('Drug Sensitive'); ?></option>
                                            <option <?php if($value->pp_drug_resistance_status == 'Drug Resistant'){ echo "selected"; } ?> value="Drug Resistant"><?php echo $welcome->loadPo('Drug Resistant'); ?></option>
                                            </select>
                                        <?php echo form_error('pp_drug_resistance_status','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                                <div class="form-group col-md-4" id="pp_drug_sensitive_type_div" <?php if($value->pp_drug_resistance_status == 'Drug Sensitive'){ echo 'style="display: block;"'; }else{ echo 'style="display: none"'; } ?> >
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Drug sensitive type'); ?><span class="text-danger">*</span></label>
                                        <select class="form-control" name="pp_drug_sensitive_type" id="pp_drug_sensitive_type"">
                                            <option  <?php if($value->pp_drug_sensitive_type == ''){ echo 'selected'; } ?> value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>  
                                            <option <?php if($value->pp_drug_sensitive_type == 'CAT-1'){ echo 'selected'; } ?> value="CAT-1"><?php echo $welcome->loadPo('CAT-1'); ?></option>
                                            <option <?php if($value->pp_drug_sensitive_type == 'CAT-2'){ echo 'selected'; } ?> value="CAT-2"><?php echo $welcome->loadPo('CAT-2'); ?></option>
                                            <option <?php if($value->pp_drug_sensitive_type == 'Other'){ echo 'selected'; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option>
                                        </select><br>
                                        <input style="<?php if($value->pp_drug_sensitive_type == 'Other'){ echo 'display: block'; }else{ echo 'display: none';  } ?>" type="text" name="pp_drug_sensitive_type_other" id="pp_drug_sensitive_type_other" class="form-control" value="<?php echo $value->pp_drug_sensitive_type_other; ?>">
                                        <?php echo form_error('pp_drug_sensitive_type','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                                <div class="form-group col-md-4" id="drug_resistance_type_div" <?php if($value->pp_drug_resistance_status == 'Drug Resistant'){ echo 'style="display: block;"'; }else{ echo 'style="display: none"'; } ?> >
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Drug resistant type'); ?><span class="text-danger">*</span></label>
                                        <select class="form-control" name="pp_drug_resistance_type" id="pp_drug_resistance_type"">
                                            <option <?php if($value->pp_drug_resistance_type == ''){ echo 'selected'; } ?> value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                            <option <?php if($value->pp_drug_resistance_type == 'MDR'){ echo 'selected'; } ?> value="MDR"><?php echo $welcome->loadPo('MDR'); ?></option>
                                            <option <?php if($value->pp_drug_resistance_type == 'XDR'){ echo 'selected'; } ?> value="XDR"><?php echo $welcome->loadPo('XDR'); ?></option>   
                                            <option <?php if($value->pp_drug_resistance_type == 'TDR'){ echo 'selected'; } ?> value="TDR"><?php echo $welcome->loadPo('TDR'); ?></option>
                                            <option <?php if($value->pp_drug_resistance_type == 'Other'){ echo 'selected'; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option>
                                        </select>
                                        <br>
                                        <input style="<?php if($value->pp_drug_resistance_type == 'Other'){ echo 'display: block'; }else{ echo 'display: none';  } ?> " type="text" name="pp_drug_resistance_type_other" id="pp_drug_resistance_type_other" class="form-control" value="<?php echo $value->pp_drug_sensitive_type_other; ?>">
                                        <?php echo form_error('pp_drug_resistance_type','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                            </div>
                            <div class="row" id="pp_testing_reason_div" <?php if($value->pp_testing_status == 'No'){ echo 'style="display: block;"'; }else{ echo 'style="display: none"'; } ?> >
                                <div class="form-group col-md-8">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If Not tested then, Reason for test not conducted'); ?> <span class="text-danger">*</span></label>
                                        <textarea name="pp_testing_reason" class="form-control" id="pp_testing_reason" ><?php echo $value->pp_testing_reason; ?></textarea>
                                        <?php echo form_error('pp_testing_reason','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>       
                            </div>     
                            <div class="row" id="pp_comments_div" <?php if($value->pp_drug_resistance_status == 'Drug Resistant'){ echo 'style="display: block;"'; }else{ echo 'style="display: none"'; } ?> >
                                <div class="form-group col-md-8">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Comments (add comment as referred to saksham pravaah if patient diagnosed drug resistant TB)'); ?><span class="text-danger">*</span></label>
                                        <textarea name="pp_comments" class="form-control" id="pp_comments" ><?php echo $value->pp_comments; ?></textarea>
                                        <?php echo form_error('pp_comments','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>       
                            </div>                              
                        <?php
                    }
                    ?>      
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="EditResult" ><?php echo $welcome->loadPo('Submit'); ?></button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/presumptivePatient"><?php echo $welcome->loadPo('Cancel'); ?></a>
                </div>
            </form>
        </div><br><br>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->

<script type="text/javascript">

    $(function (){       
        $('#pp_testing_date').datetimepicker({
            minDate: new Date(),
            format: 'Y-M-D'
        });  
        $('#pp_diagnosis_date').datetimepicker({
            minDate: new Date(),
            format: 'Y-M-D'
        });  
    });
    $('#pp_reached_status').on('change', function(){
        var reached_status = $('#pp_reached_status').val();
        if(reached_status == 'Yes')
        {
            $('#pp_testing_status_div').show();
        }
        else
        {
            $('#pp_testing_status_div').hide();
            $('#testing_result_div').hide();
            $('#drug_resistance_status_div').hide();
        }
    });

    $('#pp_testing_status').on('change', function(){
        var testing_status = $('#pp_testing_status').val();
        if(testing_status == 'Yes')
        {
            $('#testing_result_div').show();
            //$('#pp_comments_div').hide();
            $('#pp_testing_reason_div').hide();
        }
        else
        {
            $('#testing_result_div').hide();            
            //$('#pp_comments_div').show();
            $('#pp_testing_reason_div').show();
        }
    });

    $('#pp_testing_result').on('change', function(){
        var testing_result = $('#pp_testing_result').val();
        if(testing_result == 'Positive')
        {
            $('#drug_resistance_status_div').show();            
        }
        else
        {
            $('#drug_resistance_status_div').hide(); 
            $('#pp_comments_div').hide();           
        }
    });

    $('#pp_drug_resistance_status').on('change', function(){
        var pp_drug_resistance_status = $('#pp_drug_resistance_status').val();
        if(pp_drug_resistance_status == 'Drug Sensitive')
        {
            $('#pp_drug_sensitive_type_div').show();
            $('#drug_resistance_type_div').hide();
            $('#pp_comments_div').hide();
        }
        else if(pp_drug_resistance_status == 'Drug Resistant')
        {
            $('#drug_resistance_type_div').show();
            $('#pp_drug_sensitive_type_div').hide();
            $('#pp_comments_div').show();
        }
    });

    $('#pp_drug_sensitive_type').on('change', function(){
        var pp_drug_sensitive_type = $('#pp_drug_sensitive_type').val();
        if(pp_drug_sensitive_type == 'Other')
        {
            $('#pp_drug_sensitive_type_other').show();
        }
        else
        {
            $('#pp_drug_sensitive_type_other').hide();
        }
    });

    $('#pp_drug_resistance_type').on('change', function(){
        var pp_drug_resistance_type = $('#pp_drug_resistance_type').val();
        if(pp_drug_resistance_type == 'Other')
        {
            $('#pp_drug_resistance_type_other').show();
        }
        else
        {
            $('#pp_drug_resistance_type_other').hide();
        }
    });
</script>