<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			<?php echo $welcome->loadPo('Presumptive Referrals'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/presumptivePatient"><?php echo $welcome->loadPo('Presumptive Referrals'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Presumptive Referrals Report'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Presumptive Referrals Report</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/presumptivePatient" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div> 
                    <?php
                    foreach ($presumptivePatient_details as $value) 
                    {
                        ?>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Name of the presumptive'); ?><span class="text-danger">*</span></label>
                                    <input type="text" disabled class="form-control" value="<?php echo $value->pp_patient_name; ?>">
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Age'); ?><span class="text-danger">*</span></label>
                                    <input type="text" disabled class="form-control" value="<?php echo $value->pp_age; ?>">
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Gender'); ?><span class="text-danger">*</span></label>
                                    <input type="text" disabled class="form-control" value="<?php echo $value->pp_sex; ?>">
                                </div>
                            </div> 
                        </div>
                        <div class="row">                         
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Country'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->country_name; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('State'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->state_name; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('City'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_city; ?>">
                                    </div>
                                </div>   
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Address'); ?><span class="text-danger">*</span></label>
                                        <textarea disabled class="form-control"><?php echo $value->pp_address; ?></textarea>
                                    </div>
                                </div>                        
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Postal Code'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_postal_code; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Phone'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_phone_no; ?>">
                                    </div>
                                </div>   
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Landmark'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_landmark; ?>">
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Patient identified by Saksham jan urja'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_referral_type; ?>">
                                    </div>
                                </div> 
                                <div class="form-group col-md-4" >
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Drug resistance type'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_drug_resistance_type; ?>">
                                    </div>
                                </div> 
                            </div>
                            
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Diagnosis Name'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->diagnosis_name; ?>">
                                    </div>
                                </div>  
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Patient lab number'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_testing_number; ?>">
                                    </div>
                                </div>   
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Date of lab test'); ?></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_referral_date; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row"> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Date of diagnosis'); ?></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_referral_date; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Patient Nikshay ID number'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_patient_nikshay_id; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Date of linkage to Saksham counsellor'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_date_of_saksham_counsellor; ?>"> 
                                    </div>
                                </div>              
                            </div>  
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Health post area of patient'); ?> <span class="text-danger">*</span></label>
                                        <select disabled name="pp_helth_post_area" id="pp_helth_post_area" class="form-control">
                                           
                                            <?php
                                            foreach ($healthpostarea_list as $helthpost_res) 
                                            {
                                                ?>
                                                <option <?php if($value->pp_helth_post_area == $helthpost_res->helthpostarea_id){ echo "selected"; } ?> value="<?php echo $helthpost_res->helthpostarea_id; ?>"><?php echo $helthpost_res->helthpostarea_name; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>                        
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Saksham Pravah'); ?><span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->sp_name; ?>">
                                    </div>
                                </div>                             
                            </div>                      
                        <?php
                    }
                    ?>      
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                  <!--   <button class="btn btn-success btn-sm" type="submit" name="Submit" value="sendSakshamPravah" >Submit</button> -->
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/presumptivePatient"><?php echo $welcome->loadPo('Cancel'); ?></a>
                </div>
            </form>
        </div><br><br>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->

<script type="text/javascript">
     $(function (){       
        $('#pp_date_of_saksham_counsellor').datetimepicker({
            minDate: new Date(),
            format: 'Y-M-D'
        });    
    });


    $('#pp_reached_status').on('change', function(){
        var reached_status = $('#pp_reached_status').val();
        if(reached_status == 'Yes')
        {
            $('#pp_testing_status_div').show();
            $('#pp_testing_reason_div').hide();
        }
        else
        {
            $('#pp_testing_status_div').hide();
            $('#testing_result_div').hide();
            $('#pp_testing_reason_div').show();
            $('#drug_resistance_status_div').hide();
        }
    });

    $('#pp_testing_status').on('change', function(){
        var testing_status = $('#pp_testing_status').val();
        if(testing_status == 'Yes')
        {
            $('#testing_result_div').show();
            $('#pp_comments_div').hide();
        }
        else
        {
            $('#testing_result_div').hide();            
            $('#pp_comments_div').show();
        }
    });

    $('#pp_testing_result').on('change', function(){
        var testing_result = $('#pp_testing_result').val();
        if(testing_result == 'Positive')
        {
            $('#drug_resistance_status_div').show();            
        }
        else
        {
            $('#drug_resistance_status_div').hide(); 
            $('#pp_comments_div').hide();           
        }
    });

    $('#pp_drug_resistance_status').on('change', function(){
        var pp_drug_resistance_status = $('#pp_drug_resistance_status').val();
        if(pp_drug_resistance_status == 'Drug Sensitive')
        {
            $('#pp_drug_sensitive_type_div').show();
            $('#drug_resistance_type_div').hide();
            $('#pp_comments_div').hide();
        }
        else if(pp_drug_resistance_status == 'Drug Resistant')
        {
            $('#drug_resistance_type_div').show();
            $('#pp_drug_sensitive_type_div').hide();
            $('#pp_comments_div').show();
        }
    });
</script>














<!--
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label>Date of Referral</label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->pp_referral_date; ?>">
                                    </div>
                                </div>
                                
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label>Presumptive referred<span class="text-danger">*</span></label>
                                        <input type="text" disabled class="form-control" value="<?php echo $value->diagnosis_name; ?>">
                                    </div>
                                </div>                       
                            </div>
                            
                            <div class="row"> 
                                <?php
                                if($value->pp_reached_status)
                                {
                                    ?>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label>Has the patient reached to the referred facility<span class="text-danger">*</span></label>
                                            <input type="text" disabled class="form-control" value="<?php echo $value->pp_reached_status; ?>">
                                        </div>
                                    </div> 
                                    <?php
                                }
                                ?> 
                                <?php
                                if($value->pp_testing_status)
                                {
                                    ?>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label>Sputum testing done<span class="text-danger">*</span></label>
                                            <input type="text" disabled class="form-control" value="<?php echo $value->pp_testing_status; ?>">
                                        </div>
                                    </div> 
                                    <?php
                                }
                                ?>
                                <?php
                                if($value->pp_testing_number)
                                {
                                    ?>
                                     <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label>Microscopy test number/ ID form the referred<span class="text-danger">*</span></label>
                                            <input type="text" disabled class="form-control" value="<?php echo $value->pp_testing_number; ?>">
                                        </div>
                                    </div> 
                                    <?php
                                }
                                ?>
                                <?php
                                if($value->pp_testing_result)
                                {
                                    ?>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label>Result of the TB testing<span class="text-danger">*</span></label>
                                            <input type="text" disabled class="form-control" value="<?php echo $value->pp_testing_result; ?>">
                                        </div>
                                    </div> 
                                    <?php
                                }
                                ?>
                                <?php
                                if($value->pp_drug_resistance_status)
                                {
                                    ?>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label>Drug resistance status<span class="text-danger">*</span></label>
                                            <input type="text" disabled class="form-control" value="<?php echo $value->pp_drug_resistance_status; ?>">
                                        </div>
                                    </div> 
                                    <?php
                                }
                                ?>
                                <?php
                                if($value->pp_drug_sensitive_type)
                                {
                                    ?>
                                     <div class="form-group col-md-4" >
                                        <div class="input text">
                                            <label>Drug sensitive type<span class="text-danger">*</span></label>
                                            <input type="text" disabled class="form-control" value="<?php echo $value->pp_drug_sensitive_type; ?>">
                                        </div>
                                    </div> 
                                    <?php
                                }
                                ?>
                                
                            </div>
                            <div class="row" >
                                <?php
                                if($value->pp_testing_reason)
                                {
                                    ?>                                    
                                    <div class="form-group col-md-6">
                                        <div class="input text">
                                            <label>Reason for test not conducted <span class="text-danger">*</span></label>
                                            <textarea disabled name="pp_testing_reason" class="form-control" id="pp_testing_reason" ><?php echo $value->pp_testing_reason; ?></textarea>
                                        </div>
                                    </div> 
                                    <?php
                                }
                                ?>      
                            </div>     
                            <div class="row">
                                <?php
                                if($value->pp_comments)
                                {
                                    ?>
                                    <div class="form-group col-md-6">
                                        <div class="input text">
                                            <label>Comments <span class="text-danger">*</span></label>
                                            <textarea disabled name="pp_comments" class="form-control" id="pp_comments" ><?php echo $value->pp_comments; ?></textarea>
                                        </div>
                                    </div>  
                                    <?php
                                }
                                ?>
                                 
                            </div> 
                            
-->