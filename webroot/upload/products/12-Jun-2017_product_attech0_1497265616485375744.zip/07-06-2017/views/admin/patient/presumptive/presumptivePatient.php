<?php
$user_id = $this->data['session'][0]->user_id;
$user_role_id = $this->data['session'][0]->user_role_id;
?>
<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Presumptive Referrals'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Presumptive Referrals'); ?> </li>
        </ol>
    </section>   
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
               <!--  <div class="pull-left">
                    <h3 class="box-title">Presumptive Referrals Details</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <?php
                        foreach($getAllTabAsPerRole as $role)
                        {
                            if($this->uri->segment(2) == $role->controller_name && $role->userAdd == '1')
                            {
                                ?>
                                    <a href="<?php echo base_url();?>admin/presumptivePatient/addPresumptivePatient" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Add New'); ?></a>              
                                <?php
                            }
                        }
                    ?>                    
                </div>
            </div>           
            <!-- /.box-header -->
            <div class="box-body">
                <div>
                    <div id="msg_div">
                        <?php echo $this->session->flashdata('message');?>
                    </div>
                </div>
                <table id="example2" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <?php
                            if($user_role_id != '7')
                            {
                                ?>
                                    <th><?php echo $welcome->loadPo('CSW Name'); ?></th>
                                <?php
                            }
                            ?>
                            <th><?php echo $welcome->loadPo('Date of Referral'); ?></th>
                            <th><?php echo $welcome->loadPo('Type of Referral'); ?></th>
                            <th><?php echo $welcome->loadPo('Patient Name'); ?></th>
                            <th><?php echo $welcome->loadPo('Phone Number'); ?></th>
                            <th><?php echo $welcome->loadPo('Refered To'); ?></th>
                            <th><?php echo $welcome->loadPo('Drug Resistance status'); ?></th>
                            <th><?php echo $welcome->loadPo('Testing Status'); ?></th>
                            <?php
                                if($user_role_id == '7')
                                {
                                    ?>
                                    <th><?php echo $welcome->loadPo('Report'); ?></th>
                                    <th><?php echo $welcome->loadPo('Consent'); ?></th>
                                    <th><?php echo $welcome->loadPo('Forward'); ?></th>
                                    <th><?php echo $welcome->loadPo('Action'); ?></th>
                                    <?php
                                }
                                else
                                {
                                    ?>
                                    <th><?php echo $welcome->loadPo('Testing Result'); ?></th>
                                    <th><?php echo $welcome->loadPo('Action'); ?></th>
                                    <?php
                                }
                            ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if(!empty($presumptivePatient_res))
                            {
                                foreach($presumptivePatient_res as $res)
                                {                                    
                                    $u_level = explode(',', $res->user_all_level);
                                    if(in_array($user_id, $u_level))
                                    {
                                        ?>
                                        <tr>
                                            <?php
                                            if($user_role_id != '7')
                                            {
                                                ?>
                                                    <td><?php echo $res->added_by; ?></td>
                                                <?php
                                            }
                                            ?>
                                            <td><?php echo $res->pp_referral_date; ?></td>
                                            <td><?php echo $res->pp_referral_type; ?></td>
                                            <td><?php echo $res->pp_patient_name; ?></td>
                                            <td><?php echo $res->pp_phone_no; ?></td>
                                            <td><?php echo $res->diagnosis_name; ?></td>
                                            <td><?php echo $res->pp_drug_resistance_status; ?></td>
                                            <td><?php echo $res->pp_testing_status; ?></td>
                                            <?php
                                            if($user_role_id == 7)
                                            {
                                                ?>
                                                <td>
                                                <?php
                                                    if($res->pp_report_status == 1)
                                                    {
                                                        if($res->pp_testing_result == 'Positive')
                                                        {
                                                            ?>
                                                            <span class="text-success"><?php echo $welcome->loadPo('Positive'); ?></span>
                                                            <?php
                                                        }
                                                        else
                                                        {
                                                            ?>
                                                            <span class="text-danger"><?php echo $welcome->loadPo('Negative'); ?></span>
                                                            <?php
                                                        }
                                                    }
                                                    else
                                                    {
                                                        ?>
                                                        <a href="<?php echo base_url();?>admin/presumptivePatient/addPresumptiveResult/<?php echo $res->pp_id; ?>" title="Edit"><i class="fa fa-plus-square fa-2x "></i></a>
                                                        <?php
                                                    }
                                                ?>
                                                </td>
                                                <td width="10%">
                                                    <?php
                                                    if($res->pp_report_status == 1)
                                                    {
                                                        ?>
                                                            <a id="active_<?php echo $res->pp_id;?>" <?php if($res->pp_permission_presumptive_status != 1){ echo "style='display:none;'"; } ?> class="btn-group" onclick="return setStatus(<?php echo $res->pp_id;?>,'<?php echo base_url();?>admin/presumptivePatient/setStatus','0')">
                                                                <button class="btn btn-sm btn-success"><?php echo $welcome->loadPo('Yes'); ?></button>
                                                                <button class="btn btn-sm btn-default"><?php echo $welcome->loadPo('No'); ?></button>
                                                            </a>
                                                            <a id="inactive_<?php echo $res->pp_id;?>" <?php if($res->pp_permission_presumptive_status != 0){ echo "style='display:none;'"; } ?> class="btn-group" onclick="return setStatus(<?php echo $res->pp_id;?>,'<?php echo base_url();?>admin/presumptivePatient/setStatus','1')">
                                                                <button class="btn btn-sm btn-default"><?php echo $welcome->loadPo('Yes'); ?></button>
                                                                <button class="btn btn-sm btn-success"><?php echo $welcome->loadPo('No'); ?></button>
                                                            </a>
                                                        <?php
                                                    }
                                                    ?>
                                                </td>
                                                <td >
                                                    <div id="Forward_<?php echo $res->pp_id;?>" style="<?php if($res->pp_permission_presumptive_status == 1){ echo 'display:block'; }else{ echo 'display:none'; } ?>">
                                                    <?php
                                                        if($res->pp_permission_presumptive_status == 1)
                                                        {
                                                            if($res->pp_report_status == 1)
                                                            {
                                                                if($res->pp_testing_result == 'Positive')
                                                                {
                                                                    if($res->pp_drug_resistance_status == 'Drug Resistant')
                                                                    {
                                                                        if($res->pp_send_pravah_status == 0)
                                                                        {
                                                                            ?>
                                                                            <a href="<?php echo base_url();?>admin/presumptivePatient/sendToShakshamPravah/<?php echo $res->pp_id; ?>" class="text-primary"><u><?php echo $welcome->loadPo('Link to counsellor'); ?></u></a>
                                                                            <?php
                                                                        }
                                                                        elseif($res->pp_send_pravah_status == 2)
                                                                        {
                                                                            ?>
                                                                            <a href="<?php echo base_url();?>admin/presumptivePatient/showSendSakhamPravahData/<?php echo $res->pp_id; ?>" class="text-warnning"><u><?php echo $welcome->loadPo('Linked to counsellor'); ?></u></a>
                                                                            <?php
                                                                        }
                                                                         elseif($res->pp_send_pravah_status == 1)
                                                                        {
                                                                            ?>
                                                                            <span class="text-success"><?php echo $welcome->loadPo('Accepted by counsellor'); ?></span>
                                                                            <?php
                                                                        }
                                                                    }
                                                                    if($res->pp_drug_resistance_status == 'Drug Sensitive')
                                                                    {
                                                                        if($res->pp_register_patient_Status == 0)
                                                                        {
                                                                            ?>
                                                                            <a href="<?php echo base_url();?>admin/patient/addPatient/<?php echo $res->pp_id; ?>" title="Edit" class="text-primary"><u><?php echo $welcome->loadPo('Register as Patient'); ?></u></a>
                                                                            <?php
                                                                        }
                                                                        else
                                                                        {
                                                                            ?>
                                                                            <span class="text-success"><?php echo $welcome->loadPo('Registered as Patient'); ?></span>
                                                                            <?php
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    ?>
                                                    </div>
                                                </td>
                                                <td>
                                                    <?php
                                                    if($res->pp_report_status == 0)
                                                    {
                                                        foreach($getAllTabAsPerRole as $role)
                                                        {
                                                            if($this->uri->segment(2) == $role->controller_name && $role->userEdit == 1)
                                                            {
                                                                ?>
                                                                    <a href="<?php echo base_url();?>admin/presumptivePatient/addPresumptivePatient/<?php echo $res->pp_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp;                
                                                                <?php
                                                            }
                                                            if($this->uri->segment(2) == $role->controller_name && $role->userDelete == 1)
                                                            {
                                                                ?>
                                                                    <a class="confirm" onclick="return delete_presumptivePatient(<?php echo $res->pp_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>                                      
                                                                <?php
                                                            }
                                                        }
                                                    }
                                                    ?> 
                                                </td>
                                                <?php
                                            }
                                            else
                                            {
                                                ?>
                                                <td> <span class="text-success"><?php echo $res->pp_testing_result; ?></span></td>
                                                <td> 
                                                 <a href="<?php echo base_url();?>admin/presumptivePatient/presumptivePatientView/<?php echo $res->pp_id; ?>" title="Edit"><i class="fa fa-eye fa-2x "></i></a>&nbsp;&nbsp;
                                                </td>
                                                <?php
                                            } 
                                            ?>
                                        </tr>
                                        <?php
                                    }
                                }
                            }
                            else
                            {
                                ?>
                                <tr>
                                    <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                </tr>
                                <?php
                            }
                            
                        ?>
                       
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function delete_presumptivePatient(pp_id)
    {
        bootbox.confirm("Are you sure you want to delete presumptive patient details",function(confirmed){
            if(confirmed)
            {
                location.href="<?php echo base_url();?>admin/presumptivePatient/delete_presumptivePatient/"+pp_id;
            }
        });
    }    

    function setStatus(ID, PAGE, status) 
    {
        var str = 'id='+ID+'&status='+status;
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {     

                if(data==1)
                {
                    location.reload();
                    var a_spanid = 'active_'+ID ;
                    var d_spanid = 'inactive_'+ID ;
                    if(status == '0')
                    {

                        $("#Forward_"+ID).css('display', 'none');
                        $("#"+a_spanid).hide();
                        $("#"+d_spanid).show();               
                    }
                    else
                    {  
                        $("#Forward_"+ID).css('display', 'block'); 
                        $("#"+d_spanid).hide();
                        $("#"+a_spanid).show();                 
                    }
                }
            } 
        });
    }
</script>