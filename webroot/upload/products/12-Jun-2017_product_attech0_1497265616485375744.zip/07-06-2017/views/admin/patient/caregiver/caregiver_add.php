<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			<?php echo $welcome->loadPo('Patient caregiver'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/patient/caregiver/<?php echo $pp_id; ?>/<?php echo $patient_id; ?>"><?php echo $welcome->loadPo('Patient caregiver'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Patient caregiver Add'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Patient caregiver Add</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/patient/caregiver/<?php echo $pp_id; ?>/<?php echo $patient_id; ?>" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
            <?php
            foreach ($patient_res as $value) 
            {
                ?>
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div> 
                    <div class="row">  
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Patient Name'); ?><span class="text-danger">*</span></label>
                                <input readonly="" name="pcg_patient_name" class="form-control" type="text" id="pcg_patient_name" value="<?php echo $value->patient_name; ?>" />
                            </div>
                        </div>  
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo("Patient's father's Name"); ?><span class="text-danger">*</span></label>
                                <input readonly="" name="pcg_patient_father_name" class="form-control" type="text" id="pcg_patient_father_name" value="<?php echo $value->patient_father_name; ?>" />
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo("Patient's Date of birth"); ?><span class="text-danger">*</span></label>
                                <div class='input-group date_pic'>
                                    <input readonly="" type="text" class="form-control" name="pcg_patient_dob" id="pcg_patient_dob" value="<?php echo $value->patient_dob; ?>">
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">  
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Saksham ID of Patient'); ?><span class="text-danger">*</span></label>
                                 <input readonly="" name="patient_saksham_id" class="form-control" type="text" id="patient_saksham_id" value="<?php echo $value->saksham_patient_id; ?>" />
                            </div>
                        </div>  
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Date of caregiver registration'); ?><span class="text-danger">*</span></label>
                                <div class='input-group'>
                                    <input type="text" class="form-control date_val" name="pcg_date_of_registration" id="pcg_date_of_registration" value="">
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Place of Visit for Registration'); ?><span class="text-danger">*</span></label>
                                <input name="pcg_place_for_registration" class="form-control" type="text" id="pcg_place_for_registration" value="" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Care giver has provided consent for counselling and to share details about self'); ?><span class="text-danger">*</span></label>
                              <select class="form-control"  name="pcg_share_detail_status" id="pcg_share_detail_status">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option> 
                                    <option value="No"><?php echo $welcome->loadPo('No'); ?></option> 
                                </select>
                            </div>
                        </div> 
                    </div>
                     <div class="row">
                        <div class="form-group col-md-4">
                            <h3><u><?php echo $welcome->loadPo('Caregiver details'); ?></u></h3>
                        </div> 
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Name of Caregiver'); ?><span class="text-danger">*</span></label>
                                <input name="pcg_caregiver_name" class="form-control" type="text" id="pcg_caregiver_name" value="" />
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Relationship with Patient'); ?><span class="text-danger">*</span></label>
                                <input name="pcg_relationship_with_patient" class="form-control" type="text" id="pcg_relationship_with_patient" value="" />
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Age of the caregiver'); ?><span class="text-danger">*</span></label>
                                <input name="pcg_caregiver_age" class="form-control" type="number" id="pcg_caregiver_age" value="" min="0"/>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Sex of the caregiver'); ?><span class="text-danger">*</span></label>
                              <select class="form-control"  name="pcg_caregiver_gender" id="pcg_caregiver_gender">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Male"><?php echo $welcome->loadPo('Male'); ?></option> 
                                    <option value="Female"><?php echo $welcome->loadPo('Female'); ?></option> 
                                    <option value="Transgender"><?php echo $welcome->loadPo('Transgender'); ?></option> 
                                </select>
                            </div>
                        </div> 
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <h3><u><?php echo $welcome->loadPo('Caregiver TB history'); ?></u></h3>
                        </div> 
                    </div> 
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Does care giver have any past history of TB'); ?><span class="text-danger">*</span></label>
                              <select class="form-control" name="pcg_past_history_of_TB" id="pcg_past_history_of_TB">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option> 
                                    <option value="No"><?php echo $welcome->loadPo('No'); ?></option> 
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('If yes, Which type of TB did the caregiver suffer from?'); ?><span class="text-danger">*</span></label>
                              <select class="form-control"  name="pcg_suffer_from_TB" id="pcg_suffer_from_TB">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Pulmonary TB"><?php echo $welcome->loadPo('Pulmonary TB'); ?></option> 
                                    <option value="Extra Pulmonary TB"> <?php echo $welcome->loadPo('Extra Pulmonary TB'); ?></option> 
                                    <option value="Don't know"><?php echo $welcome->loadPo("Don't know"); ?></option> 
                                </select>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('If yes, Specify the category of TB which the caregiver had'); ?><span class="text-danger">*</span></label>
                              <select class="form-control" name="pcg_category_of_TB" id="pcg_category_of_TB">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Category-1"><?php echo $welcome->loadPo('Category-1'); ?></option> 
                                    <option value="Category-2"><?php echo $welcome->loadPo('Category-2'); ?></option> 
                                    <option value="MDR"><?php echo $welcome->loadPo('MDR'); ?></option> 
                                    <option value="XDR"><?php echo $welcome->loadPo('XDR'); ?></option> 
                                    <option value="Don't know"><?php echo $welcome->loadPo("Don't know"); ?></option> 
                                </select>
                            </div>
                        </div>  
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('If the caregiver had extra pulmonary TB, organ affected'); ?><span class="text-danger">*</span></label>
                                <input name="pcg_organ_affected_from_TB" class="form-control" type="text" id="pcg_organ_affected_from_TB" value="" />
                            </div>
                        </div> 
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo("Specify the caregiver's TB treatments present outcome"); ?> <span class="text-danger">*</span></label><br>
                                <input name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Cure" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Cure'); ?><br/>
                                <input name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Treatment completed" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Treatment completed'); ?><br/>
                                <input name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Treatment failed" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Treatment failed'); ?><br/>
                                <input name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Lost of Follow-Up" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Lost of Follow-Up'); ?><br/>
                                <input name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Not evaluated(Transfer out-RNTCP)" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Not evaluated(Transfer out-RNTCP)'); ?><br/>
                                <input name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Treatment stopped due to ADR" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Treatment stopped due to ADR'); ?><br/>
                                <input name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Treatment regimen changed" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Treatment regimen changed'); ?><br/>
                                <input name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Still on treatment" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Still on treatment'); ?><br/>
                                <input name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Don't know"/>&nbsp;&nbsp;<?php echo $welcome->loadPo("Don't know"); ?><br/>                                               
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo("Caregiver's Self-reported history of substance abuse"); ?><span class="text-danger">*</span></label><br>
                                <input name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Ghutka" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Ghutka'); ?><br/>
                                <input name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Pan" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Pan'); ?><br/>
                                <input name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Tobacco chewing" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Tobacco chewing'); ?><br/>
                                <input name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Smoking" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Smoking'); ?><br/>
                                <input name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Alcohol consumption" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Alcohol consumption'); ?><br/>
                                <input name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Drug addiction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Drug addiction'); ?><br/>
                                <input name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="No history" />&nbsp;&nbsp;<?php echo $welcome->loadPo('No history'); ?><br/>
                                <input name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse" value="Other" onclick="addInputFieldCheckBox(this.value, 'pcg_self_substance_abuse')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                <input type="text" style="display: none" id="pcg_self_substance_abuse_other" name="pcg_self_substance_abuse_other" class="form-control" value="" />
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo("Caregiver's reported patient history of substance abuse"); ?><span class="text-danger">*</span></label><br>
                                <input name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Ghutka" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Ghutka'); ?><br/>
                                <input name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Pan" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Pan'); ?><br/>
                                <input name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Tobacco chewing" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Tobacco chewing'); ?><br/>
                                <input name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Smoking" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Smoking'); ?><br/>
                                <input name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Alcohol consumption" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Alcohol consumption'); ?><br/>
                                <input name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Drug addiction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Drug addiction'); ?><br/>
                                <input name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="No history" />&nbsp;&nbsp;<?php echo $welcome->loadPo('No history'); ?><br/>
                                <input name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse" value="Other" onclick="addInputFieldCheckBox(this.value, 'pcg_patient_substance_abuse')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                <input type="text" style="display: none" id="pcg_patient_substance_abuse_other" name="pcg_patient_substance_abuse_other" class="form-control" value="" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <h3><u><?php echo $welcome->loadPo('Counselling details'); ?></u></h3>
                        </div> 
                    </div> 
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Counselling topics'); ?> <span class="text-danger">*</span></label><br>
                                <input name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="DS-TB treatment and Education" />&nbsp;&nbsp;<?php echo $welcome->loadPo('DS-TB treatment and Education'); ?><br/>
                                <input name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="DS-TB treatment adherence" />&nbsp;&nbsp;<?php echo $welcome->loadPo('DS-TB treatment adherence'); ?><br/>
                                <input name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Cough hygiene and sputum disposal" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Cough hygiene and sputum disposal'); ?><br/>
                                <input name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Substance abuse and De-addiction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Substance abuse and De-addiction'); ?><br/>
                                <input name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Reproductive health related" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Reproductive health related'); ?><br/>
                                <input name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Role of Diet and Nutrition" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Role of Diet and Nutrition'); ?><br/>
                                <input name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Adverse Drug Reactions" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Adverse Drug Reactions'); ?><br/>
                                <input name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Addressing Stigma and Discrimination" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Addressing Stigma and Discrimination'); ?><br/>
                                <input name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Role of family support in completing treatment" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Role of family support in completing treatment'); ?><br/>
                                <input name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics" value="Other" onclick="addInputFieldCheckBox(this.value, 'pcg_counselling_topics')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                <input type="text" style="display: none" id="pcg_counselling_topics_other" name="pcg_counselling_topics_other" class="form-control" value="" />
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                 <label><?php echo $welcome->loadPo('Saksham Sathi Remarks'); ?><span class="text-danger">*</span></label>
                                 <textarea name="pcg_csw_remarks" class="form-control" rows="5" id="pcg_csw_remarks" ></textarea>
                            </div>
                        </div>  
                    </div> 
                    <div class="box-footer">
                        <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Add"><?php echo $welcome->loadPo('Submit'); ?></button>
                        <a class="btn btn-danger btn-sm" href="<?php echo base_url();?>admin/patient/caregiver/<?php echo $pp_id; ?>/<?php echo $patient_id; ?>"><?php echo $welcome->loadPo('Cancel'); ?></a>
                    </div>
                </div> 
                <?php
            }
            ?>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->

<script type="text/javascript">
    $(function () {       
        $('.date_pic').datetimepicker({
            format: 'Y-M-D'
        });     
    });

  
   function addInputField(f_val, f_id)
    {
        if(document.getElementById(f_id).checked)
        {
            $('#'+f_id+'_other').css('display', 'block');
        }
        else
        {
            $('#'+f_id+'_other').css('display', 'none');
        }
    }
  
</script>