<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			<?php echo $welcome->loadPo('Presumptive Referrals'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/presumptivePatient"><?php echo $welcome->loadPo('Presumptive Referrals'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Presumptive Referrals Add'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
               <!--  <div class="pull-left">
                    <h3 class="box-title">Presumptive Referrals Add</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/presumptivePatient" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div> 
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Date of Referral'); ?><span class="text-danger">*</span></label><br><br>
                                <div class='input-group'>
                                    <input type="text" class="form-control date_val" name="pp_referral_date" id="pp_referral_date" value="<?php echo set_value('pp_referral_date'); ?>">
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                                <?php echo form_error('pp_referral_date','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Type of Referral'); ?><span class="text-danger">*</span></label><br><br>
                                <select class="form-control"  name="pp_referral_type" id="pp_referral_type">
                                    <option value=""></option>  
                                    <option value="Self referral during community activity"><?php echo $welcome->loadPo('Self referral during community activity'); ?></option>
                                    <option value="Community referral"><?php echo $welcome->loadPo('Community referral'); ?></option>
                                    <option value="Referral during active case finding"><?php echo $welcome->loadPo('Referral during active case finding'); ?></option>
                                    <option value="Self referral during field visit"><?php echo $welcome->loadPo('Self referral during field visit'); ?></option>
                                </select>
                                <?php echo form_error('pp_referral_type','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('If Self referral, then community activity through which case is referred'); ?><span class="text-danger">*</span></label>
                                <input name="pp_community_activity_name" class="form-control" type="text" id="pp_community_activity_name" value="<?php echo set_value('pp_community_activity_name'); ?>" />
                                <?php echo form_error('pp_community_activity_name','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>                        
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Sputum date'); ?><span class="text-danger">*</span></label><br><br>
                                <div class='input-group'>
                                    <input type="text" class="form-control date_val" name="pp_sputum_date" id="pp_sputum_date" value="<?php echo set_value('pp_sputum_date'); ?>">
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                                <?php echo form_error('pp_sputum_date','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Date of activity'); ?><span class="text-danger">*</span></label><br><br>
                                <div class='input-group'>
                                    <input type="text" class="form-control date_val" name="pp_date_of_activity" id="pp_date_of_activity" value="<?php echo set_value('pp_date_of_activity'); ?>">
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                                <?php echo form_error('pp_date_of_activity','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('If Community referral, then name of the stakeholder referring the case'); ?><span class="text-danger">*</span></label>
                                <div class="form-group">
                                    <select name="pp_stakeholder_name" id="pp_stakeholder_name" class="selectpicker form-control" data-live-search="true">
                                        <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                        <?php 
                                            foreach ($stakeholder_list as $s_list)
                                            {
                                                ?>
                                                <option value="<?php echo $s_list->stakeholder_name; ?>"><?php echo $s_list->stakeholder_name; ?></option>
                                                <?php
                                            }
                                        ?>
                                    </select>
                                    <?php echo form_error('pp_stakeholder_name','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div> 
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Name of the presumptive case referred'); ?><span class="text-danger">*</span></label>
                                <input name="pp_patient_name" class="form-control" type="text" id="pp_patient_name" value="<?php echo set_value('pp_patient_name'); ?>" />
                                <?php echo form_error('pp_patient_name','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Age'); ?><span class="text-danger">*</span></label>
                                 <input name="pp_age" class="form-control" min="0" type="number" id="pp_age" value="<?php echo set_value('pp_age'); ?>" />
                                <?php echo form_error('pp_age','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Sex'); ?><span class="text-danger">*</span></label>
                                <select class="form-control"  name="pp_sex" id="pp_sex">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>     
                                    <option value="Male"><?php echo $welcome->loadPo('Male'); ?></option>
                                    <option value="Female"><?php echo $welcome->loadPo('Female'); ?></option>
                                    <option value="Transgender"><?php echo $welcome->loadPo('Transgender'); ?></option>
                                </select>
                                <?php echo form_error('pp_sex','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                    </div>
                    <div class="row">                         
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Country'); ?><span class="text-danger">*</span></label>
                                <input disabled name="stakeholder_country_id" class="form-control" type="text" id="stakeholder_country_id" value="India" />
                                <?php echo form_error('stakeholder_country_id','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('State'); ?><span class="text-danger">*</span></label>
                                <input disabled name="stakeholder_state_id" class="form-control" type="text" id="stakeholder_state_id" value="Maharashtra" />
                                <?php echo form_error('stakeholder_state_id','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('City'); ?><span class="text-danger">*</span></label>
                                <input disabled name="stakeholder_city" class="form-control" type="text" id="stakeholder_city" value="Mumbai" />
                                <?php echo form_error('stakeholder_city','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>   
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Address'); ?><span class="text-danger">*</span></label>
                                <textarea name="pp_address" class="form-control" id="pp_address" ></textarea>
                                <?php echo form_error('pp_address','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>   
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Landmark'); ?><span class="text-danger">*</span></label>
                                <textarea name="pp_landmark" class="form-control" id="pp_landmark" ></textarea>
                                <?php echo form_error('pp_landmark','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>                     
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Postal Code'); ?><span class="text-danger">*</span></label>
                                <input name="pp_postal_code" class="form-control" min="0" type="number" id="pp_postal_code" value="<?php echo set_value('pp_postal_code'); ?>" />
                                <?php echo form_error('pp_postal_code','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>  
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Phone number'); ?><span class="text-danger">*</span></label>
                                <input name="pp_phone_no" class="form-control" min="0" type="number" id="pp_phone_no" value="<?php echo set_value('pp_phone_no'); ?>" />
                                <?php echo form_error('pp_phone_no','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Facility where the presumptive case is referred'); ?><span class="text-danger">*</span></label>
                                <div class="form-group">
                                    <select name="diagnosis_id" id="diagnosis_id" class="selectpicker form-control" data-live-search="true">
                                        <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                        <?php 
                                            foreach ($diagnosis_list as $d_list)
                                            {
                                                ?>
                                                <option value="<?php echo $d_list->diagnosis_id; ?>"><?php echo $d_list->diagnosis_name; ?></option>
                                                <?php
                                            }
                                        ?>
                                    </select>
                                </div>
                                <?php echo form_error('diagnosis_id','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Add" ><?php echo $welcome->loadPo('Submit'); ?></button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/presumptivePatient"><?php echo $welcome->loadPo('Cancel'); ?></a>
                </div>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->