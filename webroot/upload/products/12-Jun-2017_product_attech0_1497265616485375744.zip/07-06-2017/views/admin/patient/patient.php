<?php
$user_id = $this->data['session'][0]->user_id;
$user_role_id = $this->data['session'][0]->user_role_id;
?>
<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Patient'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Patient'); ?></li>
        </ol>
    </section>   
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <!-- <div class="box-header">
                <div class="pull-left">
                    <h3 class="box-title">Patient Details</h3>
                </div>
            </div>   -->         
            <!-- /.box-header -->
            <div class="box-body">
                <div>
                    <div id="msg_div">
                        <?php echo $this->session->flashdata('message');?>
                    </div>
                </div>
                <table id="example2" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <?php
                                if($user_role_id != '7')
                                {
                                    ?>
                                    <th><?php echo $welcome->loadPo('Added By'); ?></th>
                                    <?php
                                }
                            ?>
                            <th><?php echo $welcome->loadPo('Referral Type'); ?></th>
                            <th><?php echo $welcome->loadPo('Name'); ?></th>
                            <th><?php echo $welcome->loadPo('Phone'); ?></th>
                            <th><?php echo $welcome->loadPo('Address'); ?></th>
                            <th><?php echo $welcome->loadPo('City'); ?></th>
                            <th><?php echo $welcome->loadPo('Consent'); ?></th>
                            <th><?php echo $welcome->loadPo('Follow-up'); ?></th>
                            <th><?php echo $welcome->loadPo('Caregiver'); ?></th>
                            <th><?php echo $welcome->loadPo('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if(!empty($patient_res))
                            {
                                foreach($patient_res as $res)
                                { 
                                    $u_level = explode(',', $res->user_all_level);
                                    if(in_array($user_id, $u_level))
                                    {
                                        ?>
                                        <tr>
                                            <?php
                                                if($user_role_id != '7')
                                                {
                                                    ?>
                                                    <td><?php echo $res->added_by; ?></td>
                                                    <?php
                                                }
                                            ?>
                                            <td><?php echo $res->ptb_referral_type; ?></td>
                                            <td><?php echo $res->patient_name; ?></td>
                                            <td><?php echo $res->patient_contact_no; ?></td>
                                            <td><?php echo $res->patient_c_address; ?></td>
                                            <td><?php echo $res->patient_c_city; ?></td>
                                            <td width="10%">
                                                <a href="#" id="active_<?php echo $res->patient_id;?>" <?php if($res->patient_followup_permission != 1){ echo "style='display:none;'"; } ?> class="btn-group" onclick="return setStatus(<?php echo $res->patient_id;?>,'<?php echo base_url();?>admin/patient/setStatus','0')">
                                                    <button class="btn btn-sm btn-success"><?php echo $welcome->loadPo('Yes'); ?></button>
                                                    <button class="btn btn-sm btn-default"><?php echo $welcome->loadPo('No'); ?></button>
                                                </a>
                                                <a href="#" id="inactive_<?php echo $res->patient_id;?>" <?php if($res->patient_followup_permission != 0){ echo "style='display:none;'"; } ?> class="btn-group" onclick="return setStatus(<?php echo $res->patient_id;?>,'<?php echo base_url();?>admin/patient/setStatus','1')">
                                                    <button class="btn btn-sm btn-default"><?php echo $welcome->loadPo('Yes'); ?></button>
                                                    <button class="btn btn-sm btn-success"><?php echo $welcome->loadPo('No'); ?></button>
                                                </a>
                                            </td>
                                            <td>
                                                <span id="<?php echo $res->patient_id;?>" style="<?php if($res->patient_followup_permission == 1){ echo 'display: block;'; }else{ echo 'display: none;'; } ?>">
                                                    <a href="<?php echo base_url();?>admin/patient/showFollowUp/<?php echo $res->patient_id; ?>"><i class="fa fa-plus-square fa-2x "></i></a>&nbsp;&nbsp;  
                                                </span> 
                                            </td>
                                            <td>
                                                <a href="<?php echo base_url();?>admin/patient/caregiver/<?php echo $res->pp_id; ?>/<?php echo $res->patient_id; ?>"><i class="fa fa-plus-square fa-2x "></i></a>&nbsp;&nbsp;   
                                            </td>
                                            <td>
                                                <?php
                                                    foreach($getAllTabAsPerRole as $role)
                                                    {
                                                        if($this->uri->segment(2) == $role->controller_name && $role->userEdit == '1')
                                                        {
                                                            ?>
                                                                <a href="<?php echo base_url();?>admin/patient/addPatient/<?php echo $res->pp_id; ?>/<?php echo $res->patient_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp;                
                                                            <?php
                                                        }
                                                        if($this->uri->segment(2) == $role->controller_name && $role->userDelete == '1')
                                                        {
                                                            ?>
                                                                <a class="confirm" onclick="return delete_patient(<?php echo $res->patient_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>                                      
                                                            <?php
                                                        }
                                                    }
                                                ?>&nbsp;&nbsp; 
                                                <a href="<?php echo base_url();?>admin/patient/patientView/<?php echo $res->pp_id; ?>/<?php echo $res->patient_id; ?>"><i class="fa fa-eye fa-2x "></i></a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                            }
                            else
                            {
                                ?>
                                <tr>
                                    <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                </tr>
                                <?php
                            }
                            
                        ?>
                       
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function delete_patient(patient_id)
    {
        bootbox.confirm("Are you sure you want to delete patient details",function(confirmed){
            if(confirmed)
            {
                location.href="<?php echo base_url();?>admin/patient/delete_patient/"+patient_id;
            }
        });
    } 

    function setStatus(ID, PAGE, status) 
    {
        var str = 'id='+ID+'&status='+status;
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {           
                if(data==1)
                {
                    var a_spanid = 'active_'+ID ;
                    var d_spanid = 'inactive_'+ID ;
                    if(status !="1")
                    {
                        $("#"+ID).hide()
                        $("#"+a_spanid).hide();
                        $("#"+d_spanid).show();                     
                        jQuery("#msg_div").html();              
                    }
                    else
                    {    
                        $("#"+ID).show()       
                        $("#"+d_spanid).hide();
                        $("#"+a_spanid).show();             
                        jQuery("#msg_div").html();                  
                    }
                }
            } 
        });
    }   
</script>>