<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			<?php echo $welcome->loadPo('Patient follow-up'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/patient/showFollowUp/<?php echo $patient_id; ?>"><?php echo $welcome->loadPo('Patient follow-up'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Patient follow-up update'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
               <!--  <div class="pull-left">
                    <h3 class="box-title">Patient follow-up update</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/patient/showFollowUp/<?php echo $patient_id; ?>" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div> 
                    <?php
                    foreach ($patient_followup_res as $value) 
                    {
                        ?>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <h3><u><?php echo $welcome->loadPo('Visit Details'); ?></u></h3>
                                </div>
                            </div>    
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Saksham registration ID'); ?></label>
                                        <input readonly type="text" class="form-control" value="<?php echo $value->saksham_patient_id; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo("Patient's Name"); ?></label>
                                        <input readonly name="pfu_patient_name" type="text" class="form-control" value="<?php echo $value->pfu_patient_name; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo("Patient's Father's Name"); ?></label>
                                        <input readonly name="pfu_patient_father_name" type="text" class="form-control" value="<?php echo $value->pfu_patient_father_name; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo("Patient's date of birth"); ?></label>
                                        <input readonly name="pfu_patient_dob" id="pfu_patient_dob" type="text" class="form-control" value="<?php echo $value->pfu_patient_dob; ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Date of follow-up visit'); ?> <span class="text-danger">*</span></label>
                                        <div class='input-group'>
                                            <input name="pfu_follow_up_visit" class="form-control date_val" type="text" id="pfu_follow_up_visit" value="<?php echo $value->pfu_follow_up_visit; ?>" />
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Follow up visit number'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_follow_up_visit_no" name="pfu_follow_up_visit_no" class="form-control" value="<?php echo $value->pfu_follow_up_visit_no; ?>" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">    
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Visited at'); ?> <span class="text-danger">*</span></label><br><br>
                                         <select class="form-control" name="pfu_visited_at" id="pfu_visited_at" onchange="addInputFieldSelectBox(this.value, 'pfu_visited_at')">
                                            <option <?php if($value->pfu_visited_at == 'Health Care Facility'){ echo "selected"; } ?> value="Health Care Facility"><?php echo $welcome->loadPo('Health Care Facility'); ?></option>
                                            <option <?php if($value->pfu_visited_at == 'Home'){ echo "selected"; } ?> value="Home"><?php echo $welcome->loadPo('Home'); ?></option>
                                            <option <?php if($value->pfu_visited_at == 'Work place'){ echo "selected"; } ?> value="Work place"><?php echo $welcome->loadPo('Work place'); ?></option>
                                            <option <?php if($value->pfu_visited_at == 'Telephonic follow-up'){ echo "selected"; } ?> value="Telephonic follow-up"><?php echo $welcome->loadPo('Telephonic follow-up'); ?></option>
                                            <option <?php if($value->pfu_visited_at == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option>
                                        </select><br>
                                        <input type="text" style="<?php if($value->pfu_visited_at == 'Other'){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="pfu_visited_at_other" name="pfu_visited_at_other" class="form-control" value="<?php echo $value->pfu_visited_at_other; ?>" />
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Patient has provided consent for counselling & sharing details'); ?></label>
                                        <select name="pfu_share_detail_status" id="pfu_share_detail_status" class="form-control">
                                            <option <?php if($value->pfu_share_detail_status == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                            <option <?php if($value->pfu_share_detail_status == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                        </select>
                                    </div>
                                </div>
                            </div> 
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Present Country'); ?><span class="text-danger">*</span></label>
                                        <select disabled id="pfu_country_id" name="pfu_country_id" class="form-control">
                                            <option value="99">India</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Present State'); ?><span class="text-danger">*</span></label>
                                        <select disabled id="pfu_state_id" name="pfu_state_id" class="form-control">
                                            <option value="1493">Maharashtra</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Present City (enter if changed)'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_city" name="pfu_city" class="form-control" value="<?php echo $value->pfu_city; ?>" />
                                    </div>
                                </div>  
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Present Address (enter if changed)'); ?><span class="text-danger">*</span></label>
                                        <textarea id="pfu_address" name="pfu_address" class="form-control" ><?php echo $value->pfu_address; ?></textarea>
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Present Landmark (enter if changed)'); ?><span class="text-danger">*</span></label>
                                        <textarea id="pfu_landmark"  name="pfu_landmark" class="form-control" ><?php echo $value->pfu_landmark; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Present Postal Code (enter if changed)'); ?><span class="text-danger">*</span></label>
                                        <input type="number" id="pfu_postal_code" name="pfu_postal_code" class="form-control" value="<?php echo $value->pfu_postal_code; ?>" min="0" />
                                    </div>
                                </div> 
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Patient Phone number (enter if changed)'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_contact_no" name="pfu_contact_no" class="form-control" value="<?php echo $value->pfu_contact_no; ?>" />
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If caregivers present, name of caregivers present during counselling session'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_name_of_caregiver" name="pfu_name_of_caregiver" class="form-control" value="<?php echo $value->pfu_name_of_caregiver; ?>" />
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Patient treatment status'); ?> <span class="text-danger">*</span></label>
                                         <select class="form-control" name="pfu_treatment_status" id="pfu_treatment_status">
                                            <option <?php if($value->pfu_treatment_status == 'Countinued on treatment'){ echo "selected"; } ?>  value="Countinued on treatment"><?php echo $welcome->loadPo('Countinued on treatment'); ?></option>
                                            <option <?php if($value->pfu_treatment_status == 'transferred out'){ echo "selected"; } ?> value="transferred out"><?php echo $welcome->loadPo('transferred out'); ?></option>
                                            <option <?php if($value->pfu_treatment_status == 'Defaulted/loss to follow up'){ echo "selected"; } ?> value="Defaulted/loss to follow up"><?php echo $welcome->loadPo('Defaulted/loss to follow up'); ?></option>
                                            <option <?php if($value->pfu_treatment_status == 'Treatment completed'){ echo "selected"; } ?> value="Treatment completed"><?php echo $welcome->loadPo('Treatment completed'); ?></option>
                                            <option <?php if($value->pfu_treatment_status == 'Treatment failed'){ echo "selected"; } ?> value="Treatment failed"><?php echo $welcome->loadPo('Treatment failed'); ?></option>
                                            <option <?php if($value->pfu_treatment_status == 'Cured'){ echo "selected"; } ?> value="Cured"><?php echo $welcome->loadPo('Cured'); ?></option>
                                            <option <?php if($value->pfu_treatment_status == 'Died'){ echo "selected"; } ?> value="Died"><?php echo $welcome->loadPo('Died'); ?></option>
                                        </select>
                                    </div>
                                </div> 
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Did patient report of having any ADR occurrence since last visit/Call'); ?> <span class="text-danger">*</span></label>
                                         <select class="form-control" name="pfu_ADR_occurance_last_visit" id="pfu_ADR_occurance_last_visit">
                                             <option <?php if($value->pfu_ADR_occurance_last_visit == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                            <option <?php if($value->pfu_ADR_occurance_last_visit == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                        </select>
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If yes, Name of the ADR'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_name_of_ADR" name="pfu_name_of_ADR" class="form-control" value="<?php echo $value->pfu_name_of_ADR; ?>" />
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If patient reported ADR then, where did the patient approach for ADR'); ?> <span class="text-danger">*</span></label>
                                         <select class="form-control" name="pfu_approch_for_ADR" id="pfu_approch_for_ADR" onchange="addInputFieldSelectBox(this.value, 'pfu_approch_for_ADR')">
                                            <option <?php if($value->pfu_approch_for_ADR == 'DTC/TB center/TB-unit'){ echo "selected"; } ?> value="DTC/TB center/TB-unit"><?php echo $welcome->loadPo('DTC/TB center/TB-unit'); ?></option>
                                            <option <?php if($value->pfu_approch_for_ADR == 'Health Post'){ echo "selected"; } ?> value="Health Post"><?php echo $welcome->loadPo('Health Post'); ?></option>
                                            <option <?php if($value->pfu_approch_for_ADR == 'Saksham Sathi'){ echo "selected"; } ?> value="Saksham Sathi"><?php echo $welcome->loadPo('Saksham Sathi'); ?></option>
                                            <option <?php if($value->pfu_approch_for_ADR == 'Private clinic/practitioner/hospital'){ echo "selected"; } ?> value="Private clinic/practitioner/hospital"><?php echo $welcome->loadPo('Private clinic/practitioner/hospital'); ?></option>
                                            <option <?php if($value->pfu_approch_for_ADR == 'Not visited anywhere'){ echo "selected"; } ?> value="Not visited anywhere"><?php echo $welcome->loadPo('Not visited anywhere'); ?></option>
                                            <option <?php if($value->pfu_approch_for_ADR == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option>
                                        </select><br>
                                        <input type="text" style="<?php if($value->pfu_approch_for_ADR == 'Other'){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="pfu_approch_for_ADR_other" name="pfu_approch_for_ADR_other" class="form-control" value="<?php echo $value->pfu_approch_for_ADR_other; ?>" />
                                    </div>
                                </div> 
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('What is outcome of approaching for ADR'); ?> <span class="text-danger">*</span></label>
                                         <select class="form-control" name="pfu_outcome_approch_for_ADR" id="pfu_outcome_approch_for_ADR">
                                            <option <?php if($value->pfu_outcome_approch_for_ADR == 'Improved'){ echo "selected"; } ?> value="Improved"><?php echo $welcome->loadPo('Improved'); ?></option>
                                            <option <?php if($value->pfu_outcome_approch_for_ADR == 'Worsened'){ echo "selected"; } ?> value="Worsened"><?php echo $welcome->loadPo('Worsened'); ?></option>
                                            <option <?php if($value->pfu_outcome_approch_for_ADR == 'Similar to earlier'){ echo "selected"; } ?> value="Similar to earlier"><?php echo $welcome->loadPo('Similar to earlier'); ?></option>
                                        </select>
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If patient reports any ADR and not have approached anyone till that particular date, did Sasham Sathi refer the patient for any medical advice?'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control" name="pfu_refer_any_medical_advice" id="pfu_refer_any_medical_advice">
                                             <option <?php if($value->pfu_refer_any_medical_advice == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                            <option <?php if($value->pfu_refer_any_medical_advice == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Since last visit was there any experience / instance of stigma?'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control" name="pfu_instance_of_stigma" id="pfu_instance_of_stigma">
                                             <option <?php if($value->pfu_instance_of_stigma == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                            <option <?php if($value->pfu_instance_of_stigma == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                        </select>
                                    </div>
                                </div>
                            </div> 
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Was it addressed by counselling'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control" name="pfu_addressed_by_counselling" id="pfu_addressed_by_counselling">
                                             <option <?php if($value->pfu_addressed_by_counselling == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                            <option <?php if($value->pfu_addressed_by_counselling == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Any instance of treatment interruption since last visit'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control" name="pfu_treatment_iterruption_last_visit" id="pfu_treatment_iterruption_last_visit">
                                             <option <?php if($value->pfu_treatment_iterruption_last_visit == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                            <option <?php if($value->pfu_treatment_iterruption_last_visit == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If yes, Number of Doses missed'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_number_of_doses_missed" name="pfu_number_of_doses_missed" class="form-control" value="<?php echo $value->pfu_number_of_doses_missed; ?>" />
                                    </div>
                                </div>
                            </div> 
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If yes, duration of interruption'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control" name="pfu_duration_of_iterruption" id="pfu_duration_of_iterruption">
                                            <option <?php if($value->pfu_treatment_iterruption_last_visit == 'Less then 1 week'){ echo "selected"; } ?> value="Less then 1 week"><?php echo $welcome->loadPo('Less then 1 week'); ?></option>
                                            <option <?php if($value->pfu_treatment_iterruption_last_visit == '1-2 week'){ echo "selected"; } ?> value="1-2 week"><?php echo $welcome->loadPo('1-2 week'); ?></option>
                                            <option <?php if($value->pfu_treatment_iterruption_last_visit == '2-3 week'){ echo "selected"; } ?> value="2-3 week"><?php echo $welcome->loadPo('2-3 week'); ?></option>
                                            <option <?php if($value->pfu_treatment_iterruption_last_visit == '3-4 week'){ echo "selected"; } ?> value="3-4 week"><?php echo $welcome->loadPo('3-4 week'); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo("If yes, reason's for interruption"); ?><span class="text-danger">*</span></label><br/>
                                        <?php
                                            $a_arr = explode(',', $value->pfu_reason_of_iterruption);
                                        ?>
                                        <input <?php if(in_array('Adverse drug reaction', $a_arr)){ echo "checked"; } ?> type="checkbox" id="pfu_reason_of_iterruption[]" name="pfu_reason_of_iterruption[]" value="Adverse drug reaction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Adverse drug reaction'); ?><br/>
                                        <input <?php if(in_array('Substance abuse', $a_arr)){ echo "checked"; } ?> type="checkbox" id="pfu_reason_of_iterruption[]" name="pfu_reason_of_iterruption[]"  value="Substance abuse" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Substance abuse'); ?><br/>
                                        <input <?php if(in_array('Family problem', $a_arr)){ echo "checked"; } ?> type="checkbox" id="pfu_reason_of_iterruption[]" name="pfu_reason_of_iterruption[]"  value="Family problem" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Family problem'); ?><br/>
                                        <input <?php if(in_array('Taking Private treatment', $a_arr)){ echo "checked"; } ?> type="checkbox" id="pfu_reason_of_iterruption[]" name="pfu_reason_of_iterruption[]"  value="Taking Private treatment" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Taking Private treatment'); ?><br/>
                                        <input <?php if(in_array('Want to native place', $a_arr)){ echo "checked"; } ?> type="checkbox" id="pfu_reason_of_iterruption[]" name="pfu_reason_of_iterruption[]"  value="Want to native place" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Went to native place'); ?><br/>
                                        <input <?php if(in_array('Financial issues', $a_arr)){ echo "checked"; } ?> type="checkbox" id="pfu_reason_of_iterruption[]" name="pfu_reason_of_iterruption[]"  value="Financial issues" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Financial issues'); ?><br/>
                                        <input <?php if(in_array('Stigma', $a_arr)){ echo "checked"; } ?> type="checkbox" id="pfu_reason_of_iterruption[]" name="pfu_reason_of_iterruption[]"  value="Stigma" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Stigma'); ?><br/>
                                        <input <?php if(in_array('Lack of nutrition', $a_arr)){ echo "checked"; } ?> type="checkbox" id="pfu_reason_of_iterruption[]" name="pfu_reason_of_iterruption[]" value="Lack of nutrition" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Lack of nutrition'); ?><br/>
                                        <input <?php if(in_array('Other', $a_arr)){ echo "checked"; } ?> type="checkbox" id="pfu_reason_of_iterruption" name="pfu_reason_of_iterruption[]" value="Other" onclick="addInputFieldCheckBox(this.value, 'pfu_reason_of_iterruption')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                        <input type="text" style="<?php if(in_array('Other', $a_arr)){ echo 'display: block'; }else{ echo 'display: none'; } ?> " id="pfu_reason_of_iterruption_other" name="pfu_reason_of_iterruption_other" class="form-control" value="<?php echo $value->pfu_reason_of_iterruption_other; ?>" />
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Any instance of lost to follow-up in treatment since last counselling interaction'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control" name="pfu_last_counselling_iteraction" id="pfu_last_counselling_iteraction">
                                             <option <?php if($value->pfu_share_detail_status == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                            <option <?php if($value->pfu_share_detail_status == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                        </select>
                                    </div>
                                </div>
                            </div> 
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <h3><u><?php echo $welcome->loadPo('Counselling details'); ?></u></h3>
                                </div>
                            </div>  
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Counselling topics covered'); ?> <span class="text-danger">*</span></label><br>
                                         <?php
                                        $b_arr = explode(',', $value->pfu_counselling_topic_covered);
                                        ?>
                                        <input <?php if(in_array('DS-TB treatment and Education', $b_arr)){ echo "checked"; } ?> name="pfu_counselling_topic_covered[]" type="checkbox" id="pfu_counselling_topic_covered[]" value="DS-TB treatment and Education" />&nbsp;&nbsp;<?php echo $welcome->loadPo('DS-TB treatment and Education'); ?><br/>
                                        <input <?php if(in_array('DS-TB treatment adherence', $b_arr)){ echo "checked"; } ?> name="pfu_counselling_topic_covered[]" type="checkbox" id="pfu_counselling_topic_covered[]" value="DS-TB treatment adherence" />&nbsp;&nbsp;<?php echo $welcome->loadPo('DS-TB treatment adherence'); ?><br/>
                                        <input <?php if(in_array('Cough hygiene and sputum disposal', $b_arr)){ echo "checked"; } ?> name="pfu_counselling_topic_covered[]" type="checkbox" id="pfu_counselling_topic_covered[]" value="Cough hygiene and sputum disposal" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Cough hygiene and sputum disposal'); ?><br/>
                                        <input <?php if(in_array('Substance abuse and De-addiction', $b_arr)){ echo "checked"; } ?> name="pfu_counselling_topic_covered[]" type="checkbox" id="pfu_counselling_topic_covered[]" value="Substance abuse and De-addiction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Substance abuse and De-addiction'); ?><br/>
                                        <input <?php if(in_array('Reproductive health related', $b_arr)){ echo "checked"; } ?> name="pfu_counselling_topic_covered[]" type="checkbox" id="pfu_counselling_topic_covered[]" value="Reproductive health related" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Reproductive health related'); ?><br/>
                                        <input <?php if(in_array('Role of Diet and Nutrition', $b_arr)){ echo "checked"; } ?> name="pfu_counselling_topic_covered[]" type="checkbox" id="pfu_counselling_topic_covered[]" value="Role of Diet and Nutrition" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Role of Diet and Nutrition'); ?><br/>
                                        <input <?php if(in_array('Adverse Drug Reactions', $b_arr)){ echo "checked"; } ?> name="pfu_counselling_topic_covered[]" type="checkbox" id="pfu_counselling_topic_covered[]" value="Adverse Drug Reactions" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Adverse Drug Reactions'); ?><br/>
                                        <input <?php if(in_array('Addressing Stigma and Discrimination', $b_arr)){ echo "checked"; } ?> name="pfu_counselling_topic_covered[]" type="checkbox" id="pfu_counselling_topic_covered[]" value="Addressing Stigma and Discrimination" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Addressing Stigma and Discrimination'); ?><br/>
                                        <input <?php if(in_array('Others', $b_arr)){ echo "checked"; } ?> name="pfu_counselling_topic_covered[]" type="checkbox" id="pfu_counselling_topic_covered" value="Others" onclick="addInputFieldCheckBox(this.value, 'pfu_counselling_topic_covered')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Others'); ?><br/>
                                        <input type="text" style="<?php if(in_array('Others', $b_arr)){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="pfu_counselling_topic_covered_other" name="pfu_counselling_topic_covered_other" class="form-control" value="<?php echo $value->pfu_counselling_topic_covered_other; ?>" />
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo("Patient's need for referral /linkage identified"); ?><span class="text-danger">*</span></label>
                                         <select class="form-control" name="pfu_linkage_identified" id="pfu_linkage_identified">
                                             <option <?php if($value->pfu_linkage_identified == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                            <option <?php if($value->pfu_linkage_identified == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Referral services/linkages made towards'); ?><span class="text-danger">*</span></label><br>
                                        <?php
                                        $c_arr = explode(',', $value->pfu_linkage_made_towards);
                                        ?>
                                        <input <?php if(in_array('Health services', $c_arr)){ echo "checked"; } ?> name="pfu_linkage_made_towards[]" type="checkbox" id="pfu_linkage_made_towards[]" value="Health services" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Health services'); ?><br/>
                                        <input <?php if(in_array('FU sputum', $c_arr)){ echo "checked"; } ?> name="pfu_linkage_made_towards[]" type="checkbox" id="pfu_linkage_made_towards[]" value="FU sputum" />&nbsp;&nbsp;<?php echo $welcome->loadPo('FU sputum'); ?><br/>
                                        <input <?php if(in_array('Referral for ADR', $c_arr)){ echo "checked"; } ?> name="pfu_linkage_made_towards[]" type="checkbox" id="pfu_linkage_made_towards[]" value="Referral for ADR" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Referral for ADR'); ?><br/>
                                        <input <?php if(in_array('Mental health professional', $c_arr)){ echo "checked"; } ?> name="pfu_linkage_made_towards[]" type="checkbox" id="pfu_linkage_made_towards[]" value="Mental health professional" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Mental health professional'); ?><br/>
                                        <input <?php if(in_array('Nutritional support', $c_arr)){ echo "checked"; } ?> name="pfu_linkage_made_towards[]" type="checkbox" id="pfu_linkage_made_towards[]" value="Nutritional support" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Nutritional support'); ?><br/>
                                        <input <?php if(in_array('Livelihood', $c_arr)){ echo "checked"; } ?> name="pfu_linkage_made_towards[]" type="checkbox" id="pfu_linkage_made_towards[]" value="Livelihood" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Livelihood'); ?><br/>
                                        <input <?php if(in_array('Income generation schemes', $c_arr)){ echo "checked"; } ?> name="pfu_linkage_made_towards[]" type="checkbox" id="pfu_linkage_made_towards[]" value="Income generation schemes" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Income generation schemes'); ?><br/>
                                        
                                        <input <?php if(in_array('Others', $c_arr)){ echo "checked"; } ?> name="pfu_linkage_made_towards[]" type="checkbox" id="pfu_linkage_made_towards" value="Others" onclick="addInputFieldCheckBox(this.value, 'pfu_linkage_made_towards')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Others'); ?><br/>
                                        <input type="text" style="<?php if(in_array('Others', $c_arr)){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="pfu_linkage_made_towards_other" name="pfu_linkage_made_towards_other" class="form-control" value="<?php echo $value->pfu_linkage_made_towards_other; ?>" />
                                    </div>
                                </div>
                            </div> 
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <h3><u><?php echo $welcome->loadPo('Caregiver assessment'); ?></u></h3>
                                </div>
                            </div>   
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If any TB symptom seen, Number of caregivers referred for testing'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_number_of_caregiver_testing" name="pfu_number_of_caregiver_testing" class="form-control" value="<?php echo $value->pfu_number_of_caregiver_testing; ?>" />
                                    </div>
                                </div>  
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Out of referred caregivers, how many are diagnosed as TB positive'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_caregiver_diagnosed_TB_positive" name="pfu_caregiver_diagnosed_TB_positive" class="form-control" value="<?php echo $value->pfu_caregiver_diagnosed_TB_positive; ?>" />
                                    </div>
                                </div>  
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If TB positive, Number of household members started TB treatment'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_household_member_started_treatment" name="pfu_household_member_started_treatment" class="form-control" value="<?php echo $value->pfu_household_member_started_treatment; ?>" />
                                    </div>
                                </div>  
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <h3><u><?php echo $welcome->loadPo('Monthly Treatment adherance'); ?></u></h3>
                                </div>
                            </div>   
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Month of treatment'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_month_of_treatment" name="pfu_month_of_treatment" class="form-control month_year" value="<?php echo $value->pfu_month_of_treatment; ?>" />
                                    </div>
                                </div>  
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Number of doses expected in this month'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_number_of_doses_in_month" name="pfu_number_of_doses_in_month" class="form-control" value="<?php echo $value->pfu_number_of_doses_in_month; ?>" />
                                    </div>
                                </div>  
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Number of doses missed in this month'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_number_of_doses_missed_in_month" name="pfu_number_of_doses_missed_in_month" class="form-control" value="<?php echo $value->pfu_number_of_doses_missed_in_month; ?>" />
                                    </div>
                                </div>  
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Mention the treatment regimen that the patient in undertaking(Abbreviations of Medicine names)'); ?><span class="text-danger">*</span></label>
                                        <input type="text" id="pfu_mention_the_treatment_regimen" name="pfu_mention_the_treatment_regimen" class="form-control" value="<?php echo $value->pfu_mention_the_treatment_regimen; ?>" />
                                    </div>
                                </div>  
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Next follow-up on'); ?><span class="text-danger">*</span></label>
                                        <div class='input-group'>
                                            <input name="pfu_next_follo_up_date" class="form-control date_val" type="text" id="pfu_next_follo_up_date" value="<?php echo $value->pfu_next_follo_up_date; ?>" />
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                    </div>
                                </div>  
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Next follow up visit place'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control" name="pfu_next_follow_up_visit_place" id="pfu_next_follow_up_visit_place" onchange="addInputFieldSelectBox(this.value, 'pfu_next_follow_up_visit_place')">  
                                            <option <?php if($value->pfu_next_follow_up_visit_place == 'Health Center Facility'){ echo "selected"; } ?> value="Health Center Facility"><?php echo $welcome->loadPo('Health Center Facility'); ?></option>  
                                            <option <?php if($value->pfu_next_follow_up_visit_place == 'Home'){ echo "selected"; } ?> value="Home"><?php echo $welcome->loadPo('Home'); ?></option> 
                                            <option <?php if($value->pfu_next_follow_up_visit_place == 'Workplace'){ echo "selected"; } ?> value="Workplace"><?php echo $welcome->loadPo('Workplace'); ?></option> 
                                            <option <?php if($value->pfu_next_follow_up_visit_place == 'Community meeting'){ echo "selected"; } ?> value="Community meeting"><?php echo $welcome->loadPo('Other convenient place'); ?></option> 
                                            <option <?php if($value->pfu_next_follow_up_visit_place == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option> 
                                        </select><br>
                                        <input type="text" style="<?php if($value->pfu_next_follow_up_visit_place == 'Other'){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="pfu_next_follow_up_visit_place_other" name="pfu_next_follow_up_visit_place_other" class="form-control" value="<?php echo $value->pfu_next_follow_up_visit_place_other; ?>" />
                                    </div>
                                </div>   
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                         <label><?php echo $welcome->loadPo('Any remarks by Saksham Sathi'); ?><span class="text-danger">*</span></label>
                                         <textarea name="pfu_csw_remarks" class="form-control" rows="5" id="pfu_csw_remarks" ><?php echo $value->pfu_csw_remarks; ?></textarea>
                                    </div>
                                </div> 
                            </div>  
                                                       
                        <?php
                    }
                    ?>      
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="EditFollowUp" ><?php echo $welcome->loadPo('Submit'); ?></button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/patient/showFollowUp/<?php echo $patient_id; ?>"><?php echo $welcome->loadPo('Cancel'); ?></a>
                </div>
            </form>
        </div><br><br>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    $(function() {
        $( "#pfu_patient_dob" ).datepicker({
            dateFormat : 'yy-mm-dd',
            changeMonth : true,
            changeYear : true,           
        });
        $( "#pfu_follow_up_visit" ).datepicker({
            dateFormat : 'yy-mm-dd',
            changeMonth : true,
            changeYear : true,           
        });
        $( "#pfu_next_follo_up_date" ).datepicker({
            dateFormat : 'yy-mm-dd',
            changeMonth : true,
            changeYear : true,           
        });
    });
</script>