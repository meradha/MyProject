<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Patient'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/patient"><?php echo $welcome->loadPo('Patient'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Patient View'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Patient Update</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/patient" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div> 
                    <ul class="nav nav-tabs">
                        <li id="t_link1" class="active"><a data-toggle="tab" href="#tab1"><?php echo $welcome->loadPo('Patient Profile'); ?></a></li>
                        <li id="t_link2"><a data-toggle="tab" href="#tab2"><?php echo $welcome->loadPo('Details of family members'); ?></a></li>
                        <li id="t_link3"><a data-toggle="tab" href="#tab3"><?php echo $welcome->loadPo('Patient disease status'); ?></a></li>
                        <li id="t_link4"><a data-toggle="tab" href="#tab4"><?php echo $welcome->loadPo('Counselling'); ?></a></li>
                        <li id="t_link5"><a data-toggle="tab" href="#tab5"><?php echo $welcome->loadPo('Caregiver registration'); ?></a></li>
                    </ul>
                    <div class="tab-content">
                        <!--****************** Patient Profile *******************-->
                        <div id="tab1" class="tab-pane fade in active"><br>
                            <?php
                            foreach ($patient_edit as $p_res) 
                            {
                                /******************* AMIT CODE *******************/ 
                                $fromRegAddress = $welcome->getAddressFromLatLng($p_res->patient_let,$p_res->patient_long);
                            if($fromRegAddress)
                            $fromRegAddress = $fromRegAddress;
                            else
                            $fromRegAddress = 'No Address Found';
                            
                                /*Get Permanent Address*/
                            $permanetAddress = $welcome->getAddressFromLatLng($p_res->patient_p_a_let,$p_res->patient_p_a_long);
                            if($permanetAddress)
                            $permanetAddress = $permanetAddress;
                            else
                            $permanetAddress = 'No Address Found';
                            
                          ?>
                            <script type="text/javascript">
                              var from_reg = [
                                <?php
                                  echo '['.$p_res->patient_let.','.$p_res->patient_long.',"'.'<p>Patient Name: '.$p_res->patient_name.
                                        '</p><p>Reg Address: '.$fromRegAddress.'</p>'.'","'.base_url('webroot/admin/upload/common_img/pen.png').'"],';
                                ?>
                              ];
                              var permanet_address = [
                                <?php
                                  echo '['.$p_res->patient_p_a_let.','.$p_res->patient_p_a_long .',"'.'<p>Patient Name: '.$p_res->patient_name.
                                        '</p><p>Permanent Address: '.$permanetAddress.'","'.base_url('webroot/admin/upload/common_img/home.png').'"],';
                                ?>
                              ];
                              
                              var current_address = [
                                <?php
                                  echo '['.$p_res->patient_c_a_let.','.$p_res->patient_c_a_long .',"'.'<p>Patient Name: '.$p_res->patient_name.
                                        '</p><p>Current Address: '.$p_res->patient_c_address.'","'.base_url('webroot/admin/upload/common_img/home.png').'"],';
                                ?>
                              ];
                             

                              function initialize() 
                              {
                                var myOptions = {
                                  center: new google.maps.LatLng(19.075984, 72.877656),
                                  zoom: 10,
                                  mapTypeId: google.maps.MapTypeId.ROADMAP
                                };
                                var map = new google.maps.Map(document.getElementById("map"), myOptions);
                                setMarkers(map,from_reg);
                                setMarkers(map,permanet_address);
                                setMarkers(map,current_address);
                              }

                              function setMarkers(map,locations)
                              {
                                var marker, i;

                              for (i = 0; i < locations.length; i++)
                              {  
                                var lat  = locations[i][0];
                                var long = locations[i][1];
                                var str =  locations[i][2];
                                var custom_icons = locations[i][3];
                                latlngset = new google.maps.LatLng(lat, long);

                                var marker = new google.maps.Marker({  
                                  map: map, title: str , position: latlngset,
                                  icon: custom_icons
                                });
                                map.setCenter(marker.getPosition())

                               
                                var infowindow = new google.maps.InfoWindow()
                                google.maps.event.addListener(marker,'click', (function(marker,str,infowindow){ 
                                  return function(){
                                    infowindow.setContent(str);
                                    infowindow.open(map,marker);
                                  };
                                })(marker,str,infowindow)); 
                              }
                            }
                             </script>
                             <script src="//maps.googleapis.com/maps/api/js?key=AIzaSyA47YEA7hkdrE6PJYe91NawcsmvW9DL3ss&callback=initialize" async defer></script>
                                                           
                                <!-- /******************* AMIT CODE *******************/  -->
                               
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Name of the patient'); ?> <span class="text-danger">*</span></label>
                                            <input type="text" id="patient_name" disabled name="patient_name" class="form-control" value="<?php echo $p_res->patient_name; ?>" />
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo("Patient's father's Name"); ?><span class="text-danger">*</span></label>
                                            <input type="text" id="patient_father_name" disabled name="patient_father_name" class="form-control" value="<?php echo $p_res->patient_father_name; ?>" />
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Date of birth'); ?><span class="text-danger">*</span></label>
                                            <div class='input-group'>
                                                <input type="text" class="form-control date_val" disabled name="patient_dob" id="patient_dob" value="<?php echo $p_res->patient_dob; ?>">
                                                <span class="input-group-addon">
                                                    <span class="glyphicon glyphicon-calendar"></span>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Age'); ?><span class="text-danger">*</span></label>
                                            <input type="number" id="patient_age" disabled name="patient_age" class="form-control" value="<?php echo $p_res->patient_age; ?>" min="0" />
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Contact Number'); ?><span class="text-danger">*</span></label>
                                            <input type="number" id="patient_contact_no" disabled name="patient_contact_no" class="form-control" min="0" value="<?php echo $p_res->patient_contact_no; ?>" />
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Alternate Contact Number'); ?><span class="text-danger">*</span></label>
                                            <input type="number" id="patient_alternat_contact_no" disabled name="patient_alternat_contact_no" class="form-control" min="0" value="<?php echo $p_res->patient_alternat_contact_no; ?>" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Present Country'); ?><span class="text-danger">*</span></label>
                                            <input disabled type="text" id="patient_c_country_id" disabled name="patient_c_country_id" class="form-control" value="India" />
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Present State'); ?><span class="text-danger">*</span></label>
                                            <input disabled type="text" id="patient_c_state_id" disabled name="patient_c_state_id" class="form-control" value="Maharashtra" />
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Present City'); ?><span class="text-danger">*</span></label>
                                            <input disabled type="text" id="patient_c_city" disabled name="patient_c_city" class="form-control" value="<?php echo $p_res->patient_c_city; ?>" />
                                        </div>
                                    </div>  
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Present Address(enter address in details as- house no., street no, location)'); ?><span class="text-danger">*</span></label>
                                            <textarea id="patient_c_address" disabled name="patient_c_address" class="form-control" ><?php echo $p_res->patient_c_address; ?></textarea>
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Present Landmark'); ?><span class="text-danger">*</span></label><br><br>
                                            <textarea id="patient_c_landmark"  disabled name="patient_c_landmark" class="form-control" ><?php echo $p_res->patient_c_landmark; ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Present Postal Code'); ?><span class="text-danger">*</span></label><br><br>
                                            <input type="number" id="patient_c_postal_code" disabled name="patient_c_postal_code" class="form-control" value="<?php echo $p_res->patient_c_postal_code; ?>" min="0" />
                                        </div>
                                    </div> 
                                </div>
                                 <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Permanent Country'); ?><span class="text-danger">*</span></label>
                                            <input disabled type="text" id="patient_c_country_id" disabled name="patient_c_country_id" class="form-control" value="India" />
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Permanent State'); ?><span class="text-danger">*</span></label>
                                            <select id="patient_p_state_id" disabled name="patient_p_state_id" class="form-control">
                                                <?php 
                                                    foreach ($state_list as $s_list)
                                                    {
                                                        ?>
                                                        <option <?php if($p_res->patient_p_state_id == $s_list->state_id){ echo "selected"; } ?> value="<?php echo $s_list->state_id; ?>"><?php echo $s_list->state_name; ?></option>
                                                        <?php
                                                    }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Permanent City'); ?><span class="text-danger">*</span></label>
                                            <input type="text" id="patient_p_city" disabled name="patient_p_city" class="form-control" value="<?php echo $p_res->patient_p_city; ?>" />
                                        </div>
                                    </div>  
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Permanent Address(enter address in details as- house no., street no, location)'); ?><span class="text-danger">*</span></label>
                                            <textarea id="patient_p_address" disabled name="patient_p_address" class="form-control" ><?php echo $p_res->patient_p_address; ?></textarea>
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Permanent Postal Code'); ?><span class="text-danger">*</span></label><br><br>
                                            <input type="number" id="patient_p_postal_code" disabled name="patient_p_postal_code" class="form-control" value="<?php echo $p_res->patient_p_postal_code; ?>" min="0" />
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Religion'); ?><span class="text-danger">*</span></label><br><br>
                                             <select class="form-control" disabled name="patient_religion" id="patient_religion"  onchange="addInputFieldSelectBox(this.value, 'patient_religion')">
                                                <option <?php if($p_res->patient_religion == 'Hindu'){ echo "selected"; } ?> value="Hindu"><?php echo $welcome->loadPo('Hindu'); ?></option>
                                                <option <?php if($p_res->patient_religion == 'Muslim'){ echo "selected"; } ?> value="Muslim"><?php echo $welcome->loadPo('Muslim'); ?></option>
                                                <option <?php if($p_res->patient_religion == 'Budhhist'){ echo "selected"; } ?> value="Budhhist"><?php echo $welcome->loadPo('Budhhist'); ?></option>
                                                <option <?php if($p_res->patient_religion == 'Christian'){ echo "selected"; } ?> value="Christian"><?php echo $welcome->loadPo('Christian'); ?></option>
                                                <option <?php if($p_res->patient_religion == 'Sikh'){ echo "selected"; } ?> value="Sikh"><?php echo $welcome->loadPo('Sikh'); ?></option>
                                                <option <?php if($p_res->patient_religion == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option>
                                            </select><br>
                                                <input type="text" style="<?php if($p_res->patient_religion == 'Other'){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="patient_religion_other" disabled name="patient_religion_other" class="form-control" value="<?php echo $p_res->patient_religion_other; ?>" />
                                        </div>
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Caste'); ?><span class="text-danger">*</span></label>
                                             <select class="form-control" disabled name="patient_caste" id="patient_caste" >
                                                <option <?php if($p_res->patient_caste == 'SC'){ echo "selected"; } ?> value="SC"><?php echo $welcome->loadPo('SC'); ?></option>
                                                <option <?php if($p_res->patient_caste == 'ST'){ echo "selected"; } ?> value="ST"><?php echo $welcome->loadPo('ST'); ?></option>
                                                <option <?php if($p_res->patient_caste == 'OBC'){ echo "selected"; } ?> value="OBC"><?php echo $welcome->loadPo('OBC'); ?></option>
                                                <option <?php if($p_res->patient_caste == 'General'){ echo "selected"; } ?> value="General"><?php echo $welcome->loadPo('General'); ?></option>
                                            </select>
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Aadhar Card Number'); ?><span class="text-danger">*</span></label>
                                            <input type="text" id="patient_aadhar_no" disabled name="patient_aadhar_no" class="form-control" value="<?php echo $p_res->patient_aadhar_no; ?>" />
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Ration Card Number'); ?><span class="text-danger">*</span></label>
                                            <input type="text" id="patient_ration_card_no" disabled name="patient_ration_card_no" class="form-control" value="<?php echo $p_res->patient_ration_card_no; ?>" />
                                        </div>
                                    </div>                                    
                                </div>
                                 <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Sex'); ?><span class="text-danger">*</span></label>
                                             <select id="patient_gender" disabled name="patient_gender" class="form-control">                                 
                                                <option <?php if($p_res->patient_gender == 'Male'){ echo "selected"; } ?> value="Male"><?php echo $welcome->loadPo('Male'); ?></option>                                   
                                                <option <?php if($p_res->patient_gender == 'Female'){ echo "selected"; } ?> value="Female"><?php echo $welcome->loadPo('Female'); ?></option>                                   
                                                <option <?php if($p_res->patient_gender == 'Transgender'){ echo "selected"; } ?> value="Transgender"><?php echo $welcome->loadPo('Transgender'); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Type of Locality'); ?><span class="text-danger">*</span></label>
                                             <select class="form-control" disabled name="patient_type_of_locality" id="patient_type_of_locality" onchange="addInputFieldSelectBox(this.value, 'patient_type_of_locality')" >
                                                <option <?php if($p_res->patient_type_of_locality == 'Slum'){ echo "selected"; } ?> value="Slum"><?php echo $welcome->loadPo('Slum'); ?></option>
                                                <option <?php if($p_res->patient_type_of_locality == 'Non-Slum'){ echo "selected"; } ?> value="Non-Slum"><?php echo $welcome->loadPo('Non-Slum'); ?></option>
                                                <option <?php if($p_res->patient_type_of_locality == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option>
                                            </select><br>
                                            <input type="text" style="<?php if($p_res->patient_type_of_locality == 'Other'){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="patient_type_of_locality_other" disabled name="patient_type_of_locality_other" class="form-control" value="<?php echo $p_res->patient_type_of_locality_other; ?>" />
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Education'); ?><span class="text-danger">*</span></label>
                                             <select class="form-control" disabled name="patient_education" id="patient_education" onchange="addInputFieldSelectBox(this.value, 'patient_education');">
                                                <option <?php if($p_res->patient_education == 'Illeterate'){ echo "selected"; } ?> value="Illeterate"><?php echo $welcome->loadPo('Illeterate'); ?></option>
                                                <option <?php if($p_res->patient_education == 'Primary(1st to 4th std)'){ echo "selected"; } ?> value="Primary(1st to 4th std)"><?php echo $welcome->loadPo('Primary(1st to 4th std)'); ?></option>           
                                                <option <?php if($p_res->patient_education == 'Secondary(5th to 9th std)'){ echo "selected"; } ?> value="Secondary(5th to 9th std)"><?php echo $welcome->loadPo('Secondary(5th to 9th std)'); ?></option>
                                                <option <?php if($p_res->patient_education == 'SSC(10th std. complete)'){ echo "selected"; } ?> value="SSC(10th std. complete)"><?php echo $welcome->loadPo('SSC(10th std. complete)'); ?></option>           
                                                <option <?php if($p_res->patient_education == 'HSC(12th std. complete)'){ echo "selected"; } ?> value="HSC(12th std. complete)"><?php echo $welcome->loadPo('HSC(12th std. complete)'); ?></option>           
                                                <option <?php if($p_res->patient_education == 'Certificate/Diploma course'){ echo "selected"; } ?> value="Certificate/Diploma course"><?php echo $welcome->loadPo('Certificate/Diploma course'); ?></option>
                                                <option <?php if($p_res->patient_education == 'Graduate'){ echo "selected"; } ?> value="Graduate"><?php echo $welcome->loadPo('Graduate'); ?></option>           
                                                <option <?php if($p_res->patient_education == 'Post Graduate'){ echo "selected"; } ?> value="Post Graduate"><?php echo $welcome->loadPo('Post Graduate'); ?></option>
                                                <option <?php if($p_res->patient_education == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option>           
                                            </select><br>
                                            <input type="text" style="<?php if($p_res->patient_education == 'Other'){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="patient_education_other" disabled name="patient_education_other" class="form-control" value="<?php echo $p_res->patient_education_other; ?>" />
                                        </div>
                                    </div> 
                                </div> 
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Current Working Status'); ?><span class="text-danger">*</span></label>
                                             <select class="form-control"  disabled name="patient_working_status" id="patient_working_status">
                                                <option <?php if($p_res->patient_working_status == 'Employed'){ echo "selected"; } ?> value="Employed"><?php echo $welcome->loadPo('Employed'); ?></option>
                                                <option <?php if($p_res->patient_working_status == 'Unemployed'){ echo "selected"; } ?> value="Unemployed"><?php echo $welcome->loadPo('Unemployed'); ?></option>           
                                            </select>
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('If employed, then employment Status'); ?><span class="text-danger">*</span></label>
                                             <select class="form-control"  disabled name="patient_employement_status" id="patient_employement_status">
                                                <option <?php if($p_res->patient_employement_status == 'Part Time'){ echo "selected"; } ?> value="Part Time"><?php echo $welcome->loadPo('Part Time'); ?></option>
                                                <option <?php if($p_res->patient_employement_status == 'Full Time'){ echo "selected"; } ?> value="Full Time"><?php echo $welcome->loadPo('Full Time'); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('If employed, Occupation of the patient'); ?><span class="text-danger">*</span></label>
                                             <select class="form-control"  disabled name="patient_occupation" id="patient_occupation" onchange="addInputFieldSelectBox(this.value, 'patient_occupation');">
                                                <option <?php if($p_res->patient_occupation == 'Service'){ echo "selected"; } ?> value="Service"><?php echo $welcome->loadPo('Service'); ?></option>
                                                <option <?php if($p_res->patient_occupation == 'Business'){ echo "selected"; } ?> value="Business"><?php echo $welcome->loadPo('Business'); ?></option>           
                                                <option <?php if($p_res->patient_occupation == 'Skilled worker'){ echo "selected"; } ?> value="Skilled worker"><?php echo $welcome->loadPo('Skilled worker'); ?></option>
                                                <option <?php if($p_res->patient_occupation == 'Unskilled worker'){ echo "selected"; } ?> value="Unskilled worker"><?php echo $welcome->loadPo('Unskilled worker'); ?></option> 
                                                <option <?php if($p_res->patient_occupation == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option>           
                                            </select><br>
                                            <input type="text" style="<?php if($p_res->patient_occupation == 'Other'){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="patient_occupation_other" disabled name="patient_occupation_other" class="form-control" value="<?php echo $p_res->patient_occupation_other; ?>" />
                                        </div>
                                    </div>  
                                </div> 
                                <div class="row"> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('If Unemployed, reasons'); ?><span class="text-danger">*</span></label>
                                             <select class="form-control"  disabled name="patient_unemployed_reason" id="patient_unemployed_reason" onchange="addInputFieldSelectBox(this.value, 'patient_unemployed_reason');">
                                               <option <?php if($p_res->patient_unemployed_reason == 'Was not working earlier'){ echo "selected"; } ?> value="Was not working earlier"><?php echo $welcome->loadPo('Was not working earlier'); ?></option>
                                                <option <?php if($p_res->patient_unemployed_reason == 'Voluntarily left work due to TB(illness)'){ echo "selected"; } ?> value="Voluntarily left work due to TB(illness)"><?php echo $welcome->loadPo('Voluntarily left work due to TB(illness)'); ?></option>
                                                <option <?php if($p_res->patient_unemployed_reason == 'Lost job due to TB disease'){ echo "selected"; } ?> value="Lost job due to TB disease"><?php echo $welcome->loadPo('Lost job due to TB disease'); ?></option>
                                                <option <?php if($p_res->patient_unemployed_reason == 'Student'){ echo "selected"; } ?> value="Student"><?php echo $welcome->loadPo('Student'); ?></option>
                                                <option <?php if($p_res->patient_unemployed_reason == 'Home Maker'){ echo "selected"; } ?> value="Home Maker"><?php echo $welcome->loadPo('Home Maker'); ?></option>
                                                <option <?php if($p_res->patient_unemployed_reason == 'Retired'){ echo "selected"; } ?> value="Retired"><?php echo $welcome->loadPo('Retired'); ?></option>
                                                <option <?php if($p_res->patient_unemployed_reason == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option>
                                            </select><br>
                                            <input type="text" style="<?php if($p_res->patient_unemployed_reason == 'Other'){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="patient_unemployed_reason_other" disabled name="patient_unemployed_reason_other" class="form-control" value="<?php echo $p_res->patient_unemployed_reason_other; ?>" />
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Staying With'); ?><span class="text-danger">*</span></label>
                                             <select class="form-control"  disabled name="patient_staying_with" id="patient_staying_with">     
                                                <option <?php if($p_res->patient_staying_with == 'Living alone'){ echo "selected"; } ?> value="Living alone"><?php echo $welcome->loadPo('Living alone'); ?></option>
                                                <option <?php if($p_res->patient_staying_with == 'Living with Family(with wife or one or more blood relative)'){ echo "selected"; } ?> value="Living with Family(with wife or one or more blood relative)"><?php echo $welcome->loadPo('Living with Family(with wife or one or more blood relative)'); ?></option>
                                                <option <?php if($p_res->patient_staying_with == 'With others or relative(anybody except blood relatives/friends/roommates/colleagues/hostelmates/dharmshala/foster home)'){ echo "selected"; } ?> value="With others or relative(anybody except blood relatives/friends/roommates/colleagues/hostelmates/dharmshala/foster home)"><?php echo $welcome->loadPo('With others or relative(anybody except blood relatives/friends/roommates/colleagues/hostelmates/dharmshala/foster home)'); ?></option>            
                                            </select>
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Total number of household members'); ?><span class="text-danger">*</span></label>
                                            <input disabled name="patient_total_house_member" class="form-control" type="number" id="patient_total_house_member" value="<?php echo $p_res->patient_total_house_member; ?>" min="0" />
                                        </div>
                                    </div> 
                                </div> 
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Total number of children < 6 in the household'); ?><span class="text-danger">*</span></label>
                                            <input disabled name="patient_total_children_less_6" class="form-control" type="number" id="patient_total_children_less_6" value="<?php echo $p_res->patient_total_children_less_6; ?>" min="0"  />
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Total number of earning members in the household'); ?><span class="text-danger">*</span></label>
                                            <input disabled name="patient_earning_house_member" class="form-control" type="number" id="patient_earning_house_member" value="<?php echo $p_res->patient_earning_house_member; ?>" min="0" />
                                        </div>
                                    </div>     
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Monthly family income from all sources'); ?><span class="text-danger">*</span></label>
                                             <select class="form-control"  disabled name="patient_family_income" id="patient_family_income"> 
                                                <option <?php if($p_res->patient_family_income == '<5000'){ echo "selected"; } ?> value="<5000"><5000</option>
                                                <option <?php if($p_res->patient_family_income == '5000 to 10000'){ echo "selected"; } ?> value="5000 to 10000">5000 <?php echo $welcome->loadPo('to'); ?> 10000</option>
                                                <option <?php if($p_res->patient_family_income == '10001 to 25000'){ echo "selected"; } ?> value="10001 to 25000">10001 <?php echo $welcome->loadPo('to'); ?> 25000</option>
                                                <option <?php if($p_res->patient_family_income == '25001 to 50000'){ echo "selected"; } ?> value="25001 to 50000">25001 <?php echo $welcome->loadPo('to'); ?> 50000</option>
                                                <option <?php if($p_res->patient_family_income == '50001 to 100000'){ echo "selected"; } ?> value="50001 to 100000">50001 <?php echo $welcome->loadPo('to'); ?> 100000</option>
                                                <option <?php if($p_res->patient_family_income == '>100000'){ echo "selected"; } ?> value=">100000">>100000</option>        
                                            </select>
                                        </div>
                                    </div> 
                                </div>
                                <div class="row">  
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Current Marital Status'); ?><span class="text-danger">*</span></label>
                                             <select class="form-control"  disabled name="patient_marital_status" id="patient_marital_status">     
                                                <option <?php if($p_res->patient_marital_status == 'Currently married'){ echo "selected"; } ?> value="Currently married"><?php echo $welcome->loadPo('Currently married'); ?></option>   
                                                <option <?php if($p_res->patient_marital_status == 'Married but gauna not performed'){ echo "selected"; } ?> value="Married but gauna not performed"><?php echo $welcome->loadPo('Married but gauna not performed'); ?></option>   
                                                <option <?php if($p_res->patient_marital_status == 'Divorced/Seperated/Deserted'){ echo "selected"; } ?> value="Divorced/Seperated/Deserted"><?php echo $welcome->loadPo('Divorced/Seperated/Deserted'); ?></option>   
                                                <option <?php if($p_res->patient_marital_status == 'Never Married'){ echo "selected"; } ?> value="Never Married"><?php echo $welcome->loadPo('Never Married'); ?></option>   
                                                <option <?php if($p_res->patient_marital_status == 'Widow/ Widower'){ echo "selected"; } ?> value="Widow/ Widower"><?php echo $welcome->loadPo('Widow/ Widower'); ?></option>  
                                            </select>
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Living in Mumbai'); ?><span class="text-danger">*</span></label>
                                             <select class="form-control"  disabled name="patient_living_in_mumbai" id="patient_living_in_mumbai"> 
                                                <option <?php if($p_res->patient_living_in_mumbai == 'Since Birth'){ echo "selected"; } ?> value="Since Birth"><?php echo $welcome->loadPo('Since Birth'); ?></option>  
                                                <option <?php if($p_res->patient_living_in_mumbai == '< 6 month'){ echo "selected"; } ?> value="< 6 month"><?php echo $welcome->loadPo('< 6 months'); ?></option>  
                                                <option <?php if($p_res->patient_living_in_mumbai == '> 6 months to 5 years'){ echo "selected"; } ?> value="> 6 months to 5 years"><?php echo $welcome->loadPo('> 6 months to 5 years'); ?>  </option>  
                                                <option <?php if($p_res->patient_living_in_mumbai == '>5 years to 10 years'){ echo "selected"; } ?> value=">5 years to 10 years"><?php echo $welcome->loadPo('> 5 years to 10 years'); ?> </option>  
                                                <option <?php if($p_res->patient_living_in_mumbai == '> 10 years'){ echo "selected"; } ?> value="> 10 years"><?php echo $welcome->loadPo('> 10 years'); ?> </option>  
                                            </select>
                                        </div>
                                    </div>  
                                </div>   
                                <div class="box-footer">
                                   <a id="tab_next2" class="btn btn-success btn-sm" data-toggle="tab" href="#tab2"><?php echo $welcome->loadPo('Next'); ?></a>
                                </div>
                                <?php
                            }
                            ?>                            
                        </div>
                        <!--****************** Patient Family *******************-->
                        <div id="tab2" class="tab-pane fade"><br>
                            <?php
                            foreach ($patient_family_edit as $fm_res) 
                            {
                               ?>
                                <div class="row col-md-12">
                                   <h3><?php echo $welcome->loadPo('Family Member'); ?></h3>
                                   <div class="form-group col-md-6">
                                      <div class="input text"><label><?php echo $welcome->loadPo('Name'); ?><span class="text-danger">*</span></label><input disabled name="pf_name_u[]" class="form-control" type="text" id="pf_name_u[]" value="<?php echo $fm_res->pf_name; ?>" /></div>
                                   </div>
                                   <div class="form-group col-md-6">
                                      <div class="input text"><label><?php echo $welcome->loadPo('Age'); ?><span class="text-danger">*</span></label><input disabled name="pf_age_u[]" class="form-control" type="number" min="0" id="pf_age_u[]" value="<?php echo $fm_res->pf_age; ?>" /></div>
                                   </div>
                                   <div class="form-group col-md-6">
                                      <div class="input text">
                                         <label><?php echo $welcome->loadPo('Sex'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="pf_sex_u[]" id="pf_sex_u[]">
                                            <option <?php if($fm_res->pf_sex == 'Male'){ echo "selected"; } ?> value="Male"><?php echo $welcome->loadPo('Male'); ?></option>
                                            <option <?php if($fm_res->pf_sex == 'Female'){ echo "selected"; } ?> value="Female"><?php echo $welcome->loadPo('Female'); ?></option>
                                            <option <?php if($fm_res->pf_sex == 'Transgender'){ echo "selected"; } ?> value="Transgender"><?php echo $welcome->loadPo('Transgender'); ?></option>
                                         </select>
                                      </div>
                                   </div>
                                   <div class="form-group col-md-6">
                                      <div class="input text"><label><?php echo $welcome->loadPo('Relationship with patient'); ?><span class="text-danger">*</span></label><input disabled name="pf_relationship_u[]" class="form-control" type="text" id="pf_relationship_u[]" value="<?php echo $fm_res->pf_relationship; ?>" /></div>
                                   </div>
                                   <div class="form-group col-md-6">
                                      <div class="input text">
                                         <label><?php echo $welcome->loadPo("Is this household member your caregiver?(a person who lives in the patient's household and provides direct care and support to the patient)"); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="pf_household_is_caregiver_u[]" id="pf_household_is_caregiver_u[]">
                                            <option <?php if($fm_res->pf_household_is_caregiver == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                            <option <?php if($fm_res->pf_household_is_caregiver == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                         </select>
                                      </div>
                                   </div>
                                   <div class="form-group col-md-6">
                                      <div class="input text">
                                         <label><?php echo $welcome->loadPo('Did the Household member have any history of TB before the patient was diagnosed with TB?'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="pf_household_history_tb_u[]" id="pf_household_history_tb_u[]">
                                            <option <?php if($fm_res->pf_household_history_tb == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                            <option <?php if($fm_res->pf_household_history_tb == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                         </select>
                                      </div>
                                   </div>
                                   <div class="form-group col-md-6">
                                      <div class="input text">
                                         <label><?php echo $welcome->loadPo('After the patient was diagnosed with TB, Household member ever got tested positive for TB, then has he/she started with treatment'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="pf_household_treatment_u[]" id="pf_household_treatment_u[]">
                                            <option <?php if($fm_res->pf_household_treatment == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                            <option <?php if($fm_res->pf_household_treatment == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                         </select>
                                      </div>
                                   </div>
                                </div>
                               <?php
                            }
                            ?>
                            <div class="row col-md-12">             
                                <div id="TextBoxesGroup"> <br>           
                                                             
                                </div> 
                            </div>
                            <div class="box-footer">
                                <a id="tab_previous1" class="btn btn-success btn-sm" data-toggle="tab" href="#tab1"><?php echo $welcome->loadPo('Previous'); ?></a>
                                <a id="tab_next3" class="btn btn-success btn-sm" data-toggle="tab" href="#tab3"><?php echo $welcome->loadPo('Next'); ?></a>
                            </div>
                        </div>
                        <!--****************** Patient TB *******************-->
                        <div id="tab3" class="tab-pane fade"><br>
                        <?php
                        foreach ($patient_tb_details_edit as $tb_res) 
                        {
                        ?>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Saksham Patient ID'); ?><span class="text-danger">*</span></label>
                                        <input readonly disabled name="patient_saksham_id" class="form-control" type="text" id="patient_saksham_id" value="<?php echo $tb_res->patient_saksham_id; ?>" />
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Date of Saksham registration'); ?><span class="text-danger">*</span></label>
                                        <div class='input-group'>
                                            <input type="text" class="form-control date_val" disabled name="ptb_saksham_registration_date" id="ptb_saksham_registration_date" value="<?php echo $tb_res->ptb_saksham_registration_date; ?>">
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Name of ward'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control" disabled name="ptb_name_ward" id="ptb_name_ward">       
                                            <option <?php if($tb_res->ptb_name_ward == 'M/East'){ echo "selected"; } ?> value="M/East"><?php echo $welcome->loadPo('M/East'); ?></option>  
                                            <option <?php if($tb_res->ptb_name_ward == 'M/West'){ echo "selected"; } ?> value="M/West"><?php echo $welcome->loadPo('M/West'); ?></option>  
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Patient Referred through'); ?><span class="text-danger">*</span></label><br><br>
                                        <select class="form-control"  disabled name="ptb_referral_type" id="ptb_referral_type">    
                                            <option <?php if($tb_res->ptb_referral_type == 'Self referral during community activity'){ echo "selected"; } ?> value="Self referral during community activity"><?php echo $welcome->loadPo('Self referral during community activity'); ?></option>            
                                            <option <?php if($tb_res->ptb_referral_type == 'Community referral'){ echo "selected"; } ?> value="Community referral"><?php echo $welcome->loadPo('Community referral'); ?></option>
                                            <option <?php if($tb_res->ptb_referral_type == 'Referral during active case finding'){ echo "selected"; } ?> value="Referral during active case finding"><?php echo $welcome->loadPo('Referral during active case finding'); ?></option>
                                            <option <?php if($tb_res->ptb_referral_type == 'Self referral during field visit'){ echo "selected"; } ?> value="Self referral during field visit"><?php echo $welcome->loadPo('Self referral during field visit'); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Patient has provided consent to share details about self and conselling'); ?><span class="text-danger">*</span></label>
                                        <select class="form-control"  disabled name="ptb_share_details_status" id="ptb_share_details_status">    
                                           <option <?php if($tb_res->ptb_share_details_status == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>  
                                            <option <?php if($tb_res->ptb_share_details_status == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                        </select>
                                    </div>
                                </div>   
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Patient has provided consent to meet household caregivers'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="ptb_consent_for_counselling_status" id="ptb_consent_for_counselling_status">  
                                            <option <?php if($tb_res->ptb_consent_for_counselling_status == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>  
                                            <option <?php if($tb_res->ptb_consent_for_counselling_status == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                        </select>
                                    </div>
                                </div>   
                            </div>  
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Place of registration'); ?><span class="text-danger">*</span></label><br><br>
                                         <select class="form-control"  disabled name="ptb_place_of_registration" id="ptb_place_of_registration" onchange="addInputFieldSelectBox(this.value, 'ptb_place_of_registration')"> 
                                            <option <?php if($tb_res->ptb_place_of_registration == 'Home'){ echo "selected"; } ?> value="Home"><?php echo $welcome->loadPo('Home'); ?></option>  
                                            <option <?php if($tb_res->ptb_place_of_registration == 'Health care institute'){ echo "selected"; } ?> value="Health care institute"><?php echo $welcome->loadPo('Health care institute'); ?></option>
                                            <option <?php if($tb_res->ptb_place_of_registration == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option>
                                        </select><br>
                                        <input type="text" style="<?php if($tb_res->ptb_place_of_registration == 'Other'){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="ptb_place_of_registration_other" disabled name="ptb_place_of_registration_other" class="form-control" value="<?php echo $tb_res->ptb_place_of_registration_other; ?>" />

                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Type of tuberculosis(As verified with patient card)'); ?><span class="text-danger">*</span></label><br><br>
                                         <select class="form-control"  disabled name="ptb_type_of_tb_by_card" id="ptb_type_of_tb_by_card">    
                                            <option <?php if($tb_res->ptb_type_of_tb_by_card == 'Pulmonary Tuberculosis'){ echo "selected"; } ?> value="Pulmonary Tuberculosis"><?php echo $welcome->loadPo('Pulmonary Tuberculosis'); ?></option>  
                                            <option <?php if($tb_res->ptb_type_of_tb_by_card == 'Extra Pulmonary Tuberculosis'){ echo "selected"; } ?> value="Extra Pulmonary Tuberculosis"><?php echo $welcome->loadPo('Extra Pulmonary Tuberculosis'); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If Extra-pulmonary, organ affected(As verified with patient card)'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="ptb_extra_organ_affected_by_card" class="form-control" type="text" id="ptb_extra_organ_affected_by_card" value="<?php echo $tb_res->ptb_extra_organ_affected_by_card; ?>" />
                                    </div>
                                </div>
                            </div>  
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Drug sensitive TB status(As verified with patient card)'); ?><span class="text-danger">*</span></label><br><br>
                                        <select class="form-control"  disabled name="ptb_drug_sensitive_status_by_card" id="ptb_drug_sensitive_status_by_card">
                                            <option <?php if($tb_res->ptb_drug_sensitive_status_by_card == ''){ echo "selected"; } ?> value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                            <option <?php if($tb_res->ptb_drug_sensitive_status_by_card == 'CAT-1'){ echo "selected"; } ?> value="CAT-1"><?php echo $welcome->loadPo('CAT-1'); ?></option>  
                                            <option <?php if($tb_res->ptb_drug_sensitive_status_by_card == 'CAT-2'){ echo "selected"; } ?> value="CAT-2"><?php echo $welcome->loadPo('CAT-2'); ?></option>
                                            <option <?php if($tb_res->ptb_drug_sensitive_status_by_card == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option>
                                        </select><br>
                                         <input type="text" style="<?php if($tb_res->ptb_drug_sensitive_status_by_card == 'Other'){ echo 'display: block'; }else{ echo 'display: none'; } ?> " id="ptb_drug_sensitive_status_by_card_other" disabled name="ptb_drug_sensitive_status_by_card_other" class="form-control" value="<?php $tb_res->ptb_drug_sensitive_status_by_card; ?>" />
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Current phase of treatment(As verified with patient card)'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="ptb_current_phase_of_treatment_card" id="ptb_current_phase_of_treatment_card">     
                                            <option <?php if($tb_res->ptb_current_phase_of_treatment_card == 'Intensive phase'){ echo "selected"; } ?> value="Intensive phase"><?php echo $welcome->loadPo('Intensive phase'); ?></option>  
                                            <option <?php if($tb_res->ptb_current_phase_of_treatment_card == 'Continuation phase'){ echo "selected"; } ?> value="Continuation phase"><?php echo $welcome->loadPo('Continuation phase'); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Name of the PHC/Health Post/Facility where the patient is taking treatment for DS TB'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="ptb_name_of_PHC" class="form-control" type="text" id="ptb_name_of_PHC" value="<?php echo $tb_res->ptb_name_of_PHC; ?>" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('PMDT Number of Patient'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="ptb_PMDT_no" class="form-control" type="text" id="ptb_PMDT_no" value="<?php echo $tb_res->ptb_PMDT_no; ?>" />
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('PMDT registration Date'); ?><span class="text-danger">*</span></label>
                                        <div class='input-group' >
                                            <input type="text" class="form-control date_val" disabled name="ptb_RNTCP_registration_date" id="ptb_RNTCP_registration_date" value="<?php echo $tb_res->ptb_RNTCP_registration_date; ?>">
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Patient DS TB diagnosed date'); ?><span class="text-danger">*</span></label>
                                        <div class='input-group' >
                                            <input type="text" class="form-control date_val" disabled name="ptb_diagnosis_date" id="ptb_diagnosis_date" value="<?php echo $tb_res->ptb_diagnosis_date; ?>">
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Patient DS TB treatment started on date'); ?><span class="text-danger">*</span></label>
                                        <div class='input-group '>
                                            <input type="text" class="form-control date_val" disabled name="ptb_start_treatment_date" id="ptb_start_treatment_date" value="<?php echo $tb_res->ptb_start_treatment_date; ?>">
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                    </div>
                                </div>  
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('History of TB Treatment'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="ptb_treatement_history" id="ptb_treatement_history">    
                                            <option <?php if($tb_res->ptb_treatement_history == 'New'){ echo "selected"; } ?> value="New"><?php echo $welcome->loadPo('New'); ?></option>  
                                            <option <?php if($tb_res->ptb_treatement_history == 'Recurrent TB case(treatment completed earlier)'){ echo "selected"; } ?> value="Recurrent TB case"><?php echo $welcome->loadPo('Recurrent TB case(treatment completed earlier)'); ?></option>  
                                            <option <?php if($tb_res->ptb_treatement_history == 'Treatment after failure'){ echo "selected"; } ?> value="Treatment after failure"><?php echo $welcome->loadPo('Treatment after failure'); ?></option>  
                                            <option <?php if($tb_res->ptb_treatement_history == 'Relapse'){ echo "selected"; } ?> value="Relapse"><?php echo $welcome->loadPo('Relapse'); ?></option>  
                                            <option <?php if($tb_res->ptb_treatement_history == 'Treatment after LFU/default LFU'){ echo "selected"; } ?> value="Treatment after LFU/default LFU"><?php echo $welcome->loadPo('Treatment after LFU/default LFU'); ?></option>  
                                            <option <?php if($tb_res->ptb_treatement_history == 'Transfer in'){ echo "selected"; } ?> value="Transfer in"><?php echo $welcome->loadPo('Transfer in'); ?></option>  
                                            <option <?php if($tb_res->ptb_treatement_history == 'Other previously treated patient'){ echo "selected"; } ?> value="Other previously treated patient"><?php echo $welcome->loadPo('Other previously treated patient'); ?></option>  
                                        </select>
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('HIV status'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="ptb_HIV_status" id="ptb_HIV_status">   
                                            <option <?php if($tb_res->ptb_HIV_status == 'Positive'){ echo "selected"; } ?> value="Positive"><?php echo $welcome->loadPo('Positive'); ?></option>  
                                            <option <?php if($tb_res->ptb_HIV_status == 'Negative'){ echo "selected"; } ?> value="Negative"><?php echo $welcome->loadPo('Negative'); ?></option> 
                                            <option <?php if($tb_res->ptb_HIV_status == "Don't know"){ echo "selected"; } ?> value="Don't know"><?php echo $welcome->loadPo("Don't know"); ?></option>  
                                        </select>
                                    </div>
                                </div> 
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If HIV positive, status of treatment'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="ptb_HIV_treatment_status" id="ptb_HIV_treatment_status">   
                                            <option <?php if($tb_res->ptb_HIV_treatment_status == 'Non ART'){ echo "selected"; } ?> value="Non ART"><?php echo $welcome->loadPo('Non ART'); ?></option>
                                            <option <?php if($tb_res->ptb_HIV_treatment_status == 'On ART'){ echo "selected"; } ?> value="On ART"><?php echo $welcome->loadPo('On ART'); ?></option> 
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Diabetes status of patient'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="ptb_diabetes_status" id="ptb_diabetes_status">   
                                            <option <?php if($tb_res->ptb_diabetes_status == 'Having diabetes'){ echo "selected"; } ?> value="Having diabetes"><?php echo $welcome->loadPo('Having diabetes'); ?></option>  
                                            <option <?php if($tb_res->ptb_diabetes_status == "Doesn't have diabetes"){ echo "selected"; } ?> value="Doesn't have diabetes"><?php echo $welcome->loadPo("Doesn't have diabetes"); ?></option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If diabetes, taking treatment for diabetes'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="ptb_diabetes_treatment_status" id="ptb_diabetes_treatment_status">    
                                            <option <?php if($tb_res->ptb_diabetes_treatment_status == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>  
                                            <option <?php if($tb_res->ptb_diabetes_treatment_status == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option> 
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If patient having any other disease mention'); ?><span class="text-danger">*</span></label>
                                        <textarea id="ptb_other_diseas" disabled name="ptb_other_diseas" class="form-control" ><?php echo $tb_res->ptb_other_diseas; ?></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <h3><u><?php echo $welcome->loadPo('Substance abuse'); ?></u></h3>
                                </div> 
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Self reported history of substance use'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control" disabled name="ptb_substance_abuse" id="ptb_substance_abuse" onchange="addInputFieldSelectBox(this.value, 'ptb_use_substance')">     
                                            <option <?php if($tb_res->ptb_substance_abuse == 'Alcohol consumption'){ echo "selected"; } ?> value="Alcohol consumption"><?php echo $welcome->loadPo('Alcohol consumption'); ?></option>  
                                            <option <?php if($tb_res->ptb_substance_abuse == 'Tobacco Chewing/Gutkha/Pan'){ echo "selected"; } ?> value="Tobacco Chewing / Gutkha/Pan"><?php echo $welcome->loadPo('Tobacco Chewing/Gutkha/Pan'); ?></option> 
                                            <option <?php if($tb_res->ptb_substance_abuse == 'Smoking'){ echo "selected"; } ?> value="Smoking"><?php echo $welcome->loadPo('Smoking'); ?></option> 
                                            <option <?php if($tb_res->ptb_substance_abuse == 'Drug addiction'){ echo "selected"; } ?> value="Drug addiction"><?php echo $welcome->loadPo('Drug addiction'); ?></option> 
                                            <option <?php if($tb_res->ptb_substance_abuse == 'No history'){ echo "selected"; } ?> value="No history"><?php echo $welcome->loadPo('No history'); ?></option> 
                                            <option <?php if($tb_res->ptb_substance_abuse == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option> 
                                        </select><br>
                                        <input type="text" style="<?php if($tb_res->ptb_substance_abuse == 'Other'){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="ptb_substance_abuse_other" disabled name="ptb_substance_abuse_other" class="form-control" value="<?php echo $tb_res->ptb_substance_abuse_other; ?>" />
                                    </div>
                                </div> 
                            </div>
                            <div class="box-footer">
                                <a id="tab_previous2" class="btn btn-success btn-sm" data-toggle="tab" href="#tab2"><?php echo $welcome->loadPo('Previous'); ?></a>
                                <a id="tab_next4" class="btn btn-success btn-sm" data-toggle="tab" href="#tab4"><?php echo $welcome->loadPo('Next'); ?></a>
                            </div>
                        </div>
                        <?php
                        }
                        ?>
                        <div id="tab4" class="tab-pane fade"><br>
                        <?php
                        foreach ($patient_tb_details_edit as $tb_res) 
                        {
                        ?>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Has Patient agreed to be visited at home'); ?><span class="text-danger">*</span></label><br><br>
                                         <select class="form-control"  disabled name="ptb_home_visit_status" id="ptb_home_visit_status">
                                            <option <?php if($tb_res->ptb_home_visit_status == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>  
                                            <option <?php if($tb_res->ptb_home_visit_status == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option> 
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Has Patient agreed to be visited at workplace/convenient place'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="ptb_worklace_status" id="ptb_worklace_status">   
                                            <option <?php if($tb_res->ptb_worklace_status == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>  
                                            <option <?php if($tb_res->ptb_worklace_status == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option> 
                                        </select>
                                    </div>
                                </div>
                            </div>  
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Counselling topics'); ?> <span class="text-danger">*</span></label><br>
                                        <?php
                                        $ptb_counselling_topics = explode(',', $tb_res->ptb_counselling_topics);                
                                        ?>
                                        <input <?php if(in_array('DS-TB treatment and Education',  $ptb_counselling_topics)){ echo "checked"; } ?> disabled name="ptb_counselling_topics[]" type="checkbox" id="ptb_counselling_topics[]" value="DS-TB treatment and Education" />&nbsp;&nbsp;<?php echo $welcome->loadPo('DS-TB treatment and Education'); ?><br/>
                                        <input <?php if(in_array('DS-TB treatment adherence',  $ptb_counselling_topics)){ echo "checked"; } ?> disabled name="ptb_counselling_topics[]" type="checkbox" id="ptb_counselling_topics[]" value="DS-TB treatment adherence" />&nbsp;&nbsp;<?php echo $welcome->loadPo('DS-TB treatment adherence'); ?><br/>
                                        <input <?php if(in_array('Cough hygiene and sputum disposal',  $ptb_counselling_topics)){ echo "checked"; } ?> disabled name="ptb_counselling_topics[]" type="checkbox" id="ptb_counselling_topics[]" value="Cough hygiene and sputum disposal" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Cough hygiene and sputum disposal'); ?><br/>
                                        <input <?php if(in_array('Substance abuse and De-addiction',  $ptb_counselling_topics)){ echo "checked"; } ?> disabled name="ptb_counselling_topics[]" type="checkbox" id="ptb_counselling_topics[]" value="Substance abuse and De-addiction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Substance abuse and De-addiction'); ?><br/>
                                        <input <?php if(in_array('Reproductive health related',  $ptb_counselling_topics)){ echo "checked"; } ?> disabled name="ptb_counselling_topics[]" type="checkbox" id="ptb_counselling_topics[]" value="Reproductive health related" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Reproductive health related'); ?><br/>
                                        <input <?php if(in_array('Role of Diet and Nutrition',  $ptb_counselling_topics)){ echo "checked"; } ?> disabled name="ptb_counselling_topics[]" type="checkbox" id="ptb_counselling_topics[]" value="Role of Diet and Nutrition" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Role of Diet and Nutrition'); ?><br/>
                                        <input <?php if(in_array('Adverse Drug Reactions',  $ptb_counselling_topics)){ echo "checked"; } ?> disabled name="ptb_counselling_topics[]" type="checkbox" id="ptb_counselling_topics[]" value="Adverse Drug Reactions" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Adverse Drug Reactions'); ?><br/>
                                        <input <?php if(in_array('Addressing Stigma and Discrimination',  $ptb_counselling_topics)){ echo "checked"; } ?> disabled name="ptb_counselling_topics[]" type="checkbox" id="ptb_counselling_topics[]" value="Addressing Stigma and Discrimination" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Addressing Stigma and Discrimination'); ?><br/>                          
                                        <input <?php if(in_array('Other',  $ptb_counselling_topics)){ echo "checked"; } ?> disabled name="ptb_counselling_topics[]" type="checkbox" id="ptb_counselling_topics[]" value="Other" onclick="addInputFieldCheckBox(this.value, 'pcg_counselling_topics')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                        <input type="text" style=" <?php if(in_array('Other',  $ptb_counselling_topics)){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="ptb_counselling_topics_other" disabled name="ptb_counselling_topics_other" class="form-control" value="<?php echo $tb_res->ptb_counselling_topics_other; ?>" />
                                    </div>
                                </div>   
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                         <label><?php echo $welcome->loadPo('Counselling tools used'); ?><span class="text-danger">*</span></label>
                                         <input disabled name="ptb_counselling_tool" class="form-control" type="text" id="ptb_counselling_tool" value="<?php echo $tb_res->ptb_counselling_tool; ?>"/>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo("Patient's need for referral/linkage identified"); ?><span class="text-danger">*</span></label>
                                         <select class="form-control"  disabled name="ptb_need_referral_linkage_identified" id="ptb_need_referral_linkage_identified"> 
                                            <option <?php if($tb_res->ptb_need_referral_linkage_identified == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>  
                                            <option <?php if($tb_res->ptb_need_referral_linkage_identified == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option> 
                                        </select>
                                    </div>
                                </div>  
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If referral made then referral services/linkages made towards'); ?><span class="text-danger">*</span></label><br>
                                        <?php
                                            $ptb_referral_service_linkage_towords = explode(',', $tb_res->ptb_referral_service_linkage_towords);
                                        ?>
                                        <input <?php if(in_array('Health services',  $ptb_referral_service_linkage_towords)){ echo "checked"; } ?>  disabled name="ptb_referral_service_linkage_towords[]" type="checkbox" id="ptb_referral_service_linkage_towords[]" value="Health services" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Health services'); ?><br/>
                                        <input <?php if(in_array('FU sputum',  $ptb_referral_service_linkage_towords)){ echo "checked"; } ?>  disabled name="ptb_referral_service_linkage_towords[]" type="checkbox" id="ptb_referral_service_linkage_towords[]" value="FU sputum" />&nbsp;&nbsp;<?php echo $welcome->loadPo('FU sputum'); ?><br/>
                                        <input <?php if(in_array('Mental helth professional',  $ptb_referral_service_linkage_towords)){ echo "checked"; } ?>  disabled name="ptb_referral_service_linkage_towords[]" type="checkbox" id="ptb_referral_service_linkage_towords[]" value="Mental helth professional" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Mental helth professional'); ?><br/>
                                        <input <?php if(in_array('Nutritional support',  $ptb_referral_service_linkage_towords)){ echo "checked"; } ?>  disabled name="ptb_referral_service_linkage_towords[]" type="checkbox" id="ptb_referral_service_linkage_towords[]" value="Nutritional support" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Nutritional support'); ?><br/>
                                        <input <?php if(in_array('Income generation scheme',  $ptb_referral_service_linkage_towords)){ echo "checked"; } ?>  disabled name="ptb_referral_service_linkage_towords[]" type="checkbox" id="ptb_referral_service_linkage_towords[]" value="Income generation scheme" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Income generation scheme'); ?><br/>
                                        <input <?php if(in_array('Social protection scheme= GOI',  $ptb_referral_service_linkage_towords)){ echo "checked"; } ?>  disabled name="ptb_referral_service_linkage_towords[]" type="checkbox" id="ptb_referral_service_linkage_towords[]" value="Social protection scheme= GOI" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Social protection scheme= GOI'); ?><br/>
                                        <input <?php if(in_array('NGO',  $ptb_referral_service_linkage_towords)){ echo "checked"; } ?>  disabled name="ptb_referral_service_linkage_towords[]" type="checkbox" id="ptb_referral_service_linkage_towords[]" value="NGO" />&nbsp;&nbsp;<?php echo $welcome->loadPo('NGO'); ?><br/>
                                        <input <?php if(in_array('Referral for ADR',  $ptb_referral_service_linkage_towords)){ echo "checked"; } ?>  disabled name="ptb_referral_service_linkage_towords[]" type="checkbox" id="ptb_referral_service_linkage_towords[]" value="Referral for ADR" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Referral for ADR'); ?><br/>
                                        <input <?php if(in_array('Livelihood',  $ptb_referral_service_linkage_towords)){ echo "checked"; } ?>  disabled name="ptb_referral_service_linkage_towords[]" type="checkbox" id="ptb_referral_service_linkage_towords[]" value="Livelihood" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Livelihood'); ?><br/>
                                        <input <?php if(in_array('Other',  $ptb_referral_service_linkage_towords)){ echo "checked"; } ?>  disabled name="ptb_referral_service_linkage_towords[]" type="checkbox" id="ptb_referral_service_linkage_towords[]" value="Others"  onclick="addInputFieldCheckBox(this.value, 'ptb_referral_service_linkage_towords')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                        <input type="text" style=" <?php if(in_array('Other',  $ptb_referral_service_linkage_towords)){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="ptb_referral_service_linkage_towords_other" disabled name="ptb_referral_service_linkage_towords_other" class="form-control" value="<?php echo $tb_res->ptb_referral_service_linkage_towords_other; ?>" />
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('If yes, specify name of referral agency'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="ptb_name_of_referred_agency" class="form-control" type="text" id="ptb_name_of_referred_agency" value="<?php echo $tb_res->ptb_name_of_referred_agency; ?>"/>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                         <label><?php echo $welcome->loadPo('CSW Remarks'); ?><span class="text-danger">*</span></label>
                                         <textarea disabled name="ptb_csw_remarks" class="form-control" rows="5" id="ptb_csw_remarks" ><?php echo $tb_res->ptb_csw_remarks; ?></textarea>
                                    </div>
                                </div>
                            </div> 
                            <div class="row">                                       
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Next folow up on'); ?><span class="text-danger">*</span></label>
                                         <div class='input-group' >
                                            <input type="text" class="form-control date_val" disabled name="ptb_next_follow_up_date" id="ptb_next_follow_up_date" value="<?php echo $tb_res->ptb_next_follow_up_date; ?>">
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                    </div>
                                </div> 
                                <div class="form-group col-md-4">
                                    <div class="bootstrap-timepicker">
                                        <div class="form-group">
                                            <label><?php echo $welcome->loadPo('Time of meeting(From)'); ?><span class="text-danger">*</span></label>
                                            <div class="input-group">
                                                <input disabled name="ptb_next_follow_up_time" class="form-control timepicker" type="text" id="ptb_next_follow_up_time" value="<?php echo $tb_res->ptb_next_follow_up_time; ?>" />
                                                <div class="input-group-addon">
                                                <i class="fa fa-clock-o"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>                                       
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Next follow up visit place'); ?><span class="text-danger">*</span></label>
                                         <select class="form-control" disabled name="ptb_next_follow_up_visit_place" id="ptb_next_follow_up_visit_place" onchange="addInputFieldSelectBox(this.value, ptb_next_follow_up_visit_place)">    
                                            <option <?php if($tb_res->ptb_next_follow_up_visit_place == 'Institution'){ echo "selected"; } ?> value="Institution"><?php echo $welcome->loadPo('Institution'); ?></option>  
                                            <option <?php if($tb_res->ptb_next_follow_up_visit_place == 'Home'){ echo "selected"; } ?> value="Home"><?php echo $welcome->loadPo('Home'); ?></option> 
                                            <option <?php if($tb_res->ptb_next_follow_up_visit_place == 'Workplace'){ echo "selected"; } ?> value="Workplace"><?php echo $welcome->loadPo('Workplace'); ?></option> 
                                            <option <?php if($tb_res->ptb_next_follow_up_visit_place == 'Community meeting'){ echo "selected"; } ?> value="Community meeting"><?php echo $welcome->loadPo('Community meeting'); ?></option> 
                                            <option <?php if($tb_res->ptb_next_follow_up_visit_place == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option> 
                                        </select><br>
                                        <input type="text" style=" <?php if($tb_res->ptb_next_follow_up_visit_place == 'Other'){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="ptb_next_follow_up_visit_place_other" disabled name="ptb_next_follow_up_visit_place_other" class="form-control" value="<?php echo $tb_res->ptb_next_follow_up_visit_place_other; ?>" />
                                    </div>
                                </div>                              
                            </div> 
                            <div class="box-footer">
                                <a id="tab_previous3" class="btn btn-success btn-sm" data-toggle="tab" href="#tab3"><?php echo $welcome->loadPo('Previous'); ?></a>
                                <a id="tab_next5" class="btn btn-success btn-sm" data-toggle="tab" href="#tab5"><?php echo $welcome->loadPo('Next'); ?></a>
                            </div>
                        <?php
                        }
                        ?>
                        </div>
                        <div id="tab5" class="tab-pane fade"><br>  
                            <?php
                            foreach ($patient_caregiver_edit as $cg_res) 
                            {
                                ?>
                                <div class="row">  
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Patient Name'); ?><span class="text-danger">*</span></label>
                                            <input disabled name="pcg_patient_name" class="form-control" type="text" id="pcg_patient_name" value="<?php echo $cg_res->pcg_patient_name; ?>" />
                                        </div>
                                    </div>  
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo("Patient's father's Name"); ?><span class="text-danger">*</span></label>
                                            <input disabled name="pcg_patient_father_name" class="form-control" type="text" id="pcg_patient_father_name" value="<?php echo $cg_res->pcg_patient_father_name; ?>" />
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo("Patient's Date of birth"); ?><span class="text-danger">*</span></label>
                                            <div class='input-group'>
                                                <input type="text" class="form-control date_val" disabled name="pcg_patient_dob" id="pcg_patient_dob" value="<?php echo $cg_res->pcg_patient_dob; ?>">
                                                <span class="input-group-addon">
                                                    <span class="glyphicon glyphicon-calendar"></span>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">  
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Saksham ID of Patient'); ?><span class="text-danger">*</span></label>
                                            <input disabled name="patient_saksham_id" class="form-control" type="text" id="patient_saksham_id" value="<?php echo $cg_res->patient_saksham_id; ?>" />
                                        </div>
                                    </div>  
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Date of caregiver registration'); ?><span class="text-danger">*</span></label>
                                            <div class='input-group' >
                                                <input type="text" class="form-control date_val" disabled name="pcg_date_of_registration" id="pcg_date_of_registration" value="<?php echo $cg_res->pcg_date_of_registration; ?>">
                                                <span class="input-group-addon">
                                                    <span class="glyphicon glyphicon-calendar"></span>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Place of Visit for Registration'); ?><span class="text-danger">*</span></label>
                                            <input disabled name="pcg_place_for_registration" class="form-control" type="text" id="pcg_place_for_registration" value="<?php echo $cg_res->pcg_place_for_registration; ?>" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Care giver has provided consent for counselling and to share details about self'); ?><span class="text-danger">*</span></label>
                                          <select class="form-control"  disabled name="pcg_share_detail_status" id="pcg_share_detail_status">        
                                                <option <?php if($cg_res->pcg_share_detail_status == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option> 
                                                <option <?php if($cg_res->pcg_share_detail_status == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option> 
                                            </select>
                                        </div>
                                    </div> 
                                </div>
                                 <div class="row">
                                    <div class="form-group col-md-4">
                                        <h3><u><?php echo $welcome->loadPo('Caregiver details'); ?></u></h3>
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Name of Caregiver'); ?><span class="text-danger">*</span></label>
                                            <input disabled name="pcg_caregiver_name" class="form-control" type="text" id="pcg_caregiver_name" value="<?php echo $cg_res->pcg_caregiver_name; ?>" />
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Relationship with Patient'); ?><span class="text-danger">*</span></label>
                                            <input disabled name="pcg_relationship_with_patient" class="form-control" type="text" id="pcg_relationship_with_patient" value="<?php echo $cg_res->pcg_relationship_with_patient; ?>" />
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Age of the caregiver'); ?><span class="text-danger">*</span></label>
                                            <input disabled name="pcg_caregiver_age" class="form-control" type="number" id="pcg_caregiver_age" value="<?php echo $cg_res->pcg_caregiver_age; ?>" min="0"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Sex of the caregiver'); ?><span class="text-danger">*</span></label>
                                          <select class="form-control"  disabled name="pcg_caregiver_gender" id="pcg_caregiver_gender">     
                                                <option <?php if($cg_res->pcg_caregiver_gender == 'Male'){ echo "selected"; } ?> value="Male"><?php echo $welcome->loadPo('Male'); ?></option> 
                                                <option <?php if($cg_res->pcg_caregiver_gender == 'Female'){ echo "selected"; } ?> value="Female"><?php echo $welcome->loadPo('Female'); ?></option> 
                                                <option <?php if($cg_res->pcg_caregiver_gender == 'Transgender'){ echo "selected"; } ?> value="Transgender"><?php echo $welcome->loadPo('Transgender'); ?></option> 
                                            </select>
                                        </div>
                                    </div>  
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <h3><u><?php echo $welcome->loadPo('Caregiver TB history'); ?></u></h3>
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Does care giver have any past history of TB'); ?><span class="text-danger">*</span></label><br><br>
                                          <select class="form-control" disabled name="pcg_past_history_of_TB" id="pcg_past_history_of_TB">    
                                                <option <?php if($cg_res->pcg_past_history_of_TB == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option> 
                                                <option <?php if($cg_res->pcg_past_history_of_TB == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option> 
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('If yes, Which type of TB did the caregiver suffer from?'); ?><span class="text-danger">*</span></label><br><br>
                                          <select class="form-control"  disabled name="pcg_suffer_from_TB" id="pcg_suffer_from_TB">      
                                                <option <?php if($cg_res->pcg_suffer_from_TB == 'Pulmonary TB'){ echo "selected"; } ?> value="Pulmonary TB"><?php echo $welcome->loadPo('Pulmonary TB'); ?></option> 
                                                <option <?php if($cg_res->pcg_suffer_from_TB == 'Extra Pulmonary TB'){ echo "selected"; } ?> value="Extra Pulmonary TB"> <?php echo $welcome->loadPo('Extra Pulmonary TB'); ?></option> 
                                                <option <?php if($cg_res->pcg_suffer_from_TB == "Don't know"){ echo "selected"; } ?> value="Don't know"><?php echo $welcome->loadPo("Don't know"); ?></option> 
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('If yes, Specify the category of TB which the caregiver had'); ?><span class="text-danger">*</span></label>
                                          <select class="form-control" disabled name="pcg_category_of_TB" id="pcg_category_of_TB">    
                                                <option <?php if($cg_res->pcg_category_of_TB == 'Category-1'){ echo "selected"; } ?> value="Category-1"><?php echo $welcome->loadPo('Category-1'); ?></option> 
                                                <option <?php if($cg_res->pcg_category_of_TB == 'Category-2'){ echo "selected"; } ?> value="Category-2"><?php echo $welcome->loadPo('Category-2'); ?></option> 
                                                <option <?php if($cg_res->pcg_category_of_TB == 'MDR'){ echo "selected"; } ?> value="MDR"><?php echo $welcome->loadPo('MDR'); ?></option> 
                                                <option <?php if($cg_res->pcg_category_of_TB == 'XDR'){ echo "selected"; } ?> value="XDR"><?php echo $welcome->loadPo('XDR'); ?></option> 
                                                <option <?php if($cg_res->pcg_category_of_TB == "Don't know"){ echo "selected"; } ?> value="Don't know"><?php echo $welcome->loadPo("Don't know"); ?></option> 
                                            </select>
                                        </div>
                                    </div>   
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo("If the caregiver had extra pulmonary TB, organ affected"); ?><span class="text-danger">*</span></label>
                                            <input disabled name="pcg_organ_affected_from_TB" class="form-control" type="text" id="pcg_organ_affected_from_TB" value="<?php echo $cg_res->pcg_organ_affected_from_TB; ?>" />
                                        </div>
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo("Specify the caregiver's TB treatments present outcome"); ?> <span class="text-danger">*</span></label><br>
                                            <?php
                                                $pcg_treatment_present_outcome = explode(',', $cg_res->pcg_treatment_present_outcome);
                                            ?>
                                            <input <?php if(in_array('Cure',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> disabled name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Cure" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Cure'); ?><br/>
                                            <input <?php if(in_array('Treatment completed',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> disabled name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Treatment completed" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Treatment completed'); ?><br/>
                                            <input <?php if(in_array('Treatment failed',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> disabled name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Treatment failed" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Treatment failed'); ?><br/>
                                            <input <?php if(in_array('Lost of Follow-Up',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> disabled name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Lost of Follow-Up" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Lost of Follow-Up'); ?><br/>
                                            <input <?php if(in_array('Not evaluated(Transfer out-RNTCP)',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> disabled name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Not evaluated(Transfer out-RNTCP)" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Not evaluated(Transfer out-RNTCP)'); ?><br/>
                                            <input <?php if(in_array('Treatment stopped due to ADR',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> disabled name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Treatment stopped due to ADR" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Treatment stopped due to ADR'); ?><br/>
                                            <input <?php if(in_array('Treatment regimen changed',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> disabled name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Treatment regimen changed" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Treatment regimen changed'); ?><br/>
                                            <input <?php if(in_array('Still on treatment',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> disabled name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Still on treatment" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Still on treatment'); ?><br/>
                                            <input <?php if(in_array("Don't know",  $pcg_treatment_present_outcome)){ echo "checked"; } ?> disabled name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Don't know"/>&nbsp;&nbsp;<?php echo $welcome->loadPo("Don't know"); ?><br/>                                               
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo("Caregiver's Self-reported history of substance abuse"); ?><span class="text-danger">*</span></label><br>
                                            <?php
                                                $pcg_self_substance_abuse = explode(',', $cg_res->pcg_self_substance_abuse);
                                            ?>
                                            <input <?php if(in_array('Ghutka',  $pcg_self_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Ghutka" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Ghutka'); ?><br/>
                                            <input <?php if(in_array('Pan',  $pcg_self_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Pan" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Pan'); ?><br/>
                                            <input <?php if(in_array('Tobacco',  $pcg_self_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Tobacco" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Tobacco'); ?><br/>
                                            <input <?php if(in_array('Smoking',  $pcg_self_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Smoking" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Smoking'); ?><br/>
                                            <input <?php if(in_array('Alcohol consumption',  $pcg_self_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Alcohol consumption" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Alcohol consumption'); ?><br/>
                                            <input <?php if(in_array('Drug addiction',  $pcg_self_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Drug addiction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Drug addiction'); ?><br/>
                                            <input <?php if(in_array('No history',  $pcg_self_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="No history" />&nbsp;&nbsp;<?php echo $welcome->loadPo('No history'); ?><br/>
                                            <input <?php if(in_array('Other',  $pcg_self_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_self_substance_abuse[]" type="checkbox" id="patient_city" value="Other" onclick="addInputFieldCheckBox(this.value, 'pcg_self_substance_abuse')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                            <input type="text" style="<?php if(in_array('No history',  $pcg_self_substance_abuse)){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="pcg_self_substance_abuse_other" disabled name="pcg_self_substance_abuse_other" class="form-control" value="<?php echo $cg_res->pcg_self_substance_abuse_other; ?>" />
                                        </div>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo("Caregiver's reported patient history of substance abuse"); ?><span class="text-danger">*</span></label><br>
                                            <?php
                                                $pcg_patient_substance_abuse = explode(',', $cg_res->pcg_patient_substance_abuse);
                                            ?>
                                            <input <?php if(in_array('Ghutka',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Ghutka" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Ghutka'); ?><br/>
                                            <input <?php if(in_array('Pan',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Pan" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Pan'); ?><br/>
                                            <input <?php if(in_array('Tobacco',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Tobacco" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Tobacco'); ?><br/>
                                            <input <?php if(in_array('Smoking',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Smoking" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Smoking'); ?><br/>
                                            <input <?php if(in_array('Alcohol consumption',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Alcohol consumption" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Alcohol consumption'); ?><br/>
                                            <input <?php if(in_array('Drug addiction',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Drug addiction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Drug addiction'); ?><br/>
                                            <input <?php if(in_array('No history',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="No history" />&nbsp;&nbsp;<?php echo $welcome->loadPo('No history'); ?><br/>
                                            <input <?php if(in_array('Other',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> disabled name="pcg_patient_substance_abuse[]" type="checkbox" id="patient_city" value="Other" onclick="addInputFieldCheckBox(this.value, 'pcg_patient_substance_abuse')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                            <input type="text" style="<?php if(in_array('No history',  $pcg_patient_substance_abuse)){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="pcg_patient_substance_abuse_other" disabled name="pcg_patient_substance_abuse_other" class="form-control" value="<?php echo $cg_res->pcg_patient_substance_abuse_other; ?>" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <h3><u><?php echo $welcome->loadPo('Counselling details'); ?></u></h3>
                                    </div> 
                                </div>
                                <div class="row">
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                            <label><?php echo $welcome->loadPo('Counselling topics '); ?><span class="text-danger">*</span></label><br>
                                            <?php
                                                $pcg_counselling_topics = explode(',', $cg_res->pcg_counselling_topics);
                                            ?>
                                            <input <?php if(in_array('DS-TB treatment and Education',  $pcg_counselling_topics)){ echo "checked"; } ?> disabled name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="DS-TB treatment and Education" />&nbsp;&nbsp;<?php echo $welcome->loadPo('DS-TB treatment and Education'); ?><br/>
                                            <input <?php if(in_array('DS-TB treatment adherence',  $pcg_counselling_topics)){ echo "checked"; } ?> disabled name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="DS-TB treatment adherence" />&nbsp;&nbsp;<?php echo $welcome->loadPo('DS-TB treatment adherence'); ?><br/>
                                            <input <?php if(in_array('Cough hygiene and sputum disposal',  $pcg_counselling_topics)){ echo "checked"; } ?> disabled name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Cough hygiene and sputum disposal" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Cough hygiene and sputum disposal'); ?><br/>
                                            <input <?php if(in_array('Substance abuse and De-addiction',  $pcg_counselling_topics)){ echo "checked"; } ?> disabled name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Substance abuse and De-addiction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Substance abuse and De-addiction'); ?><br/>
                                            <input <?php if(in_array('Reproductive health related',  $pcg_counselling_topics)){ echo "checked"; } ?> disabled name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Reproductive health related" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Reproductive health related'); ?><br/>
                                            <input <?php if(in_array('Role of Diet and Nutrition',  $pcg_counselling_topics)){ echo "checked"; } ?> disabled name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Role of Diet and Nutrition" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Role of Diet and Nutrition'); ?><br/>
                                            <input <?php if(in_array('Adverse Drug Reactions',  $pcg_counselling_topics)){ echo "checked"; } ?> disabled name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Adverse Drug Reactions" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Adverse Drug Reactions'); ?><br/>
                                            <input <?php if(in_array('Addressing Stigma and Discrimination',  $pcg_counselling_topics)){ echo "checked"; } ?> disabled name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Addressing Stigma and Discrimination" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Addressing Stigma and Discrimination'); ?><br/>
                                            <input <?php if(in_array('Role of family support in completing treatment',  $pcg_counselling_topics)){ echo "checked"; } ?> disabled name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Role of family support in completing treatment" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Role of family support in completing treatment'); ?><br/>
                                           <input <?php if(in_array('Other',  $pcg_counselling_topics)){ echo "checked"; } ?> disabled name="pcg_counselling_topics[]" type="checkbox" id="patient_city" value="Other" onclick="addInputFieldCheckBox(this.value, 'pcg_counselling_topics')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                            <input type="text" style="<?php if(in_array('No history',  $pcg_counselling_topics)){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="pcg_counselling_topics_other" disabled name="pcg_counselling_topics_other" class="form-control" value="<?php echo $cg_res->pcg_counselling_topics_other; ?>" />
                                        </div>
                                    </div> 
                                    <div class="form-group col-md-4">
                                        <div class="input text">
                                             <label><?php echo $welcome->loadPo('Saksham Sathi Remarks'); ?><span class="text-danger">*</span></label>
                                             <textarea disabled name="pcg_csw_remarks" class="form-control" rows="5" id="pcg_csw_remarks" ><?php echo $cg_res->pcg_csw_remarks; ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>                          
                            <div class="box-footer">
                                <a id="tab_previous4" class="btn btn-success btn-sm" data-toggle="tab" href="#tab4"><?php echo $welcome->loadPo('Previous'); ?></a>
                                <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/patient"><?php echo $welcome->loadPo('Cancel'); ?></a>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div id="map" style="height:500px;width: 100%;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>               
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->

<script type="text/javascript">

    $('#tab_next2').on('click', function(){
        $('#t_link2').addClass('active');
        $('#t_link1').removeClass('active');
        $('#t_link3').removeClass('active');
        $('#t_link4').removeClass('active');
        $('#t_link5').removeClass('active');
    });

    $('#tab_previous1').on('click', function(){
        $('#t_link1').addClass('active');
        $('#t_link2').removeClass('active');
        $('#t_link3').removeClass('active');
        $('#t_link4').removeClass('active');
        $('#t_link5').removeClass('active');
    });
    $('#tab_next3').on('click', function(){
        $('#t_link3').addClass('active');
        $('#t_link1').removeClass('active');
        $('#t_link2').removeClass('active');
        $('#t_link4').removeClass('active');
        $('#t_link5').removeClass('active');
    });

    $('#tab_previous2').on('click', function(){
        $('#t_link2').addClass('active');
        $('#t_link1').removeClass('active');
        $('#t_link3').removeClass('active');
        $('#t_link4').removeClass('active');
        $('#t_link5').removeClass('active');
    });
    $('#tab_next4').on('click', function(){
        $('#t_link4').addClass('active');
        $('#t_link1').removeClass('active');
        $('#t_link2').removeClass('active');
        $('#t_link3').removeClass('active');
        $('#t_link5').removeClass('active');
    });

    $('#tab_previous3').on('click', function(){
        $('#t_link3').addClass('active');
        $('#t_link1').removeClass('active');
        $('#t_link2').removeClass('active');
        $('#t_link4').removeClass('active');
        $('#t_link5').removeClass('active');
    });
    $('#tab_next5').on('click', function(){
        $('#t_link5').addClass('active');
        $('#t_link1').removeClass('active');
        $('#t_link2').removeClass('active');
        $('#t_link3').removeClass('active');
        $('#t_link4').removeClass('active');
    });

    $('#tab_previous4').on('click', function(){
        $('#t_link4').addClass('active');
        $('#t_link1').removeClass('active');
        $('#t_link2').removeClass('active');
        $('#t_link3').removeClass('active');
        $('#t_link5').removeClass('active');
    });

</script>