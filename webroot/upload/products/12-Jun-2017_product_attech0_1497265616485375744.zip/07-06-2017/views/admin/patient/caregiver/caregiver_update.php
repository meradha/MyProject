<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			<?php echo $welcome->loadPo('Patient caregiver'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/patient/caregiver/<?php echo $pp_id; ?>/<?php echo $patient_id; ?>"><?php echo $welcome->loadPo('Patient caregiver'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Patient caregiver Update'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
               <!--  <div class="pull-left">
                    <h3 class="box-title">Patient caregiver Update</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/patient/caregiver/<?php echo $pp_id; ?>/<?php echo $patient_id; ?>" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <div class="box-body">
                <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <?php
                    foreach ($patient_caregiver_edit as $cg_res) 
                    {
                        ?>
                        <div class="row">  
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Patient Name'); ?><span class="text-danger">*</span></label>
                                    <input readonly name="pcg_patient_name" class="form-control" type="text" id="pcg_patient_name" value="<?php echo $cg_res->pcg_patient_name; ?>" />
                                </div>
                            </div>  
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo("Patient's father's Name"); ?><span class="text-danger">*</span></label>
                                    <input readonly name="pcg_patient_father_name" class="form-control" type="text" id="pcg_patient_father_name" value="<?php echo $cg_res->pcg_patient_father_name; ?>" />
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo("Patient's Date of birth"); ?><span class="text-danger">*</span></label>
                                    <div class='input-group date_pic'>
                                        <input readonly type="text" class="form-control" name="pcg_patient_dob" id="pcg_patient_dob" value="<?php echo $cg_res->pcg_patient_dob; ?>">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">  
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Saksham ID of Patient'); ?><span class="text-danger">*</span></label>
                                    <input readonly name="patient_saksham_id" class="form-control" type="text" id="patient_saksham_id" value="<?php echo $cg_res->patient_saksham_id; ?>" />
                                </div>
                            </div>  
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Date of caregiver registration'); ?><span class="text-danger">*</span></label>
                                    <div class='input-group'>
                                        <input type="text" class="form-control date_val" name="pcg_date_of_registration" id="pcg_date_of_registration" value="<?php echo $cg_res->pcg_date_of_registration; ?>">
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Place of Visit for Registration'); ?><span class="text-danger">*</span></label>
                                    <input name="pcg_place_for_registration" class="form-control" type="text" id="pcg_place_for_registration" value="<?php echo $cg_res->pcg_place_for_registration; ?>" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Care giver has provided consent for counselling and to share details about self'); ?><span class="text-danger">*</span></label>
                                  <select class="form-control"  name="pcg_share_detail_status" id="pcg_share_detail_status">        
                                        <option <?php if($cg_res->pcg_share_detail_status == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option> 
                                        <option <?php if($cg_res->pcg_share_detail_status == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option> 
                                    </select>
                                </div>
                            </div> 
                        </div>
                         <div class="row">
                            <div class="form-group col-md-4">
                                <h3><u><?php echo $welcome->loadPo('Caregiver details'); ?></u></h3>
                            </div> 
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Name of Caregiver'); ?><span class="text-danger">*</span></label>
                                    <input name="pcg_caregiver_name" class="form-control" type="text" id="pcg_caregiver_name" value="<?php echo $cg_res->pcg_caregiver_name; ?>" />
                                </div>
                            </div> 
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Relationship with Patient'); ?><span class="text-danger">*</span></label>
                                    <input name="pcg_relationship_with_patient" class="form-control" type="text" id="pcg_relationship_with_patient" value="<?php echo $cg_res->pcg_relationship_with_patient; ?>" />
                                </div>
                            </div> 
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Age of the caregiver'); ?><span class="text-danger">*</span></label>
                                    <input name="pcg_caregiver_age" class="form-control" type="number" id="pcg_caregiver_age" value="<?php echo $cg_res->pcg_caregiver_age; ?>" min="0"/>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Sex of the caregiver'); ?><span class="text-danger">*</span></label>
                                  <select class="form-control"  name="pcg_caregiver_gender" id="pcg_caregiver_gender">     
                                        <option <?php if($cg_res->pcg_caregiver_gender == 'Male'){ echo "selected"; } ?> value="Male"><?php echo $welcome->loadPo('Male'); ?></option> 
                                        <option <?php if($cg_res->pcg_caregiver_gender == 'Female'){ echo "selected"; } ?> value="Female"><?php echo $welcome->loadPo('Female'); ?></option> 
                                        <option <?php if($cg_res->pcg_caregiver_gender == 'Transgender'){ echo "selected"; } ?> value="Transgender"><?php echo $welcome->loadPo('Transgender'); ?></option> 
                                    </select>
                                </div>
                            </div>  
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <h3><u><?php echo $welcome->loadPo('Caregiver TB history'); ?></u></h3>
                            </div> 
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Does care giver have any past history of TB'); ?><span class="text-danger">*</span></label>
                                  <select class="form-control" name="pcg_past_history_of_TB" id="pcg_past_history_of_TB">    
                                        <option <?php if($cg_res->pcg_past_history_of_TB == 'Yes'){ echo "selected"; } ?> value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option> 
                                        <option <?php if($cg_res->pcg_past_history_of_TB == 'No'){ echo "selected"; } ?> value="No"><?php echo $welcome->loadPo('No'); ?></option> 
                                    </select>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('If yes, Which type of TB did the caregiver suffer from?'); ?><span class="text-danger">*</span></label>
                                  <select class="form-control"  name="pcg_suffer_from_TB" id="pcg_suffer_from_TB">      
                                        <option <?php if($cg_res->pcg_suffer_from_TB == 'Pulmonary TB'){ echo "selected"; } ?> value="Pulmonary TB"><?php echo $welcome->loadPo('Pulmonary TB'); ?></option> 
                                        <option <?php if($cg_res->pcg_suffer_from_TB == 'Extra Pulmonary TB'){ echo "selected"; } ?> value="Extra Pulmonary TB"><?php echo $welcome->loadPo('Extra Pulmonary TB'); ?> </option> 
                                        <option <?php if($cg_res->pcg_suffer_from_TB == "Don't know"){ echo "selected"; } ?> value="Don't know"><?php echo $welcome->loadPo("Don't know"); ?></option> 
                                    </select>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('If yes, Specify the category of TB which the caregiver had'); ?><span class="text-danger">*</span></label>
                                  <select class="form-control" name="pcg_category_of_TB" id="pcg_category_of_TB">    
                                        <option <?php if($cg_res->pcg_category_of_TB == 'Category-1'){ echo "selected"; } ?> value="Category-1"><?php echo $welcome->loadPo('Category-1'); ?></option> 
                                        <option <?php if($cg_res->pcg_category_of_TB == 'Category-2'){ echo "selected"; } ?> value="Category-2"><?php echo $welcome->loadPo('Category-2'); ?></option> 
                                        <option <?php if($cg_res->pcg_category_of_TB == 'MDR'){ echo "selected"; } ?> value="MDR"><?php echo $welcome->loadPo('MDR'); ?></option> 
                                        <option <?php if($cg_res->pcg_category_of_TB == 'XDR'){ echo "selected"; } ?> value="XDR"><?php echo $welcome->loadPo('XDR'); ?></option> 
                                        <option <?php if($cg_res->pcg_category_of_TB == "Don't know"){ echo "selected"; } ?> value="Don't know"><?php echo $welcome->loadPo("Don't know"); ?></option> 
                                    </select>
                                </div>
                            </div>   
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('If the caregiver had extra pulmonary TB, organ affected'); ?><span class="text-danger">*</span></label>
                                    <input name="pcg_organ_affected_from_TB" class="form-control" type="text" id="pcg_organ_affected_from_TB" value="<?php echo $cg_res->pcg_organ_affected_from_TB; ?>" />
                                </div>
                            </div> 
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo("Specify the caregiver's TB treatments present outcome"); ?> <span class="text-danger">*</span></label><br>
                                    <?php
                                        $pcg_treatment_present_outcome = explode(',', $cg_res->pcg_treatment_present_outcome);
                                    ?>
                                    <input <?php if(in_array('Cure',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Cure" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Cure'); ?><br/>
                                    <input <?php if(in_array('Treatment completed',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Treatment completed" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Treatment completed'); ?><br/>
                                    <input <?php if(in_array('Treatment failed',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Treatment failed" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Treatment failed'); ?><br/>
                                    <input <?php if(in_array('Lost of Follow-Up',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Lost of Follow-Up" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Lost of Follow-Up'); ?><br/>
                                    <input <?php if(in_array('Not evaluated(Transfer out-RNTCP)',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Not evaluated(Transfer out-RNTCP)" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Not evaluated(Transfer out-RNTCP)'); ?><br/>
                                    <input <?php if(in_array('Treatment stopped due to ADR',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Treatment stopped due to ADR" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Treatment stopped due to ADR'); ?><br/>
                                    <input <?php if(in_array('Treatment regimen changed',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Treatment regimen changed" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Treatment regimen changed'); ?><br/>
                                    <input <?php if(in_array('Still on treatment',  $pcg_treatment_present_outcome)){ echo "checked"; } ?> name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Still on treatment" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Still on treatment'); ?><br/>
                                    <input <?php if(in_array("Don't know",  $pcg_treatment_present_outcome)){ echo "checked"; } ?> name="pcg_treatment_present_outcome[]" type="checkbox" id="pcg_treatment_present_outcome[]" value="Don't know"/>&nbsp;&nbsp;<?php echo $welcome->loadPo("Don't know"); ?><br/>                                               
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Caregivers Self-reported history of substance abuse'); ?><span class="text-danger">*</span></label><br>
                                    <?php
                                        $pcg_self_substance_abuse = explode(',', $cg_res->pcg_self_substance_abuse);
                                    ?>
                                    <input <?php if(in_array('Ghutka',  $pcg_self_substance_abuse)){ echo "checked"; } ?> name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Ghutka" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Ghutka'); ?><br/>
                                    <input <?php if(in_array('Pan',  $pcg_self_substance_abuse)){ echo "checked"; } ?> name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Pan" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Pan'); ?><br/>
                                    <input <?php if(in_array('Tobacco',  $pcg_self_substance_abuse)){ echo "checked"; } ?> name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Tobacco" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Tobacco'); ?><br/>
                                    <input <?php if(in_array('Smoking',  $pcg_self_substance_abuse)){ echo "checked"; } ?> name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Smoking" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Smoking'); ?><br/>
                                    <input <?php if(in_array('Alcohol consumption',  $pcg_self_substance_abuse)){ echo "checked"; } ?> name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Alcohol consumption" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Alcohol consumption'); ?><br/>
                                    <input <?php if(in_array('Drug addiction',  $pcg_self_substance_abuse)){ echo "checked"; } ?> name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="Drug addiction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Drug addiction'); ?><br/>
                                    <input <?php if(in_array('No history',  $pcg_self_substance_abuse)){ echo "checked"; } ?> name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse[]" value="No history" />&nbsp;&nbsp;<?php echo $welcome->loadPo('No history'); ?><br/>
                                    <input <?php if(in_array('Other',  $pcg_self_substance_abuse)){ echo "checked"; } ?> name="pcg_self_substance_abuse[]" type="checkbox" id="pcg_self_substance_abuse" value="Other" onclick="addInputFieldCheckBox(this.value, 'pcg_self_substance_abuse')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                    <input type="text" style="<?php if(in_array('Other',  $pcg_self_substance_abuse)){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="pcg_self_substance_abuse_other" name="pcg_self_substance_abuse_other" class="form-control" value="<?php echo $cg_res->pcg_self_substance_abuse_other; ?>" />
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Caregivers reported patient history of substance abuse'); ?><span class="text-danger">*</span></label><br>
                                    <?php
                                        $pcg_patient_substance_abuse = explode(',', $cg_res->pcg_patient_substance_abuse);
                                    ?>
                                    <input <?php if(in_array('Ghutka',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Ghutka" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Ghutka'); ?><br/>
                                    <input <?php if(in_array('Pan',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Pan" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Pan'); ?><br/>
                                    <input <?php if(in_array('Tobacco',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Tobacco" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Tobacco'); ?><br/>
                                    <input <?php if(in_array('Smoking',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Smoking" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Smoking'); ?><br/>
                                    <input <?php if(in_array('Alcohol consumption',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Alcohol consumption" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Alcohol consumption'); ?><br/>
                                    <input <?php if(in_array('Drug addiction',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="Drug addiction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Drug addiction'); ?><br/>
                                    <input <?php if(in_array('No history',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse[]" value="No history" />&nbsp;&nbsp;<?php echo $welcome->loadPo('No history'); ?><br/>
                                    <input <?php if(in_array('Other',  $pcg_patient_substance_abuse)){ echo "checked"; } ?> name="pcg_patient_substance_abuse[]" type="checkbox" id="pcg_patient_substance_abuse" value="Other" onclick="addInputFieldCheckBox(this.value, 'pcg_patient_substance_abuse')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                    <input type="text" style="<?php if(in_array('Other',  $pcg_patient_substance_abuse)){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="pcg_patient_substance_abuse_other" name="pcg_patient_substance_abuse_other" class="form-control" value="<?php echo $cg_res->pcg_patient_substance_abuse_other; ?>" />
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <h3><u><?php echo $welcome->loadPo('Counselling details'); ?></u></h3>
                            </div> 
                        </div>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Counselling topics'); ?> <span class="text-danger">*</span></label><br>
                                    <?php
                                        $pcg_counselling_topics = explode(',', $cg_res->pcg_counselling_topics);
                                    ?>
                                    <input <?php if(in_array('DS-TB treatment and Education',  $pcg_counselling_topics)){ echo "checked"; } ?> name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="DS-TB treatment and Education" />&nbsp;&nbsp;<?php echo $welcome->loadPo('DS-TB treatment and Education'); ?><br/>
                                    <input <?php if(in_array('DS-TB treatment adherence',  $pcg_counselling_topics)){ echo "checked"; } ?> name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="DS-TB treatment adherence" />&nbsp;&nbsp;<?php echo $welcome->loadPo('DS-TB treatment adherence'); ?><br/>
                                    <input <?php if(in_array('Cough hygiene and sputum disposal',  $pcg_counselling_topics)){ echo "checked"; } ?> name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Cough hygiene and sputum disposal" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Cough hygiene and sputum disposal'); ?><br/>
                                    <input <?php if(in_array('Substance abuse and De-addiction',  $pcg_counselling_topics)){ echo "checked"; } ?> name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Substance abuse and De-addiction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Substance abuse and De-addiction'); ?><br/>
                                    <input <?php if(in_array('Reproductive health related',  $pcg_counselling_topics)){ echo "checked"; } ?> name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Reproductive health related" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Reproductive health related'); ?><br/>
                                    <input <?php if(in_array('Role of Diet and Nutrition',  $pcg_counselling_topics)){ echo "checked"; } ?> name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Role of Diet and Nutrition" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Role of Diet and Nutrition'); ?><br/>
                                    <input <?php if(in_array('Adverse Drug Reactions',  $pcg_counselling_topics)){ echo "checked"; } ?> name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Adverse Drug Reactions" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Adverse Drug Reactions'); ?><br/>
                                    <input <?php if(in_array('Addressing Stigma and Discrimination',  $pcg_counselling_topics)){ echo "checked"; } ?> name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Addressing Stigma and Discrimination" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Addressing Stigma and Discrimination'); ?><br/>
                                    <input <?php if(in_array('Role of family support in completing treatment',  $pcg_counselling_topics)){ echo "checked"; } ?> name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics[]" value="Role of family support in completing treatment" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Role of family support in completing treatment'); ?><br/>
                                   <input <?php if(in_array('Other',  $pcg_counselling_topics)){ echo "checked"; } ?> name="pcg_counselling_topics[]" type="checkbox" id="pcg_counselling_topics" value="Other" onclick="addInputFieldCheckBox(this.value, 'pcg_counselling_topics')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                    <input type="text" style="<?php if(in_array('Other',  $pcg_counselling_topics)){ echo 'display: block'; }else{ echo 'display: none'; } ?>" id="pcg_counselling_topics_other" name="pcg_counselling_topics_other" class="form-control" value="<?php echo $cg_res->pcg_counselling_topics_other; ?>" />
                                </div>
                            </div> 
                            <div class="form-group col-md-4">
                                <div class="input text">
                                     <label><?php echo $welcome->loadPo('Saksham Sathi Remarks'); ?><span class="text-danger">*</span></label>
                                     <textarea name="pcg_csw_remarks" class="form-control" rows="5" id="pcg_csw_remarks" ><?php echo $cg_res->pcg_csw_remarks; ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Edit"><?php echo $welcome->loadPo('Submit'); ?></button>
                            <a class="btn btn-danger btn-sm" href="<?php echo base_url();?>admin/patient/caregiver/<?php echo $pp_id; ?>/<?php echo $patient_id; ?>"><?php echo $welcome->loadPo('Cancel'); ?></a>
                        </div>
                        <?php
                    }
                    ?>
                </form>
            </div>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->

<script type="text/javascript">
    $(function () {       
        $('.date_pic').datetimepicker({
            format: 'Y-M-D'
        });     
    });

  
    function addInputField(f_val, f_id)
    {
        if(f_val == 'Other')
        {
            $('#'+f_id+'_other').css('display', 'block');
        }
        else
        {
            $('#'+f_id+'_other').css('display', 'none');
        }
    }
  
</script>