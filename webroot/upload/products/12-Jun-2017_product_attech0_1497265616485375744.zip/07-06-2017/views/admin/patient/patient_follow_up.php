<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Patient follow-up'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Hindi'); ?>Home</a></li>
            <li class="active"><?php echo $welcome->loadPo('Patient follow-up'); ?></li>
        </ol>
    </section>   
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Patient Follow-up Details</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/patient/addPatientFollowUp/<?php echo $patient_id; ?>" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Add New'); ?></a>             
                </div>
            </div>           
            <!-- /.box-header -->
            <div class="box-body">
                <div>
                    <div id="msg_div">
                        <?php echo $this->session->flashdata('message');?>
                    </div>
                </div>
                <table id="example2" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th><?php echo $welcome->loadPo('Added By'); ?></th>
                            <th><?php echo $welcome->loadPo('Patient Name'); ?></th>
                            <th><?php echo $welcome->loadPo('Visit Number'); ?></th>
                            <th><?php echo $welcome->loadPo('Visit Place'); ?></th>
                            <th><?php echo $welcome->loadPo('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if(!empty($patient_followup_res))
                            {
                                foreach($patient_followup_res as $res)
                                {
                                    ?>
                                    <tr>
                                        <td><?php echo $res->added_by; ?></td>
                                        <td><?php echo $res->patient_name; ?></td>
                                        <td><?php echo $res->pfu_follow_up_visit_no; ?></td>
                                        <td><?php echo $res->pfu_visited_at; ?></td>                           
                                        <td>
                                            <?php
                                                foreach($getAllTabAsPerRole as $role)
                                                {
                                                    if($this->uri->segment(2) == $role->controller_name && $role->userEdit == '1')
                                                    {
                                                        ?>
                                                            <a href="<?php echo base_url();?>admin/patient/addPatientFollowUp/<?php echo $patient_id; ?>/<?php echo $res->pfu_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp;                
                                                        <?php
                                                    }
                                                    if($this->uri->segment(2) == $role->controller_name && $role->userDelete == '1')
                                                    {
                                                        ?>
                                                            <a class="confirm" onclick="return delete_patientFollowUp(<?php echo $patient_id; ?>,<?php echo $res->pfu_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>                                      
                                                        <?php
                                                    }
                                                }
                                            ?> &nbsp;&nbsp;  
                                            <a href="<?php echo base_url();?>admin/patient/showFollowUpView/<?php echo $patient_id; ?>/<?php echo $res->pfu_id; ?>"><i class="fa fa-eye fa-2x "></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            }
                            else
                            {
                                ?>
                                <tr>
                                    <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                </tr>
                                <?php
                            }
                            
                        ?>
                       
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function delete_patientFollowUp(patient_id, pfu_id)
    {
        bootbox.confirm("Are you sure you want to delete follow-up details",function(confirmed){
            if(confirmed)
            {
                location.href="<?php echo base_url();?>admin/patient/delete_patientFollowUp/"+patient_id+'/'+pfu_id;
            }
        });
    }    
</script>>