<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			<?php echo $welcome->loadPo('Knowledgebase'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/knowledgebase"><?php echo $welcome->loadPo('Knowledgebase'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Knowledgebase Add'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
               <!--  <div class="pull-left">
                    <h3 class="box-title">Knowledgebase Add</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/knowledgebase" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div> 
                
                    <div class="row">
                        <div class="form-group col-md-10">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Title'); ?><span class="text-danger">*</span></label>
                                <input name="kb_title" class="form-control" type="text" id="kb_title" value="<?php echo set_value('kb_title'); ?>" />
                                <?php echo form_error('kb_title','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                    </div>
                     <div class="row">
                        <div class="form-group col-md-10">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Description'); ?><span class="text-danger">*</span></label>
                                <textarea name="kb_description" rows="8" class="form-control" id="kb_description"></textarea>
                                <?php echo form_error('kb_description','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Images'); ?></label>
                                <input type="file" multiple name="kb_img[]" id="kb_img">
                                <?php echo form_error('kb_img','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>  
                        <div class="form-group col-md-12">
                            <div id="previewImg"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                             <label><?php echo $welcome->loadPo('Video URL'); ?></label>&nbsp;&nbsp;
                            <button class="btn btn-success btn-sm" type="button" id="add_spacification_box" ><i class="fa fa-plus"></i></button>
                            <button class="btn btn-danger btn-sm" type="button" style="margin-left: 20px; display: none;" id="removeButton"><i class="fa fa-remove"></i></button>
                            <input type="hidden" id="owners_validate" >
                        </div> 
                    </div>
                    <div class="row col-md-12">             
                        <div id="TextBoxesGroup"> <br>           
                                                     
                        </div> 
                    </div>
                  <!--   <div class="row">             
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php //echo $welcome->loadPo('Status'); ?></label>
                                <select name="kb_status" id="kb_status" class="form-control">
                                    <option value="">-- <?php //echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="1"><?php //echo $welcome->loadPo('Responsive'); ?></option>
                                    <option value="0"><?php //echo $welcome->loadPo('Unresponsive'); ?></option>
                                </select>
                                <?php //echo //form_error('kb_status','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div> -->
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Add" ><?php echo $welcome->loadPo('Submit'); ?></button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/knowledgebase"><?php echo $welcome->loadPo('Cancel'); ?></a>
                </div>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->

<script type="text/javascript">
    $("#kb_img").on("change", function (e) {
        var files = e.target.files,
        filesLength = files.length;
        for (var i = 0; i < filesLength; i++) 
        {
            var f = files[i]
            var fileReader = new FileReader();
            fileReader.onload = (function (e) {
                var file = e.target;
                var img = new Image();
                img.src = e.target.result;
                var res = null;
                img.onload = function() {                                                             
                    $("#previewImg").append("<div style='float:left;border:4px solid #303641;padding:5px;margin:5px;'><img height='80' src='" + e.target.result + "'></div>").insertAfter("#previewImg");
                }
            });
            fileReader.readAsDataURL(f);
        }
    });

    $(document).ready(function()
    {
        var counter = 0;
        $("#add_spacification_box").click(function () {
            $('#owners_validate').val('1');
            $('#removeButton').show();

            var newTextBoxDiv = $(document.createElement('div')).attr("id", 'TextBoxDiv' + counter);
            newTextBoxDiv.after().html('<div class="row"><div class="form-group col-md-8"><div class="input text">'+'<label>Video URL'+'</label><input name="kb_video[]" class="form-control" type="text" required id="kb_video"/></div></div></div>');
            newTextBoxDiv.appendTo("#TextBoxesGroup");        
            counter++;
        });

        $("#removeButton").click(function () {
            counter--;
            $("#TextBoxDiv" + counter).remove();         
            if(counter == 0){
                $('#removeButton').hide();
                $('#owners_validate').val('');
            }
        });
    });
    $(function () {       
        $('#user_dob').datetimepicker({
            format: 'Y-M-D'
        });    
    });

    function selectRole(role_id, user_role_id)
    {
        var user_rol_id = parseInt(user_role_id) + 1;
        //alert(user_rol_id);
        $('#p_user').show();
    }

    function getChildUser(user_id)
    {
        var role_id = $('#user_role_id').val();
        var str = 'user_id='+user_id+'&role_id='+role_id;
        var PAGE = '<?php echo base_url(); ?>admin/knowledgebase/getChildUser';

        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {
                // alert(data);
                // return false;
                if(data != "")
                {
                    $('#ch_user').html(data);
                }
                else
                {
                    $('#ch_user').html('<option value="">-- Select --</option>');
                }
            } 
        });
    }

     function getChildUser1(user_id, ref_id)
    {
        var role_id = $('#user_role_id').val();
        var str = 'user_id='+user_id+'&role_id='+role_id;
        var PAGE = '<?php echo base_url(); ?>admin/knowledgebase/getChildUser';       
        
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {
                if(data != "")
                {
                    $('#ch_user_'+ref_id).html(data);
                }
                else
                {
                    $('#ch_user_'+ref_id).remove();
                }
            } 
        });
    }
</script>