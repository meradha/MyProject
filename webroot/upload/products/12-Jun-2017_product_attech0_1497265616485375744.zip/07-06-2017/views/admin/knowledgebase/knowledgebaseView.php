<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Knowledgebase'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Knowledgebase'); ?></li>
        </ol>
    </section>   
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
               <!--  <div class="pull-left">
                    <h3 class="box-title">Knowledgebase Details</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/knowledgebase" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                 
                </div>
            </div>           
            <!-- /.box-header -->
            <div class="box-body">

                <?php 
                    foreach($knowledgebase_res as $value) 
                    {
                        ?>
                        <h3><?php echo $value->kb_title; ?></h3>
                        <br>
                         <h3><u><?php echo $welcome->loadPo('Images'); ?></u></h3>
                            <div class="row">
                            <?php
                                foreach ($img_video_res as $value_img) 
                                {
                                    if($value_img->kb_iv_type == 'IMAGE')
                                    {
                                    ?>
                                        <div class="col-md-3">
                                            <img class="img-responsive" src="<?php echo $value_img->kb_img_video; ?>">
                                        </div>
                                    <?php
                                    }
                                }
                            ?><br>
                            </div>
                            <br>
                            <h3><u><?php echo $welcome->loadPo('Description'); ?></u></h3><br>
                        <p><?php echo $value->kb_description; ?></p>
                       <?php 
                    }
                ?>    
               
                <h3><u><?php echo $welcome->loadPo('Video'); ?></u></h3>
                <div class="row">
                <?php
                    foreach ($img_video_res as $value_img) 
                    {
                        if($value_img->kb_iv_type == 'VIDEO')
                        {
                        ?>
                            <div class="col-md-10">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="<?php echo $value_img->kb_img_video;?>" width="500" height="200"></iframe>
                                </div>
                            </div>
                        <?php
                        }
                    }
                ?><br>
                </div>         
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>