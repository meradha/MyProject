<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Knowledgebase'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Knowledgebase'); ?></li>
        </ol>
    </section>   
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Knowledgebase Details</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <?php
                        foreach($getAllTabAsPerRole as $role)
                        {
                            if($this->uri->segment(2) == $role->controller_name && $role->userAdd == '1')
                            {
                                ?>
                                    <a href="<?php echo base_url();?>admin/knowledgebase/addKnowledgebase" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Add New'); ?></a>              
                                <?php
                            }
                        }
                    ?>                    
                </div>
            </div>           
            <!-- /.box-header -->
            <div class="box-body" style="display: inline-block;width: 100%;">
                <div>
                    <div id="msg_div">
                        <?php echo $this->session->flashdata('message');?>
                    </div>
                </div>
                <ul class="nav nav-tabs">
                    <?php
                    $user_role_id = $this->data['session'][0]->user_role_id;
                    if($user_role_id == '7')
                    {
                        ?>
                        <li class="active"><a data-toggle="tab" href="#approved_task"><?php echo $welcome->loadPo('Show Knowledgebase'); ?></a></li>
                        <?php
                    }
                    else
                    {
                        ?>
                        <li class="active"><a data-toggle="tab" href="#added_task"><?php echo $welcome->loadPo('Added Knowledgebase'); ?></a></li>
                        <li><a data-toggle="tab" href="#approved_task"><?php echo $welcome->loadPo('Show Knowledgebase'); ?></a></li>
                        <?php
                    }
                    ?>
                    
                </ul>

                <div class="tab-content">
                    <!-- ******************************************************************** -->
                    <?php
                    $user_role_id = $this->data['session'][0]->user_role_id;
                    if($user_role_id == '7')
                    {
                        ?>
                        <div id="approved_task" class="tab-pane fade in active"><br/>
                            <?php
                            if(!empty($knowledgebase_res))
                            {
                                $i=4;
                                foreach($knowledgebase_res as $res)
                                {
                                    $u_level = explode(',', $res->kb_assign_level);
                                    $user_id = $this->data['session'][0]->user_id;

                                    if(in_array($user_id, $u_level))
                                    {
                                        //echo $i ;

                                        if($i/4 == 0)
                                        {
                                            ?>
                                            <div class="row">
                                            <?php
                                        }
                                        ?>
                                            <div class="col-md-3">
                                                <div class="thumbnail">
                                                    <img src="<?php echo $res->kb_thumb_img; ?>" alt="Lights" style="width:100%">
                                                    <div class="caption">
                                                        <h4><?php echo $res->kb_title; ?></h4>
                                                        <p><?php echo substr($res->kb_title, 0, 500); ?></p>
                                                        <a href="<?php echo base_url(); ?>admin/knowledgebase/knowledgebaseView/<?php echo $res->kb_id; ?>">Read more...</a>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php
                                        if($i/4==0)
                                        {
                                            ?>
                                            </div>
                                            <?php
                                        }
                                        
                                     $i++;
                                    }
                                }
                                
                            }
                            else
                            {
                                ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="thumbnail">
                                            <div class="caption">
                                                <h4><?php echo $welcome->loadPo('No records found'); ?>...</h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }                           
                    }
                    else
                    {
                        ?>
                        <div id="added_task" class="tab-pane fade in active"><br/>
                            <table id="example2" class="table table-bordered table-striped">
                                <thead>
                                    <tr>                                       
                                        <th><?php echo $welcome->loadPo('Title'); ?></th>
                                        <th><?php echo $welcome->loadPo('Description'); ?></th>            
                                        <th><?php echo $welcome->loadPo('Action'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        if(!empty($add_knowledgebase_res))
                                        {
                                            foreach($add_knowledgebase_res as $res)
                                            {
                                                ?>
                                                <tr>
                                                    
                                                    <td><?php echo $res->kb_title; ?></td>
                                                    <td><?php echo substr($res->kb_description,0,250);  ?></td>                                                   
                                                    <td width="12%">
                                                        <?php
                                                            foreach($getAllTabAsPerRole as $role)
                                                            {
                                                                if($this->uri->segment(2) == $role->controller_name && $role->userEdit == '1')
                                                                {
                                                                    ?>
                                                                        <a href="<?php echo base_url();?>admin/knowledgebase/addKnowledgebase/<?php echo $res->kb_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp;                
                                                                    <?php
                                                                }
                                                                if($this->uri->segment(2) == $role->controller_name && $role->userDelete == '1')
                                                                {
                                                                    ?>
                                                                        <a class="confirm" onclick="return delete_knowledgebase(<?php echo $res->kb_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>                                      
                                                                    <?php
                                                                }
                                                            }
                                                        ?>  
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            ?>
                                            <tr>
                                                <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                            </tr>
                                            <?php
                                        }
                                        
                                    ?>
                                   
                                </tbody>
                            </table>
                        </div>
                        <div id="approved_task" class="tab-pane fade"><br/>
                            <?php
                                $i=4;
                                foreach($knowledgebase_res as $res1)
                                {
                                   ?>
                                            <div class="col-md-3">
                                                <div class="thumbnail">
                                                    <img src="<?php echo $res1->kb_thumb_img; ?>" alt="Lights" style="width:100%">
                                                    <div class="caption">
                                                        <h4><?php echo $res1->kb_title; ?></h4>
                                                        <p><?php echo substr($res1->kb_title, 0, 500); ?></p>
                                                        <a href="<?php echo base_url(); ?>admin/knowledgebase/knowledgebaseView/<?php echo $res1->kb_id; ?>">Read more...</a>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php
                                        if($i/4==0)
                                        {
                                            ?>
                                            </div>
                                            <?php
                                        
                                    }
                                 $i++;
                                }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                    
                </div>                
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function delete_knowledgebase(knowledgebase_id)
    {
        bootbox.confirm("Are you sure you want to delete knowledgebase details",function(confirmed){
            if(confirmed)
            {
                location.href="<?php echo base_url();?>admin/knowledgebase/delete_knowledgebase/"+knowledgebase_id;
            }
        });
    }    
</script>