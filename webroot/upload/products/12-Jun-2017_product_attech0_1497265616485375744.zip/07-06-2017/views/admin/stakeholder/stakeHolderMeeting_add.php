<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Stakeholder Meeting'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/stakeHolderMeeting/index/<?php echo $stakeholder_id; ?>"><?php echo $welcome->loadPo('Stakeholder Meeting'); ?> </a></li>
            <li class="active"><?php echo $welcome->loadPo('Stakeholder Meeting Add'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Stakeholder Meeting Add</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/stakeHolderMeeting/index/<?php echo $stakeholder_id; ?>" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <div class="box-body">
                     <!-- /.box-header -->
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div>                     
                    <div class="row col-md-12">
                        <h3><u><?php echo $welcome->loadPo("Stakeholder's information"); ?></u></h3>
                    </div>
                    <?php
                    if(!empty($stakeholder_id))
                    {
                        foreach ($stakeHolder_res as $value) 
                        {
                            ?>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo("Organization's Name"); ?><span class="text-danger">*</span></label>
                                        <input readonly class="form-control" value="<?php echo $value->stakeholder_name; ?>" />
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Name of the corresponding person'); ?><span class="text-danger">*</span></label>
                                        <input readonly class="form-control" value="<?php echo $value->stakeholder_correspondance_person; ?>" />
                                    </div>
                                </div>   
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Phone number of corresponding person'); ?><span class="text-danger">*</span></label>
                                        <input readonly class="form-control" value="<?php echo $value->stakeholder_phone; ?>" />
                                    </div>
                                </div> 
                            </div>
                            <?php
                        }
                    }
                    else
                    {
                        ?>
                        <div class="row">
                            <div class="form-group col-md-4">
                                <div class="input text">
                                    <label><?php echo $welcome->loadPo('Stakeholder Name'); ?><span class="text-danger">*</span></label> 
                                    <select onchange="getTotalNumberOfMeetingOrder(this.value);" name="stakeholder_id" id="stakeholder_id" class="form-control selectpicker">
                                        <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                        <?php
                                            foreach ($stakeHolder_res as $value) 
                                            {
                                                ?>
                                                <option value="<?php echo $value->stakeholder_id; ?>"><?php echo 

                                                $value->stakeholder_name; ?></option>
                                                <?php
                                            }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    
                    ?>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Number of participants in meeting'); ?><span class="text-danger">*</span></label>
                                <input name="shm_no_of_participants" class="form-control" type="text" id="shm_no_of_participants" value="<?php echo set_value('shm_no_of_participants'); ?>" />
                                <?php echo form_error('shm_no_of_participants','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>   
                        <div class="form-group col-md-8">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Location of the Meeting(With address)'); ?><span class="text-danger">*</span></label>
                                <textarea name="shm_meting_location" class="form-control" id="shm_meting_location" ></textarea>
                                <?php echo form_error('shm_meting_location','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>     
                    </div>  
                    <div class="row"> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Date of meeting'); ?><span class="text-danger">*</span></label>
                                <div class='input-group'>
                                <input type="text" class="form-control date_val" name="shm_meeting_date" id="shm_meeting_date" value="<?php echo set_value('shm_meeting_date'); ?>">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                                <?php echo form_error('shm_meeting_date','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="bootstrap-timepicker">
                                <div class="form-group">
                                    <label><?php echo $welcome->loadPo('Time of meeting(From)'); ?><span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <input name="shm_meeting_time_from" class="form-control timepicker" type="text" id="shm_meeting_time_from" value="<?php echo set_value('shm_meeting_time_from'); ?>" />
                                        <div class="input-group-addon">
                                        <i class="fa fa-clock-o"></i>
                                        </div>
                                    </div>
                                    <?php echo form_error('shm_meeting_time_from','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div>
                        </div>  
                        <div class="form-group col-md-4">
                            <div class="bootstrap-timepicker">
                                <div class="form-group">
                                    <label><?php echo $welcome->loadPo('Time of meeting(to)'); ?><span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <input name="shm_meeting_time_to" class="form-control timepicker" type="text" id="shm_meeting_time_to" value="<?php echo set_value('shm_meeting_time_to'); ?>" />
                                        <div class="input-group-addon">
                                        <i class="fa fa-clock-o"></i>
                                        </div>
                                    </div>
                                    <?php echo form_error('shm_meeting_time_to','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div>
                        </div>   
                    </div>
                    <div class="row col-md-12">
                        <h3><u><?php echo $welcome->loadPo('Details of Meeting'); ?></u></h3>
                    </div>
                    <div class="row"> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Sr. Number/ Order of meeting for this month'); ?><span class="text-danger">*</span></label>
                                <input readonly name="shm_order_of_meeting_this_month" class="form-control" type="text" id="shm_order_of_meeting_this_month" value="<?php if($this->uri->segment(4)){  if(!empty($stakeHolder_meeting_res)){ echo $stakeHolder_meeting_res[0]->shm_order_of_meeting_this_month + 1; }else{ echo '1'; } } ?>" />
                                <?php echo form_error('shm_order_of_meeting_this_month','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Have this stakeholder been met before this month'); ?><span class="text-danger">*</span></label>
                                <select onchange="getTotalNumberOfMeeting(this.value, 'shm_no_of_meeting_before_month')" name="shm_met_status_before_month" id="shm_met_status_before_month" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                    <option value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                </select>
                                <?php echo form_error('shm_met_status_before_month','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div style="display: none;" class="form-group col-md-4" id="shm_no_of_meeting_before_month_div">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('If yes, total number of meeting conducted before this month'); ?><span class="text-danger">*</span></label>
                                <input readonly name="shm_no_of_meeting_before_month" class="form-control" type="text" id="shm_no_of_meeting_before_month" value="<?php echo set_value('shm_no_of_meeting_before_month'); ?>" />
                                <?php echo form_error('shm_no_of_meeting_before_month','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-12">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Agenda/ Purpose of the meeting'); ?><span class="text-danger">*</span></label><br/>
                                <input class="aa" name="shm_purpose_of_meeting[]" type="checkbox" id="shm_purpose_of_meeting[]" value="Introduction of self, Introduction of project, Repport building with stakeholder" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Introduction of self, Introduction of project, Repport building with stakeholder'); ?><br/>
                                
                                <input class="aa"  name="shm_purpose_of_meeting[]" type="checkbox" id="shm_purpose_of_meeting[]" value="Assessment of stakeholder profile and community profile in detail" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Assessment of stakeholder profile and community profile in detail'); ?><br/>

                                <input  class="aa" name="shm_purpose_of_meeting[]" type="checkbox" id="shm_purpose_of_meeting[]" value="Introduction of TB details, Magnitude and vulnerability of M-ward for tuberculosis and available BMC infrastructure for TB diagnosis, treatment and referral facilities" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Introduction of TB details, Magnitude and vulnerability of M-ward for tuberculosis and available BMC infrastructure for TB diagnosis, treatment and referral facilities'); ?><br/>

                                <input  class="aa" name="shm_purpose_of_meeting[]" type="checkbox" id="shm_purpose_of_meeting[]" value="Community event planning and resource planning" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Community event planning and resource planning'); ?><br/>

                                <input  class="aa" name="shm_purpose_of_meeting[]" type="checkbox" id="shm_purpose_of_meeting[]" value="Follow up for the community referral" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Follow up for the community referral'); ?><br/>

                                <input  class="aa" name="shm_purpose_of_meeting[]" type="checkbox" id="shm_purpose_of_meeting[]" value="Planning of next meeting and agendas" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Planning of next meeting and agendas'); ?><br/>

                                <input  class="aa" name="shm_purpose_of_meeting[]" type="checkbox" id="shm_purpose_of_meeting" value="Other" onclick="addInputFieldCheckBox(this.value, 'shm_purpose_of_meeting')"/>&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/> 

                                <input type="text" style="display: none" id="shm_purpose_of_meeting_other" name="shm_purpose_of_meeting_other" class="form-control" value="" />                                     
                                <?php echo form_error('shm_purpose_of_meeting[]','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>  
                    </div>
                    <div class="row">
                        <div class="form-group col-md-12">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Points of discussion'); ?><span class="text-danger">*</span></label><br/>

                                <input name="shm_point_of_discussion[]" type="checkbox" id="shm_point_of_discussion[]" value="Self Introduction" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Self Introduction'); ?><br/>
                                
                                <input name="shm_point_of_discussion[]" type="checkbox" id="shm_point_of_discussion[]" value="Introduction about saksham, Objective of Saksham JU and Repport building" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Introduction about saksham, Objective of Saksham JU and Repport building'); ?><br/>
                                
                                <input name="shm_point_of_discussion[]" type="checkbox" id="shm_point_of_discussion[]" value="Understanding the role of stakeholder in the community, our expectations from them in TB prevention, treatment, referral and linking patients to social protection scheme" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Understanding the role of stakeholder in the community, our expectations from them in TB prevention, treatment, referral and linking patients to social protection scheme'); ?><br/>
                                
                                <input name="shm_point_of_discussion[]" type="checkbox" id="shm_point_of_discussion[]" value="Introduction about TB as illness, Signs, Symptoms, Mode of transmission, Prevention methods, treatment details" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Introduction about TB as illness, Signs, Symptoms, Mode of transmission, Prevention methods, treatment details'); ?><br/>
                                
                                <input name="shm_point_of_discussion[]" type="checkbox" id="shm_point_of_discussion[]" value="Introduction about drug sensitive and drug resistance TB(MDR, TDR,XDR)" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Introduction about drug sensitive and drug resistance TB(MDR, TDR,XDR)'); ?><br/>
                                
                                <input name="shm_point_of_discussion[]" type="checkbox" id="shm_point_of_discussion[]" value="Myths and Misconception and sigma related to disease in the society" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Myths and Misconception and sigma related to disease in the society'); ?><br/>
                                
                                <input name="shm_point_of_discussion[]" type="checkbox" id="shm_point_of_discussion[]" value="Introduction about available diagnostic and treatment facilities within the area, awareness about how to access lab and TU services, Awareness about right procedure for availing the public health facilities" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Introduction about available diagnostic and treatment facilities within the area, awareness about how to access lab and TU services, Awareness about right procedure for availing the public health facilities'); ?><br/>
                                
                                <input name="shm_point_of_discussion[]" type="checkbox" id="shm_point_of_discussion[]" value="Importance of sanitation and home based care to be taken" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Importance of sanitation and home based care to be taken'); ?><br/>
                                
                                <input name="shm_point_of_discussion[]" type="checkbox" id="shm_point_of_discussion[]" value="Activities carried out by Jan Urja and discussion on partnership for conducting community activities and community referral of the TB patient through referral slips" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Activities carried out by Jan Urja and discussion on partnership for conducting community activities and community referral of the TB patient through referral slips'); ?><br/>
                                
                                <input name="shm_point_of_discussion[]" type="checkbox" id="shm_point_of_discussion[]" value="Planning of community activities on particular occasion and place and discussion on resources and help from the stakeholder" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Planning of community activities on particular occasion and place and discussion on resources and help from the stakeholder'); ?><br/>
                                
                                <input name="shm_point_of_discussion[]" type="checkbox" id="shm_point_of_discussion" value="Other" onclick="addInputFieldCheckBox(this.value, 'shm_point_of_discussion')"/>&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>

                                <input type="text" style="display: none" id="shm_point_of_discussion_other" name="shm_point_of_discussion_other" class="form-control" value="" />                                     
                                <?php echo form_error('shm_point_of_discussion[]','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row col-md-12">
                        <h3><u><?php echo $welcome->loadPo('Evaluation of meeting'); ?></u></h3>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Stayed on track with agenda'); ?><span class="text-danger">*</span></label>
                                <select onchange="getVal()" name="shm_track_with_agenda" id="shm_track_with_agenda" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                    <option value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                </select>
                                <?php echo form_error('shm_track_with_agenda','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Everyone participated in meeting'); ?><span class="text-danger">*</span></label>
                                <select name="shm_participated_status" id="shm_participated_status" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                    <option value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                </select>
                                <?php echo form_error('shm_participated_status','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Achieved purpose of the meeting'); ?><span class="text-danger">*</span></label>
                                <select name="shm_achived_purpose" id="shm_achived_purpose" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                    <option value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                </select>
                                <?php echo form_error('shm_achived_purpose','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Clarified next steps'); ?><span class="text-danger">*</span></label>
                                <select name="shm_clearified_next_step" id="shm_clearified_next_step" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                    <option value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                </select>
                                <?php echo form_error('shm_clearified_next_step','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                         <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Stackholder responsive and affirmed to work with Saksham-JU'); ?><span class="text-danger">*</span></label>
                                <select name="shm_stakeholde_work_status" id="shm_stakeholde_work_status" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                    <option value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                </select>
                                <?php echo form_error('shm_stakeholde_work_status','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                         <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('This meeting was time writh spent'); ?><span class="text-danger">*</span></label>
                                <select name="shm_meeting_time_wroth_spent" id="shm_meeting_time_wroth_spent" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                    <option value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                </select>
                                <?php echo form_error('shm_meeting_time_wroth_spent','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row col-md-12">
                        <h3><u><?php echo $welcome->loadPo('Rating of Stakeholder'); ?></u></h3>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Power'); ?><span class="text-danger">*</span></label>
                                <select name="shm_power" id="shm_power" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Low"><?php echo $welcome->loadPo('Low'); ?></option>
                                    <option value="High"><?php echo $welcome->loadPo('High'); ?></option>
                                </select>
                                <?php echo form_error('shm_power','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Interest'); ?><span class="text-danger">*</span></label>
                                <select name="shm_interest" id="shm_interest" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Low"><?php echo $welcome->loadPo('Low'); ?></option>
                                    <option value="High"><?php echo $welcome->loadPo('High'); ?></option>
                                </select>
                                <?php echo form_error('shm_interest','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Based on above rating, classification of organization as'); ?> <span class="text-danger">*</span></label>
                                <select name="shm_organization_classified" id="shm_organization_classified" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="High power, High interest"><?php echo $welcome->loadPo('High power, High interest'); ?></option>
                                    <option value="High power, Low interest"><?php echo $welcome->loadPo('High power, Low interest'); ?></option>
                                    <option value="Low power, High interest"><?php echo $welcome->loadPo('Low power, High interest'); ?></option>
                                    <option value="Low power, Low interest"><?php echo $welcome->loadPo('Low power, Low interest'); ?></option>
                                </select>
                                <?php echo form_error('shm_organization_classified','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row col-md-12">
                        <h3><u><?php echo $welcome->loadPo('Affiliation with Social protection scheme'); ?></u></h3>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Affiliation with any social protection scheme?'); ?><span class="text-danger">*</span></label>
                                <select name="shm_application_social_protection_scheme_status" id="shm_application_social_protection_scheme_status" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="Yes"><?php echo $welcome->loadPo('Yes'); ?></option>
                                    <option value="No"><?php echo $welcome->loadPo('No'); ?></option>
                                </select>
                                <?php echo form_error('shm_application_social_protection_scheme_status','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('if yes, mention them'); ?><span class="text-danger">*</span></label>
                                <textarea name="shm_application_social_protection_scheme" class="form-control" id="shm_application_social_protection_scheme" ></textarea>
                                <?php echo form_error('shm_application_social_protection_scheme','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                    </div>
                    <div class="row col-md-12">
                        <h3><u><?php echo $welcome->loadPo('Planning of next meeting'); ?></u></h3>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Purpose of next meeting'); ?><span class="text-danger">*</span></label>
                                <textarea name="shm_purpose_of_next_meeting" class="form-control" id="shm_purpose_of_next_meeting" ></textarea>
                                <?php echo form_error('shm_purpose_of_next_meeting','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Probable date of next meeting'); ?><span class="text-danger">*</span></label>
                                <div class='input-group' >
                                <input type="text" class="form-control date_val" name="shm_date_of_next_meeting" id="shm_date_of_next_meeting" value="<?php echo set_value('shm_date_of_next_meeting'); ?>">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                                <?php echo form_error('shm_date_of_next_meeting','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="bootstrap-timepicker">
                                <div class="form-group">
                                    <label><?php echo $welcome->loadPo('Probable time of next meeting'); ?><span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <input name="shm_time_of_next_meeting" class="form-control timepicker" type="text" id="shm_time_of_next_meeting" value="<?php echo set_value('shm_time_of_next_meeting'); ?>" />
                                        <div class="input-group-addon">
                                        <i class="fa fa-clock-o"></i>
                                        </div>
                                    </div>
                                    <?php echo form_error('shm_time_of_next_meeting','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row col-md-12">
                        <h3><u><?php echo $welcome->loadPo('Details, if any community activity is planned in collaboration with stakeholder'); ?></u></h3>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Date of community activity'); ?><span class="text-danger">*</span></label>
                                <div class='input-group'>
                                <input type="text" class="form-control date_val" name="shm_date_of_community_activity" id="shm_date_of_community_activity" value="<?php echo set_value('shm_date_of_community_activity'); ?>">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                                <?php echo form_error('shm_date_of_community_activity','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="bootstrap-timepicker">
                                <div class="form-group">
                                    <label><?php echo $welcome->loadPo('Time of community activity'); ?><span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <input name="shm_time_of_community_activity" class="form-control timepicker" type="text" id="shm_time_of_community_activity" value="<?php echo set_value('shm_time_of_community_activity'); ?>" />
                                        <div class="input-group-addon">
                                        <i class="fa fa-clock-o"></i>
                                        </div>
                                    </div>
                                    <?php echo form_error('shm_time_of_community_activity','<span class="text-danger">','</span>'); ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Venue of community activity'); ?><span class="text-danger">*</span></label>
                                <textarea name="shm_venue_of_community_activity" class="form-control" id="shm_venue_of_community_activity" ></textarea>
                                <?php echo form_error('shm_venue_of_community_activity','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>                             
                    </div>
                    <div class="row">
                         <div class="form-group col-md-8">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Help from stakeholde'); ?><span class="text-danger">*</span></label>
                                <textarea name="shm_stakeholder_help" class="form-control" id="shm_stakeholder_help" ></textarea>
                                <?php echo form_error('shm_stakeholder_help','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Healthpost area'); ?><span class="text-danger">*</span></label>
                                <select name="healthpostarea_id" id="healthpostarea_id" class="form-control selectpicker" data-live-search="true">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <?php
                                    foreach ($healthpostarea_list as $helthpost_res) 
                                    {
                                        ?>
                                        <option value="<?php echo $helthpost_res->helthpostarea_id; ?>"><?php echo $helthpost_res->helthpostarea_name; ?></option>
                                        <?php
                                    }
                                    ?>
                                </select>
                                <?php echo form_error('healthpostarea_id','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row"> 
                        <div class="form-group col-md-10">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Images'); ?> <span style="font-size: 12px;">(select one or more than one)</span></label>
                                <input type="file" multiple name="shm_img[]" id="shm_img">
                                <?php echo form_error('shm_img[]','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-12">
                            <div id="previewImg"></div>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Add" ><?php echo $welcome->loadPo('Submit'); ?></button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/stakeHolderMeeting/index/<?php echo $stakeholder_id; ?>"><?php echo $welcome->loadPo('Cancel'); ?></a>
                </div>                    
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    $("#shm_img").on("change", function (e) {
       var files = e.target.files,
       filesLength = files.length;
       for (var i = 0; i < filesLength; i++) {
          // $('#img_valid').css('display', 'none');
           var f = files[i]
           var fileReader = new FileReader();
           fileReader.onload = (function (e) {
              var file = e.target;
                   var img = new Image();
                   img.src = e.target.result;
                   var res = null;
                   img.onload = function() {                                                             
                   $("#previewImg").append("<div style='float:left;border:4px solid #303641;padding:5px;margin:5px;'><img height='80' src='" + e.target.result + "'></div>").insertAfter("#previewImg");
                   }
           });
           fileReader.readAsDataURL(f);
       }
    });


    function getTotalNumberOfMeetingOrder(stackholder_id)
    {   
        var str = 'stackholder_id='+stackholder_id;
        var PAGE = '<?php echo base_url(); ?>admin/stakeHolderMeeting/getTotalNumberOfMeetingOrder';
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {   
                // alert(data);return false;
                if(data != "")
                {
                    $('#shm_order_of_meeting_this_month').val(data);
                }
            } 
        });
    }

    function getTotalNumberOfMeeting(f_val, f_id)
    {   
        if(f_val == 'Yes')
        {
            $('#'+f_id+'_div').css('display', 'block');
            stackholder_id = '<?php echo $this->uri->segment(4); ?>';

            var str = 'stackholder_id='+stackholder_id;
            var PAGE = '<?php echo base_url(); ?>admin/stakeHolderMeeting/getTotalNumberOfMeeting';
            
            jQuery.ajax({
                type :"POST",
                url  :PAGE,
                dataType: "json",
                data : str,
                success:function(data)
                {   
                    if(data.stakeHolder_meeting_res != "")
                    {
                        $('#'+f_id).val(data.stakeHolder_meeting_res);
                    }
                    else
                    {
                        $('#'+f_id).val(data.stakeHolder_meeting_res);
                    }
                } 
            });
        }
        else
        {
            $('#'+f_id+'_div').css('display', 'none');
        }
    }
</script>


