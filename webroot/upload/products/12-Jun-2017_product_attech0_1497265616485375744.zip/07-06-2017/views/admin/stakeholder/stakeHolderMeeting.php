<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Stakeholder Meeting'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Stakeholder Meeting'); ?> </li>
        </ol>
    </section>   
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Stakeholder Meeting Details</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <?php
                        foreach($getAllTabAsPerRole as $role)
                        {
                            if($this->uri->segment(2) == $role->controller_name && $role->userAdd == '1')
                            {
                                ?>
                                    <a href="<?php echo base_url();?>admin/stakeHolderMeeting/addStakeHolderMeeting/<?php echo $this->uri->segment(4); ?>" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Add New'); ?></a>              
                                <?php
                            }
                        }
                    ?>                    
                </div>
            </div>           
            <!-- /.box-header -->
            <div class="box-body">
                <div>
                    <div id="msg_div">
                        <?php echo $this->session->flashdata('message');?>
                    </div>
                </div>
                <table id="example2" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th><?php echo $welcome->loadPo('Added By'); ?></th>
                            <th><?php echo $welcome->loadPo('Stakeholder Name'); ?></th>
                            <th><?php echo $welcome->loadPo('Meeting Date'); ?></th>
                            <th><?php echo $welcome->loadPo('Time(From-to)'); ?></th>
                            <th><?php echo $welcome->loadPo('Location'); ?></th>
                            <th><?php echo $welcome->loadPo('Purpose'); ?></th>
                            <th><?php echo $welcome->loadPo('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if(!empty($stakeholder_res))
                            {
                                foreach($stakeholder_res as $res)
                                {
                                    $levels = explode(',', $res->user_all_level);
                                    $login_user_id = $this->data['session'][0]->user_id;
                                    if(in_array($login_user_id, $levels))
                                    {
                                    ?>
                                    <tr>
                                        <td><?php echo $res->added_by; ?></td>
                                        <td><?php echo $res->stakeholder_name; ?></td>
                                        <td><?php echo $res->shm_meeting_date; ?></td>
                                        <td><?php echo $res->shm_meeting_time_from.' - '.$res->shm_meeting_time_to; ?></td>
                                        <td><?php echo $res->shm_meting_location; ?></td>
                                        <td><?php echo $res->shm_purpose_of_meeting; ?></td>
                                        <td>
                                            <?php
                                                foreach($getAllTabAsPerRole as $role)
                                                {
                                                    if($this->uri->segment(2) == $role->controller_name && $role->userEdit == '1')
                                                    {
                                                        ?>
                                                            <a href="<?php echo base_url();?>admin/stakeHolderMeeting/addStakeHolderMeeting/<?php echo $res->stakeholder_id; ?>/<?php echo $res->shm_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp;                
                                                        <?php
                                                    }
                                                    if($this->uri->segment(2) == $role->controller_name && $role->userDelete == '1')
                                                    {
                                                        ?>
                                                            <a class="confirm" onclick="return delete_stakeHolderMeeting(<?php echo $res->stakeholder_id;?>, <?php echo $res->shm_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>                                      
                                                        <?php
                                                    }
                                                    if($this->uri->segment(2) == $role->controller_name && $role->userView == '1')
                                                    {
                                                        ?>
                                                            &nbsp;&nbsp;<a href="<?php echo base_url();?>admin/stakeHolderMeeting/stakeHolderMeetingView/<?php echo $res->stakeholder_id; ?>/<?php echo $res->shm_id; ?>" title="Edit"><i class="fa fa-eye fa-2x "></i></a>               
                                                        <?php
                                                    }
                                                }
                                            ?>  
                                        </td>
                                    </tr>
                                    <?php
                                    }
                                }
                            }
                            else
                            {
                                ?>
                                <tr>
                                    <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                </tr>
                                <?php
                            }
                            
                        ?>
                       
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function delete_stakeHolderMeeting(stakeholder_id, shm_id)
    {
        bootbox.confirm("Are you sure you want to delete stake holder details",function(confirmed){
            if(confirmed)
            {
                location.href="<?php echo base_url();?>admin/stakeHolderMeeting/delete_stakeHolderMeeting/"+stakeholder_id+'/'+shm_id;
            }
        });
    }    
</script>>