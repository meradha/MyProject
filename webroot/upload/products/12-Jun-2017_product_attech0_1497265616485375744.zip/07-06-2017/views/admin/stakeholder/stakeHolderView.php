<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Stakeholder'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li><a href="<?php echo base_url();?>admin/stakeHolder"><?php echo $welcome->loadPo('Stakeholder'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Stakeholder View'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <!-- <div class="pull-left">
                    <h3 class="box-title">Stakeholder Update</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/stakeHolder" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <?php
                foreach ($stakeHolder_edit as $value) 
                {
                    /*Get Address*/
                    $fromRegAddress = $welcome->getAddressFromLatLng($value->stakeholder_let,$value->stakeholder_long);
                    if($fromRegAddress)
                    $fromRegAddress = $fromRegAddress;
                    else
                    $fromRegAddress = 'No Address Found';

                    ?>
                    <script type="text/javascript">
                    var from_reg = [
                    <?php
                    echo '['.$value->stakeholder_let.','.$value->stakeholder_long.',"'.'<p>StackHolder Name: '.$value->stakeholder_name.
                    '</p><p>Reg Address: '.$fromRegAddress.'</p>'.'","'.base_url('webroot/admin/upload/common_img/pen.png').'"],';
                    ?>
                    ];
                    var resident_address = [
                    <?php
                    echo '['.$value->stakeholder_a_let.','.$value->stakeholder_a_long .',"'.'<p>StackHolder Name: '.$value->stakeholder_name.
                    '</p><p>Resident Address: '.$value->stakeholder_address.'","'.base_url('webroot/admin/upload/common_img/home.png').'"],';
                    ?>
                    ];


                    function initialize() 
                    {
                    var myOptions = {
                    center: new google.maps.LatLng(19.075984, 72.877656),
                    zoom: 10,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                    };
                    var map = new google.maps.Map(document.getElementById("map"), myOptions);
                    setMarkers(map,from_reg);
                    setMarkers(map,resident_address);
                    }

                    function setMarkers(map,locations)
                    {
                    var marker, i;

                    for (i = 0; i < locations.length; i++)
                    {  
                    var lat  = locations[i][0];
                    var long = locations[i][1];
                    var str =  locations[i][2];
                    var custom_icons = locations[i][3];
                    latlngset = new google.maps.LatLng(lat, long);

                    var marker = new google.maps.Marker({  
                    map: map, title: str , position: latlngset,
                    icon: custom_icons
                    });
                    map.setCenter(marker.getPosition())


                    var infowindow = new google.maps.InfoWindow()
                    google.maps.event.addListener(marker,'click', (function(marker,str,infowindow){ 
                    return function(){
                    infowindow.setContent(str);
                    infowindow.open(map,marker);
                    };
                    })(marker,str,infowindow)); 
                    }
                    }
                    </script>
                    <script src="//maps.googleapis.com/maps/api/js?key=AIzaSyA47YEA7hkdrE6PJYe91NawcsmvW9DL3ss&callback=initialize" async defer></script>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <div>
                                <div id="msg_div">
                                    <?php echo $this->session->flashdata('message');?>
                                </div>
                            </div>                     
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Date of mapping'); ?><span class="text-danger">*</span></label>
                                        <div class='input-group'>
                                            <input type="text" class="form-control date_val" disabled name="stakeholder_mapping_date" id="stakeholder_mapping_date" value="<?php echo $value->stakeholder_mapping_date; ?>">
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                        <?php echo form_error('stakeholder_mapping_date','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Name of stakeholder'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="stakeholder_name" class="form-control" type="text" id="stakeholder_name" value="<?php echo $value->stakeholder_name; ?>" />
                                        <?php echo form_error('stakeholder_name','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Contact number'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="stakeholder_phone" class="form-control" min="0" type="number" id="stakeholder_phone" value="<?php echo $value->stakeholder_phone; ?>" />
                                        <?php echo form_error('stakeholder_phone','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                            </div>
                            <div class="row">                         
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Country'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="stakeholder_country_id" class="form-control" type="text" id="stakeholder_country_id" value="India" />
                                        <?php echo form_error('stakeholder_country_id','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('State'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="stakeholder_state_id" class="form-control" type="text" id="stakeholder_state_id" value="Maharashtra" />
                                        <?php echo form_error('stakeholder_state_id','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('City'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="stakeholder_city" class="form-control" type="text" id="stakeholder_city" value="Mumbai" />
                                        <?php echo form_error('stakeholder_city','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>   
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Address'); ?><span class="text-danger">*</span></label>
                                        <textarea disabled name="stakeholder_address" class="form-control" id="stakeholder_address" ><?php echo $value->stakeholder_address; ?></textarea>
                                        <?php echo form_error('stakeholder_address','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>   
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Landmark'); ?><span class="text-danger">*</span></label>
                                        <textarea disabled name="stakeholder_landmark" class="form-control" id="stakeholder_landmark" ><?php echo $value->stakeholder_landmark; ?></textarea>
                                        <?php echo form_error('stakeholder_landmark','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>                      
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Postal Code'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="stakeholder_postal_code" class="form-control" min="0" type="number" id="stakeholder_postal_code" value="<?php echo $value->stakeholder_postal_code; ?>" />
                                        <?php echo form_error('stakeholder_postal_code','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>                        
                            </div>
                            <div class="row">             
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Type of stakeholder'); ?></label>
                                        <select disabled name="stakeholder_type" id="stakeholder_type" class="form-control" onchange="addInputFieldSelectBox(this.value, 'stakeholder_type')">
                                            <option <?php if($value->stakeholder_type == 'Mahila Mandal'){ echo "selected"; } ?> value="Mahila Mandal"><?php echo $welcome->loadPo('Mahila Mandal'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'Religious group/Faith based organisations/Mandirs/Mosque/Church'){ echo "selected"; } ?> value="Religious group/Faith based organisations/Mandirs/Mosque/Church"><?php echo $welcome->loadPo('Religious group/Faith based organisations/Mandirs/Mosque/Church'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'Festive group/Ganesh mandal/navaratri mandal'){ echo "selected"; } ?> value="Festive group/Ganesh mandal/navaratri mandal"><?php echo $welcome->loadPo('Festive group/Ganesh mandal/navaratri mandal'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'Employer'){ echo "selected"; } ?> value="Employer"><?php echo $welcome->loadPo('Employer'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'Youth group'){ echo "selected"; } ?> value="Youth group"><?php echo $welcome->loadPo('Youth group'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'Political leadership(Corporator, MP, MLA, etc.)'){ echo "selected"; } ?> value="Political leadership(Corporator, MP, MLA, etc.)"><?php echo $welcome->loadPo('Political leadership(Corporator, MP, MLA, etc.)'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'SHGs'){ echo "selected"; } ?> value="SHGs"><?php echo $welcome->loadPo('SHGs'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'Anganwadi/ICDS centers'){ echo "selected"; } ?> value="Anganwadi/ICDS centers"><?php echo $welcome->loadPo('Anganwadi/ICDS centers'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'BMC officials/ BMC clinic staff'){ echo "selected"; } ?> value="BMC officials/ BMC clinic staff"><?php echo $welcome->loadPo('BMC officials/ BMC clinic staff'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'Education institute/ library/ research institute'){ echo "selected"; } ?> value="Education institute/ library/ research institute"><?php echo $welcome->loadPo('Education institute/ library/ research institute'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'Sports club'){ echo "selected"; } ?> value="Sports club"><?php echo $welcome->loadPo('Sports club'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'Local NGO'){ echo "selected"; } ?> value="Local NGO"><?php echo $welcome->loadPo('Local NGO'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'Private Clinics/ Hospitals'){ echo "selected"; } ?> value="Private Clinics/ Hospitals"><?php echo $welcome->loadPo('Private Clinics/ Hospitals'); ?></option>
                                            <option <?php if($value->stakeholder_type == 'Other'){ echo "selected"; } ?> value="Other"><?php echo $welcome->loadPo('Other'); ?></option>
                                        </select><br>
                                        <input type="text" style="<?php if($value->stakeholder_type == 'Other'){ echo "display: block"; }else{ echo "display: none"; } ?>" id="stakeholder_type_other" disabled name="stakeholder_type_other" class="form-control" value="" />
                                        <?php echo form_error('stakeholder_type','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Person of correspondence'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="stakeholder_correspondance_person" class="form-control" type="text" id="stakeholder_correspondance_person" value="<?php echo $value->stakeholder_correspondance_person; ?>" />
                                        <?php echo form_error('stakeholder_correspondance_person','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>  
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Healthpost area'); ?><span class="text-danger">*</span></label>
                                        <select disabled name="healthpostarea_id" id="healthpostarea_id" class="form-control selectpicker" data-live-search="true">
                                            <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                            <?php
                                            foreach ($healthpostarea_list as $helthpost_res) 
                                            {
                                                ?>
                                                <option <?php if($helthpost_res->helthpostarea_id == $value->healthpostarea_id){ echo "selected"; } ?> value="<?php echo $helthpost_res->helthpostarea_id; ?>"><?php echo $helthpost_res->helthpostarea_name; ?></option>
                                                <?php
                                            }
                                            ?>
                                            
                                        </select>
                                        <?php echo form_error('healthpostarea_id','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>                       
                            </div>
                           
                            <div class="row">    
                                <div class="form-group col-md-5">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Trust Area'); ?></label><br/>
                                        <?php
                                            $stakeholder_trust_area = explode(',', $value->stakeholder_trust_area);
                                        ?>
                                        <input <?php if(in_array('Social Work / women empowerment / minority issues etc.', $stakeholder_trust_area)){ echo "checked"; } ?> disabled name="stakeholder_trust_area[]" type="checkbox" id="stakeholder_trust_area[]" value="Social Work / women empowerment / minority issues etc." />&nbsp;&nbsp;<?php echo $welcome->loadPo('Social Work / women empowerment / minority issues etc.'); ?><br/>
                                        <input <?php if(in_array('Health / Disabilities', $stakeholder_trust_area)){ echo "checked"; } ?> disabled name="stakeholder_trust_area[]" type="checkbox" id="stakeholder_trust_area[]" value="Health / Disabilities" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Health / Disabilities'); ?><br/>
                                        <input <?php if(in_array('Education', $stakeholder_trust_area)){ echo "checked"; } ?> disabled name="stakeholder_trust_area[]" type="checkbox" id="stakeholder_trust_area[]" value="Education" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Education'); ?><br/>
                                        <input <?php if(in_array('Religious Work', $stakeholder_trust_area)){ echo "checked"; } ?> disabled name="stakeholder_trust_area[]" type="checkbox" id="stakeholder_trust_area[]" value="Religious Work" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Religious Work'); ?><br/>
                                        <input <?php if(in_array('Sports', $stakeholder_trust_area)){ echo "checked"; } ?> disabled name="stakeholder_trust_area[]" type="checkbox" id="stakeholder_trust_area[]" value="Sports" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Sports'); ?><br/>
                                        <input <?php if(in_array('Politics', $stakeholder_trust_area)){ echo "checked"; } ?> disabled name="stakeholder_trust_area[]" type="checkbox" id="stakeholder_trust_area[]" value="Politics" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Politics'); ?><br/>
                                        <input <?php if(in_array('Employment opportunities', $stakeholder_trust_area)){ echo "checked"; } ?> disabled name="stakeholder_trust_area[]" type="checkbox" id="stakeholder_trust_area[]" value="Employment opportunities" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Employment opportunities'); ?><br/>
                                        <input <?php if(in_array('Other', $stakeholder_trust_area)){ echo "checked"; } ?> disabled name="stakeholder_trust_area[]" type="checkbox" id="stakeholder_trust_area" value="Other" onclick="addInputFieldCheckBox(this.value, 'stakeholder_trust_area')"  />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                        <input type="text" style="<?php if(in_array('Other', $stakeholder_trust_area)){ echo "display: block"; }else{ echo "display: none"; } ?> " id="stakeholder_trust_area_other" disabled name="stakeholder_trust_area_other" class="form-control" value="<?php echo $value->stakeholder_trust_area_other; ?>" />
                                        <?php echo form_error('stakeholder_trust_area[]','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                                <div class="form-group col-md-5">
                                    <div class="input text">
                                        <?php
                                        $stakeholder_focus_population = explode(',', $value->stakeholder_focus_population);
                                        ?>
                                        <label><?php echo $welcome->loadPo('Focus Population / Target Population'); ?></label><br/>
                                        <input <?php if(in_array('Male', $stakeholder_focus_population)){ echo "checked"; } ?> disabled name="stakeholder_focus_population[]" type="checkbox" id="stakeholder_focus_population[]" value="Male" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Male'); ?><br/>
                                        <input <?php if(in_array('Women', $stakeholder_focus_population)){ echo "checked"; } ?> disabled name="stakeholder_focus_population[]" type="checkbox" id="stakeholder_focus_population[]" value="Women" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Women'); ?><br/>
                                        <input <?php if(in_array('Children', $stakeholder_focus_population)){ echo "checked"; } ?> disabled name="stakeholder_focus_population[]" type="checkbox" id="stakeholder_focus_population[]" value="Children" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Children'); ?><br/>
                                        <input <?php if(in_array('LGBTQ', $stakeholder_focus_population)){ echo "checked"; } ?> disabled name="stakeholder_focus_population[]" type="checkbox" id="stakeholder_focus_population[]" value="LGBTQ" />&nbsp;&nbsp;<?php echo $welcome->loadPo('LGBTQ'); ?><br/>
                                        <input <?php if(in_array('Workers', $stakeholder_focus_population)){ echo "checked"; } ?> disabled name="stakeholder_focus_population[]" type="checkbox" id="stakeholder_focus_population[]" value="Workers" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Workers'); ?><br/>
                                        <input <?php if(in_array('Health condition specific population(TB HIV)', $stakeholder_focus_population)){ echo "checked"; } ?> disabled name="stakeholder_focus_population[]" type="checkbox" id="stakeholder_focus_population[]" value="Health condition specific population(TB HIV)" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Health condition specific population(TB, HIV)'); ?><br/>
                                        <input <?php if(in_array('General Population', $stakeholder_focus_population)){ echo "checked"; } ?> disabled name="stakeholder_focus_population[]" type="checkbox" id="stakeholder_focus_population[]" value="General Population" />&nbsp;&nbsp;<?php echo $welcome->loadPo('General Population'); ?><br/>
                                        <input <?php if(in_array('Elderly', $stakeholder_focus_population)){ echo "checked"; } ?> disabled name="stakeholder_focus_population[]" type="checkbox" id="stakeholder_focus_population[]" value="Elderly" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Elderly'); ?><br/>
                                        <input <?php if(in_array('Other', $stakeholder_focus_population)){ echo "checked"; } ?> disabled name="stakeholder_focus_population[]" type="checkbox" id="stakeholder_focus_population" value="Other" onclick="addInputFieldCheckBox(this.value, 'stakeholder_focus_population')" />&nbsp;&nbsp;<?php echo $welcome->loadPo('Other'); ?><br/>
                                        <input type="text" style="<?php if(in_array('Other', $stakeholder_focus_population)){ echo "display: block"; }else{ echo "display: none"; } ?> " id="stakeholder_focus_population_other" disabled name="stakeholder_focus_population_other" class="form-control" value="<?php echo $value->stakeholder_focus_population_other; ?>" />
                                        <?php echo form_error('stakeholder_focus_population[]','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                            </div>
                           
                            <div class="row">   
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Area'); ?></label>
                                        <select disabled name="stakeholder_area" id="stakeholder_area" class="form-control">
                                            <option <?php if($value->stakeholder_area == 'High case burden area'){ echo "selected"; } ?> value="High case burden area"><?php echo $welcome->loadPo('High case burden areas'); ?></option>
                                            <option <?php if($value->stakeholder_area == 'Low case burden area'){ echo "selected"; } ?> value="Low case burden area"><?php echo $welcome->loadPo('Low case burden areas'); ?></option>
                                        </select>
                                        <?php echo form_error('stakeholder_area','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>   
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Working since(in years)'); ?><span class="text-danger">*</span></label>
                                        <input disabled name="stakeholder_working_since" class="form-control" type="text" id="stakeholder_working_since" value="<?php echo $value->stakeholder_working_since; ?>" />
                                        <?php echo form_error('stakeholder_working_since','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>   
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Any Remarks'); ?><span class="text-danger">*</span></label>
                                        <textarea disabled name="stakeholder_any_remarks" class="form-control" id="stakeholder_any_remarks" ><?php echo $value->stakeholder_any_remarks; ?></textarea>
                                        <?php echo form_error('stakeholder_any_remarks','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div> 
                            </div>
                            <div class="row">   
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Power structure'); ?></label>
                                        <select disabled name="stakeholder_power_structure" id="stakeholder_power_structure" class="form-control">
                                            <option value="">-- select --</option>
                                            <option <?php if($value->stakeholder_power_structure == 'High power, High interest'){ echo "selected"; } ?> value="High power, High interest"><?php echo $welcome->loadPo('High power, High interest'); ?></option>
                                            <option <?php if($value->stakeholder_power_structure == 'High power, Low interest'){ echo "selected"; } ?> value="High power, Low interest"><?php echo $welcome->loadPo('High power, Low interest'); ?></option>
                                            <option <?php if($value->stakeholder_power_structure == 'Low power, High interest'){ echo "selected"; } ?> value="Low power, High interest"><?php echo $welcome->loadPo('Low power, High interest'); ?></option>
                                            <option <?php if($value->stakeholder_power_structure == 'Low power, Low interest'){ echo "selected"; } ?> value="Low power, Low interest"><?php echo $welcome->loadPo('Low power, Low interest'); ?></option>
                                        </select>
                                        <?php echo form_error('stakeholder_power_structure','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>          
                                <div class="form-group col-md-4">
                                    <div class="input text">
                                        <label><?php echo $welcome->loadPo('Status'); ?></label>
                                        <select disabled name="stakeholder_status" id="stakeholder_status" class="form-control">
                                            <option <?php if($value->stakeholder_status == '1'){ echo "selected"; } ?> value="1"><?php echo $welcome->loadPo('Responsive'); ?></option>
                                            <option <?php if($value->stakeholder_status == '0'){ echo "selected"; } ?> value="0"><?php echo $welcome->loadPo('Unresponsive'); ?></option>
                                        </select>
                                        <?php echo form_error('stakeholder_status','<span class="text-danger">','</span>'); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                           <div class="col-md-12">
                              <div id="map" style="height:500px;width: 100%;">
                              </div>
                           </div>
                        </div>
                        <!-- /.box-body -->      
                        <div class="box-footer">
                            <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/stakeHolder"><?php echo $welcome->loadPo('Cancel'); ?></a>
                        </div>
                    <?php
                }
                ?>   
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->