<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title><?php echo $welcome->loadPo('Saksham Jan Urja'); ?></title>
		<link rel="shortcut icon" href="<?php echo base_url(); ?>webroot/frontend/img/uedu/icon-16x16.png">
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href="<?php echo base_url();?>webroot/admin/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>webroot/admin/css/bootstrap-select.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="<?php echo base_url();?>webroot/admin/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Ionicons -->
        <link href="<?php echo base_url();?>webroot/admin/css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- Morris chart -->
        <link href="<?php echo base_url();?>webroot/admin/css/morris/morris.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="<?php echo base_url();?>webroot/admin/css/AdminLTE.css" rel="stylesheet" type="text/css" />
        <!-- jQuery 2.0.2 -->
       <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js" type="text/javascript"></script>
       <!-- Bootstrap time Picker -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>webroot/admin/js/plugins/timepicker/bootstrap-timepicker.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>webroot/admin/calendar/jquery-ui.css"> 
        <!-- ********** Amit *********** -->
         <link href='<?php echo base_url();?>webroot/admin/calfile/assets/css/fullcalendar.css' rel='stylesheet' />
         <link href='<?php echo base_url();?>webroot/admin/calfile/assets/css/fullcalendar.print.css' rel='stylesheet' media='print' /> 
    </head>
    <body class="skin-blue">
        <!-- header logo: style can be found in header.less -->
        <header class="header">
            <a href="#" class="logo">
                <!-- Add the class icon to your logo image or logo icon to add the margining -->
               <img src="<?php echo base_url();?>webroot/admin/img/logo.png" height="50px" class="img-circle" alt="User Image" />
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top" role="navigation">
                <!-- Sidebar toggle button-->
                <a href="#" class="navbar-btn sidebar-toggle" data-toggle="offcanvas" role="button">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </a>
                <div class="navbar-right">
                    <ul class="nav navbar-nav">
                        <!-- User Account: style can be found in dropdown.less -->
                        <li class="dropdown user user-menu">
                           <form action="" method="POST">
                                <?php $sess=$this->session->all_userdata(); ?>
                                <select class="form-control" name="lng" onchange="this.form.submit()">
                                   <option value="eng" <?php if(isset($sess['lng'])){ if($sess['lng'] == 'eng'){ echo "selected"; } } ?> >English</option>
                                   <option value="hi" <?php if(isset($sess['lng'])){ if($sess['lng'] == 'hi'){ echo "selected"; } } ?> ><?php echo $welcome->loadPo('Hindi'); ?></option>
                                </select>
                            </form>
                        </li>
                        <li class="dropdown user user-menu">
                            <a href="<?php echo base_url();?>admin/login/profile/<?php echo $this->user_id;?>">
                                <i class="glyphicon glyphicon-user"></i>
                                <span><?php echo $this->user;?></span>
                            </a>
                        </li>
                        <li class="dropdown user user-menu">
                            <a href="<?php echo base_url();?>admin/login/logout">
                                <i class="fa fa-power-off" aria-hidden="true"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>