<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			<?php echo $welcome->loadPo('Referral Linkages'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?> </a></li>
            <li><a href="<?php echo base_url();?>admin/sakshamPravah"><?php echo $welcome->loadPo('Referral Linkages'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Referral Linkages Add'); ?></li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
               <!--  <div class="pull-left">
                    <h3 class="box-title">Referral Linkages Add</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/sakshamPravah" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Back'); ?></a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <div id="msg_div">
                            <?php echo $this->session->flashdata('message');?>
                        </div>
                    </div>                     
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Owner Name'); ?><span class="text-danger">*</span></label>
                                <input name="sp_owner_name" class="form-control" type="text" id="sp_owner_name" value="<?php echo set_value('sp_owner_name'); ?>" />
                                <?php echo form_error('sp_owner_name','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Center Name'); ?><span class="text-danger">*</span></label>
                                <input name="sp_name" class="form-control" type="text" id="sp_name" value="<?php echo set_value('sp_name'); ?>" />
                                <?php echo form_error('sp_name','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Email'); ?><span class="text-danger">*</span></label>
                                <input name="sp_email" class="form-control" type="email" id="sp_email" value="<?php echo set_value('sp_email'); ?>" />
                                <?php echo form_error('sp_email','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>                       
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Phone'); ?><span class="text-danger">*</span></label>
                                <input name="sp_phone" class="form-control" min="0" type="number" id="sp_phone" value="<?php echo set_value('sp_phone'); ?>" />
                                <?php echo form_error('sp_phone','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Mobile'); ?><span class="text-danger">*</span></label>
                                <input name="sp_mobile" class="form-control" min="0" type="number" id="sp_mobile" value="<?php echo set_value('sp_mobile'); ?>" />
                                <?php echo form_error('sp_mobile','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('address'); ?><span class="text-danger">*</span></label>
                                <textarea name="sp_address" class="form-control" id="sp_address" ></textarea>
                                <?php echo form_error('sp_address','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div> 
                    </div>
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Country'); ?><span class="text-danger">*</span></label>
                                <select  name="sp_country_id" class="form-control" id="sp_country_id" onchange="getStateListByCountryID(this.value)" >
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <?php 
                                    foreach ($country_list as $c_list)
                                    {
                                        ?>
                                        <option value="<?php echo $c_list->country_id; ?>"><?php echo $c_list->country_name; ?></option>
                                        <?php
                                    }
                                    ?>
                                </select>
                                <?php echo form_error('sp_country_id','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('State'); ?><span class="text-danger">*</span></label>
                                 <select  name="sp_state_id" class="form-control" id="sp_state_id" ?>
                                <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                </select>
                                <?php echo form_error('sp_state_id','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('City'); ?><span class="text-danger">*</span></label>
                                <input name="sp_city" class="form-control" type="text" id="sp_city" value="<?php echo set_value('sp_city'); ?>" />
                                <?php echo form_error('sp_city','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>                       
                    </div>
                    <div class="row">    
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Postal Code'); ?><span class="text-danger">*</span></label>
                                <input name="sp_postal_code" class="form-control" min="0" type="number" id="sp_postal_code" value="<?php echo set_value('sp_postal_code'); ?>" />
                                <?php echo form_error('sp_postal_code','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>          
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Status'); ?></label>
                                <select name="sp_status" id="sp_status" class="form-control">
                                    <option value="">-- <?php echo $welcome->loadPo('Select'); ?> --</option>
                                    <option value="1"><?php echo $welcome->loadPo('Responsive'); ?></option>
                                    <option value="0"><?php echo $welcome->loadPo('Unresponsive'); ?></option>
                                </select>
                                <?php echo form_error('sp_status','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Add" ><?php echo $welcome->loadPo('Submit'); ?></button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/sakshamPravah"><?php echo $welcome->loadPo('Cancel'); ?></a>
                </div>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function  getStateListByCountryID(country_id)
    {
        var str = 'country_id='+country_id;
        var PAGE = '<?php echo base_url(); ?>admin/sakshamPravah/getStateListByCountryID';
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {        
                if(data != "")
                {
                    $('#sp_state_id').html(data);
                }
                else
                {
                    $('#sp_state_id').html('<option value="">-- Select --</option>');
                }
            } 
        });
    }
</script>