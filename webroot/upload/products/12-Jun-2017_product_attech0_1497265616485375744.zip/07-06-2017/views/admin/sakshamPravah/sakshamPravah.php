<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Referral Linkages'); ?> <small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> <?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Referral Linkages'); ?></li>
        </ol>
    </section>   
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
               <!--  <div class="pull-left">
                    <h3 class="box-title">Referral Linkages Details</h3>
                </div> -->
                <div class="pull-right box-tools">
                    <?php
                        foreach($getAllTabAsPerRole as $role)
                        {
                            if($this->uri->segment(2) == $role->controller_name && $role->userAdd == '1')
                            {
                                ?>
                                    <a href="<?php echo base_url();?>admin/sakshamPravah/addSakshamPravah" class="btn btn-info btn-sm"><?php echo $welcome->loadPo('Add New'); ?></a>              
                                <?php
                            }
                        }
                    ?>                    
                </div>
            </div>           
            <!-- /.box-header -->
            <div class="box-body">
                <div>
                    <div id="msg_div">
                        <?php echo $this->session->flashdata('message');?>
                    </div>
                </div>
                <table id="example2" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th><?php echo $welcome->loadPo('Owner Name'); ?></th>
                            <th><?php echo $welcome->loadPo('Referral Linkages Name'); ?></th>
                            <th><?php echo $welcome->loadPo('Email'); ?></th>
                            <th><?php echo $welcome->loadPo('Phone'); ?></th>
                            <th><?php echo $welcome->loadPo('Address'); ?></th>
                            <th><?php echo $welcome->loadPo('City'); ?></th>
                            <th><?php echo $welcome->loadPo('Postal Code'); ?></th>
                            <th><?php echo $welcome->loadPo('Number of Patient registered'); ?></th>
                            <th><?php echo $welcome->loadPo('Status'); ?></th>
                            <th><?php echo $welcome->loadPo('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $user_role_id = $this->data['session'][0]->user_role_id;
                            $user_all_level = $this->data['session'][0]->user_all_level;
                            $user_id = $this->data['session'][0]->user_id;

                            if(!empty($sakshamPravah_res))
                            {
                                foreach($sakshamPravah_res as $res)
                                {
                                    ?>
                                    <tr>
                                        <td><?php echo $res->sp_owner_name; ?></td>
                                        <td><?php echo $res->sp_name; ?></td>
                                        <td><?php echo $res->sp_email; ?></td>
                                        <td><?php echo $res->sp_mobile; ?></td>
                                        <td><?php echo $res->sp_address; ?></td>
                                        <td><?php echo $res->sp_city; ?></td>
                                        <td><?php echo $res->sp_postal_code; ?></td>
                                        <td>
                                            <?php
                                                $patient_count_arr = $this->sakshampravah_model->getTotalNumberOfPatientRegister($res->sp_id);
                                                $p_count = 0;
                                                foreach ($patient_count_arr as $value) 
                                                {
                                                    $u_all_arr = explode(',', $value->user_all_level);
                                                    if(in_array($user_id, $u_all_arr))
                                                    {
                                                        $p_count++;
                                                    }
                                                    ?>
                                                    <?php
                                                }
                                                echo $p_count;
                                            ?>
                                        </td>
                                        <td  width="10%">
                                            <?php
                                                if($res->sp_status == '1')
                                                {
                                                    ?>
                                                    <span class="text-success"><?php echo $welcome->loadPo('Responsive'); ?></span>
                                                    <?php
                                                }
                                                else
                                                {
                                                    ?>
                                                    <span class="text-danger"><?php echo $welcome->loadPo('Unresponsive'); ?></span>
                                                    <?php
                                                }
                                            ?>
                                        </td>
                                        <td width="20%">
                                            <?php
                                                foreach($getAllTabAsPerRole as $role)
                                                {
                                                    if($this->uri->segment(2) == $role->controller_name && $role->userEdit == '1')
                                                    {
                                                        ?>
                                                            <a href="<?php echo base_url();?>admin/sakshamPravah/addSakshamPravah/<?php echo $res->sp_id; ?>" title="Edit"><i class="fa fa-edit fa-2x "></i></a>&nbsp;&nbsp;                
                                                        <?php
                                                    }
                                                    if($this->uri->segment(2) == $role->controller_name && $role->userDelete == '1')
                                                    {
                                                        ?>
                                                            <a class="confirm" onclick="return delete_sakshamPravah(<?php echo $res->sp_id;?>);" href="" title="Remove"><i class="fa fa-trash-o fa-2x text-danger" data-toggle="modal" data-target=".bs-example-modal-sm"></i></a>                                      
                                                        <?php
                                                    }
                                                }
                                            ?> &nbsp;&nbsp;
                                            <a href="<?php echo base_url();?>admin/sakshamPravah/sakshamPravahView/<?php echo $res->sp_id; ?>" title="Edit"><i class="fa fa-eye fa-2x "></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            }
                            else
                            {
                                ?>
                                <tr>
                                    <td colspan="10"><?php echo $welcome->loadPo('No records found'); ?>...</td>
                                </tr>
                                <?php
                            }
                            
                        ?>
                       
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function delete_sakshamPravah(sp_id)
    {
        bootbox.confirm("Are you sure you want to delete referral linkages details",function(confirmed){
            if(confirmed)
            {
                location.href="<?php echo base_url();?>admin/sakshamPravah/delete_sakshamPravah/"+sp_id;
            }
        });
    }    
</script>>