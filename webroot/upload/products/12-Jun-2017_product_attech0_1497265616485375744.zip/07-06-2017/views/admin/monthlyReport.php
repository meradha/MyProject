
<?php
$user_role_id = $this->data['session'][0]->user_role_id;
$user_all_level = $this->data['session'][0]->user_all_level;
$user_id = $this->data['session'][0]->user_id;
?>
<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>    
            <?php echo $welcome->loadPo('Monthly Report'); ?><small><?php echo $welcome->loadPo('Control panel'); ?></small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i><?php echo $welcome->loadPo('Home'); ?></a></li>
            <li class="active"><?php echo $welcome->loadPo('Monthly Report'); ?></li>
        </ol>
    </section>
    <div>
        <div id="msg_div">
            <?php echo $this->session->flashdata('message');?>
        </div>
    </div>
   
    <!-- Main content -->
    <section class="content">
        <div class="box box-primary">
           <!--  <div class="box-header">
                <div class="pull-left">
                    <h3 class="box-title"><?php echo $welcome->loadPo('Monthly Summary Sheet'); ?></h3>
                </div>
            </div> -->
            <div class="box-body">
                <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                    <div class="row">
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label><?php echo $welcome->loadPo('Month'); ?><span class="text-danger">*</span></label>
                                <select name="month" id="month" class="form-control">
                                    <!-- <option value="">-- select --</option> -->
                                    <option <?php if($month == '01'){ echo 'selected'; } ?> value='01'><?php echo $welcome->loadPo('Janaury'); ?></option>
                                    <option <?php if($month == '02'){ echo 'selected'; } ?> value='02'><?php echo $welcome->loadPo('February'); ?></option>
                                    <option <?php if($month == '03'){ echo 'selected'; } ?> value='03'><?php echo $welcome->loadPo('March'); ?></option>
                                    <option <?php if($month == '04'){ echo 'selected'; } ?> value='04'><?php echo $welcome->loadPo('April'); ?></option>
                                    <option <?php if($month == '05'){ echo 'selected'; } ?> value='05'><?php echo $welcome->loadPo('May'); ?></option>
                                    <option <?php if($month == '06'){ echo 'selected'; } ?> value='06'><?php echo $welcome->loadPo('June'); ?></option>
                                    <option <?php if($month == '07'){ echo 'selected'; } ?> value='07'><?php echo $welcome->loadPo('July'); ?></option>
                                    <option <?php if($month == '08'){ echo 'selected'; } ?> value='08'><?php echo $welcome->loadPo('August'); ?></option>
                                    <option <?php if($month == '09'){ echo 'selected'; } ?> value='09'><?php echo $welcome->loadPo('September'); ?></option>
                                    <option <?php if($month == '10'){ echo 'selected'; } ?> value='10'><?php echo $welcome->loadPo('October'); ?></option>
                                    <option <?php if($month == '11'){ echo 'selected'; } ?> value='11'><?php echo $welcome->loadPo('November'); ?></option>
                                    <option <?php if($month == '12'){ echo 'selected'; } ?> value='12'><?php echo $welcome->loadPo('December'); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <div class="input text">
                                <label>&nbsp<br><br></label>
                                <button class="btn btn-primary" type="submit" name="submit" id="submit" value="submit"><?php echo $welcome->loadPo('Submit'); ?></button>
                            </div>
                        </div>
                    </div>
                    <hr>
                </form>
                <div class="row col-md-12">
                    <h3><u><?php echo $welcome->loadPo('Monthly stakeholder meeting summary'); ?></u></h3>
                </div>
                <div class="row">
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total Number of stakeholders mapped in this month'); ?></label><br><br>
                            <input disabled class="form-control" type="text" value="<?php echo $mapped_stakeholder; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total Number of stakeholders met in this month'); ?></label><br><br>
                            <input disabled class="form-control" type="text" value="<?php echo $stakeholder_meetings; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Out of above, stakeholders met in the previous month as well'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $stakeholder_meetings_prev; ?>" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('New stakeholders met in this month'); ?></label><br><br>
                            <input disabled class="form-control" type="text" value="<?php echo $stakeholder_meetings; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total Number of stakeholders meeting cunducted'); ?></label><br><br>
                            <input disabled class="form-control" type="text" value="<?php echo $stakeholder_meetings; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total Number of stakeholders responsive in this month'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $stakeholder_responsive; ?>" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total Number of stakeholders un-responsive in this month'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $stakeholder_un_responsive; ?>" />
                        </div>
                    </div>
                </div>
                <div class="row col-md-12">
                    <h3><u><?php echo $welcome->loadPo('Total Number of community events conducted'); ?></u></h3>
                </div>
                <div class="row">
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total Number of community events/community meeting conducted'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $community_events; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total Number of community events/community meeting in high case burden areas'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $community_events_low_case; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total Number of community events/community meeting in low case burden areas'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $community_events_high_case; ?>" />
                        </div>
                    </div>
                </div>
                <div class="row col-md-12">
                    <h3><u><?php echo $welcome->loadPo('Referral Details'); ?></u></h3>
                </div>
                <div class="row">
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total self referrals in this month'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $self_referral; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total community referrals in this month'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $community_referral; ?>" />
                        </div>
                    </div>
                </div>
                <div class="row col-md-12">
                    <h3><u><?php echo $welcome->loadPo('Patient details indicator'); ?></u></h3>
                </div>
                <div class="row">
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total number of CAT-1 and CAT-2 patients found positive this month'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $cat1_cat2_patient_positive; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total number of CAT-1 and CAT-2 patients registered for counselling services for this month'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $cat1_cat2_patient_counselling_service; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total number of caregivers registered in this month'); ?></label><br><br>
                            <input disabled class="form-control" type="text" value="<?php echo $total_caregivers; ?>" />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total number of DR TB patients found positive in this month'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $total_dr_tb_positive_patient; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total number of DR TB patients linked to counsellors in this month'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $total_dr_tb_link_to_counsellor; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total number of follow-up counselling sessions provided to the registered patients this month'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $total_follow_up; ?>" />
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Total number of patients countinuing on treatment out of total number of patients registered with Saksham'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $total_follow_up; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Number of treatment interrupters brought back on treatment out of total number of patients who interrupted'); ?></label>
                            <input disabled class="form-control" type="text" value="<?php echo $total_follow_up_iteruption; ?>" />
                        </div>
                    </div>
                    <div class="form-group col-md-4">
                        <div class="input text">
                            <label><?php echo $welcome->loadPo('Number of Loss to follow up patients'); ?></label><br><br><br>
                            <input disabled class="form-control" type="text" value="<?php echo $total_follow_up_iteruption_lost; ?>" />
                        </div>
                    </div>
                </div>
                
                <div class="clearfix"></div><br/><br/><br/>
            </div>
        </div>
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    $(function() {
        $( "#start_date" ).datepicker({
            dateFormat : 'yy-mm-dd',
            changeMonth : true,
            changeYear : true,           
        });
    });
    function setEndDate(str)
    {
        $( "#end_date" ).datepicker({
            minDate:str,
            dateFormat : 'yy-mm-dd',
            changeMonth : true,
            changeYear : true,           
        });
    }
</script>