<!DOCTYPE html>
<html>
<head>
    <title>Saksham</title>
</head>
<body>
    <center>
        <div>
            <div id="msg_div">
                <?php echo $this->session->flashdata('message');?>
            </div>
        </div>
    </center>
</body>
</html>